# Predaja: prenova glave profila igralca (možnost 1a »Urejeno«)

## 1. Pregled

Celovita prenova **zgornjega dela strani profila igralca** (`/igralci/:id`) v Turnirku: od povezave »← Lestvica« do vključno vrstice s številkami (odigrane tekme, zmage–porazi, uspešnost, zadnja tekma). Vse pod tem (graf ratinga, forma, nasprotniki, seznam tekem …) ostane **nespremenjeno**.

Zakaj: današnja glava ima dve črni znački uvrstitve, ki se tepeta med seboj, majhno sliko (136 px), podatke »nametane« v desni kolofon in preveč drobnega besedila ob ratingu. Nova glava ima tri jasne sklope:

1. **Kdo je** – velik portret, ime, klub, roka, uvrstitev (ena vrstica članov, po potrebi ena vrstica mladinskega pasu, skupaj s palico »boljši od N %«).
2. **Kolikšen je** – modra ploskev Turnirko ratinga z dvema primerjavama pod njo (klubsko povprečje, točke do naslednjega mesta).
3. **Kaj je odigral** – vrstica štirih stolpcev s številkami in dvema palicama (turnirske/ligaške, zmage/porazi).

Dejanja (Sezonski zapisnik / Spremljaj / Uredi sliko) so zgoraj desno: eno glavno dejanje + meni »⋯«.

Uporabnik je izbral **možnost 1a**. Možnost 1b (Karton) je v projektu samo kot zavrnjena alternativa; ne implementiraj je.

## 2. O datotekah v paketu

Datoteke v `reference/` so **oblikovalska referenca v HTML**: prototip videza in obnašanja, **ne produkcijska koda**. Naloga je **ponovno zgraditi glavo v obstoječem vmesniku** (React + TypeScript + navaden CSS z BEM razredi v `vmesnik/src/slog.css`, po `DESIGN.md`) – ne kopirati HTML-ja. Prototip uporablja inline slog in Google Fonts; v aplikaciji uporabi CSS spremenljivke in lokalne pisave (fontsource), ki že obstajajo.

| Pot | Vsebina |
|---|---|
| `README.md` | ta dokument |
| `screenshots/00-trenutno-stanje-pred-prenovo.png` | današnja glava (za primerjavo, ne za posnemanje) |
| `screenshots/01…05-*.png` | celoten posnetek umetnine makete (1280 oz. 390 px, DPR 1) |
| `screenshots/ref/ref-*.png` | **referenčni posnetki, obrezani točno na element glave** – z njimi primerjaš (poglavje 12) |
| `geometrija.json` | izmerjene pozicije in velikosti vseh besedil/blokov v maketi (poglavje 12) |
| `reference/Glava A.dc.html` | prototip (props `stanje`: `moj`/`gost`, `naprava`: `namizje`/`telefon`, `meniOdprto`) |
| `reference/Glava A - posnetki.dc.html` | stran, iz katere so posnetki |
| `reference/support.js`, `reference/assets/miha-fatur.png` | zagon prototipa in fotografija (povečan izrez, ~134 px vir) |

Prototip se odpre prek HTTP strežnika (npr. `npx serve reference`), ne prek `file://`.

## 3. Zvestoba

**Visoka (hi-fi).** Barve, pisave, velikosti, razmiki in besedila so končni. Ujemanje s posnetki mora biti **pikselsko** (poglavje 12). Mere v tem dokumentu so prepisane iz prototipa, zato jih **ne »poravnavaj« na ritem 8 px** (ista logika kot v `DESIGN.md` 4b: 20, 14, 12, 10, 6 px so namerni).

## 4. Pravila, ki veljajo (iz `DESIGN.md` in `PRODUCT.md`)

- Radij `0` povsod, brez senc, brez gradientov, brez ikon (puščice in ⋯ so znaki v besedilu), brez emojijev.
- Tri družine: Bricolage Grotesque (`--pisava-display`), Karla (`--pisava-telo`), IBM Plex Mono (`--pisava-mono`). Teža naslova 800, nadnaslova 200.
- Barve samo iz spremenljivk (poglavje 9). V CSS ne piši hex vrednosti.
- Vse klikljivo ≥ 44 × 44 px.
- Besedilo je slovensko, kratko, zapisniško. **Besedil ne spreminjaj** (razen kjer jih poda podatek).
- Strežnik odloča o pravicah; vmesnik le skrije (nespremenjeno obnašanje `smemZasebno`, `jeMoj`, `imaSirokoSpremljanje`).
- Ne spreminjaj zaledja, DTO-jev ali API-ja. Vsi prikazani podatki že obstajajo v `ProfilDto` / `ProfilZasebnoDto`.
- Osebni podatki ostanejo izven javnega pogleda (nič novega ne dodajaš).

## 5. Kaj se zgodi v `ProfilStran.tsx`

Zamenjaš blok od `<div>` z `povezava-nazaj` do konca `<div className="stran-glava">` (tik pred `<GrafRatinga …>`). Priporočilo: **izloči čisto prikazno komponento** `vmesnik/src/komponente/ProfilGlava.tsx`, ki dobi že pripravljene vrednosti kot props (kar omogoča preverjalni harness, poglavje 12). Logika (`useQuery`, `izracunajOkolico`, `mestoVPasu`, `smemZasebno`, spremljanje, okno slike) ostane v `ProfilStran`.

### Preslikava podatkov

| Prikaz | Vir (že obstaja) |
|---|---|
| Ime / priimek | `razbijIme(p.glava.polnoIme)` (ime = nadnaslov 200, priimek = naslov 800) |
| Klub | `p.glava.klub ?? 'brez kluba'` |
| Roka | `p.glava.igralnaRoka` → »Levičar« / »Desničar« (kot zdaj) |
| Oznaka »Tvoj profil« | `jeMoj` |
| Fotografija | `slikaProfila` (`useSlikeIgralcev`) → `urlProfilneSlike(zgostitev, 'VELIKA')` |
| Uvrstitev 1 (člani) | `p.uvrstitev.mesto` · `skupajIgralcev` · oznaka iz `imeLestvice(p.uvrstitev)` brez predpone »Lestvica « (npr. »Moški · Člani«) |
| Palica in »Boljši od N %« | `p.uvrstitev.percentil` (palica = N % širine) |
| Uvrstitev 2 (pas) | `vPasu` (`mestoVPasu`) + `p.uvrstitev.spol` → »Moški · U21« / »Ženske · U21«. Samo če `vPasu && spol !== null` |
| Rating | `p.glava.rating ?? '—'` |
| »+17 / 30 dni« in »vrh 1600« | `z?.forma.spremembaElo30dni`, `z?.forma.najvisjiRating` – **točno obstoječa logika** (vključno z »brez tekem v 30 dneh«); samo če obstaja `z` |
| Klubsko povprečje + razlika | `p.uvrstitev.klubskoPovprecje`, razlika kot zdaj (`+`/`−`, zelena `--poz` / rjasta `--neg`) |
| »Do N. mesta« | `okolica.mestoNad`, `okolica.razlikaNad` + `sklonTock` |
| Odigrane tekme | `p.pregled.odigrane`; palica: `turnirskih` (modra) / `ligaskih` (črna) |
| Zmage – porazi | `${zmage}–${porazi}` (en dash), palica: `zmage/odigrane` zelena, ostalo rjasto |
| Uspešnost | `${p.pregled.odstotekZmag} %` (z navadnim presledkom pred %) |
| Zadnja tekma | `datum(p.tekme[0].datum)` → `25. 10. 2026`; »—« če ni |

Iz glave **odpade** (podatek je zdaj drugje): kolofon »Tekme na turnirjih / Ligaške tekme« (zdaj legenda pod palico odigranih tekem), »Zadnja tekma« (zdaj stolpec v vrstici številk), blok `.rating-blok` + `.kolofon` v stari obliki, dve črni znački `profil__mesto-znacka`, `naslov-z-logotipom` okoli naslova profila.

## 6. Zgradba (JSX skica)

```tsx
<div className="profil-glava">
  <div className="profil-glava__vrstica">
    <Link className="povezava-nazaj" …>← …</Link>            {/* obstoječa logika izvora */}
    <div className="profil-glava__dejanja"> glavno dejanje + <meni ⋯> </div>
  </div>

  <div className="profil-glava__glavno">
    {slika && <div className="profil-glava__slika"><img … /></div>}

    <div className="profil-glava__oseba" style={{ '--znakov': priimek.length }}>
      <h1 className="profil-glava__ime">
        <span className="profil-glava__ime-nad">{ime}</span>
        <span className="profil-glava__ime-glavni">{priimek}</span>
      </h1>
      <div className="profil-glava__meta"> klub · roka · [Tvoj profil] </div>
      {uvrstitev && <div className="profil-glava__uvrstitev"> … </div>}
    </div>

    <div className="profil-glava__rating-stolpec">
      <div className="profil-glava__rating"> … </div>
      <div className="kolofon profil-glava__primerjava"> 2 vrstici </div>
    </div>
  </div>

  <div className="profil-glava__povzetek"> 4 × .profil-glava__kazalnik </div>
</div>
```

Nad `<h1>` ostane en sam `<h1>` na strani (ime = nadnaslov, priimek = glavni, kot zdaj). Palice so okras (`aria-hidden`), ker številke stojijo ob njih.

## 7. Postavitev – namizje (≥ 1100 px; maketa 1280 px)

Glava je široka 1200 px (vsebina z 40 px odmikom; `.vsebina` ga že da). Vse navpično znotraj elementa glave:

**Vrstica 1** (`__vrstica`): flex, `space-between`, `align-items:center`, višina 44, `margin-bottom: 32px`.
- Levo: `.povezava-nazaj` (mono 500 12/1.4, `.1em`, verzalke, `--barva-crnilo-3`, brez podčrtaja). **`margin-bottom` mora biti 0** (razred ima zdaj 24 px).
- Desno (`__dejanja`, `position:relative`, flex, `gap:8px`):
  - Glavni gumb: višina 44, `padding:0 20px` (»Sezonski zapisnik →«) oz. `0 28px` (»Spremljaj«), podlaga `--barva-glavna-polna`, obroba 1 px `--barva-glavna`, bela Karla **700** 15/1.2. Hover kot `.gumb--glavni`.
  - Gumb »⋯« (znak U+22EF): 44 × 44, obroba 1 px `--barva-crnilo`, prosojna podlaga, Karla 600 18, hover podlaga `--barva-polnilo`. Nov razred (obstoječi `.kartoteka__meni-gumb` ima svetlo obrobo).
  - Meni: **enak `.kartoteka__meni` / `.kartoteka__meni-postavka`** (248 px, bel, 1 px črn rob, `top:52px`, `right:0`, postavke 44 px, Karla 400 15, hover `--barva-vrstica-hover`).

**Glavna vrstica** (`__glavno`): flex, `gap:40px`, `align-items:stretch`.
- **Portret** (`__slika`): `width:300px` + 1 px obroba `--barva-crnilo` (zunanja širina **302**), `min-height:400px`, podlaga `--barva-bela`, **višina se raztegne na višino srednjega stolpca** (v maketi 450 px). `img` je `position:absolute; inset:0; 100 % × 100 %; object-fit:cover; object-position:50% 18%`. `alt=""`. Brez slike elementa **ni** (ne prazen okvir, ne silhueta) in priimek se poveča (spodaj).
- **Srednji stolpec** (`__oseba`): `flex:1 1 0; min-width:0`, flex stolpec, `container-type:inline-size`.
  - `h1`: `margin:0`, display, `line-height:.88`, `letter-spacing:-.035em`.
    - Ime: 200, **56 px**, `--barva-crnilo-3`.
    - Priimek: 800, `margin-top:calc(.08em + 6px)`, `--barva-crnilo`; velikost **112 px** (s sliko) oz. **144 px** (brez slike), a ne več, kot dovoli širina: `font-size: min(var(--priimek-najvec), calc(100cqw / (var(--znakov) * .47)))` (prototip uporablja isto pravilo: širina / (št. znakov × 0,47)). Dolg priimek (npr. »Kovačič-Šegula«) se zato sam zmanjša.
  - Meta vrstica (`__meta`): flex, `flex-wrap:wrap`, `align-items:center`, `gap:8px 20px`, `margin-top:20px`. Klub: Karla **600** 18 `--barva-crnilo`. Roka: Karla **300** 17 `--barva-crnilo-2`. Oznaka »Tvoj profil«: mono 600 12/1, `.1em`, verzalke, barva in 1 px obroba `--barva-glavna-tekst`, `padding:5px 8px`. (V maketi 1280 se oznaka prelomi v drugo vrstico – tako mora ostati.)
  - Uvrstitev (`__uvrstitev`): `margin-top:auto; padding-top:32px`; znotraj `border-top:3px solid --barva-crnilo; padding-top:16px`.
    - Vrstica člani: flex, `align-items:baseline`, `gap:12px`: mesto (Bricolage 800 **64 px**/.9, `-.04em`, tabular) · »od 619« (mono 500 14/1, `--barva-crnilo-3`) · oznaka lestvice (`margin-left:auto`, mono 500 12/1.4, `.1em`, verzalke, `--barva-crnilo-3`).
    - Palica: `margin-top:14px; height:6px; background:--barva-polnilo`; polnilo `--barva-glavna`, širina = percentil.
    - Napis: `margin-top:8px`, mono 500 12/1.4, `.1em`, verzalke, `--barva-crnilo-2`: »Boljši od 85 %«.
    - Vrstica pas (neobvezna): `margin-top:16px; padding-top:12px; border-top:1px solid --barva-crta`; enaka zgradba, mesto 800 **32 px**/1; brez palice.
- **Desni stolpec** (`__rating-stolpec`): `flex:none; width:372px`, flex stolpec.
  - Ploskev (`__rating`): `--barva-glavna-polna`, `padding:24px`. Zgornja vrstica: flex, `space-between`, `baseline`, `gap:16px`: »Turnirko rating« (mono 500 12/1.4, `.14em`, verzalke, bela) in povezava »Kako se računa →« (`Link to="/o-ratingu"`, mono 500 12/1.4, `.08em`, verzalke, bela, podčrtana, `text-underline-offset:3px`; **odpravi** `min-height:32px` in `margin-top` iz `.rating-blok__povezava`). Številka: `margin-top:16px`, Bricolage 800 **128 px**/.82, `-.05em`, tabular, bela. Noga (samo ob `z`): flex, `space-between`, `gap:16px`, `margin-top:24px`, mono 500 12/1.4, `.08em`, verzalke; levo bela, desno (»vrh 1600«) `--barva-na-glavni-2`.
  - Primerjava: **obstoječi `.kolofon`** z `margin-top:8px` (ne 24). Dve vrstici: »Klubsko povprečje« + vrednost (mono 600 16, razlika zelena/rjasta) in »Do 95. mesta« + »5 točk«. Vsaka vrstica `padding:10px 0`, `border-bottom:1px solid --barva-crta`.

**Vrstica številk** (`__povzetek`): `margin-top:40px; padding-top:24px; border-top:3px solid --barva-crnilo`; grid `1.15fr 1.25fr 1fr 1fr`.
- Stolpec 1 (odigrane): `padding-right:24px`. Stolpec 2 (zmage–porazi): `padding:0 24px; border-left:1px solid --barva-crta`. Stolpec 3 (uspešnost): `padding-left:24px; border-left:4px solid --barva-glavna`. Stolpec 4 (zadnja tekma): `padding-left:24px; border-left:1px solid --barva-crta`.
- Vrednost: Bricolage 800 **56 px**/1, `-.04em`, tabular, `white-space:nowrap`. Datum: mono 600 **24 px**/**56 px**, tabular, nowrap.
- Oznaka: `margin-top:8px`, mono 500 12/1.4, `.08em`, verzalke, `--barva-crnilo-3`.
- Palici (samo stolpca 1 in 2): `margin-top:12px; height:6px`, flex. Odigrane: `--barva-glavna` (turnirske) + `--barva-crnilo` (ligaške, `flex:1`). Zmage–porazi: `--barva-poudarek` (zmage) + `--barva-negativna` (porazi, `flex:1`). Pod palico legenda: flex, `gap:16px`, `margin-top:8px`, mono 500 12/1.4, `.04em`, `--barva-crnilo-2`; kvadratek 8 × 8 px, `margin-right:6px`. Besedila legende: »270 turnirske«, »251 ligaške«, »zmage«, »porazi« (števke iz podatkov).

## 8. Postavitev – telefon (≤ 640 px; maketa 390 px, vsebina 350 px)

Vsebina je široka `viewport − 40 px`. Zgoraj 16 px odmika (aplikacijska glava telefona ostane kot zdaj).

1. Vrstica: `margin-bottom:20px`; povezava nazaj `inline-flex; min-height:44px`; glavni gumb `padding:0 16px` (»Sezonski zapisnik →«, Karla 700 15) oz. `0 24px` (»Spremljaj«); ⋯ 44 × 44. Meni enak kot na namizju (na telefonu se odpre pod gumbom, `right:0`).
2. Oseba (flex, `gap:16px`, `align-items:stretch`): portret `width:148px` (+ obroba = 150), `min-height:200px`; desno ime **32 px** (200) in priimek **64 px** (s sliko) / **88 px** (brez slike), omejen z `cqw` pravilom; pod imenom (`margin-top:16px`) **stolpec** `gap:6px`, `align-items:flex-start`: klub Karla 600 **15**/1.3, roka Karla 300 15, oznaka »Tvoj profil«.
3. Ploskev ratinga: `margin-top:24px; padding:20px`; številka **112 px** (`margin-top:14px`); noga `margin-top:20px`, `gap:12px`.
4. Primerjava (`.kolofon`): `margin-top:4px`.
5. Uvrstitev: `margin-top:32px; border-top:3px; padding-top:16px`; mesto **56 px**/.9 (`gap:10px`); palica `margin-top:12px`; napis `margin-top:8px`; vrstica pas `margin-top:14px; padding-top:12px`, mesto 32 px.
6. Številke: grid 2 stolpca, `margin-top:32px; border-top:3px solid --barva-crnilo`. Vrednosti **44 px**/1; datum mono 600 **20 px**/44 px.
   - Celica 1 (odigrane): `padding:16px 12px 20px 0; border-bottom:1px solid --barva-crta`; palica `margin-top:10px`; legenda **v dveh vrsticah** (`flex-direction:column; gap:2px; margin-top:6px`), vsaka s kvadratkom.
   - Celica 2 (zmage–porazi): `padding:16px 0 20px 16px; border-left:1px solid --barva-crta; border-bottom:1px solid --barva-crta`; palica `margin-top:10px`, **brez legende**.
   - Celica 3 (uspešnost): `padding:16px 12px 16px 16px; border-left:4px solid --barva-glavna`.
   - Celica 4 (zadnja tekma): `padding:16px 0 16px 16px; border-left:1px solid --barva-crta`.
   - Oznake `margin-top:6px`.

## 9. Spremenljivke (design tokens)

Vse že obstajajo v `slog.css`:

| Namen | Spremenljivka | Vrednost |
|---|---|---|
| Papir | `--barva-papir` | `#fbf9f5` |
| Črnilo / 2 / 3 | `--barva-crnilo` / `-2` / `-3` | `#14110f` / `#332e29` / `#5b534d` |
| Črta, polnilo | `--barva-crta`, `--barva-polnilo` | `#ded7ce`, `#ede7df` |
| Modra (risanje) / polna (pod besedilom) | `--barva-glavna`, `--barva-glavna-polna` | `#0088ce`, `#0071ab` |
| Modra za besedilo | `--barva-glavna-tekst` | `#0071ab` |
| Na modri / drugotno na modri | `--barva-na-glavni`, `--barva-na-glavni-2` | `#ffffff`, `#e8f5c4` |
| Zelena (zmage), zelena za besedilo | `--barva-poudarek`, `--barva-poudarek-tekst` | `#7bb900`, `#4a7500` |
| Rjasta (porazi, negativno) | `--barva-negativna` | `#b23a1e` |
| Bela, hover vrstice | `--barva-bela`, `--barva-vrstica-hover` | `#ffffff`, `#f3efe9` |
| Ritem | `--r1…--r8` | 8, 16, 24, 32, 40, 48, 56, 64 px |
| Pisave | `--pisava-display`, `--pisava-telo`, `--pisava-mono` | Bricolage Grotesque Variable, Karla Variable, IBM Plex Mono |

Prototip uporablja hex vrednosti; v kodi uporabi zgornje spremenljivke. Radij 0, sence ni.

## 10. Stanja, dejanja in robni primeri

**Dejanja zgoraj desno** (logika obstaja – preslikaj, ne piši na novo):

| Gledalec | Glavno dejanje | Meni »⋯« |
|---|---|---|
| Moj profil (`jeMoj`) | »Sezonski zapisnik →« (`/igralci/:id/sezona`) samo če `imaSirokoSpremljanje`; sicer ga ni | »Uredi sliko« / »Dodaj sliko« (odpre `ProfilnaSlikaOkno`, kot zdaj) |
| Tuj profil, gost ali prijavljen (`!jeMoj && !nalaganje`) | »Spremljaj« = obstoječa logika `GumbSpremljanja` (+ registracija za gosta) | »Sezonski zapisnik za tisk →« samo če `imaSirokoSpremljanje` |

- Če meni nima nobene postavke, gumba »⋯« **ni**. Če ni ne glavnega dejanja ne menija, vrstica vsebuje samo povezavo nazaj.
- **»Spremljam«** v maketi ni narisano. Predlog: obrobni `.gumb` z besedilom »Spremljaš« (`aria-pressed="true"`); klik ga izklopi. Brez ikon. Obstoječe obnašanje (`spremljanjeIgralcev.preklopi`, `odpriRegistracijo`) ostane.
- **`DruzinaGumb`, `SporociloNapake` in povezava »Naročnina →«** (napaka spremljanja) niso v maketi, a funkcije se ne smejo izgubiti: prikaži jih, **samo kadar nekaj prikažejo**, v vrstici tik pod vrstico 1 (levo, `margin-bottom:16px`).
- Meni: odpre/zapre klik na »⋯«; zapre ga klik zunaj in `Escape` (fokus nazaj na gumb); `aria-haspopup="menu"`, `aria-expanded`, postavke `role="menuitem"`. Vzorec kopiraj iz `IgralciStran.tsx` (meni `.kartoteka__meni`).
- **Brez uvrstitve** (`p.uvrstitev.mesto === null`): blok uvrstitve ne obstaja; srednji stolpec ima samo ime in meta vrstico.
- **Brez percentila:** brez palice in napisa, ostane mesto + »od N« + oznaka lestvice.
- **Brez ratinga:** številka »—«; noga in vrstici primerjave se prikažeta samo, če imata podatke (razlika klubskega povprečja zahteva rating).
- **Brez `z` (gost, brez Premium):** ploskev nima noge (maketa 02 in 05). To je javni pogled.
- **Brez slike:** glej poglavje 7 (2. maketa). Maketa gosta: igralec **Luka Zupan** je izmišljen.
- **`razlikaNad == null`:** vrstice »Do N. mesta« ni.
- **Brez tekem** (`p.tekme.length === 0`): zadnja tekma »—«.
- Fotografija: v maketi je povečan majhen izrez; produkcijska slika `VELIKA` je 480 px, kar zadošča za 300 × ~450 px pri DPR 1. Okvir `SlikaIgralca` je kvadraten – za glavo profila ga **ne uporabi**, uporabi navaden `<img>` z `urlProfilneSlike`. Odstrani zastarelo pravilo `.profil__slika` (88 px na telefonu) in `naslov-z-logotipom` na tej strani.

## 11. Odzivnost med telefonom in namizjem (v maketi ni)

Maketi sta samo 1280 in 390 px. Vmes uporabi presojo v duhu obstoječih prelomov (`1100`, `768`, `640`):

- `≤ 1100`: desni stolpec (ploskev + primerjava) preide pod `__oseba`, v celo širino; vrstica številk ostane 4-stolpčna.
- `≤ 768`: vrstica številk postane 2 × 2 kot na telefonu.
- `≤ 640`: postavitev telefona (poglavje 8).
- Preveri 768 in 1024 px: brez vodoravnega drsenja, brez odrezanega besedila. Tu **ni** pikselske primerjave, le vizualna.

## 12. OBVEZNO: preverjanje s posnetki – ponavljaj, dokler se ne ujemata

Delo **ni končano**, dokler tvoja izvedba ni pikselsko enaka referenčnim posnetkom. Postopek:

### 12.1 Harness (kot `src/dev/PosnetkiOkna.tsx`)
Ustvari razvojno pot `/dev/profil-glava` (samo `import.meta.env.DEV`, leno naložena, brez prijave, brez omrežja). Parametri: `stanje=moj|gost`, `meni=1` (meni odprt). Podatki so **fiksni** in morajo biti natanko ti:

| | `moj` (Miha Fatur) | `gost` (Luka Zupan) |
|---|---|---|
| Klub, roka | Namiznoteniški klub Savinja, Desničar | Namiznoteniški klub Žalec, Levičar |
| Slika | da – uporabi `reference/assets/miha-fatur.png` (kopiraj v `public/dev/`) | ne |
| `jeMoj`, `z` (zasebno) | da, da (`+17 / 30 dni`, vrh `1600`) | ne, ne |
| Uvrstitev 1 | 96. od 619, percentil 85, »Moški · Člani« | 38. od 619, percentil 94, »Moški · Člani« |
| Uvrstitev 2 | 20. od 259, »Moški · U21« | – |
| Rating | 1393 | 1612 |
| Klubsko povprečje | 1474 (razlika −81) | 1498 (razlika +114) |
| Do mesta | 95. mesta, 5 točk | 37. mesta, 9 točk |
| Odigrane / turnirske / ligaške | 521 / 270 / 251 | 388 / 203 / 185 |
| Zmage–porazi, uspešnost | 294–227, 56 % | 247–141, 64 % |
| Zadnja tekma | 25. 10. 2026 | 1. 11. 2026 |
| Glavno dejanje | »Sezonski zapisnik →« | »Spremljaj« |

Celotna stran ni potrebna: harness lahko izriše samo `ProfilGlava` v okvirju širine `viewport − 80 px` (namizje, odmik 40 px kot `.vsebina`) oz. `viewport − 40 px` (telefon), na podlagi `--barva-papir`.

### 12.2 Posnetki
Playwright (ali Puppeteer / headless Chrome): viewport **1280 × 900** in **390 × 900**, `deviceScaleFactor: 1`, počakaj na `document.fonts.ready` in sliko, izključi animacije. Posnemi **samo element `.profil-glava`** (`locator.screenshot()`) za štiri stanja:

| Stanje | Viewport | Referenca (enake mere) |
|---|---|---|
| moj, namizje | 1280 | `screenshots/ref/ref-01-namizje-moj-profil-1200x716.png` |
| gost, namizje | 1280 | `screenshots/ref/ref-02-namizje-gost-brez-slike-1200x654.png` |
| moj, telefon | 390 | `screenshots/ref/ref-04-telefon-moj-profil-350x1078.png` |
| gost, telefon | 390 | `screenshots/ref/ref-05-telefon-gost-brez-slike-350x957.png` |

Odprt meni: primerjaj z `screenshots/03-namizje-meni-odprt-1280.png` (zgornjih 340 px; meni 248 px pod gumbom ⋯, desno poravnan).

### 12.3 Primerjava (obe ravni)
1. **Vizualno:** odpri svoj in referenčni posnetek (oba), pa še diff (`pixelmatch` / ImageMagick `compare -metric AE`) in ugotovi razlike po sklopih: vrstica dejanj, portret, ime, meta, uvrstitev, ploskev ratinga, primerjava, vrstica številk.
2. **Numerično:** za vsako besedilo/blok iz `geometrija.json` izmeri `getBoundingClientRect()` (list z istim besedilom; koordinate relativno na `.profil-glava`; `PORTRET` = `.profil-glava__slika`, `SLAB` = `.profil-glava__rating`) in izpiši odstopanja. Primer:

```js
// v page.evaluate: root = document.querySelector('.profil-glava'); spec = geometrija['namizje-moj-profil']
const r0 = root.getBoundingClientRect();
const najdi = t => [...root.querySelectorAll('*')].find(e => !e.children.length && e.textContent.trim() === t);
for (const [t, [x, y, w, h]] of Object.entries(spec)) {
  if (t.startsWith('_') || ['viewport', 'element', 'PORTRET', 'SLAB'].includes(t)) continue;
  const e = najdi(t); if (!e) { out.push([t, 'MANJKA']); continue; }
  const r = e.getBoundingClientRect();
  out.push([t, [r.left - r0.left - x, r.top - r0.top - y, r.width - w, r.height - h].map(Math.round)]);
}
```
3. **Barve in pisave:** `getComputedStyle` na ključnih elementih (podlaga ploskve `rgb(0,113,171)`, barve besedil, teža in velikost pisav) po poglavjih 7–9.

### 12.4 Merilo uspeha
- Velikost elementa enaka referenci (1200 × 716, 1200 × 654, 350 × 1078, 350 × 957) ±1 px.
- Vsa besedila enaka (znak po znak) in vsak blok v `geometrija.json` znotraj **±1 px** po x, y, širini in višini.
- Diff posnetka: razlike le robno (anti-aliasing, prag `0.1`), **< 1 % slikovnih pik**, brez celotnih premaknjenih blokov; območje fotografije izvzeto samo, če nisi mogel uporabiti iste PNG slike.
- Barve in teže pisav natančno kot v poglavju 7–9.

### 12.5 Zanka
Če merilo ni doseženo: popravi CSS → ponovno posnemi → primerjaj → ponovi, **dokler se obe ravni popolnoma ne ujemata**. Ne končaj z »približno enako«. Če ostane razlika, ki je ne moreš odpraviti (npr. pisava), jo izmeri, ugotovi vzrok in jo izrecno navedi v sklepnem poročilu.

Znan vir majhnih razlik: prototip nalaga pisave iz Google Fonts z optičnim izravnavanjem (`opsz`), aplikacija ima lokalni fontsource. Če so širine črk Bricolage ≥ 2 px drugačne, preveri `font-optical-sizing`/osi in ravnaj po videzu **obstoječih naslovov v aplikaciji** (ne spreminjaj pisave); razliko zapiši.

### 12.6 Pred oddajo
- `npm run build` (`tsc --noEmit` + vite) brez napak.
- Preostanek profila (graf, forma, nasprotniki, tekme) je vizualno nespremenjen; `grep` po starih razredih (`rating-blok`, `profil__povzetek`, `kazalnik`, `profil__mesto-znacka`, `profil__meta`, `profil__spremljanje`, `stran-glava`), izbriši samo tiste, ki jih nihče več ne uporablja (`profil__percentil` ostane: uporablja ga `OkolicaBlok`).
- V `DESIGN.md` dodaj kratek razdelek »4e. Glava profila igralca (november 2026)« z razredi `.profil-glava__*` in pravili iz poglavij 7–8.
- Pošlji poročilo: kaj si spremenil, 4 + 1 posnetke harnessa ob referencah, preostale razlike.
