# Predaja: Končna razvrstitev (možnost 1b »Stopničke« + tisk 1c)

Vir: projekt »Prenova lestvice turnirja«. Repozitorij: `MihaFatur/Turnirko`, veja `main`, podmapa `vmesnik/`.
Nadomesti razdelek **»Končna razvrstitev«** zaključenega dogodka (`vmesnik/src/strani/DogodekStran.tsx`, funkcija `Zakljucek` in njeni pomočniki).

---

## 1. O datotekah v tem paketu

Datoteke v `referenca/` so **oblikovalske reference v HTML** (prototip: kaže videz in obnašanje), **ne produkcijska koda**. Nalogo je **poustvariti v obstoječem vmesniku** (React + TypeScript + Vite, navaden CSS z BEM razredi v `slog.css`, TanStack Query, slovenska imena brez šumnikov v identifikatorjih) z obstoječimi vzorci. HTML se ne kopira v aplikacijo.

**Zvestoba: visoka (hi-fi).** Barve, pisave, mere, razmiki in gibanje so končni. Poustvari jih na piksel natančno (glej razdelek 9 — postopek primerjave).

Ostalo v paketu:

| Pot | Vsebina |
|---|---|
| `posnetki/*.png` | ciljni posnetki (razdelek 9.2) |
| `primerPodatki.json` | natančni podatki za tri primere (isti kot v posnetkih) |
| `referenca/Koncna razvrstitev.dc.html` | prototip: **1b** (cilj), 1a (zavržena zmerna različica), 1c (tisk), 0a (trenutno stanje za primerjavo) |
| `referenca/Foto.dc.html`, `referenca/support.js` | pomožna komponenta prototipa in zagonska skripta |

Prototip se odpre samo prek HTTP (npr. `npx serve referenca`), ker se `dc-import` prek `file://` ne naloži (enako kot makete v `vmesnik/turnirko-profil-redesign/project/`).

**Obseg te predaje:** izvedi **samo 1b in 1c**. 1a ni za izvedbo. 0a je prikaz sedanjega stanja.

---

## 2. Preden začneš

Preberi (vse že obstaja v repozitoriju):
1. `vmesnik/turnirko-profil-redesign/project/DESIGN.md` — zavezujoč sistem. **Ta predaja ga zavestno razteguje** (razdelek 7); izjeme moraš zapisati vanj.
2. `PRODUCT.md`, `CLAUDE.md` (korenska mapa) — ton, zasebnost, pravila testiranja.
3. `DogodekStran.tsx`: `Zakljucek`, `bilancePrijav`, `steviloNaMestu`, `oznakaMesta`, `podnapisPrijave`, `RazvrstitevSeznam`, `RazvrstitevPoNivojih`, `Tekmovanje` (od ~vrstice 1680; `zakljucekVZavihku`).
4. `slog.css`: `.razvrstitev__*` (~6264), `.vrstni-red__*` (~6370, 18554, 22014), `.razvrstitev__vrh--slike` (~26203), `.slika-igralca` (~26110).
5. `komponente/SlikaIgralca.tsx`, `pomozno/profilneSlike.ts`, `pomozno/telefon.ts` (`useTelefon`).
6. Vzorec dev posnetkov: `src/dev/ProfilGlavaPosnetki.tsx`, `src/dev/primerPodatki.ts` (in kako je registrirana pot `/dev/profil-glava`).
7. Vzorec tiskalnih strani: `strani/ZrebMrezeStran.tsx`, `strani/ListkiStran.tsx`, razdelek 16 v `slog.css` (tisk).

---

## 3. Kaj se spremeni (povzetek)

Danes: prva tri mesta so v vrsti kartic z levo črto, pod njimi celoten seznam (do 24 v dveh stolpcih, sicer 16 vrstic + »Pokaži še N«), vsaka vrstica ima bilanco in rating.

Novo (1b):
- **Samo stopničke so izpostavljene**: mesta 1., 2. in 3. (ali 1., 2. in dve »3.–4.«, kadar si tretje mesto delita dva). Slika, mesto, ime, klub.
- **Stopničke so prave stopnice**: obarvani bloki različnih višin stojijo na skupnih tleh, slika igralca stoji na vrhu bloka. Na namizju vrstni red na zaslonu 2. – 1. – 3. (– 3.), na telefonu palice 1., 2., 3. od zgoraj navzdol, vsaka krajša od prejšnje.
- **Vsi ostali so skriti**. Tla pod stopnicami so črn trak-gumb »Še 44 igralcev · Pokaži vse ↓«. Po kliku se seznam razgrne po nivojih (5.–8., 9.–16. …).
- **Izpuščeno**: rating, sprememba ratinga, razlika nizov, bilanca (razen pri krožnem sistemu, glej 4.3).
- **Nov gumb »Natisni razvrstitev«** (cela razvrstitev, črno-belo, A4) — razdelek 6.

---

## 4. Zaslon: Končna razvrstitev

Prikaz: razdelek zaključenega dogodka. Namizje: nad pasom pogledov (`PodnavigacijaDogodka`), kot danes. Telefon: zavihek »Razvrstitev«, kot danes (`zakljucekVZavihku`). **Logika zavihkov in pozicij se ne spreminja.**

### 4.1 Podatki in logika

Ostane kot v `Zakljucek`:
- `razvrscene` = prijave s `koncnoMesto !== null`, urejene po mestu.
- `vrh` = `koncnoMesto <= 3` → 3 elementi (1., 2., 3.) ali 4 (1., 2., 3., 3. — deljeno »3.–4.«). `ostali` = `koncnoMesto > 3`.
- `deljena = steviloNaMestu(razvrscene)`; oznaka mesta `oznakaMesta(mesto, deljena, false)` → `1.`, `3.–4.`, `5.–8.` (vedno s pikami, tudi na telefonu — telefonska »kratka« oblika brez pik odpade).
- Posamično/ekipno: `ekipno = disciplina === 'EKIPNO'`. `posamicno = !ekipno && vse prijave idIgralca2 === null`.
- Slike: `useSlikeIgralcev(ids vrha)` samo če `posamicno` (kot danes). **Če nihče na stopničkah nima slike → slik in okvirjev sploh ni** (kot danes `zSlikami === false`; glej posnetke `ekipni-*`, kjer je blok brez slike). Če jo ima vsaj eden, dobijo okvir vsi (igralec brez slike: obris glave in ramen, ki ga že riše `SlikaIgralca` v praznem stanju).
- **Slika mora biti večja kot doslej** (24–320 px) → zahtevaj `velikost="VELIKA"` (480 px na strežniku). `MALA` (160 px) bi bila zamegljena. `SlikaIgralca` ima `mera` (stranica v px); ostane `alt=""` (okras, ime stoji ob njej — DESIGN 4d).
- Ime: v oblikovanju sta **ime (Karla 300)** in **priimek (Bricolage 800)** v ločenih vrsticah. Preveri `PrijavaDto` (`api/tipi.ts` ~298). Če ločenih polj ni, razdeli `polnoIme` pri **zadnjem** presledku za posameznika; za ekipo in par (`idIgralca2 !== null`) je ime prazno, **celoten `polnoIme` gre v vrstico priimka**. Ločena polja v DTO bi pomenila spremembo zaledja + test (pravilo projekta), zato najprej razdeli v vmesniku.
- Klub: `podnapisPrijave(prijava, ekipno)` (pri ekipi, ki ime nosi po klubu, je prazen).
- **Nivoji ostalih** (od 4. mesta naprej): zaporedne prijave z istim `koncnoMesto` so ena skupina. Skupina z več kot enim članom: velika oznaka `5.–8.` + mono števec (»4 igralci«); skupina z enim članom: samo velika oznaka (`4.`), števca ni.
- **SV regija** (`RazvrstitevPoNivojih`, `skupineZrebane`): v oblikovanju ni pokrita. **Stopničke zamenjaj z novimi, seznam ostalih pa obdrži kot danes** (zložljivi nivoji `SkupinaVrstica`), brez gumba »Še N igralcev«.

### 4.2 Postavitev — NAMIZJE (≥ 641 px; mere za vsebino široko 1200 px)

Ovoj razdelka: `display:flex; flex-direction:column; gap:32px`.

**Glava razdelka** (vzorec »naslovna vrstica«): `border-top:3px solid #14110f; padding-top:16px; display:flex; align-items:baseline; justify-content:space-between; gap:24px`.
- Levo `h2` »Končna razvrstitev«: Bricolage Grotesque 800, 40 px / 1, letter-spacing −0.03em.
- Desno (flex, `align-items:center; gap:24px`): meta »48 igralcev« (mono 500 12px / 1.4, 0.1em, uppercase, `#5b534d`; pri ekipah »12 ekip«) in gumb **»Natisni razvrstitev«**: `min-height:44px; padding:12px 16px; border:1px solid #14110f; radius 0; bg none; Karla 600 15px / 1.2`; hover: besedilo `#0071ab`, obroba `#0088ce`.

**Stopničke**: `display:grid; column-gap:4px; align-items:end`.
- Stolpci: 3 elementi `1fr 1.15fr 1fr`; 4 elementi `1fr 1.15fr 1fr 1fr`. 2 elementa (le finale): `1fr 1.15fr`.
- DOM po vrstnem redu mest; **CSS `order`**: 1. → 2, 2. → 1, tretje mesto (in tretje mesto 2) → 3, 4.
- Vsaka stopnička = `flex column`: [slika] nad [blok].

*Slika* (če slike so): kvadrat, levo poravnan, neposredno na bloku (brez vrzeli), obroba 1px `#14110f`.
| | 3 elementi | 4 elementi |
|---|---|---|
| 1. mesto | 320 px | 280 px |
| 2. mesto | 280 px | 240 px |
| 3. / 3.–4. | 260 px | 240 px |

Naj bo `width: min(Npx, 100%)` (slika nikoli ne preseže stolpca).

*Blok*: `box-sizing:border-box; padding:20px 24px; display:flex; flex-direction:column; overflow:hidden`.
| Mesto | Višina | Podlaga | Besedilo |
|---|---|---|---|
| 1. | 400 px | `#7bb900` (`--barva-poudarek`) | `#14110f` |
| 2. | 316 px | **`#0071ab`** (`--barva-glavna-polna`, **ne** `#0088ce`: bela na `#0088ce` pade pod AA) | `#ffffff` |
| 3., 3.–4. | 252 px | `#14110f` | `#fbf9f5` (`--barva-papir`) |

Vsebina bloka (zgoraj): 
1. ime — Karla 300, 20 px / 1.2, `min-height:24px` (da ostane vrstica, tudi če je ime prazno);
2. priimek — Bricolage 800, `margin-top:2px`, line-height 0.95, letter-spacing −0.03em; velikost 36 px (4 elementi: 30 px; ekipa pri 3 elementih: 32 px);
3. klub — mono 500 12px / 1.4, 0.1em, uppercase, `margin-top:10px`, `min-height:17px`;
4. samo krožni sistem: bilanca »9 – 0« — mono 600 14px / 1.4, `margin-top:2px`.

Vsebina bloka (spodaj, `margin-top:auto`): oznaka mesta — Bricolage 800, `line-height:0.74`, letter-spacing −0.06em, `white-space:nowrap`; velikost 1.: **220 px**, 2.: **180 px**, 3.: **128 px**; deljeno »3.–4.«: **100 px** (3 elementi) oziroma **84 px** (4 elementi).

**Tla / gumb**: `<button>` čez celotno širino, `margin-top:4px; min-height:72px; padding:0 24px; border:none; radius 0; background:#14110f; color:#fbf9f5; display:flex; justify-content:space-between; align-items:center; gap:24px; cursor:pointer`; hover `background:#332e29`.
- Levo: Bricolage 800, 28 px / 1, −0.03em: »Še 44 igralcev« (ekipe: »Še 9 ekip«).
- Desno: mono 500 12px / 1.4, 0.1em, uppercase: »Pokaži vse ↓« / »Skrij ↑« (znaka v besedilu, ne ikoni).
- Sklanjanje (samo `n % 100`): 1 → igralec/ekipa, 2 → igralca/ekipi, 3–4 → igralci/ekipe, sicer igralcev/ekip. **21–24, 31–34 … so rodilnik množine** (»44 igralcev«), ne »igralci«. Za to že obstaja `sklonIgralcev`/`sklonEkip` v `DogodekStran.tsx` — uporabi ju, če dajeta isti rezultat.
- `aria-expanded`, `aria-controls` na razgrnjeno področje.

**Razgrnjen seznam** (nivoji):
- Ovoj: `display:grid; grid-template-rows:0fr→1fr` (transition 420 ms `cubic-bezier(.2,.8,.2,1)`), notranji `min-height:0; overflow:hidden`, vsebina `padding-top:8px; opacity:0→1` (300 ms ease).
- **Zaprto stanje mora izločiti vsebino iz tab-vrstnega reda in bralnika** (`inert` ali `visibility:hidden` po koncu prehoda); prototip samo reže.
- Nivo: `display:grid; grid-template-columns:208px minmax(0,1fr); column-gap:40px; padding:20px 0; border-top: none (prvi) / 1px solid #14110f (ostali)`.
  - Levo: oznaka (Bricolage 800, 48 px / 0.85, −0.05em, `#14110f`); pod njo (samo pri skupini > 1) števec: mono 500 12px / 1.4, 0.1em, uppercase, `#5b534d`, `margin-top:10px`.
  - Desno: `display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); column-gap:40px; align-content:start` (skupina z enim članom: 1 stolpec). Vrstica: `display:flex; align-items:baseline; justify-content:space-between; gap:16px; padding:10px 0; border-bottom:1px solid #ded7ce`. Ime: Karla 400, 18 px / 1.3 (ime teža **300**, priimek teža **700**). Desno: klub mono 500 12px / 1.4, 0.08em, uppercase, `#5b534d`; pri krožnem še bilanca mono 500 14px, `#14110f`, `gap:16px`.

### 4.3 Postavitev — TELEFON (≤ 640 px; vsebina 350 px = 390 − 2×20)

Ovoj: `display:flex; flex-direction:column; gap:24px`. Glava telefona, naslov dogodka in zavihki ostanejo, kot so (razdelek `slog.css` 17).

**Glava razdelka**: `display:flex; align-items:center; justify-content:space-between; gap:12px` (brez zgornje črte: zavihki so tik nad njo, kot danes `naslovna-mobi--brez-crte`). Levo `h2` Bricolage 800 24 px / 1, −0.02em. Desno gumb **»Natisni«**: `min-height:44px; padding:0 12px; border:1px solid #14110f; mono 600 11px / 1.2, 0.08em, uppercase`. (Števca igralcev na telefonu ni.)

**Palice**: kontejner `display:flex; flex-direction:column; gap:4px; border-left:3px solid #14110f` (»stena«).
| Mesto | Širina | Min. višina = slika | Številka |
|---|---|---|---|
| 1. | 100 % | 148 px | 52 px |
| 2. | 92 % | 136 px | 44 px |
| 3. | 84 % | 116 px | 36 px |
| 3.–4. (deljeno) | 84 % | 116 px | 24 px |
Barve podlage in besedila enake kot na namizju. Palica: `display:flex; align-items:stretch; overflow:hidden`. Slika (če je) `flex:none`, kvadrat s stranico = višina palice, **brez razmika do roba**. Besedilni stolpec: `flex:1; min-width:0; display:flex; flex-direction:column; justify-content:space-between; gap:8px; padding:10px 14px 12px`: zgoraj oznaka mesta (Bricolage 800, line-height 0.85, −0.06em, nowrap), spodaj ime (Karla 300, 15px / 1.2), priimek (Bricolage 800, 26 px / 1, −0.03em, `overflow-wrap:anywhere`), klub (mono 500 11px / 1.4, 0.08em, uppercase, `margin-top:4px`; pri krožnem za klubom še bilanca).

**Tla / gumb**: `margin-top:4px; min-height:56px; padding:0 16px; background:#14110f; color:#fbf9f5`; levo Bricolage 800 20 px / 1, −0.02em (»Še 44 igralcev«), desno mono 500 11px / 1.4, 0.08em, uppercase (»Pokaži vse ↓« / »Skrij ↑«). Isti razgrni mehanizem kot na namizju.

**Nivoji**: `padding:16px 0 8px; border-top: none (prvi) / 1px solid #14110f`. Glava nivoja: `display:flex; align-items:baseline; justify-content:space-between; gap:12px`: oznaka (Bricolage 800, 32 px / 0.9, −0.04em), števec (mono 500 11px / 1.4, 0.08em, uppercase, `#5b534d`). Vrstice (`margin-top:8px`): `display:flex; align-items:baseline; justify-content:space-between; gap:12px; padding:10px 0; border-top:1px solid #ded7ce`; ime Karla 400 17px / 1.25 (ime 300, priimek 700); desno mono 500 11px / 1.4, 0.08em, uppercase, `#5b534d` (klub, pri krožnem še bilanca).

### 4.4 Vmesne širine

Prototip pokriva 1280 (vsebina 1200) in 390 px. Za vmesno območje velja: **namizna postavitev šele, kadar je ovoj razdelka širok vsaj ~900 px; pod tem postavitev s palicami.** Priporočeno z `container-type:inline-size` na ovoju + `@container (max-width: 899px)` (ena struktura, dve postavitvi), ne z JS. Ujemanje preveri samo pri 1200 in 350 px; vmes ohrani načela (slika nikoli ≥ stolpec, številke ne smejo preliti bloka).

### 4.5 Posebni primeri
- **Krožni sistem**: edini, ki prikaže bilanco (zmage – porazi), ker po njej določa vrstni red. Stopničke in seznam: glej posnetke `krozni-*`. Vsak nivo je en igralec (oznaka `4.`, brez števca).
- **Ekipni**: brez slik (blok sam), brez imena (samo priimek-vrstica z imenom ekipe), brez kluba pri imenih, ki ga že vsebujejo; tretje mesto je enojno (tekma za 3. mesto), 4. mesto je v seznamu.
- **Brez ratinga/bilance** za vse razen krožnega.
- **Prazno** (`razvrscene.length === 0`): razdelek se ne izriše (kot danes `return null`).

---

## 5. Gibanje

Samo `transform`, `opacity` in `grid-template-rows` pri razgrnitvi.
- **Vstop stopnic** (ob prvem prikazu razdelka in menjavi dogodka): vsaka stopnička (namizje) oz. palica (telefon) začne z `translateY(28px)` in `opacity:0`; končno `translateY(0)`, `opacity:1`. `transition: transform 520ms cubic-bezier(.2,.8,.2,1) {i*90}ms, opacity 360ms ease {i*90}ms` (i = indeks v DOM-vrstnem redu 1., 2., 3.(, 4.)).
- **Razgrnitev seznama**: razdelek 4.2 (420 ms + 300 ms).
- **`prefers-reduced-motion: reduce`**: takoj končno stanje, brez prehodov.
- Začetnega stanja ne sprožaj z `requestAnimationFrame` (v skritem zavihku ne teče): `useEffect` + `setTimeout(…, 60)`; privzeto stanje naj bo vidno.

---

## 6. Tisk (1c)

Gumb »Natisni razvrstitev« natisne **vso** razvrstitev (ne glede na to, ali je seznam na zaslonu razgrnjen). Črno-belo, A4, DESIGN.md razdelek 6. Sledi obstoječemu vzorcu tiskalnih strani (`ZrebMrezeStran.tsx` / `ListkiStran.tsx`): bodisi nova pot (npr. `/dogodki/:id/razvrstitev-tisk`) bodisi tiskalni del strani; **izberi tisto, ki je v projektu že uveljavljena**, in ne dodajaj slik.

Merila lista (referenca 794 × 1123 px = A4 pri 96 dpi, `posnetki/*-tisk-a4.png`): `padding:48px 56px`, bela podlaga, `#14110f`.
1. Vrstica: logotip (štiri poteze, **vse črne**; 22 px) + »Turnirko« Bricolage 800 20 px; desno mono 500 12px, 0.1em, uppercase »Končna razvrstitev«.
2. `margin-top:16px; border-top:3px solid #14110f; padding-top:12px`: `h1` ime dogodka (Bricolage 800 34 px / 0.95, −0.035em); pod njim mono 500 12px / 1.4, 0.06em, uppercase: `{lastnosti} · {skupaj}`.
3. `margin-top:16px; border-top:2px solid #14110f`: vrstice vrha — `grid-template-columns:96px 1fr auto; column-gap:16px; align-items:baseline; padding:8px 0; border-bottom:1px solid #14110f`; oznaka Bricolage 800 36 px / 1, −0.05em; ime Karla 24 px / 1.1 (ime 300, priimek 800); desno klub mono 500 14px, 0.06em, uppercase (+ bilanca pri krožnem).
4. `margin-top:16px`: dva stolpca (`repeat(2,minmax(0,1fr))`, `column-gap:32px`, `align-items:start`); ploski seznam ostalih razpolovljen na `ceil(n/2)`; vrstica: `grid-template-columns:64px 1fr auto; column-gap:8px; padding:4px 0`; `border-top`: prva vrstica stolpca nič, prva v nivoju `1px solid #14110f`, ostale `1px dotted #5b534d`; oznaka nivoja (Bricolage 800 16 px / 1.2, −0.02em) se izpiše v prvi vrstici nivoja **in v prvi vrstici vsakega stolpca**; ime Karla 16 px / 1.2 (300 / 700); desno klub mono 500 12px, 0.04em, uppercase.
5. Noga (`margin-top:auto; padding-top:12px; border-top:1px solid #14110f`): mono 500 12px: levo »Turnirko · turnirko-nt.si«, desno »Natisnjeno iz končne razvrstitve« (nadomesti z datumom izpisa, če je v projektu običaj).
- Pri > ~60 igralcev se seznam prelomi na drugo stran; vrstice se ne smejo lomiti (`break-inside:avoid`), glava se ne ponavlja.
- Besedilo najmanj 12 px mono / 16 px telo (12 pt pravilo za izpise).

---

## 7. Odstopanja od DESIGN.md — zapiši jih kot odločitev lastnika

Lastnik je zahteval drznejšo prenovo (4. 11. 2026). Dodaj v DESIGN.md nov razdelek (npr. »5h. Izjema: končna razvrstitev — stopničke«) in ga navedi v točki 12 razdelka 5. Izjema velja samo za ta razdelek:

1. **Velikost slike**: razdelek 4d omejuje stopničke na 72/44 px. Zdaj 240–320 px (namizje) in 116–148 px (telefon). Ostane: radij 0, obroba 1 px `#14110f`, brez medalj in okvirjev v barvi mesta, `alt=""`.
2. **Ploskve v barvi mesta**: odličje ni več samo črta ob robu, ampak polna ploskev (zelena / `--barva-glavna-polna` / črnilo). Barve ostanejo hišne in pomensko iste (zmagovalec = zelena, drugi = modra, tretji = črnilo); besedilo izrecno `#14110f` / `#ffffff` / `#fbf9f5` (kontrast ≥ 5,3 : 1).
3. **Tipografija**: številke mest 84–220 px presegajo `--tip-rezultat` (96–112 px). Veljajo samo na stopnicah.
4. **Gibanje**: točka 12 dovoljuje samo prehode barve do 120 ms. Nova izjema: vstop 520 ms, razgrnitev 420/300 ms; samo `transform`, `opacity`, `grid-template-rows`; ob `prefers-reduced-motion` takoj končno stanje.
5. **Novi razredi**: to je nov vzorec, zato novi razredi (npr. `.stopnice__*`, `.nivoji__*`, BEM, slovensko, v zadnjem razdelku `slog.css`). **Preden izbrišeš `.razvrstitev__*` in `.vrstni-red__*`, preveri z grep, kje se še uporabljajo** (SV regija, tisk, udeleženci).
6. Barve v novih razredih zapiši kot obstoječe spremenljivke (preslikava spodaj), ne kot hex.

---

## 8. Oblikovni žetoni (preslikava na obstoječe spremenljivke v `slog.css`)

| Vrednost | Spremenljivka |
|---|---|
| `#14110f` | `--barva-crnilo` |
| `#332e29` | `--barva-crnilo-2` (hover tal) |
| `#5b534d` | `--barva-crnilo-3` |
| `#fbf9f5` | `--barva-papir` |
| `#ded7ce` | `--barva-crta` |
| `#7bb900` | `--barva-poudarek` |
| `#0071ab` | `--barva-glavna-polna` (2. mesto), `--barva-glavna-tekst` (hover gumba) |
| `#0088ce` | `--barva-glavna` (samo obroba ob hoverju) |
| `#ffffff` | `--barva-bela` (besedilo na modrem) |
| Bricolage Grotesque | `--pisava-display` (teža 800 / 300 / 400 / 700 pri Karli) |
| Karla | `--pisava-telo` |
| IBM Plex Mono | `--pisava-mono` |

**Pozor na pisavo**: prototip nalaga Bricolage iz Google Fonts z osjo `opsz` 12–96 in samodejno optično velikostjo; velike številke (220 px) so zato uporabljene z `opsz` ≈ 96 (ožje črke). Vmesnik nosi lokalni `Bricolage Grotesque Variable`. Če širina številk ali priimkov ni enaka, nastavi `font-optical-sizing:auto` oz. `font-variation-settings:'opsz' N` (glej DESIGN.md razdelek 5g, kjer je ista težava že opisana), dokler se širine ne ujemajo.

Razmiki: 4, 8, 10, 12, 16, 20, 24, 32, 40 px (nekateri po optični poravnavi niso večkratniki 8, kot dovoljuje DESIGN.md). Radij povsod 0. Sence in gradienti jih ni.

---

## 9. Postopek primerjave s posnetki (obvezen)

Cilj: **popolno ujemanje**. Ne ustavi se, dokler vsi primeri niso enaki.

### 9.1 Dev pot s fiksnimi podatki
Po vzorcu `ProfilGlavaPosnetki` dodaj razvojno pot, npr. `/dev/koncna-razvrstitev?primer=izlocilni|krozni|ekipni&stanje=zaprto|odprto&naprava=namizje|telefon`:
- podatke vzemi iz `primerPodatki.json` (brez omrežja); map: `koncnoMesto`, `steviloNaMestu`, `ime`, `priimek`, `klub`, `foto` (`slika` | `obris` | `brez`), `izid` (krožni);
- `foto:'slika'` izriši kot **razvojni nadomestek**: kvadrat z 1 px `#14110f`, bela podlaga, poševne proge 45° (SVG vzorec 8 × 8, širina proge 3 px, barva `#ede7df`), mono 500 10px / 1 »FOTO«, 0.1em, `#5b534d`, levo 6 px, spodaj 5 px (točen zapis: `referenca/Foto.dc.html`); `foto:'obris'` = obstoječi prazni `SlikaIgralca` (silhueta: krog `r=7.5` in pot `M6 36c0-7.7 6.3-14 14-14s14 6.3 14 14`, črta `#5b534d`, 2 px, 60 % okvirja); `foto:'brez'` = brez slike;
- `stanje=odprto` razgrne seznam; `naprava=telefon` izrisuje ovoj 390 px z 20 px odmikom levo/desno, `namizje` 1200 px.

### 9.2 Ciljni posnetki (`posnetki/`)
Ime: `<primer>-<stanje>-<naprava>.png`. Posnet je **samo element razdelka** (od 3 px črte glave do konca), brez glave strani.

| Posnetek | Velikost v CSS px | DPR |
|---|---|---|
| `izlocilni-zaprto-namizje` | 1200 × 858 | 1 |
| `izlocilni-odprto-namizje` | 1200 × 2006 | 1 |
| `krozni-zaprto-namizje` | 1200 × 898 | 1 |
| `krozni-odprto-namizje` | 1200 × 1548 | 1 |
| `ekipni-zaprto-namizje` | 1200 × 578 | 1 |
| `ekipni-odprto-namizje` | 1200 × 937 | 1 |
| `izlocilni-zaprto-telefon` | 390 × 676 | 2 (PNG 780 × 1352) |
| `izlocilni-odprto-telefon` | 390 × 2789 | 2 (PNG 780 × 5578) |
| `krozni-zaprto-telefon` | 390 × 564 | 2 (PNG 780 × 1128) |
| `krozni-odprto-telefon` | 390 × 1299 | 2 (PNG 780 × 2598) |
| `ekipni-zaprto-telefon` | 390 × 556 | 2 (PNG 780 × 1112) |
| `ekipni-odprto-telefon` | 390 × 1129 | 2 (PNG 780 × 2258) |
| `izlocilni-tisk-a4`, `krozni-tisk-a4`, `ekipni-tisk-a4` | 794 × 1123 | 1 |

Dodatna `izlocilni-zaprto-*-cela-stran.png` kažeta razdelek v kontekstu strani (glava, naslov dogodka, zavihki). Kontekst je samo približek — **ne primerjaj ga piksel za pikslom**.

Opomba o posnetkih: posneti so z orodjem, ki DOM ponovno izriše (ne s pikselskim zajemom zaslona), zato se zglajevanje robov črk lahko malenkostno razlikuje. Strukture, mere in razmiki se morajo ujemati točno.

### 9.3 Merilo
V repozitoriju velja (DESIGN.md, 5d; CLAUDE.md): **merilo ujemanja je prototip `*.dc.html`, izrisan v istem brezglavem Chromu kot tvoja izvedba**, ne PNG. Torej:
1. Postreži `referenca/` prek HTTP, odpri `Koncna razvrstitev.dc.html` v brezglavem Chromu (širina okna ≥ 3700 px ali posnemi element posebej).
2. Stanje: gumb primera po besedilu (»Izločilni · 48«, »Krožni · 10«, »Ekipni · 12«); razgrnitev: `#1b button[aria-expanded]` (počakaj ≥ 900 ms). Elementi za posnetek: `[data-sn="1b-namizje-odsek"]` (1200 px), `[data-sn="1b-telefon-odsek"]` (390 px, DPR 2), `[data-sn="1c-tisk"]` (794 × 1123).
3. Svoj izris posnemi z enakim viewportom/DPR in počakaj na `document.fonts.ready` in konec prehodov (ali `prefers-reduced-motion: reduce`).
4. Primerjaj **(a) mere**: višine in širine elementov (`getBoundingClientRect`) morajo biti enake, vključno s skupno višino iz tabele; **(b) piksle**: diff (pixelmatch ali ekvivalent); sprejemljive so le razlike pri zglajevanju črk. Vsako večjo razliko razišči (premik, drugačna velikost, drugačen prelom, pisava) in popravi.
5. Ponavljaj, dokler **vseh 15 primerov** (6 namizje, 6 telefon, 3 tisk) ne ujemata. Šele nato zaključi.
6. Na koncu še `npm run build` (preverba tipov), obstoječi testi (`mvnw test` ne zadeva, če zaledje ni spremenjeno) in dodaj preizkus vmesnika, če jih projekt za čiste prikazne komponente piše (glej CLAUDE.md).

### 9.4 Kaj sam preveri še zunaj posnetkov
- 3 elementi, 4 elementi (deljeno 3.–4.), 2 elementa (samo finale), prazno.
- Nihče na stopničkah brez slike → slik ni (ekipni posnetek); eden s sliko → vsi dobijo okvir (obris).
- Tipkovnica: gumb tal in »Natisni« dosegljiva; zaprt seznam ni v tab-vrstnem redu; fokusni obroč iz `slog.css` (2 px `#0088ce`).
- Kontrast: bela na `#0071ab` 5,3 : 1; `#14110f` na `#7bb900` ≈ 9 : 1; `#fbf9f5` na `#14110f` ≈ 17 : 1.
- Dolga imena (npr. »Zupančič«, ime ekipe z 20+ znaki) ne smejo preliti bloka ali palice.
- Tisk v Chromu: ena stran A4 za 48 igralcev; brez barv, brez slik.

---

## 10. Datoteke, ki jih verjetno spremeniš
- `vmesnik/src/strani/DogodekStran.tsx` — `Zakljucek` (nova komponenta, npr. `komponente/KoncnaRazvrstitev.tsx`; stran jo samo vključi), odstrani `RazvrstitevSeznam` in `VRSTIC_*`, če nista več v rabi; `RazvrstitevPoNivojih` ostane za SV regijo.
- `vmesnik/src/slog.css` — nov razdelek na koncu (po vzorcu predaj); izbris neuporabljenih `.razvrstitev__*` / `.vrstni-red__*` šele po grepu.
- `vmesnik/src/dev/` — nova posnetkovna stran + registracija poti.
- `vmesnik/turnirko-profil-redesign/project/DESIGN.md` — izjema (razdelek 7).
- Tisk: po vzorcu obstoječih tiskalnih strani.
- `github.md`-ove vrstice ne spreminjaš; `CLAUDE.md` posodobi samo, če projekt tako zahteva za nove razdelke.
