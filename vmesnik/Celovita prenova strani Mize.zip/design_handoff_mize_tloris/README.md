# Predaja: prenova strani »Mize«, tloris dvorane (smer 1b)

## Pregled
Stran **Mize** (`/turnirji/:id/mize`, `vmesnik/src/strani/MizeStran.tsx`) dobi novo podobo. Mize so narisane kot **tloris dvorane**: vsaka miza je pravokotnik z mrežo na sredini, ime vsakega igralca stoji na njegovi strani mreže. Organizator na prenosniku pri pultu:
- na prvi pogled vidi, katere mize so proste (modra črtkana obroba), kaj se igra in koliko časa, in koliko tekem čaka;
- tekmo **povleče z vrste na prosto mizo** in s tem pokliče (ali klikne mizo, da se odpre okno klica);
- s klikom na zasedeno mizo vpiše izid; če zasedeno mizo povleče na drugo prosto mizo, tekmo premakne;
- ob klicu natisne **listek z že vpisano številko mize**;
- v načinu **»Uredi dvorano«** izklaplja, vklaplja, dodaja in odstranjuje mize kar na tlorisu;
- odpre **»Zaslon za igralce«** (TV v dvorani), ki kaže zadnje klice in naslednje tekme.

Telefon dobi pomanjšan tloris, kjer najprej tapneš mizo in nato tekmo.

## O datotekah v paketu
Datoteke v mapi `prototip/` so **referenčni prototipi v HTML**. Kažejo želeni videz in obnašanje, niso pa produkcijska koda za kopiranje. Naloga je, da se ta videz **poustvari v obstoječem vmesniku** (React + TypeScript + Vite, TanStack Query, `slog.css` z BEM razredi in CSS spremenljivkami) po ustaljenih vzorcih kodne baze. Uporabi obstoječe komponente (`ModalnoOkno`, `Namig`, `VnosRezultataOkno`, `Listek`, `GlavaTelefona` …) in obstoječe spremenljivke iz `:root` v `slog.css` (`--barva-*`, `--pisava-*`, `--r1…r8`). Ne lepi inline slogov iz prototipa: preslikaj jih v razrede v razdelku »Mize« v `slog.css` (zdaj vrstice okoli `.mize__orodja` … `.mize__okno-meta`) in ta razdelek nadomesti.

Prototip odpreš prek lokalnega strežnika (zaradi dinamičnega `import()`): `npx serve design_handoff_mize_tloris/prototip` in nato `Mize B – tloris.dc.html`. Prototip je klikljiv: klic, vlečenje, vnos izida, razveljavitev, urejanje dvorane in TV, ki sledi klicem. V `Mize – zdaj.dc.html` je za primerjavo poustvarjena trenutna stran.

## Natančnost
**Visoka (hi-fi).** Barve, pisave, razmiki, velikosti in besedila so dokončni. Poustvari jih do piksla.

## ⚠ Obvezno: primerjava s posnetki, dokler se ne ujemajo
V mapi `posnetki/` je 15 posnetkov referenčnega prototipa pri merilu 1× (CSS px = px). **Implementacija je končana šele, ko se tvoji posnetki ujemajo z njimi.** Postopek:

1. **Razvojna stran s testnimi podatki.** Kodna baza že ima ta vzorec (`src/dev/*Posnetki.tsx` + `src/dev/*Podatki.ts`, npr. `PrenovaZrebaPosnetki.tsx` / `prenovaZrebaPodatki.ts`; poglej, kako so vpeti v `App.tsx` in `PosnetkiOkna.tsx`). Naredi `src/dev/MizePosnetki.tsx` in `src/dev/mizePodatki.ts`. Podatke prepiši **natanko** iz `prototip/mize-podatki.js` (20 miz, miza 10 izklopljena, ekipno srečanje na mizah 11+12, 23 pripravljenih tekem, ura strežnika 10:42, ista imena in minute). `MizeTurnirjaDto` sestavi tako, da se ujema s prototipom. Vsako stanje spodaj mora biti dosegljivo s svojim URL-jem, npr. `?stanje=vlecenje`.
2. **Zajem.** S Playwrightom (ali enakovrednim orodjem), `deviceScaleFactor: 1`, zajemi isti izrez kot na posnetku:
   - namizje: okno širine 1280 px, element strani od vrha glave (masthead) do dna vsebine (posnetki so 1280 × ~1196);
   - telefon: okno 390 × 844 (posnetek je celoten zaslon telefona z glavo in spodnjo vrstico);
   - TV: 1280 × 720.
3. **Primerjava.** Naredi slikovno razliko (npr. `pixelmatch`, prag ~0,1). Razlike shrani kot `*.diff.png`; isti postopek je bil že uporabljen za udeležence (`vmesnik/design_handoff_udelezenci/diffs/`). Preglej vsako razliko, popravi CSS ali postavitev, zajemi znova in ponavljaj, **dokler razlika ne izgine**. Sprejemljivi so samo razlike v glajenju robov pisave (prototip nalaga Google Fonts, aplikacija lokalni fontsource) in dinamični elementi (utripalka). Odmik besedila, napačna velikost, barva ali razmik niso sprejemljivi.
4. V vsakem krogu preveri tudi pogled od blizu: odpri posnetek in svoj zajem drug ob drugem in poglej področje za področjem (glava, črna vrstica, vsaka vrsta miz, vrsta tekem, okna).

| Posnetek | Stanje |
|---|---|
| `01-namizje-v-teku.png` | Turnir v teku: proste 3, 15, 18 (s predlogom), 7 pravkar sproščena, 5 predolgo (34′), 10 izklopljena, 11+12 ekipno |
| `02-namizje-vlecenje.png` | Med vlečenjem tekme z vrste: vse proste mize so tarče, miza 3 je pod kazalcem |
| `03-namizje-okno-poklici.png` | Klik na prosto mizo 3: okno »Pokliči na mizo 3« |
| `04-namizje-okno-izid.png` | Klik na zasedeno mizo 5: okno »Vnesi izid«, izbran 3:1 za Kavčiča |
| `05-namizje-uredi-dvorano.png` | Način »Uredi dvorano« |
| `06-namizje-po-klicu-sporocilo.png` | Po klicu na mizo 3: sporočilo z »Razveljavi« |
| `07-namizje-vse-zasedene.png` | Vse mize zasedene |
| `08-namizje-prvi-zagon.png` | Mize še niso nastavljene (`steviloMiz === null`) |
| `09-telefon-prosta-miza.png` | Telefon, izbrana prosta miza 3 |
| `10-telefon-zasedena-miza.png` | Telefon, izbrana zasedena miza 5 |
| `11-telefon-vnos-izida.png` | Telefon, spodnji list za izid (3:2 za Petka) |
| `12-telefon-vse-zasedene.png` | Telefon, vse zasedeno |
| `13-telefon-prvi-zagon.png` | Telefon, prvi zagon |
| `14-tv-v-teku.png` | Zaslon za igralce |
| `15-tv-po-klicu.png` | Zaslon za igralce po klicu na mizo 3 (nov klic na vrhu, zelen) |

---

## Zasloni in komponente (namizje, 1280)

Glava aplikacije (masthead, `Postavitev.tsx`) ostane nespremenjena. Vse mere so v CSS px.

### 1. Glava strani
- Ovoj: `padding: 28px 40px 24px`; mreža `minmax(0,1fr) auto`, `gap: 32px`, `align-items: end`.
- Levo:
  - povezava »← Nazaj na turnir«: `display:inline-block; margin-bottom:16px`; mono 500 12px/1.4, `letter-spacing:.1em`, verzalke, `#5B534D` (kot `.povezava-nazaj`, le odmik je 16 namesto 24);
  - `h1` »Mize«: Bricolage Grotesque 800, 56px/0.9, `letter-spacing:-0.04em`, takoj za njim `<Namig clanek="mize" />` (22 × 22, `margin-left:6px`);
  - pod njim `p`: `margin-top:10px`, Karla 300 18px, `#332E29`, besedilo `{imeTurnirja} · ura {HH:MM}`, kjer je ura `casStreznika`.
- Desno (`display:flex; align-items:flex-end; gap:32px`):
  - števci (`flex`, `align-items:baseline`, `gap:20px`); vsak je številka (Bricolage 800 44px/0.9) in oznaka (mono 500 12px, `letter-spacing:.08em`, verzalke) z `gap:8px`:
    - »4 proste«: številka in oznaka `#0071AB`;
    - »15 v igri«: številka `#14110F`, oznaka `#5B534D`;
    - »23 na vrsti«: enako kot »v igri«;
    - števci se pokažejo samo, ko so mize nastavljene;
  - povezava-gumb »Zaslon za igralce ↗«: `min-height:44px; padding:12px 16px; border:1px solid #14110F`, Karla 600 15px/1.2, na lebdenje obroba `#0088CE` in besedilo `#0071AB`. Odpre TV pogled v novem oknu.

### 2. Črna vrstica »Dvorana«
- `min-height:64px; padding:10px 40px; background:#14110F; color:#FBF9F5`; flex, `justify-content:space-between`, `gap:24px`. Sega čez vso širino okvirja (1280), brez stranskega odmika vsebine.
- Levo (`gap:20px`):
  - »DVORANA«: mono 600 12px, `letter-spacing:.12em`, verzalke;
  - legenda: mono 500 11px/1, `letter-spacing:.06em`, verzalke, `#CFC7BD`, `gap:14px`. Vsak vzorec je 18 × 11 z `gap:6px` do oznake:
    - Prosta: `border:2px dashed #0088CE`;
    - Sproščena: `border:2px solid #7BB900; background:#EAF4D6`;
    - V igri: `background:#FBF9F5`;
    - »Nad 30 min«: črta 18 × 3 `#E2A793` (številka je meja, ki jo je mogoče nastaviti; privzeto 30);
  - namig: Karla 14px `#CFC7BD`, »Povleci tekmo z vrste na prosto mizo.«, med vlečenjem »Spusti na modro mizo.«
- Desno (`gap:10px`):
  - »Uredi dvorano«: `min-height:44px; padding:10px 14px; border:1px solid #4A433D`; prozorno ozadje; `#FBF9F5`; Karla 500 14px; na lebdenje obroba `#FBF9F5`;
  - »Pokliči vse predloge [4]«: `min-height:44px; padding:10px 16px; border:1px solid #0088CE; background:#0071AB`; belo besedilo, Karla 700 15px; `gap:10px`; značka mono 600 13px, `padding:2px 7px`, `background:#fff`, `color:#0071AB`; na lebdenje ozadje `#005A88`. Pokaže se samo, ko je kakšen predlog;
  - ko je vse zasedeno, gumba ni; namesto njega je besedilo mono 600 12px, `letter-spacing:.08em`, verzalke, `#CFC7BD`: »Vse zasedeno · Najdlje igra miza 11 (41 min)«.
- V načinu urejanja:
  - levo samo »DVORANA« in besedilo Karla 15px `#CFC7BD`: »Klikni prosto mizo, da jo izklopiš, ali izklopljeno, da jo vklopiš.«;
  - desno:
    - stikalo »Poraženec sodi« (potrditveno polje 18px, Karla 14px);
    - »− Odstrani zadnjo« (slog kot »Uredi dvorano«);
    - »Končaj urejanje« (`background:#FBF9F5; border:1px solid #FBF9F5; color:#14110F`, Karla 700 15px, `padding:10px 16px`).
  - Sem dodaj še **»Počitek N min«** (−/+) in **»Pisk ob prosti mizi«** (stikalo, hrani se v `localStorage` kot zdaj, `turnirko-mize-pisk`), v istem slogu kot »Poraženec sodi«. Ti dve kontroli v posnetku 05 manjkata. Funkcij ne smemo izgubiti, zato je tu dovoljeno odstopanje od posnetka.

### 3. Telo: tloris (levo) + vrsta (desno)
Mreža `minmax(0,1fr) 340px`, `align-items:stretch`.

#### 3a. Tloris
- `padding:32px 40px 48px; background-color:#EDE7DF`. Karirast vzorec: `background-image: linear-gradient(#E4DDD3 1px, transparent 1px), linear-gradient(90deg, #E4DDD3 1px, transparent 1px); background-size: 24px 24px`.
- Mize: `display:grid; grid-template-columns:repeat(5,minmax(0,1fr)); gap:24px 16px` (širina mize pri 1280 je ≈159 px).
- Enota mize: `flex-direction:column; gap:6px`.
  - Vrstica nad mizo: `flex`, `space-between`, `baseline`. Levo je številka (Bricolage 800 22px/1), desno stanje (mono).
  - Pravokotnik mize je **visok 88 px**.

Stanja mize:

| Stanje | Vrstica nad mizo | Pravokotnik |
|---|---|---|
| **V igri** | desno minute »12′«: mono 600 12px, `#14110F` | `background:#14110F; color:#FBF9F5`; mreža 2 stolpcev. **Mreža (net):** `position:absolute; left:50%; top:-5px; bottom:-5px; width:2px; margin-left:-1px; background:#9A9189`. **Imeni:** samo priimek, Karla 600 14px/1.2, sredinsko, `padding:0 8px`. **Spodaj:** kategorija v levi polovici, del v desni (`bottom:6px`, mono 500 9px, `letter-spacing:.06em`, verzalke, `#9A9189`; »Skupina« se skrajša v »sk.«). **Trak časa:** `absolute; left:0; bottom:0; height:3px; background:#0088CE; width: min(100, minute/meja·100)%` |
| **Predolgo** (minute ≥ meja, ne ekipno) | minute v znački: mono 600 12px, `padding:2px 6px; background:#F8E5DF; color:#8C2B14` | kot »V igri«, a brez modrega traku; namesto njega `box-shadow: inset 0 -3px 0 #E2A793`; spodnji napisi `bottom:8px` |
| **Ekipno** (dve mizi) | enota se razširi čez 2 stolpca; levo »11 + 12«, desno »EKIPE · SK. B · DVE MIZI · 41′« (mono 600 12px, verzalke) | dva pravokotnika v mreži `1fr 16px 1fr`, med njima vezna črta `height:2px; background:#14110F`; na vsaki mizi imeni ekip (Karla 600 13px, `padding:0 6px`) |
| **Prosta** | številka `#0071AB`; desno »PROSTA · 2′« (mono 600 11px, `letter-spacing:.06em`, verzalke, `#0071AB`; minute od `prostaOd`, brez njih samo »PROSTA«) | `background:#FBF9F5; border:2px dashed #0088CE`; stolpec, sredinsko, `gap:2px`, `padding:0 8px`. Predlog »Vidmar – Kolar« (Karla 600 14px/1.2), pod njim »POKLIČI ›« (mono 600 10px, `letter-spacing:.08em`, `#0071AB`). Brez predloga: »Ni primerne tekme« / »POVLECI TEKMO SEM«. Na lebdenje `background:#EAF3F9` |
| **Sproščena** (30 s po sprostitvi, obstoječi `POUDAREK_MS`) | desno »SPROŠČENA« `#4A7500` | `background:#EAF4D6; border:2px solid #7BB900`; akcija `#4A7500` |
| **Tarča** (med vlečenjem, vse proste) | številka `#0071AB`, desno »SPUSTI SEM« `#0071AB` | `border:2px solid #0088CE; background:#EAF3F9; color:#0071AB`; na sredini številka mize (Bricolage 800 28px). **Pod kazalcem:** `background:#0071AB; color:#fff` |
| **Izklopljena** | številka in »IZKLOPLJENA« `#6E655E` | `border:1px dashed #9A9189; background: repeating-linear-gradient(135deg,#DED7CE 0 2px,#EDE7DF 2px 10px)`; v urejanju napis »VKLOPI« (mono 600 12px, `#5B534D`) |
| **Urejanje, prosta** | desno »PROSTA« `#5B534D` | `border:1px solid #14110F; background:#FBF9F5`; »IZKLOPI« (mono 600 12px, `letter-spacing:.08em`, `#B23A1E`); na lebdenje `background:#F8E5DF` |

V urejanju je za zadnjo mizo še gumb »+ MIZA 21«: `margin-top:28px; height:88px; border:2px dashed #14110F`, mono 600 13px, `letter-spacing:.08em`, verzalke; na lebdenje `background:#FBF9F5`.

Kazalec je `pointer` na vseh klikljivih mizah. Otroci v pravokotniku tarče imajo `pointer-events:none`, da `dragleave` ne utripa.

#### 3b. Vrsta »Na vrsti«
- `<aside>`: `padding:20px 24px 32px; border-left:1px solid #14110F`; stolpec, `gap:10px`.
- Glava: `h2` »Na vrsti« (Bricolage 800 28px/1, `letter-spacing:-0.03em`) in desno število (mono 600 16px).
- Namig: Karla 300 14px/1.45, `#5B534D`, `margin-bottom:4px`: »Primi tekmo in jo spusti na prosto mizo. Številka desno je predlagana miza.«
- Kartica, ki jo je mogoče poklicati:
  - mreža `14px minmax(0,1fr) auto`, `gap:10px`, `padding:10px 12px`, `background:#FBF9F5`, `border:1px solid #DED7CE`, `cursor:grab`; na lebdenje obroba `#14110F`;
  - ročaj »⋮⋮«: mono 600 14px, `#9A9189`, `letter-spacing:-0.1em`;
  - polni imeni: Karla 600 15px/1.3;
  - opis »ČLANI · SKUPINA 4«: mono 500 11px, `letter-spacing:.04em`, verzalke, `#5B534D`, `margin-top:2px`;
  - predlagana miza: kvadrat najmanj 32 × 32, `border:2px dashed #0088CE`, Bricolage 800 15px, `#0071AB`.
- Zasedena kartica (`kandidat.zaseden`):
  - mreža `14px minmax(0,1fr)`, `border:1px dashed #C9C1B6`, brez ozadja, `opacity:.7`;
  - namesto opisa razlog (mono 500 11px, `#8C2B14`), npr. »Kos igra na mizi 2«;
  - tudi to kartico je mogoče povleči: klic je dovoljen, sporočilo pa opozori.
- Prikaže se prvih 10 kartic, nato gumb »POKAŽI VSEH 23« / »POKAŽI MANJ« (mono 500 12px, `letter-spacing:.08em`, `#0071AB`, `min-height:44px`).

### 4. Okno »Pokliči na mizo N« (posnetek 03)
Uporabi `ModalnoOkno` (zastor `rgb(20 17 15 / .55)`, `.modal` največ 560 px, glava s 3 px črto).
- Glava:
  - nadnaslov: opis tekme (»ČLANI · SKUPINA 4«);
  - naslov »Pokliči na mizo 3«; pri ekipnem srečanju »Pokliči na mizo 3 + 4«, kjer je druga miza sosednja prosta;
  - »✕« za zapiranje.
- Telo (`padding:24px`, `gap:20px`):
  1. Pomanjšana miza: `height:120px; background:#14110F`, 2 stolpca, mreža `top:-6px; bottom:-6px`, polni imeni Bricolage 800 22px/1.15, sredinsko, `padding:0 16px`.
  2. Če je kandidat zaseden: opozorilo `padding:12px 14px; background:#F8E5DF; border:1px solid #B23A1E; color:#8C2B14`, 15px, z razlogi in besedilom »Tekmo lahko vseeno pokličeš.« (kot v zdajšnjem `OknoKlica`).
  3. »SODNIK«: polje `min-height:44px; border:1px solid #14110F; background:#fff`, 16px. Privzeta vrednost je `privzetiSodnik(miza, tekma)`. Pod poljem namig »Poraženec prejšnje tekme na tej mizi.« (Karla 300 14px). V aplikaciji ostane `IskalniIzbirnik` z istim videzom polja in obstoječim opozorilom »… zdaj igra ali sodi na mizi N«.
  4. Potrditveno polje »Natisni listek z vpisano mizo 3«, privzeto vklopljeno.
  5. »Predlagano: do konca skupine še 2 kola · Vidmar čaka 18 min« (mono 500 12px/1.5, `#5B534D`). To so `kandidat.razlogi`. **Na tlorisu razlogov ni več, vidni so samo tu.**
  6. Gumbi:
     - »Pokliči« (glavni, `min-height:48px; padding:12px 20px`, 700 16px);
     - »Prekliči« (obroba črnila, 600 15px);
     - desno namig 13px 300 (največ 20ch): »Drugo tekmo povleci z vrste na mizo.«

### 5. Okno »Vnesi izid« (posnetek 04)
- Nadnaslov »MIZA 5 · KADETI · SKUPINA 2 · 34 MIN«, naslov »Vnesi izid«. Pri ekipnem srečanju je naslov »Ekipno srečanje«.
- Dva stolpca (`gap:24px`), med njima navpična črta 1px `#DED7CE`. V vsakem stolpcu:
  - ime (Bricolage 800 22px/1.15);
  - pod njim trije gumbi »3:0 3:1 3:2« (`flex:1; height:48px`, mono 600 16px, `border:1px solid #DED7CE`; izbran: ozadje in obroba `#14110F`, besedilo `#FBF9F5`; na lebdenje obroba `#14110F`). Gumb pod imenom pomeni zmago tega igralca s tem izidom.
- Namig: »Klikni zmagovalčev izid v nizih. Sodi Vid Rozman.«
- Gumbi:
  - »Shrani: zmaga Kavčič 3:1«; dokler izid ni izbran, je gumb onemogočen in se glasi »Izberi izid« (`background:#EDE7DF`, `color:#6E655E`);
  - »Prekliči«.
- Noga (`border-top:1px solid #DED7CE; padding-top:16px`):
  - levo »Premik: povleci mizo na drugo prosto mizo.« (13px 300);
  - desno »Prekliči klic« (`min-height:36px; padding:6px 12px; border:1px solid #DED7CE; color:#B23A1E`, 500 14px; na lebdenje obroba `#B23A1E`) → potrditev in `mizeApi.preklici`.
  - Dodaj še besedilni gumb **»Zamenjaj sodnika«**, ki odpre obstoječe okno klica v načinu `sprememba`. V posnetku ga ni, funkcija pa mora ostati.
- **Hitri izid:** preveri v `VnosRezultataOkno.tsx` in v zaledju, ali je izid mogoče shraniti samo v nizih (brez točk). Če je, shranjuj neposredno. Če ni, naj izbira izida odpre `VnosRezultataOkno` z že izbranim zmagovalcem in izidom. **Pred odločitvijo vprašaj lastnika.** Povezava »celoten vnos« do `VnosRezultataOkno` mora ostati na voljo.
- Ekipno:
  - naslov »NTK Savinja – ŠD Ptuj« (800 24px);
  - besedilo »Ekipno srečanje se vpisuje v zapisnik. Ko je zaključen, se obe mizi sprostita sami.«;
  - gumb »Odpri zapisnik« → `/srecanja/:idSrecanje`. Gumb »Srečanje je končano« je samo za prototip in v aplikaciji odpade.

### 6. Sporočilo z razveljavitvijo (posnetek 06)
- Lebdi na dnu vsebine, sredinsko (`bottom:32px`):
  - `background:#14110F; color:#FBF9F5`, 15px;
  - `padding:14px 16px 14px 20px; border-top:3px solid #0088CE; gap:20px; white-space:nowrap`.
- Gumb »RAZVELJAVI«: `min-height:36px; padding:6px 10px; border:1px solid #4A433D`, mono 500 12px, `letter-spacing:.08em`; na lebdenje obroba `#FBF9F5`.
- Izgine po 6 s.
- Besedila:
  - »Miza 3: Vidmar – Kolar poklicana · listek v tisku«;
  - »Poklicanih 4 tekem · 4 listkov v tisku«;
  - »Vidmar – Kolar: z mize 3 na mizo 15«;
  - »Miza 5 je prosta · Kavčič – Petek 3:1«;
  - pri zasedenem kandidatu se doda »· pozor, Kos igra na mizi 2«.
- Kaj naredi »Razveljavi«:
  - po klicu: `mizeApi.preklici(idTekme)`;
  - po »Pokliči vse«: prekliče vse te klice;
  - po premiku: premakne tekmo nazaj.
  - Za izid razveljavitve ni (popravek gre po obstoječi poti popravka); tam gumba ne prikaži.

### 7. Prvi zagon (posnetek 08)
Ko je `steviloMiz === null`, se namesto telesa pokaže tloris z mrežo (`padding:48px 40px 64px`) v dveh stolpcih (`380px 1fr`, `gap:48px`).
- Levo kartica (`background:#FBF9F5; border:1px solid #14110F; padding:24px; gap:16px`):
  - nadnaslov »POSTAVI DVORANO« (mono, `#0071AB`);
  - `h2` »Koliko miz imaš?« (800 32px);
  - besedilo (Karla 300 15px): »Mize so oštevilčene od 1 naprej, kot jih sodnik vpiše na listek. Tloris desno se riše sproti.«;
  - števec: gumba −/+ 56 × 80 (mono 500 28px, obroba črnila), na sredini število (Bricolage 800 64px, črti zgoraj in spodaj); privzeto 20;
  - stikalo »Poraženec sodi naslednjo tekmo«;
  - glavni gumb »Postavi 20 miz« (`min-height:52px`), sklanjatev `mizSklon`.
- Desno predogled: mreža 5 stolpcev, `gap:20px 14px`. Vsaka enota ima številko (Bricolage 800 18px, `#0071AB`) in pravokotnik `height:60px; border:2px dashed #0088CE; background:#FBF9F5` z mrežo `#9ECAE6`.

## Telefon (≤ 640 px; posnetki 09–13)
- Glava `glava-telefon`:
  - levo »← Turnir« (`useNazaj`);
  - v cilj dejanj gre gumb `glava-telefon__gumb` »POKLIČI VSE · 4«; pokaže se samo, ko so predlogi.
- Vsebina: `padding:16px 0 92px; gap:16px`. Tloris gre od roba do roba, zato ima vsebina stranske odmike 20 px po blokih.
  1. Naslov:
     - `h1` »Mize« (40px);
     - pod njim vrstica mono 600 12px, `letter-spacing:.06em`, verzalke, `#5B534D`, `white-space:nowrap`: »4 PROSTE · 15 V IGRI · 23 ČAKA«, kjer je »4 PROSTE« `#0071AB`.
  2. Mali tloris:
     - `padding:14px 20px 18px`, isto ozadje z mrežo 16 px; mreža 5 stolpcev, `gap:8px`;
     - ploščica `height:40px`, mono 600/700 13px:
       - v igri: `#14110F` / `#FBF9F5` + spodaj 2px trak `#0088CE` (širina po času);
       - predolgo: `box-shadow: inset 0 -3px 0 #E2A793`;
       - prosta: `border:2px dashed #0088CE; background:#FBF9F5; color:#0071AB`;
       - sproščena: `border:2px solid #7BB900; background:#EAF4D6; color:#4A7500`;
       - izklopljena: črtkana obroba in šrafura;
     - izbrana miza: `outline:2px solid #0088CE; outline-offset:2px`;
     - privzeto je izbrana prva prosta miza.
  3. Podrobnosti izbrane mize (`padding:0 20px`):
     - **prosta:**
       - okvir `border:2px solid #0088CE; background:#EAF3F9; padding:14px; gap:10px`;
       - nadnaslov »MIZA 3 · PROSTA 2 MIN« (mono 600 11px, `#0071AB`);
       - pomanjšana miza `height:72px` s priimkoma (Karla 700 16px);
       - »ČLANI · SKUPINA 4 · LISTEK SE NATISNE«;
       - glavni gumb »Pokliči na mizo 3« (`min-height:48px`);
       - namig 13px 300: »Ali tapni drugo tekmo spodaj – gre na to mizo.«
     - **zasedena:**
       - okvir `border:1px solid #14110F; padding:14px`;
       - nadnaslov »MIZA 5 · KADETI · SKUPINA 2 · 34 MIN«;
       - imeni (Bricolage 800 20px);
       - gumb »Vnesi izid« (obroba črnila, 600 16px, `min-height:48px`) → spodnji list.
     - **vse zasedeno:** »Vse mize so zasedene. Najdlje igra miza 11 (41 min).«
  4. »Na vrsti«:
     - `border-top:3px solid #14110F; padding-top:12px`, `h2` 24px, število;
     - vrstice `padding:8px 0`, s črto spodaj: priimka (Karla 600 15px) in opis (mono 11px);
     - gumb »Na 3«: `min-height:44px; padding:6px 12px; border:1px solid #0088CE; background:#EAF3F9; color:#0071AB`, 700 14px. Tekmo takoj pokliče na izbrano prosto mizo (če je izbrana zasedena: na predlagano ali prvo prosto). Klicu sledi sporočilo z razveljavitvijo.
- Spodnji list za izid (posnetek 11):
  - zastor `.55`; list `background:#FBF9F5; border-top:3px solid #14110F; padding:20px 20px 28px; gap:16px`;
  - za vsakega igralca ime (Bricolage 800 20px) in trije gumbi 48 px;
  - glavni gumb »Shrani: zmaga Petek 3:2« (`min-height:52px`);
  - besedilni gumb »Prekliči klic« (`#B23A1E`).
- Sporočilo: `left:12px; right:12px; bottom:72px` (nad spodnjo vrstico), 14px.

## Zaslon za igralce (TV; posnetka 14–15)
Nova pot, npr. `/turnirji/:id/mize/zaslon`:
- **brez** glave in spodnje vrstice aplikacije, celozaslonsko;
- odpre se z gumbom »Zaslon za igralce ↗« (`window.open`); predvidena raba je na drugem zaslonu ali TV prek HDMI, v isti seji organizatorja, zato zaledja ni treba spreminjati;
- osvežuje se kot stran Mize (4 s).

Referenčni okvir je 1280 × 720. Pri drugih ločljivostih ga sorazmerno povečaj (oder 16 : 9 z `transform: scale()`).

Postavitev:
- `background:#14110F; color:#FBF9F5; padding:36px 56px 40px`; vrstici `auto 1fr`, `gap:28px`.
- Vrh (`border-bottom:3px solid #FBF9F5; padding-bottom:16px`):
  - levo logotip 28 px (prvi dve potezi `#FBF9F5`, prek obstoječe `--logo-poteza`), »Turnirko« (Bricolage 800 28px) in ime turnirja (Karla 300 22px, `#B9B0A6`, `margin-left:8px`);
  - desno ura (Bricolage 800 44px, `tabular-nums`).
- Telo: mreža `1.55fr 1fr`, `gap:56px`.
- Levi stolpec:
  - oznaka »POKLICANI · POJDITE NA MIZO« (mono 600 14px, `letter-spacing:.14em`, `#B9B0A6`);
  - zadnjih 5 klicev, novejši zgoraj (po `tekma.poklicanaOb` padajoče).
  - **Najnovejši klic:**
    - mreža `150px 1fr`, `gap:24px`, `padding:14px 0`, `border-top:6px solid #7BB900`;
    - številka mize Bricolage 800 84px/0.85, `#7BB900`;
    - imeni Bricolage 700 36px/1.1 v eni vrstici z »…«;
    - meta mono 500 15px, `letter-spacing:.08em`, verzalke, `#B9B0A6`, z začetkom »PRAVKAR« v `#7BB900`, nato »KADETI · SKUPINA 3 · SODI MIHELIČ«.
  - **Ostali klici:**
    - `border-top:1px solid #4A433D; padding:12px 0`;
    - številka 800 60px/0.9, `#0088CE`;
    - imeni Karla 600 26px/1.15;
    - meta mono 500 13px, `#9A9189`, »10:37 · MLADINCI · 1/8 FINALA · SODI KUHAR«.
- Desni stolpec:
  - oznaka »NA VRSTI · PRIPRAVITE SE«;
  - 6 nezasedenih kandidatov (`border-top:1px solid #332E29; padding:8px 0`): priimka Karla 600 22px/1.2, desno kategorija mono 500 12px `#9A9189`;
  - spodaj (`margin-top:auto`) oznaka »DVORANA« in mali zemljevid: mreža 10 stolpcev, `gap:6px`, ploščice 30 px, mono 600 13px:
    - prosta: `border:2px dashed #0088CE; color:#0088CE`;
    - zasedena: `background:#332E29; color:#B9B0A6`;
    - izklopljena: `border:1px solid #332E29; color:#4A433D`.

---

## Interakcije in obnašanje
- **Vlečenje (HTML5 DnD):**
  - kartica vrste je `draggable` z vsebino `{tip:'k', idTekme}`; zasedena miza je `draggable` z vsebino `{tip:'m', miza}`;
  - med vlečenjem so vse proste in sproščene mize v stanju »Tarča«, miza pod kazalcem pa je polno modra;
  - `onDragOver` → `preventDefault()`;
  - `onDrop`:
    - kartica → `mizeApi.poklici(idTekme, { miza, miza2, idSodnika })`. `idSodnika` je `privzetiSodnik(miza, tekma)?.id`, `miza2` pri ekipnem srečanju je sosednja prosta miza (najprej +1, nato −1, sicer prva prosta);
    - miza → isti klic za tekmo, ki je že na mizi, z novo mizo in obstoječim sodnikom (kot zdajšnji »Premakni ali zamenjaj sodnika«);
  - po uspehu sporočilo z razveljavitvijo in natis listka.
  - Med vlečenjem se osveževanje (4 s) ne sme ponovno izrisati pod kazalcem: ne zamenjuj elementov tarč, menjaj samo razred.
- **Klik** (dostopna pot brez vlečenja, tudi s tipkovnico; mize in kartice so `button` ali imajo `role="button"` + `tabIndex`):
  - prosta miza s predlogom → okno klica za predlog;
  - kartica vrste → okno klica na predlagano mizo kartice ali na prvo prosto;
  - zasedena miza → okno izida.
- **»Pokliči vse predloge«** → obstoječa mutacija `klicVseh` (zaporedni klici prvih predlogov s ponovnim branjem stanja), brez potrditvenega okna; namesto njega sporočilo z razveljavitvijo.
- **Tisk listka:** če je pri klicu vklopljen »Natisni listek« (pri vlečenju vedno), se natisne en listek s številko mize v okencu.
  - Uporabi komponento `Listek` (`miza` = številka) in obstoječi tok tiska v `ListkiStran.tsx` / razdelku 16 v `slog.css`. Preveri, kako se tam natisne en list; ponovno uporabi isti pristop (skrit natisljiv vsebnik + `window.print()` ali pot do strani listkov s parametroma).
  - Pri ekipnem srečanju je to zapisnik.
- **Urejanje dvorane:**
  - klik na prosto mizo jo izklopi, klik na izklopljeno jo vklopi;
  - »+ Miza N« in »− Odstrani zadnjo« spremenita `steviloMiz`; zadnje mize ni mogoče odstraniti, če se na njej igra, kar pove sporočilo »Na zadnji mizi se igra – ne moreš je odstraniti«;
  - vse gre skozi `mizeApi.nastavi({ steviloMiz, izklopljeneMize, porazenecSodi, pocitekMin })`.
- **Sproščena miza:** obstoječa logika `sprosceneMize` + `poudarjene` (30 s) + pisk ostane.
- **Ura v glavi in minute:** `casStreznika` in `minutOd`, kot zdaj.
- **Meja »predolgo«** je 30 min. Izpostavi jo kot konstanto; po želji lastnika jo kasneje dodaj v nastavitve.
- **Prehodi:** samo barve in obrobe do 120 ms (hišno pravilo). Drugih animacij ni.

## Stanje (React)
- Ostane: `pregled` (useQuery, `refetchInterval: 4000`), `pisk`, `poudarjene`, `vnosIzida`, `preklic`.
- Novo:
  - `vlecem: {tip:'k', id} | {tip:'m', miza} | null`;
  - `nadMizo: number | null`;
  - `urejanje: boolean`;
  - `sporocilo: {besedilo, razveljavi?: () => Promise} | null` (časovnik 6 s);
  - `oknoKlica: {idTekme, miza, sodnik, tisk} | null`;
  - `prikaziVseKandidate: boolean`;
  - na telefonu `izbranaMiza: number | null`.
- Odpade: `izbiraZa` (»Druga tekma …«) in ločen obrazec `NastavitveMiz`. Ta ostane le za prvi zagon, v novi obliki.

## Preslikava podatkov (MizeTurnirjaDto)
- Proste = `prosteMize(mize)`. »V igri« = število miz z `tekma !== null`. »Na vrsti« = `kandidati.length`.
- Predlog mize = `kandidati` po `miza.predlogi[0]`, ko kandidat ni `zaseden`. Številka v kartici vrste je miza, za katero je kandidat prvi predlog (`prviPredlogi`).
- Ime na mizi je **priimek**: zadnja beseda imena iz `imeUdelezenca(udelezenec)`. Pri dvojicah sta priimka združena z » / « (»Kokalj / Logar«), pri ekipah se izpiše ime ekipe. Če je ime predolgo, se prelomi v dve vrstici.
- Kategorija = `imeDogodka`, del = `del` (»Skupina 2« → na mizi »sk. 2«, drugod polno).
- Pri ekipnem srečanju imata obe mizi (`miza`, `miza2`) isto tekmo; izriši eno enoto čez dva stolpca. Če mizi nista sosednji v mreži, ju vseeno izriši skupaj na mestu prve.
- Razlogi zasedenosti: `kandidat.razlogi`, filtrirani kot v zdajšnjem `OknoKlica` (`/ (igra|sodi)( na mizi|$)/`).

## Barve (vse obstajajo v `:root` v `slog.css`)
| Vloga | Hex | Spremenljivka |
|---|---|---|
| papir | `#FBF9F5` | `--barva-papir` |
| črnilo / črna vrstica / miza v igri | `#14110F` | `--barva-crnilo` |
| črnilo 2 | `#332E29` | `--barva-crnilo-2` |
| črnilo 3 (drugotno besedilo) | `#5B534D` | `--barva-crnilo-3` |
| črnilo 4 | `#6E655E` | `--barva-crnilo-4` |
| črta | `#DED7CE` | `--barva-crta` |
| polnilo / tla tlorisa | `#EDE7DF` | `--barva-polnilo` |
| črta karirastega vzorca tal | `#E4DDD3` | **nova** `--barva-tloris-mreza` |
| modra (črte, obrobe, trak časa) | `#0088CE` | `--barva-glavna` |
| modra polna (gumbi) | `#0071AB` | `--barva-glavna-polna` / `-tekst` |
| modra polna, lebdenje | `#005A88` | `--barva-glavna-polna-mocna` |
| modra mehka | `#EAF3F9` | `--barva-glavna-mehko` |
| zelena | `#7BB900` | `--barva-poudarek` |
| zelena tekst | `#4A7500` | `--barva-poudarek-tekst` |
| zelena mehka | `#EAF4D6` | `--barva-poudarek-mehko` |
| rjasta | `#B23A1E` | `--barva-negativna` |
| rjasta tekst | `#8C2B14` | `--barva-negativna-tekst` |
| rjasta mehka | `#F8E5DF` | `--barva-negativna-mehko` |
| rjasta srednja (»predolgo« na črni) | `#E2A793` | `--barva-negativna-srednje` |
| besedilo na črni | `#CFC7BD` | `--barva-na-crni-glavi` |
| siva na črni 2 | `#B9B0A6` | `--barva-na-crnilu-2` |
| siva na črni 3 / mreža na mizi | `#9A9189` | `--barva-na-crnilu-3` |
| črta na črni | `#4A433D` | `--barva-crta-na-crnilu-2` |
| ploščica na TV | `#332E29` | `--barva-crta-na-crnilu` |
| obroba izklopljene in zasedene kartice | `#C9C1B6` | `--barva-crta-stranska` |
| mreža na predogledu prvega zagona | `#9ECAE6` | **nova** (svetla modra) |

## Tipografija
- Display: Bricolage Grotesque (`--pisava-display`), 800 (200 za pomišljaj).
- Telo: Karla (`--pisava-telo`), 300/500/600/700.
- Mono: IBM Plex Mono (`--pisava-mono`), 500/600; oznake v verzalkah z `letter-spacing` .06–.14em.
- Velikosti so navedene pri vsaki komponenti zgoraj.
- Brez zaobljenih robov (`border-radius:0` povsod) in brez senc, razen notranje `box-shadow` črte pri »predolgo«.

## Sredstva
- Ikon ni, razen obstoječih: logotip `ZnakTurnirko`, `IkonaPomoci` v `Namig` in ikone spodnje vrstice (`IkoneNavigacije.tsx`). Ročaj »⋮⋮«, »✕«, »↗«, »›«, »′« so znaki pisave, ne ikone.
- Slik ni.

## Datoteke v paketu
- `prototip/Mize B – tloris.dc.html`: referenčni prototip (namizje, telefon, TV; klikljivo).
- `prototip/mize-podatki.js`: testni podatki in pravila (proste mize, predlogi, zasedenost, klic, izid, premik, nastavitve). Iz tega naredi `src/dev/mizePodatki.ts`.
- `prototip/support.js`: izvajalno okolje prototipa (samo za ogled; v aplikacijo ne spada).
- `prototip/Mize – zdaj.dc.html`: poustvarjena trenutna stran za primerjavo.
- `posnetki/*.png`: referenčni posnetki za primerjavo (glej zgoraj).

## Kar je treba posodobiti še drugje
- Članek pomoči `mize` v `vmesnik/src/pomoc/vsebina/rezultati.ts` omenja »Pokliči predloge«, »Druga tekma …«, »Premakni ali zamenjaj sodnika« in »Izklopi mizo« v meniju mize. Prepiši ga na vlečenje, klik na mizo, »Uredi dvorano« in zaslon za igralce.
- Testi `vmesnik/src/pomozno/mize.test.ts` morajo še vedno prestati; za priimek in sosednjo drugo mizo dodaj nove pomožne funkcije s testi.
- Povezava »Mize« na strani turnirja (`TurnirStran.tsx`) ostane.
