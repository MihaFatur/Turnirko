/* Testni podatki in pravila za prototipe strani Mize.
   Vir: vmesnik/src/strani/MizeStran.tsx, vmesnik/src/pomozno/mize.ts, api/tipi.ts (MizeTurnirjaDto).
   Stanje je navaden objekt; dejanja vrnejo novo stanje (stara ostanejo za »Razveljavi«). */

const K = (id, a, b, kat, del, razlogi = [], x = {}) => ({ id, a, b, kat, del, razlogi, ekipno: false, ...x })

export const URA0 = 642 // 10:42

const IGRA = [
  [1, K(101, 'Nejc Vrhovnik', 'Tim Zupan', 'Člani', 'Skupina 3'), 12, 'Rok Golob'],
  [2, K(102, 'Matic Potočnik', 'Žan Kos', 'Člani', 'Skupina 1'), 21, 'Gal Mlakar'],
  [4, K(103, 'Sara Bajc', 'Eva Pirc', 'Članice', 'Skupina A'), 8, 'Nika Leban'],
  [5, K(104, 'Erik Kavčič', 'Maks Petek', 'Kadeti', 'Skupina 2'), 34, 'Vid Rozman'],
  [6, K(105, 'Urban Hribar', 'Tilen Žagar', 'Člani', 'Skupina 2'), 15, 'Jan Kralj'],
  [8, K(106, 'Filip Bizjak', 'Lovro Medved', 'Mladinci', '1/8 finala'), 5, 'Žiga Kuhar'],
  [9, K(107, 'Domen Sever', 'Blaž Jereb', 'Člani', 'Skupina 3'), 27, null],
  [11, K(108, 'NTK Savinja', 'ŠD Ptuj', 'Ekipe', 'Skupina B', [], { ekipno: true }), 41, null, 12],
  [13, K(109, 'Zala Furlan', 'Lara Hočevar', 'Članice', 'Skupina B'), 18, 'Maja Klemenčič'],
  [14, K(110, 'Kokalj / Logar', 'Rebec / Fras', 'Dvojice', 'četrtfinale'), 11, null],
  [16, K(111, 'Leon Majcen', 'Oskar Rems', 'Kadeti', 'Skupina 3'), 3, 'Tadej Mihelič'],
  [17, K(112, 'Aleš Vrečko', 'Martin Zorko', 'Člani', 'Skupina 4'), 23, 'Peter Čuk'],
  [19, K(113, 'Matej Hren', 'Rok Ferk', 'Mladinci', '1/8 finala'), 9, null],
  [20, K(114, 'Jaka Ribič', 'Svit Lah', 'Kadeti', 'Skupina 2'), 14, 'Gregor Štern'],
]

const VRSTA = [
  K(201, 'Anže Vidmar', 'Lan Kolar', 'Člani', 'Skupina 4', ['do konca skupine še 2 kola', 'Vidmar čaka 18 min']),
  K(202, 'Nik Oblak', 'Jakob Zajc', 'Kadeti', 'Skupina 1', ['zadnje kolo skupine']),
  K(203, 'Tina Žnidaršič', 'Pia Ambrožič', 'Članice', 'Skupina A', ['do konca skupine še 3 kola']),
  K(204, 'Gašper Rebolj', 'Andraž Vovk', 'Mladinci', '1/8 finala', ['zmagovalec gre v četrtfinale']),
  K(205, 'Žan Kos', 'Luka Krajnc', 'Člani', 'Skupina 1'),
  K(206, 'Ema Gregorič', 'Ajda Kastelic', 'Članice', 'Skupina B', ['do konca skupine še 3 kola']),
  K(207, 'Bor Kovač', 'Jan Horvat', 'Člani', 'Skupina 4', ['do konca skupine še 2 kola']),
  K(208, 'Sara Bajc', 'Teja Bregar', 'Članice', 'Skupina A'),
  K(209, 'Simon Jug', 'Andrej Šuštar', 'Člani', 'Skupina 2', ['zadnja tekma pred 12 min']),
  K(210, 'Ožbolt / Pečnik', 'Vidic / Gorjup', 'Dvojice', 'četrtfinale', ['mreža čaka na to tekmo']),
  K(211, 'Gal Mlakar', 'Boštjan Glavič', 'Člani', 'Skupina 1'),
  K(212, 'Neža Car', 'Vesna Rot', 'Članice', 'Skupina A', ['do konca skupine še 3 kola']),
  K(213, 'NTK Celje', 'ŠD Kajuh', 'Ekipe', 'Skupina A', ['srečanje na dveh mizah'], { ekipno: true }),
  K(214, 'Erik Kavčič', 'Jaka Ribič', 'Kadeti', 'Skupina 2'),
  K(215, 'Hana Rajh', 'Lucija Pavlič', 'Članice', 'Skupina B', ['do konca skupine še 3 kola']),
  K(216, 'Tadej Mihelič', 'Oskar Rems', 'Kadeti', 'Skupina 3'),
  K(217, 'Luka Krajnc', 'Matic Potočnik', 'Člani', 'Skupina 1'),
  K(218, 'David Bezjak', 'Nace Pintar', 'Mladinci', '1/8 finala', ['zmagovalec gre v četrtfinale']),
  K(219, 'Ula Zorman', 'Ines Kunc', 'Članice', 'Skupina A', ['do konca skupine še 3 kola']),
  K(220, 'Martin Zorko', 'Bor Kovač', 'Člani', 'Skupina 4'),
  K(221, 'Žiga Kuhar', 'Rene Brglez', 'Mladinci', '1/8 finala'),
  K(222, 'Svit Lah', 'Maks Petek', 'Kadeti', 'Skupina 2'),
  K(223, 'Jan Kralj', 'Simon Jug', 'Člani', 'Skupina 2'),
]

const REZERVA = [
  K(301, 'Anže Vidmar', 'Bor Kovač', 'Člani', 'Skupina 4', ['do konca skupine še 1 kolo']),
  K(302, 'Nik Oblak', 'Rene Kolenc', 'Kadeti', 'Skupina 1', ['zadnje kolo skupine']),
  K(303, 'Eva Pirc', 'Neža Car', 'Članice', 'Skupina A', ['do konca skupine še 2 kola']),
  K(304, 'Tim Zupan', 'Blaž Jereb', 'Člani', 'Skupina 3', ['do konca skupine še 2 kola']),
  K(305, 'Urban Hribar', 'Simon Jug', 'Člani', 'Skupina 2', ['do konca skupine še 1 kolo']),
  K(306, 'Lara Hočevar', 'Ema Gregorič', 'Članice', 'Skupina B', ['do konca skupine še 2 kola']),
]

const kopija = (s) => structuredClone(s)

export function ura(min) {
  const h = Math.floor(min / 60) % 24
  const m = ((min % 60) + 60) % 60
  return h + ':' + String(m).padStart(2, '0')
}
export function osebe(t) {
  if (t.ekipno) return [t.a, t.b]
  return [t.a, t.b].flatMap((x) => x.split(' / '))
}
export function priimek(ime) {
  if (ime.includes(' / ') || /^(NTK|ŠD|NK) /.test(ime)) return ime
  const d = ime.trim().split(' ')
  return d[d.length - 1]
}
export const kratko = (t) => priimek(t.a) + ' – ' + priimek(t.b)
export const imena = (t) => t.a + ' – ' + t.b
export const opis = (t) => t.kat + ' · ' + t.del

export function mizSklon(n) {
  const o = n % 100
  if (o === 1) return 'miza'
  if (o === 2) return 'mizi'
  if (o === 3 || o === 4) return 'mize'
  return 'miz'
}

function prazneMize(n, od = 1) {
  const r = []
  for (let st = od; st <= n; st++) r.push({ st, izklopljena: false, tekma: null, prostaOd: null, cakajociSodnik: null, sproscena: 0 })
  return r
}

export function zacetnoStanje(scenarij = 'v-teku') {
  let s = {
    imeTurnirja: 'Odprto prvenstvo Celja 2026',
    steviloMiz: 20,
    porazenecSodi: true,
    pocitekMin: 5,
    ura: URA0,
    mize: prazneMize(20),
    vrsta: VRSTA.map((k) => ({ ...k })),
    rezerva: REZERVA.map((k) => ({ ...k })),
    klici: [],
    izidi: [],
  }
  s.mize[9].izklopljena = true
  for (const [st, t, min, sodnik, miza2] of IGRA) {
    const tk = { ...t, ob: URA0 - min, sodnik: sodnik || null, miza: st, miza2: miza2 || null }
    s.mize[st - 1].tekma = tk
    if (miza2) s.mize[miza2 - 1].tekma = tk
  }
  s.mize[2].prostaOd = URA0 - 2
  s.mize[2].cakajociSodnik = 'Jure Božič'
  s.mize[6].prostaOd = URA0
  s.mize[6].cakajociSodnik = 'Aljaž Košir'
  s.mize[6].sproscena = Date.now()
  s.mize[14].prostaOd = URA0 - 6
  s.klici = IGRA.map(([st, t, min, sodnik, miza2]) => ({
    st, miza2: miza2 || null, imena: imena(t), opis: opis(t), sodnik: sodnik || null, ob: URA0 - min,
  })).sort((a, b) => b.ob - a.ob)

  if (scenarij === 'vse-zasedene') {
    for (const [st, k] of predlogi(s)) s = poklici(s, k.id, st)
    s.mize.forEach((m) => (m.sproscena = 0))
  }
  if (scenarij === 'prvi-zagon') {
    s.steviloMiz = null
    s.mize = []
    s.klici = []
  }
  return s
}

/* Kdo zdaj igra ali sodi: ime -> { st, vloga }. */
export function zasedeni(s) {
  const z = new Map()
  for (const m of s.mize) {
    const t = m.tekma
    if (!t || t.miza !== m.st) continue
    osebe(t).forEach((o) => z.set(o, { st: m.st, vloga: 'igra' }))
    if (t.sodnik) z.set(t.sodnik, { st: m.st, vloga: 'sodi' })
  }
  return z
}

/* Pripravljene tekme z zasedenostjo (kot KandidatMizeDto.zaseden + razlogi). */
export function vrsta(s) {
  const z = zasedeni(s)
  return s.vrsta.map((k) => {
    const r = osebe(k).filter((o) => z.has(o)).map((o) => {
      const x = z.get(o)
      return priimek(o) + ' ' + x.vloga + ' na mizi ' + x.st
    })
    return { ...k, zaseden: r.length > 0, razlogiZasedenosti: r }
  })
}

export const prosteMize = (s) => s.mize.filter((m) => !m.izklopljena && !m.tekma)

/* Predlog za vsako prosto mizo: [st, kandidat]. Ekipnih ne predlaga (rabijo dve mizi). */
export function predlogi(s) {
  const v = vrsta(s).filter((k) => !k.zaseden && !k.ekipno)
  const zasedenoVKrogu = new Set()
  const r = new Map()
  for (const m of prosteMize(s)) {
    const k = v.find((x) => !r.has(x.id) && ![...r.values()].includes(x) && osebe(x).every((o) => !zasedenoVKrogu.has(o)))
    if (!k) continue
    r.set(m.st, k)
    osebe(k).forEach((o) => zasedenoVKrogu.add(o))
  }
  return r
}

export function privzetiSodnik(m, k) {
  const s = m && m.cakajociSodnik
  if (!s || osebe(k).includes(s)) return null
  return s
}

export const minut = (s, t) => Math.max(0, s.ura - t.ob)
export const prostaMin = (s, m) => (m.prostaOd == null ? null : Math.max(0, s.ura - m.prostaOd))

export function poklici(s0, id, st, o = {}) {
  const s = kopija(s0)
  const i = s.vrsta.findIndex((k) => k.id === id)
  if (i < 0) return s0
  const k = s.vrsta.splice(i, 1)[0]
  const m = s.mize[st - 1]
  if (!m || m.tekma || m.izklopljena) return s0
  const sodnik = o.sodnik !== undefined ? o.sodnik || null : privzetiSodnik(m, k)
  const t = { ...k, ob: s.ura, sodnik, miza: st, miza2: o.miza2 || null }
  for (const n of [st, t.miza2]) {
    if (!n) continue
    const x = s.mize[n - 1]
    x.tekma = t
    x.cakajociSodnik = null
    x.sproscena = 0
  }
  s.klici.unshift({ st, miza2: t.miza2, imena: imena(t), opis: opis(t), sodnik, ob: s.ura })
  return s
}

export function vnesiIzid(s0, st, zmagovalec, izid) {
  const s = kopija(s0)
  const t = s.mize[st - 1] && s.mize[st - 1].tekma
  if (!t) return s0
  const porazenec = zmagovalec === 'a' ? t.b : t.a
  for (const m of s.mize) {
    if (!m.tekma || m.tekma.id !== t.id) continue
    m.tekma = null
    m.prostaOd = s.ura
    m.sproscena = Date.now()
    m.cakajociSodnik = m.st === t.miza && s.porazenecSodi && !t.ekipno && !porazenec.includes(' / ') ? porazenec : null
  }
  s.izidi.unshift({ st, imena: imena(t), izid, zmagovalec: zmagovalec === 'a' ? t.a : t.b })
  if (s.rezerva.length) s.vrsta.push(s.rezerva.shift())
  return s
}

export function preklici(s0, st) {
  const s = kopija(s0)
  const t = s.mize[st - 1] && s.mize[st - 1].tekma
  if (!t) return s0
  for (const m of s.mize) if (m.tekma && m.tekma.id === t.id) m.tekma = null
  const { ob, sodnik, miza, miza2, ...k } = t
  s.vrsta.unshift(k)
  return s
}

export function premakni(s0, st, nova) {
  const s = kopija(s0)
  const t = s.mize[st - 1] && s.mize[st - 1].tekma
  const cilj = s.mize[nova - 1]
  if (!t || !cilj || cilj.tekma || cilj.izklopljena) return s0
  s.mize[st - 1].tekma = null
  s.mize[st - 1].prostaOd = s.ura
  if (t.miza2 === st) t.miza2 = nova
  else t.miza = nova
  cilj.tekma = t
  cilj.cakajociSodnik = null
  if (t.miza2 && t.miza2 !== nova) s.mize[t.miza2 - 1].tekma = t
  return s
}

export function izklopi(s0, st, da) {
  const s = kopija(s0)
  const m = s.mize[st - 1]
  if (!m || m.tekma) return s0
  m.izklopljena = da
  return s
}

export function nastavi(s0, { steviloMiz, porazenecSodi, pocitekMin, izklopljene }) {
  const s = kopija(s0)
  const n = Math.max(1, Math.min(99, steviloMiz))
  if (s.mize.length < n) s.mize = s.mize.concat(prazneMize(n, s.mize.length + 1))
  else s.mize = s.mize.slice(0, n)
  s.steviloMiz = n
  if (porazenecSodi !== undefined) s.porazenecSodi = porazenecSodi
  if (pocitekMin !== undefined) s.pocitekMin = pocitekMin
  if (izklopljene) s.mize.forEach((m) => { if (!m.tekma) m.izklopljena = izklopljene.includes(m.st) })
  return s
}

export function tik(s0) {
  return { ...s0, ura: s0.ura + 1 }
}
