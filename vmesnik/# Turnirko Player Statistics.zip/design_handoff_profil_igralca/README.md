# Handoff: Prenova strani profila igralca (Turnirko)

## Pregled

Prenova strani `vmesnik/src/strani/ProfilStran.tsx` — statistika prijavljenega igralca.
Cilj prenove: iste podatke prikazati **razgibano** (kolobar, toplotna karta, sparkline,
razsevni graf, stolpci) namesto ~15 enakih vodoravnih palic, ki jih stran uporablja danes.

Struktura ostaja **ena dolga stran**, urejena kronološko:

```
glava → Napredek ELO → Forma → Nasprotniki → Nizi in točke → Razrezi → Odigrane tekme
```

## O datotekah v paketu

`Profil igralca - prenova.dc.html` je **oblikovalska referenca**, izdelana v HTML/CSS/JS —
prototip, ki kaže želeni izgled, ne produkcijska koda za kopiranje. Naloga je ta izgled
**poustvariti v obstoječem okolju repozitorija**: React 18 + TypeScript + React Router +
TanStack Query, navaden CSS z BEM razredi v slovenščini v `vmesnik/src/slog.css`.

Podatkovni sloj, poizvedbe in razdelitev javno/zasebno ostanejo **nespremenjeni** —
prenovi se samo predstavitev. Obstoječi razredi v `slog.css` so primitivi sistema; nove
razrede dodajaj samo tam, kjer noben obstoječi ne zadošča, in v istem duhu (BEM, slovensko,
brez šumnikov v imenih razredov).

**Zavezujoč je `turnirko-profil-redesign/project/DESIGN.md`.** Če karkoli v tem paketu
nasprotuje DESIGN.md, velja DESIGN.md.

## Fidelity

**High-fidelity.** Barve, tipografija, razmiki in postavitev so končni. Poustvari
piksel natančno, z obstoječimi spremenljivkami iz `slog.css` (`var(--barva-…)`, `var(--r…)`,
`var(--tip-…)`, `var(--pisava-…)`) — v prototipu so vrednosti zapisane dobesedno samo zato,
ker prototip nima dostopa do `slog.css`.

---

## OBVEZNI POSTOPEK: primerjaj s posnetki, dokler se ne ujema

V mapi `screenshots/` je 9 posnetkov prenovljene strani. **Delo ni končano, dokler se tvoja
implementacija ne ujema z njimi.** Postopek:

1. Implementiraj sekcijo.
2. Zaženi vmesnik (`npm run dev`), odpri profil igralca in **posnemi zaslon iste sekcije**
   pri širini okna 1360 px (vsebinski okvir je 1280 px) oz. 390 px za mobilni pogled.
3. Svoj posnetek **postavi ob referenčni posnetek in ju primerjaj** — element za elementom:
   velikost in teža pisave, barva, debelina in barva črt, navpični in vodoravni razmiki,
   širine stolpcev v mrežah, poravnave številk.
4. Popravi vsako odstopanje in **ponovi koraka 2–3**. Ne nadaljuj na naslednjo sekcijo,
   dokler se trenutna ne ujema.
5. Na koncu enako primerjaj še celo stran z `01-namizje-cela-stran.png` in mobilni pogled
   z `09-mobilno-390.png`.

Posnetki:

| Datoteka | Kaj pokriva |
|---|---|
| `01-namizje-cela-stran.png` | cela stran, 1280 px (referenca za vrstni red in razmike med sekcijami) |
| `02-glava.png` | naslov, značka mesta, tri velike številke, blok ELO, kolofon |
| `03-napredek-elo.png` | graf ELO + pričakovan proti doseženemu izkupičku |
| `04-forma.png` | trak Z/P, kolobar, kazalniki niza, okolica na lestvici |
| `05-nasprotniki.png` | izpostavljeni, H2H tabela s sparkline, razsevni graf |
| `06-nizi-in-tocke.png` | toplotna karta izidov, pod pritiskom, točke |
| `07-razrezi.png` | štiri skupine razrezov v kompaktni mreži |
| `08-odigrane-tekme.png` | tabela tekem |
| `09-mobilno-390.png` | mobilni pogled |

Odstopanja, ki jih **ne** popravljaj: konkretne številke in imena (v prototipu so izmišljena),
dolžina seznamov.

---

## Oblikovni žetoni

Vsi že obstajajo v `slog.css`. V prototipu uporabljene dobesedne vrednosti in njihove spremenljivke:

| Vrednost | Spremenljivka | Vloga |
|---|---|---|
| `#FBF9F5` | `--barva-papir` | podlaga strani |
| `#14110F` | `--barva-crnilo` | besedilo, 3 px črte |
| `#332E29` | `--barva-crnilo-2` | odstavki |
| `#5B534D` | `--barva-crnilo-3` | mono oznake, meta |
| `#DED7CE` | `--barva-crta` | hairline |
| `#EDE7DF` | `--barva-polnilo` | prazen del kolobarja/osi |
| `#0088CE` | `--barva-glavna` | črte grafa, označevalci, obroba |
| `#0071AB` | `--barva-glavna-polna` / `--barva-glavna-tekst` | blok ELO, povezave, stolpci |
| `#EAF3F9` | `--barva-glavna-mehko` | podlaga tvoje vrstice v okolici |
| `#7BB900` | `--barva-poudarek` | značka mesta, kolobar, najgostejše celice |
| `#4A7500` | `--barva-poudarek-tekst` | zmage, pozitivne spremembe |
| `#EAF4D6` | `--barva-poudarek-mehko` | redke zmagovalne celice, znak Z |
| `#B23A1E` | `--barva-negativna` | porazi, negativne spremembe |
| `#8C2B14` | `--barva-negativna-tekst` | besedilo na rjasti mehki podlagi |
| `#F8E5DF` | `--barva-negativna-mehko` | redke poražene celice, znak P |
| `#E8F5C4` | `--barva-na-glavni-2` | »vrh« v bloku ELO |

Ritem 8 px (`--r1`…`--r8`), `border-radius: 0` povsod, brez senc (izjema: podčrtaj aktivne
navigacijske postavke). Pisave: Bricolage Grotesque (display), Karla (telo), IBM Plex Mono (oznake).

Nove barve za toplotno karto (interpolacija med mehko in polno; **edine nove vrednosti v paketu**):
`#C6E28A` (srednja zelena) in `#E2A793` (srednja rjasta). Predlagam `--barva-poudarek-srednje`
in `--barva-negativna-srednje` v `slog.css`.

---

## Sekcije

Vse sekcije so ločene s `56px` (`--r7`) in se začnejo z naslovno vrstico
`border-top: 3px solid var(--barva-crnilo); padding-top: 16px`, naslov `40px/800` levo,
mono meta ali segmentirani izbirnik desno (obstoječi razred `.naslovna-vrstica`).

### 1. Glava strani

Mreža `minmax(0,1fr) 380px`, `gap: 56px`, `align-items: start`.

Levi stolpec (nespremenjen glede na danes, razen zadnjega bloka):
- vrstica uvrstitve: značka `mesto. / skupaj` (zelena podlaga, mono 12/600, `padding: 5px 9px`)
  + percentil v mono 12 uppercase, `letter-spacing: 0.14em`
- naslov: nadnaslov `ime` 48 px/200 sivo, naslov `priimek` 88 px/800, `line-height: 0.88`
- meta vrstica: klub · roka · »Tvoj profil« (modro, 700)
- **NOVO:** namesto bloka »okolica na lestvici« so tu **tri velike številke** v mreži
  `repeat(3, 1fr)`, `margin-top: 40px`: `odigrane` / `zmage–porazi` / `odstotek %`.
  Vrednost: Bricolage 48 px/800, `letter-spacing: -0.04em`, `tabular-nums`.
  Oznaka pod njo: mono 12 uppercase, `margin-top: 8px`.
  Ločila: 1. stolpec `padding-right: 24px`, 2. `padding-left: 24px; border-left: 1px solid var(--barva-crta)`,
  3. `padding-left: 24px; border-left: 4px solid var(--barva-glavna)` (poudarjen).
  To je obstoječi vzorec `.kazalnik` / `.kazalnik--poudarjen`.

Desni stolpec:
- `.elo-blok` nespremenjen: polna `--barva-glavna-polna`, `padding: 24px`, oznaka mono 12,
  vrednost 112 px/800 `line-height: 0.82`, noga `+31 / 30 dni` ⟷ `vrh 1642` (zelena `#E8F5C4`)
- `.kolofon` pod njim, `margin-top: 24px`, **štiri vrstice** (ne pet):
  Klubsko povprečje (z zeleno razliko), Turnirji / lige, Zadnja tekma, Do N. mesta.
  Vrstici »Mesto«, »Odigrane«, »Zmage – porazi«, »Uspešnost« odpadejo — prevzamejo jih velike številke levo.

Blok »okolica na lestvici« se preseli v sekcijo Forma (glej spodaj).

### 2. Napredek ELO

**Graf** — obstoječa komponenta `GrafElo` ostane, spremeni se le postavitev oznak:
oznake osi Y in datuma sta zdaj **HTML** (absolutno pozicionirana nad `position: relative` ovojem),
ne `<text>` v SVG. Geometrija (mreža, ploskev 8 %, črta 2,5 px, pike 3,5 px v barvi izida) nespremenjena.
Segmentirani izbirnik obdobja (Vse · N / 12 mesecev / 3 meseci) ostane v naslovni vrstici.
Pod grafom vrstica podrobnosti v mono 14 (nespremenjena).

**NOVO — Pričakovan proti doseženemu izkupičku.** Podnaslov sekcije
(mono 12 uppercase + hairline), `margin-top: 40px`. Mreža `minmax(0,1fr) 320px`, `gap: 56px`.

- Levo: stolpčni graf po mesecih. Stolpec = dosežene zmage, polna `--barva-glavna-polna`,
  širina 26 px, korak 72 px. Vodoravna črna črta 2 px čez stolpec = **pričakovane zmage**
  glede na ELO nasprotnikov. Pod vsakim stolpcem mono 11: kratica meseca in pod njo razlika
  (`+1,6` zeleno / `−0,8` rjasto).
- Desno: vrstica `Nad pričakovanji` ⟷ velika številka 40 px/800 v zeleni, pod njo pojasnilo
  15 px/300, `max-width: 46ch`.

Označeno kot **predlog — potrebuje novo polje v API** (glej spodaj).

### 3. Forma

Mreža `minmax(0,1.35fr) minmax(0,1fr)`, `gap: 56px`.

Levi stolpec:
- trak zadnjih 10 tekem: `display: flex; gap: 2px`, vsak znak `flex: 1; height: 48px`,
  Z = `--barva-poudarek-mehko` / `--barva-poudarek-tekst`, P = `--barva-negativna-mehko` / `--barva-negativna-tekst`,
  mono 15/600 (obstoječ `.forma__trak`). Pod trakom vrstica mono 12: opis levo, bilanca `8–2` desno.
- **NOVO — kolobar deleža zmag.** Mreža `200px minmax(0,1fr)`, `gap: 40px`, `margin-top: 40px`.
  SVG 160×160, `viewBox 0 0 160 160`, dva kroga `r=60`, `stroke-width: 18`, brez zaokroženih kap:
  podlaga `--barva-polnilo`, lok `--barva-poudarek`, `stroke-dasharray = odstotek/100 × 376.99`,
  `transform: rotate(-90 80 80)`. Sredina: odstotek Bricolage 40/800 in pod njim mono 11
  `ZMAG` (`letter-spacing: 0.1em`) — **kot HTML nad SVG**, ne kot `<text>`.
- Desno od kolobarja tri vrstice `.forma__kazalnik` (mono oznaka ⟷ 40 px/800):
  Niz zmag, Najdaljši niz zmag, Najvišji ELO.

Desni stolpec — **okolica na lestvici** (preseljena iz glave, sicer nespremenjena):
glava z mono oznako in povezavo »Celotna lestvica →«, tri vrstice
`grid-template-columns: 40px minmax(0,1fr) 72px 64px`, tvoja vrstica dobi
`border-left: 4px solid var(--barva-glavna)`, `background: var(--barva-glavna-mehko)`, `padding-left: 8px`.
Pod njo stavek »Do N. mesta ti manjka X točk ELO — približno 2 zmagi proti močnejšemu nasprotniku.«

### 4. Nasprotniki

- **Izpostavljeni** (Najboljša zmaga / Nemesis / Najpogostejši nasprotnik):
  `repeat(3, 1fr)`, `gap: 32px`, vsak `border-top: 3px solid var(--barva-poudarek)`,
  naslov mono 12, ime Bricolage 24/800, opis 15/300 (obstoječ `.izpostavljen`). Nespremenjeno.
- **NOVO — H2H tabela s sparkline.** Podnaslov + glava tabele, vrstice v mreži
  `minmax(0,1fr) 96px 120px 88px 72px`, `gap: 16px`, `padding: 14px 0`, hairline spodaj.
  Stolpci: ime (17/700 modro) + klub (14/300), bilanca (mono 17/600 v barvi izida),
  **sparkline** SVG 120×28 — vodoravna hairline sredi in `polyline` 2 px v `--barva-glavna`,
  ki se ob zmagi dvigne za 5, ob porazu spusti za 5 (korak 17 px); zadnja točka je pika r=3
  v barvi skupne bilance —, njegov ELO (mono 17/600), skupno število tekem (mono 14).
- **NOVO — razsevni graf ELO nasprotnika proti izidu.** `viewBox 0 0 1120 300`,
  vodoravna os (sprememba 0) polna 1 px črnilo, navpična črtkana `--barva-glavna` `4 4`
  pri tvojem ELO z oznako »TVOJ ELO 1642« zgoraj. Pika `r=4`, `opacity: 0.85`,
  zelena za zmago, rjasta za poraz. Oznake osi (+25 / 0 / −25 levo, ratingi spodaj)
  so **HTML**, absolutno pozicionirani nad SVG. Pod grafom pojasnilo 15/300.

### 5. Nizi in točke

- **NOVO — toplotna karta končnih izidov.** `repeat(6, minmax(0,1fr))`, `gap: 8px`.
  Celica: višina 112 px, `display: grid; place-items: center`, podlaga po pogostosti:
  delež ≥ 0,75 max → polna (`#7BB900` / `#B23A1E`), ≥ 0,45 → srednja (`#C6E28A` / `#E2A793`),
  sicer mehka (`#EAF4D6` / `#F8E5DF`). Besedilo v celici: izid Bricolage 40/800 in `×N` mono 13/600;
  barva besedila mora biti izrecno zapisana — na polni zeleni `--barva-crnilo`,
  na polni rjasti bela, sicer `--barva-poudarek-tekst` / `--barva-negativna-tekst`.
  Pod celico mono 11: delež v odstotkih in kratek opis (`BREZ IZGUBLJENEGA NIZA`, `ODLOČILNI NIZ`, …).
  Ta karta **nadomesti** dosedanji seznam `.profil__razmerja`.
- **Pod pritiskom** (levi stolpec mreže `1fr 1fr`, `gap: 56px`): dve veliki številki
  (odločilni niz `13:11`, uspešnost `54 %` s poudarjenim `border-left: 4px`), pod njima tri vrstice
  `minmax(0,1fr) 200px 88px`: oznaka, **os 0–100 % brez polnila** (hairline 200 px, sredinska
  oznaka pri 50 %, označba `rect` 2×14 px v črnilu; rjasta, če je vrednost pod 50 %), vrednost mono 16/600.
- **Točke** (desni stolpec): štiri velike številke v mreži `1fr 1fr`, `row-gap: 32px`
  (Osvojene / Prejete / Delež / Povprečje na niz), pod njimi obstoječa opomba.

### 6. Razrezi

Nadomesti dosedanji sekciji »Po tekmovanjih« in palice v »Nasprotnikih«.
Mreža `repeat(2, 1fr)`, `gap: 56px`. Štiri skupine:

1. Po igralni roki nasprotnika
2. Po moči nasprotnika
3. Turnirji, lige, gostovanja
4. Po fazi in poziciji

Vsaka skupina: podnaslov (mono 12 + hairline), glava tabele (mono 11), nato vrstice v mreži
`minmax(0,1fr) 64px 80px 160px 56px`, `gap: 16px`, `padding: 12px 0`, hairline spodaj:
oznaka 17, število tekem (mono 15 sivo), `Z–P` (mono 15/500), **os 0–100 % brez polnila**
(160 px hairline, oznaka pri 50 %, označba 2×14 px; rjasta pri < 50 %), odstotek (mono 16/600).

**Nobenih polnjenih vodoravnih palic.** `.delez__stolpec` / `.delez__polnilo` se na tej strani
ne uporabljata več.

### 7. Odigrane tekme

Nespremenjeno, le tabela je zapisana kot mreža namesto `<table>`:
`104px minmax(0,1fr) minmax(0,1fr) 128px 96px`, `gap: 16px`, `padding: 14px 0`, hairline.
Rezultat Bricolage 36/800 v barvi izida, sprememba ELO mono 14/600 v isti barvi.
Če ohraniš `<table>`, uporabi obstoječe razrede `.tabela` — vizualni rezultat mora biti enak posnetku.

---

## Mobilni pogled (390 px)

Glej `09-mobilno-390.png`. Prelomna točka pri 768 px:

- vsebina `padding: 24px 16px 32px`, razmik med sekcijami 32 px
- naslov: nadnaslov 28 px, naslov 48 px
- blok ELO čez celo širino, številka 72 px
- graf ELO brez oznak osi, samo črta in ploskev
- trak forme: znak visok 36 px
- kolobar 120 px v mreži `120px 1fr` s kazalniki desno
- tabela tekem se sesede v dva stolpca: ime + (datum · tekmovanje) levo, izid desno
- vse zadetkovne površine ostanejo ≥ 44 px

---

## Nova polja v API (predlogi)

Trije bloki so v prototipu označeni z »PREDLOG — POTREBUJE NOVO POLJE V API«.
Če jih ne implementiraš, sekcije preprosto izpusti — postavitev drugih ne poruši.

1. **Pričakovan proti doseženemu izkupičku** — za vsak mesec: dosežene zmage in
   pričakovane zmage (vsota `1 / (1 + 10^((eloNasprotnika − mojElo)/400))` čez tekme meseca).
   Predlog: `ProfilForma.poMesecih: { mesec: string; zmage: number; pricakovaneZmage: number }[]`.
2. **ELO nasprotnika proti izidu** — za razsevni graf potrebuješ ELO nasprotnika **ob tekmi**.
   Predlog: `TekmaProfila.ratingNasprotnika: number | null` (in isto v `TockaGrafa`).
3. **Pod pritiskom** — delež dobljenih točk pri izidu 9:9 in več ter delež tekem brez
   izgubljenega niza. Predlog: razširitev `ProfilTocke` z `odstotekTockPodPritiskom`
   in `ProfilNiziInTocke.brezIzgubljenegaNiza: Delez`.

Vse tri sodijo v **zasebni** del profila (`profiliApi.zasebno`), ki ga vidita samo igralec in administrator.

## Interakcije

- Segmentirani izbirnik obdobja nad grafom ELO: `vse` / `12m` / `3m`, aktivni gumb
  `background: var(--barva-crnilo); color: var(--barva-papir)`. Logika filtriranja že obstaja v `GrafElo.tsx`.
- Pika grafa: `mouseenter` / `focus` izbere točko in osveži vrstico podrobnosti pod grafom (obstoječe).
- Povezave na nasprotnike vodijo na `/igralci/:id/profil`.
- Prehodi: samo barva/obroba do 120 ms. Nobenih drugih animacij.
- Stanja nalaganja, napake in 403 (»Poglobljene analize vidi samo igralec sam«) ostanejo,
  kot so danes v `ProfilStran.tsx`.

## Stanje

Novega globalnega stanja ni. Lokalno: izbrano obdobje grafa in izbrana točka grafa
(oboje že obstaja v `GrafElo`). Vsi izpeljani podatki (deleži, toplotna karta, sparkline,
razsevni graf) se izračunajo iz `ProfilDto` in `ProfilZasebnoDto` med izrisom — brez novih poizvedb.

## Sredstva

Nobenih novih. Edina ikona v vmesniku ostaja logotip (`ZnakTurnirko` v `Postavitev.tsx`).
Grafi so lasten SVG, brez knjižnic. Pisave so že vgrajene lokalno prek fontsource.

## Datoteke v paketu

- `README.md` — ta dokument
- `Profil igralca - prenova.dc.html` — oblikovalska referenca (odpri v brskalniku)
- `support.js` — izvajalno okolje prototipa (potrebno le za odpiranje reference)
- `screenshots/` — 9 referenčnih posnetkov

Datoteke v repozitoriju, ki jih boš spreminjal:
`vmesnik/src/strani/ProfilStran.tsx`, `vmesnik/src/komponente/GrafElo.tsx`,
`vmesnik/src/slog.css` (razdelek 12), po potrebi `vmesnik/src/api/tipi.ts`.
