# Predaja: prenova »Popravi skupine«, »Popravi mrežo« in »Listki za tiskanje«

Odločitev lastnika (23. 11. 2026): izbrane so različice **Skupine 1a**, **Mreža 1b** in **Listki 1b**.
Cilj prenove je **preglednost in intuitivnost**. Organizator mora na prvi pogled videti celoten žreb oz.
stanje tiska, z manj besedila in brez dolgih seznamov izbirnikov.

---

## 1. O datotekah v tem paketu

Datoteke v `prototipi/` so **oblikovalske reference v HTML**. Gre za klikljive prototipe, ki kažejo videz in
vedenje, **ne za kodo, ki bi jo kopiral**. Naloga je, da te zaslone **ponovno zgradiš v obstoječem vmesniku
Turnirka** (`vmesnik/`, React + TypeScript + Vite, navaden CSS z BEM razredi v `src/slog.css`, podatki prek
TanStack Query). Upoštevaj obstoječe vzorce, komponente in poslovno logiko.

- Prototipi uporabljajo samo inline sloge. V aplikaciji jih prepiši v **BEM razrede v `slog.css`**, z
  obstoječimi spremenljivkami (`--barva-*`, `--pisava-*`, `--r1…--r8`). Inline slogov in CSS-in-JS v aplikaciji ni.
- Natančna vrednost vsake mere, barve in pisave je zapisana v inline slogih prototipov. Če se ta dokument in
  prototip ne ujemata, velja **prototip**.
- `podatki.js` vsebuje izmišljene, a stalne vzorčne podatke: 48 igralcev, 12 skupin po 4, mrežo 64 s 16
  prostimi mesti in 72 listkov. Iz njih so narejeni vsi posnetki.

### Kako odpreš prototipe
Prototipi z `import()` naložijo `podatki.js`, zato prek `file://` ne delujejo. Postrezi mapo prek HTTP:
```
cd design_handoff_skupine_mreza_listki/prototipi
npx serve .        # ali: python -m http.server 8000
```
Nato odpri:
- `Skupine 1a.dc.html`, `Mreza 1b.dc.html`, `Listki 1b.dc.html`: posamezen prototip čez celo okno.
- `Posnetki.dc.html`: vseh 20 stanj v okvirjih s stalno velikostjo (id-ji `s01`…`l06`). Iz te strani so
  narejeni posnetki v `posnetki/`.
- `Trenutno stanje.dc.html`: prepis sedanjih oken za primerjavo.

## 2. Natančnost: visoka (hifi)

Barve, pisave, razmiki, robovi in stanja so končni. Zaslone ponovi **do piksla natančno**.

---

## 3. ⚠ Postopek: primerjaj s posnetki, dokler se ne ujemajo

To ni neobvezno. Zaslona ne štej za končanega, dokler se ne ujema s posnetkom.

1. **Razvojna pot s stalnimi podatki.** Po zgledu obstoječih `src/dev/*Posnetki.tsx`
   (npr. `KoncnaRazvrstitevPosnetki`, `ProfilGlavaPosnetki`) naredi pot, npr.
   `/dev/prenova-zreba?zaslon=skupine|mreza|listki&naprava=namizje|telefon&stanje=…`.
   Podatke prepiši iz `prototipi/podatki.js` (imena, klubi, ratingi, razpored skupin, mreža, listki), da so
   na zaslonu ista imena na istih mestih.
2. **Stanja** naj bodo ista kot v tabeli posnetkov spodaj (prop `demo` v prototipih pove, kako je stanje
   pripravljeno; glej funkcijo `demo()` v logiki vsakega prototipa).
3. **Posnemi** svojo stran v brezglavem Chromu (Playwright/Puppeteer): okno **1280 × 900** za namizje in
   **390 × 844** za telefon, `deviceScaleFactor: 1`.
4. **Primerjaj piksle** s PNG v `posnetki/`, npr. s `pixelmatch` (prag 0.1). Diff-sliko shrani poleg, kot pri
   `design_handoff_udelezenci/diffs/`.
5. **Ponavljaj**, dokler:
   - se lege in velikosti vseh besedil, črt in ploskev ne ujemajo (odstopanje ≤ 1 px),
   - je delež različnih pikslov **pod 0,5 %** za vsak posnetek (zglajevanje pisav in drsnik),
   - na diff-sliki ni nobene vidne razlike v postavitvi, barvi ali besedilu.
6. **Ko PNG in tvoja stran ne soglašata zaradi upodobitve** (posnetki so narejeni z rasterizacijo DOM,
   zato je zglajevanje lahko drugačno), je merilo prototip, ki ga v **istem** brezglavem Chromu posnameš iz
   `Posnetki.dc.html` (element `#s01` … `#l06`). Tako je repo delal že pri prenovi končne razvrstitve
   (DESIGN.md 5h).
7. Pisava **Bricolage Grotesque** je v prototipu Google Fonts z optično osjo `opsz`. Če se velike številke
   (npr. »14« pri listkih) ne ujemajo po širini, preveri `font-variation-settings` (DESIGN.md 5g opisuje isto past).

### Posnetki (`posnetki/`)
| Datoteka | Zaslon | Stanje |
|---|---|---|
| `s01-skupine-1a-namizje-popravek.png` | Popravi skupine | po žrebu, brez sprememb |
| `s02-skupine-1a-namizje-izbran.png` | Popravi skupine | izbran igralec (Rok Pirc), cilji »+ Premakni sem« |
| `s03-skupine-1a-namizje-spremembe.png` | Popravi skupine | 4 premaknjeni, gumb Shrani omogočen |
| `s04-skupine-1a-namizje-napaka.png` | Popravi skupine | 13 skupin, skupina 13 prazna → napaka |
| `s05-skupine-1a-namizje-rocni-vpis.png` | Ročni vpis skupin | vsi brez skupine |
| `s06…s08-skupine-1a-telefon-*.png` | isto, telefon | popravek, izbran, ročni vpis |
| `m01-mreza-1b-namizje-popravek.png` | Popravi mrežo | 1. četrtina, brez sprememb |
| `m02-mreza-1b-namizje-rocna-mreza.png` | Ročna mreža | pred žrebom (predlog) |
| `m03-mreza-1b-namizje-odlagalisce.png` | Popravi mrežo | igralec z mesta 11 na odlagališču → mesto prazno |
| `m04-mreza-1b-namizje-napaka.png` | Popravi mrežo | par 1 ima dve prosti mesti |
| `m05/m06-mreza-1b-telefon-*.png` | isto, telefon | popravek, spodnji list z iskanjem |
| `l01-listki-1b-namizje-nic-natisnjeno.png` | Listki | nič natisnjeno, izbrano 1. kolo |
| `l02-listki-1b-namizje-1-kolo-natisnjeno.png` | Listki | 1. kolo in del 2. natisnjena |
| `l03-listki-1b-namizje-nepoln-list.png` | Listki | 14 listkov, ponudba »dopolni s praznimi« |
| `l04-listki-1b-namizje-potrditev-tiska.png` | Listki | po tisku: »Si natisnil …?« |
| `l05/l06-listki-1b-telefon-*.png` | isto, telefon | izbira, potrditev |

---

## 4. Zasloni

### 4.1 Popravi skupine / Ročni vpis skupin (različica 1a)
**Zamenja:** UI v `src/komponente/RocniSkupineOkno.tsx`. Okno odpre `DogodekStran.tsx`, gumb »Ročni vpis
skupin« oz. »Popravi skupine«. **Logika ostane:** `predlogSkupin` / `rocniSkupine`, `izPredloga`,
`izTrenutnih`, `nastaviSteviloSkupin`, `nastaviSkupino`, preverjanja `opozorila` in `svarila`.

**Postavitev (namizje):** `ModalnoOkno` v novi, **zelo široki** velikosti: `max-width: 1180px`, zastor z
odmikom `40px 32px`, okno raztegnjeno na višino zaslona (`max-height: 100%`). Telo drsi samo, glava,
orodna vrstica in noga stojijo. Dodaj npr. prop `zelo-siroko` / razred `.modal--zelo-siroko`.
- **Glava:** padding `20px 24px 16px`, spodaj 3 px črnilo. Nadnaslov mono 12/500, `.1em`, verzalke,
  `#5b534d` (»Moški posamezno · 48 igralcev«). Naslov 28 px Bricolage 800, `-.03em` (»Popravi skupine« oz.
  »Ročni vpis skupin«). Desno »✕« 44 × 44.
- **Orodna vrstica:** padding `12px 24px`, spodaj 1 px `#ded7ce`, gap 8.
  Oznaka »SKUPIN« (mono 12) in koračnik: okvir 1 px črnilo, bela podlaga, gumba − / + 44 × 44 z notranjo
  črto `#ded7ce`, vmes število 52 px širine, mono 600 17 px, tabelarične številke. Meja je 2–26. Pri formatu
  TOP (`sistem === 'SKUPINE'`) je koračnik onemogočen.
  Sledita `.gumb--majhen` »Naključno« (pri ročnem vpisu »Predlog žreba«; oba ponovno naložita predlog) in
  »Razveljavi spremembe« (vrne izhodišče okna). Desno je namig 15 px / 300 `#5b534d`:
  »Klikni dva igralca in zamenjata se.«
- **Telo:** padding `20px 24px 24px`.
  - **Bazen »Brez skupine«** (samo če kdo nima skupine; pri TOP se imenuje »Rezerve« in ni napaka):
    ploskev `#ede7df`, padding 16. Naslov 17 px Bricolage 800 + mono števec. Čipi: min-height 40,
    padding `6px 10px`, 1 px `#ded7ce`, bela podlaga; ime 300 + priimek 700 14 px, rating mono 12 pri
    motnosti .75. Izbran čip ima modro polno podlago `#0071ab` in belo besedilo.
  - **Mreža skupin:** `grid-template-columns: repeat(4, minmax(0,1fr))`, gap `28px 24px`.
    Skupina: zgoraj 3 px črnilo (rjasto `#b23a1e` pri < 2 igralcih). Glava `10px 0 8px`, spodaj 1 px
    `#ded7ce`: »Skupina N« 20 px Bricolage 800, desno mono 12 `Ø 1830` (povprečni rating), pri napaki
    »1 igralec« v `#8c2b14`, pri prazni »prazna«.
    **Vrstica igralca** (cel gumb): grid `18px 1fr auto`, gap 10, min-height 52, padding `6px 10px 6px 8px`,
    spodaj 1 px `#ded7ce`, levo 4 px rob. Mesto (1–4) mono 600 12. Ime 300 + priimek 700, 15 px, en
    vrstica z »…«. Pod njim klub 12 px `#5b534d`. Desno rating mono 500 13.
    - privzeto: prozorna podlaga, rob prozoren, hover `#eaf3f9`;
    - **premaknjen** (drugačen od izhodišča): podlaga `#eaf3f9`, levi rob `#0088ce`;
    - **izbran:** podlaga in rob `#0071ab`, besedilo belo, drugotno `#e8f5c4`.
    **Prosta mesta** do 4: 52 px, 1 px črtkano `#ded7ce`, mono 12 verzalke »PROSTO« `#6e655e`. Ko je
    igralec izbran, dobi **vsaka druga skupina** prvo prosto mesto kot cilj »+ PREMAKNI SEM«
    (črtkano `#0088ce`, podlaga `#eaf3f9`, besedilo `#0071ab`). Polna skupina dobi dodatno ciljno mesto.
- **Noga:** padding `16px 24px`, zgoraj 3 px črnilo. Levo je kvadratek 12 × 12 v barvi stanja in stavek
  stanja 15 px. Desno so mono števec »N premaknjenih« (`#0071ab`), »Prekliči« (`.gumb`, zapre okno) in
  glavni gumb (`.gumb--glavni`): »Shrani popravek« oz. »Shrani in začni dogodek«.

**Stanja noge** (velja prvo, ki drži):
| Stanje | Kvadratek | Besedilo |
|---|---|---|
| izbran igralec | `#0088ce` | »Izbran {ime} (skupina N). Klikni igralca za zamenjavo ali »Premakni sem«.« v `#0071ab` + mono povezava »PREKLIČI IZBIRO« |
| kdo brez skupine | `#ede7df` | »Razporedi še N igralcev: klikni igralca, nato prosto mesto.« |
| skupina < 2 | `#b23a1e` | »Skupina 13 potrebuje vsaj 2 igralca.« v `#8c2b14` |
| vse v redu | `#7bb900` | »Vse je v redu: 12 skupin po 4.« |
Shrani je onemogočen pri napaki, med izbiro in pri popravku brez sprememb. Onemogočen ima podlago
`#ede7df` in besedilo `#6e655e`. Obstoječa **svarila** (skupina > 4 pri skupine+izločilni) ne ustavijo
shranjevanja: dodaj jih kot drugi stavek za »Vse je v redu«, npr. »Skupina 3 ima 5 igralcev (običajno največ 4).«

**Interakcija:** prvi klik izbere igralca, drugi klik na drugega igralca zamenja njuni `(skupina, pozicija)`.
Klik na istega izbiro prekliče. »+ Premakni sem« pokliče obstoječi `nastaviSkupino` (igralec gre na konec,
stara skupina zapre vrzel). Escape najprej prekliče izbiro, šele nato zapre okno. Vrstice so `<button>`,
zato tipkovnica deluje sama.

**Telefon (≤ 640 px):** celozaslonski list. Glava `14px 8px 12px 16px` (nadnaslov mono 11, naslov 24 px).
Orodja v eni vrstici: koračnik (število + »SKUPIN« mono 9 pod njim), »Naključno«, desno »Razveljavi«.
Skupine so ena pod drugo (vrstica 52 px, ime 16 px). Noga je lepljiva: stavek stanja, pod njim gumb 48 px čez
celo širino. Med izbiro je to »Prekliči izbiro« (obroba), sicer »Shrani popravek«.

### 4.2 Ročna mreža / Popravi mrežo (različica 1b)
**Zamenja:** UI v `src/komponente/RocnaMrezaOkno.tsx`. Odpre ga `IzlocilniZreb.tsx` za IZLOCILNI in za
izločilni del SKUPINE_IZLOCILNI. **Logika ostane:** `predlog()`, `shrani(idjiPoMestih)`, zamenjava v
`izberi()`, pravilo »dve prosti mesti v istem paru = napaka«.

**To je izjema od DESIGN.md (odločitev lastnika):** delovna ploskev čez cel zaslon s **črno glavo** namesto
navadnega okna, mreža s črtami in **vlečenje z miško**. V DESIGN.md dodaj razdelek, npr. »5k. Delovna
ploskev žreba«.

**Postavitev (namizje):** `ModalnoOkno` čez cel zaslon (nov prop, npr. `celZaslon`), podlaga `#fbf9f5`.
- **Črna glava**, 72 px, `#14110f`, padding `0 24px 0 12px`: »✕« (`#cfc7bd`), nadnaslov mono 11 `.12em`
  `#cfc7bd` (»Moški posamezno · 48 igralcev · mreža 64«), naslov 26 px Bricolage 800 papir. Desno so stanje
  (kvadratek 10 px + mono 12 verzalke), gumbi z obrobo `#5b534d` in papirnim besedilom (»Naključno« oz. pri
  ročni mreži »Nov predlog«, »Razveljavi«) in glavni gumb. Onemogočen glavni gumb ima podlago `#332e29`
  in besedilo `#8a8078`.
- **Levo: mreža četrtine** (padding `16px 32px`). Glava je grid `400px 32px 300px 1fr`, spodaj 3 px
  črnilo: »1. četrtina · mesta 1–16« (24 px Bricolage 800), mono »1. KOLO« in »2. KOLO«, desno namig 14/300.
  Mreža so 4 bloki (vsak po 2 para in 1 tekma 2. kola), gap 16:
  - **Mesto** 38 px: grid `26px 1fr auto`, levo 4 px rob. Številka mono 11, nosilec kot črna značka
    (`#14110f`, mono 600 11, padding `2px 5px`), priimek 700 + ime 300 15 px, klub mono 11, rating mono 13.
    Prosto mesto ima šrafuro `repeating-linear-gradient(135deg,#e2dbd1 0 4px,#f4f0ea 4px 8px)` in besedilo
    »prosto« `#5b534d`.
  - **Par** je okvir 1 px `#ded7ce` (rjast `#b23a1e` pri dveh prostih), med paroma gap 10.
  - **Povezava:** 32 px širok okvir, 2 px črnilo brez levega roba, višina 86 px, od vrha 38 px. Na desni je
    vodoravna črta 30 px.
  - **Tekma 2. kola** (270 px, 1 px črnilo, papir): dve vrstici po 38 px. Če ima par prosti prehod, je tam
    ime igralca 700 + mono »PROSTI PREHOD«; sicer »Kralj / Hribar« `#5b534d` + »ZMAGOVALEC 3–4«.
- **Desno: stolpec 300 px**, levo 3 px črnilo, podlaga `#ede7df`.
  - »ČETRTINE«: štirje gumbi, padding `10px 12px`, levi rob 4 px. Vsak ima naslov 17 px 800, razpon mest
    mono 11 in dva najvišja nosilca »[1] Kos · [8] Vidmar«. Aktiven: črna podlaga, papir, levi rob `#0088ce`.
    Z napako: levi rob `#b23a1e`, meta »napaka«. S praznim mestom: meta »N prazno«.
  - **Odlagališče:** 2 px črtkano `#c9c1b6` (med vlečenjem z mesta `#0088ce` + `#eaf3f9`). Odloženi
    igralci so vrstice 38 px, ki jih lahko povlečeš nazaj.

**Interakcija (namizje):**
- Povleci mesto na mesto: zamenjata se (tudi prosto mesto).
- Med vlečenjem `dragenter` na gumb četrtine preklopi pogled v to četrtino.
- Povleci na odlagališče: mesto postane **prazno** (stanje samo v odjemalcu, ne `null`). Prazno mesto ima
  črtkano rjasto obrobo in besedilo »spusti sem«. Dokler je kaj praznega, je Shrani onemogočen.
- Ciljno mesto med vlečenjem: `outline: 2px solid #0088ce` (odmik −2) in podlaga `#eaf3f9`. Vleceni element
  ima motnost .35.
- Spremenjeno mesto: levi rob 4 px `#0088ce`.
- **Dodaj tipkovnico** (prototip je nima): Enter/preslednica na mestu ga izbere, drugo mesto ga zamenja.
  To je isto kot pri skupinah 1a.

**Stanja:** pripravljeno (`#7bb900`, »Pripravljeno«); prazna mesta (`#b23a1e`, »N prazno«); dve prosti
(`#b23a1e`, »Par 1: dve prosti«); shranjeno.

**Nosilec in uvrstitev:** pri IZLOCILNI je značka `stNosilca`. Pri izločilnem delu skupin namesto
značke izpiši mono `uvrstitev` iz `udelezenciPoId` (npr. »3 · 1.«).
**Velikost mreže:** četrtina = N/4 mest. Pri mreži ≤ 16 mest prikaži vse naenkrat brez stolpca četrtin.

**Telefon:** črna glava 64 px (naslov 22 px). Pod njo so 4 zavihki četrtin, vsak 52 px (»1.« 16 px 800 +
»1–16« mono 10), spodaj 3 px črnilo. Pari so v stolpcih z levo črto 2 px; mesto je 46 px, ime 16 px. Pod
vsakima paroma je mono vrstica »2. KOLO → Kos – zmag. 3–4«.
**Tap na mesto** odpre spodnji list (zastor `rgb(20 17 15 / .55)`, 3 px črnilo zgoraj):
- mono »MESTO 3« in naslov »Zamenjaj: Domen Kralj« (22 px 800), ✕;
- iskalno polje 48 px (»Poišči igralca …«);
- seznam: vrstice 48 px, priimek 700 + ime 300 16 px, desno mono »mesto N«, po abecedi priimkov.
  Na vrhu je »Prosto mesto«, če obstaja prosto mesto v drugem paru.
Izbira takoj zamenja in zapre list.

### 4.3 Listki za tiskanje (različica 1b)
**Zamenja:** UI strani `src/strani/ListkiStran.tsx` in `src/komponente/IzbiraListkov.tsx` (izbira in
potrditev tiska). **Ostane:** `useIzbiraListkov`, `pripraviListke`, `sklopiListkov`, kode QR, `HrbetListka`,
**sam `Listek`** in natis listov A4 (2 × 3, rezi). Listi za tisk se izrišejo **samo za tisk**
(`@media print`). Velikega predogleda na zaslonu ni več; razdelek »Predogled natisa« odpade.
Ekipni dogodek (`ZapisnikiEkipnegaDogodka`) dobi isto stran z besedo »zapisnik« namesto »listek«.

**Postavitev (namizje):**
- **Črna glava** 72 px (enako kot pri mreži): mono povezava »← DOGODEK« `#cfc7bd`, nadnaslov »Jesenski turnir
  NTK Celje · Moški posamezno«, naslov »Listki za tiskanje« 26 px. Desno je legenda (kvadratki 14 px,
  mono 11 verzalke): `#0088ce` »Za tisk«, `#fff` »Še ni natisnjen«, `#ede7df` »Natisnjen«.
- **Tabela** (padding `16px 28px 20px`): grid `112px repeat(K, minmax(0,1fr))`, gap 6, K = število kol
  skupinskega dela (3 pri skupini 4, 5 pri skupini 5/6).
  - **Glava kola** je gumb 44 px: »1. kolo« 20 px 800, desno mono 11 »24 čaka« / »16 izbranih« /
    »✓ vseh 24«. Z izbranimi ima podlago `#eaf3f9` in rob `#0088ce`. Klik izbere vse nenatisnjene v kolu,
    ali jih odznači, če so že izbrani. Če je vse natisnjeno, izbere vse za ponovni tisk.
  - Pod glavo je 3 px črnilo.
  - **Vrstica skupine** se razteza na višino (`flex: 1 1 0`, min 40 px), spodaj 1 px `#ded7ce`. Glava vrstice
    »Sk. N« 17 px 800 + mono 11 število izbranih je gumb, ki izbere vso skupino.
  - **Ploščica listka:** grid `1fr auto`, padding `2px 8px`, 1 px rob; dve vrstici priimkov 700 13 px z »…«;
    desno mono 10 »M5« (miza) oz. pri natisnjenem »✓ 09:12« (`opisNatisa`).
    - nenatisnjen: bela podlaga, rob `#ded7ce`;
    - izbran: `#0071ab` podlaga in rob, belo, meta `#e8f5c4`;
    - natisnjen: podlaga in rob `#ede7df`, besedilo `#6e655e`;
    - čaka na potrditev: šrafura `repeating-linear-gradient(135deg,#0071ab 0 6px,#1b80b5 6px 12px)`.
    Klik preklopi izbiro (tudi natisnjen, za ponovni tisk).
  - Pod tabelo je namig 14/300: »Klikni listek, skupino ali kolo. Natisnjene lahko izbereš znova za ponovni tisk.«
- **Desni stolpec 340 px**, levo 3 px črnilo, podlaga `#ede7df`, padding `20px 24px`, gap 18:
  1. mono »ZA TISK«, velika številka **104 px Bricolage 800, line-height .85, `-.05em`** + »listkov« 20/300,
     mono »3 LISTI A4 · od tega N praznih«. Če so med izbranimi natisnjeni: povezava `#0071ab`
     »N izbranih je že natisnjenih · Odznači natisnjene« (obstoječi `odznaci`).
  2. **Sličice listov:** 44 × 62, bela, 1 px `#5b534d`, mreža 2 × 3 z gap 2. Izbran listek `#0088ce`,
     prazen listek `#c9c1b6`, prosto mesto prozorno.
  3. Če zadnji list ni poln: potrditveno polje kot gumb »Zadnji list ima 4 prosta mesta: dopolni s praznimi«.
     Vklopljeno doda prazne listke do polnega lista (`steviloPraznih`, prazni se ne vpišejo kot natisnjeni).
  4. »HITRA IZBIRA«: »Na vrsti: 2. kolo · 16 listkov« (prvo kolo z nenatisnjenimi), »Vsi nenatisnjeni«, »Počisti«.
  5. »Prazni listki · za ročni vpis«: koračnik 40 × 40 (0–120).
  6. »Vrstni red na listih«: segmentiran izbirnik »PO KOLIH | PO SKUPINAH« (obstoječa `razvrstitev`,
     `shraniRazvrstitev`). Pokaži ga samo, če `imaVecSkupin`.
  7. »Koda za sodnike na hrbtu«: samo če `sodnikiSlikajo`.
  8. mono navodilo »A4 OBOJESTRANSKO · 100 % · BREZ ROBOV« (brez »obojestransko«, ko ni hrbta).
  9. Spodaj glavni gumb **56 px** čez širino: »Natisni 16 listkov · 2. kolo« (kolo samo, če so vsi iz enega
     kola). Pri praznem izboru je onemogočen z besedilom »Izberi listke«.
- **Po tisku** (`izbira.caka`): desni stolpec zamenja vprašanje. Mono »PO TISKU«, »Si natisnil 16 listkov?«
  40 px 800, stavek »Potrjeni postanejo sivi in jih naslednjič ne izbere.«, nato »Da, natisnjeno«
  (`.gumb--glavni` 56 px) in »Ne, tisk ni uspel« (obroba 48 px). Po »Da« se izbira samodejno prestavi na
  naslednje kolo.
- Opozorilo o kodah (`kodePoizvedba.error || manjkaKoda`) ostane kot `.obvestilo--opozorilo` nad tabelo.
- Gost (`!smemOznacevati`) natisne brez vprašanja in brez sledi tiska.
- **Izločilni del in SV regija** (tekme brez skupine): pod tabelo dodaj vrstice z oznako faze v prvem
  stolpcu (»Mreža · 1/8 finala«, »Tolažilni«). Ploščice gredo čez vse stolpce kol (`grid-column: 2 / -1`,
  `display:flex; flex-wrap:wrap`, ploščica 180 px). Stil ploščice je isti. V prototipu tega dela ni.

**Telefon:** črna glava 64 px (»←«, naslov 22 px). Pod njo so zavihki kol, vsak 56 px (»1. kolo« 17 px 800 +
mono 10 »24/24« ali »✓ natisnjeno«), spodaj 3 px črnilo. Vrstica »Izberi celo 1. kolo« / »Odznači 1. kolo« +
»Počisti«. Skupine so v mreži 2 stolpcev (zgoraj 2 px črnilo, »Skupina N« 15 px 800); ploščice so 50 px,
priimka 14 px. Lepljiva noga ima podlago `#ede7df`: številka 32 px 800 + mono »listkov · 3 listi A4« in
»Natisni« 52 px. Po tisku se odpre spodnji list z istim vprašanjem.

---

## 5. Stanje (povzetek)
- **Skupine 1a:** `mesta` (obstoječe), `izhodisce` (za »Razveljavi« in »premaknjen«), `izbran: id | null`.
- **Mreža 1b:** `mesta: (id | null | PRAZNO)[]` (PRAZNO je samo v odjemalcu), `izhodisce`, `odlagalisce: (id|null)[]`,
  `cetrtina`, `vlecem: {iz:'mesto',i} | {iz:'odlagalisce',j} | null`, `cilj`. Telefon: `izbranoMesto`, `iskanje`.
- **Listki 1b:** obstoječi `useIzbiraListkov` (`izbrani`, `caka`, `potrdi`, `odznaci`) + `prazni`,
  `dopolniZadnji`, `koloZavihek` (telefon). Ob potrditvi se izbira nastavi na naslednje kolo z nenatisnjenimi.

## 6. Oblikovni žetoni (vsi že obstajajo v `slog.css`)
| Žeton | Vrednost | Raba |
|---|---|---|
| `--barva-papir` | `#fbf9f5` | podlaga |
| `--barva-namizje` | `#dcd8d1` | okoli okna |
| `--barva-crnilo` | `#14110f` | besedilo, 3 px črte, črne glave |
| `--barva-crnilo-2` | `#332e29` | odstavki |
| `--barva-crnilo-3` | `#5b534d` | meta |
| `--barva-crnilo-4` | `#6e655e` | onemogočeno |
| `--barva-crta` | `#ded7ce` | hairline |
| `--barva-polnilo` | `#ede7df` | stranski stolpci, natisnjeno, bazen |
| `--barva-glavna` | `#0088ce` | izbor, cilji, obrobe |
| `--barva-glavna-polna` | `#0071ab` | izbran element, glavni gumb |
| `--barva-glavna-mehko` | `#eaf3f9` | spremenjeno, cilj |
| `--barva-na-glavni-2` | `#e8f5c4` | drugotno na modri |
| `--barva-poudarek` | `#7bb900` | stanje »v redu« |
| `--barva-negativna` / `-tekst` | `#b23a1e` / `#8c2b14` | napaka |
| novo: črna glava, drugotno | `#cfc7bd` | besedilo na črni glavi |
| novo: onemogočen gumb na črni | `#332e29` / `#8a8078` | |
| novo: črta stranskega stolpca | `#c9c1b6` | ločila v `#ede7df` |

Pisave so Bricolage Grotesque (naslovi, številke), Karla (imena, gumbi) in IBM Plex Mono (oznake, števci).
Radij je 0 povsod, senc ni. Vsi kontrolniki so ≥ 44 px, razen ploščic listkov (≥ 40 px) in drobnih
povezav v stranskem stolpcu (≥ 32 px).

## 7. Gibanje
Samo `transition` barve, obrobe in podlage do 120 ms. Brez drugih animacij.

## 8. Datoteke
- `prototipi/Skupine 1a.dc.html`: Popravi skupine / Ročni vpis skupin (prop `telefon`, `zacetek=popravek|prazno`, `demo`)
- `prototipi/Mreza 1b.dc.html`: Ročna mreža / Popravi mrežo (`telefon`, `zacetek=popravek|vpis`, `demo`)
- `prototipi/Listki 1b.dc.html`: Listki za tiskanje (`telefon`, `stanje=nic|delno|potrditev`, `demo`)
- `prototipi/Posnetki.dc.html`: vseh 20 stanj v stalnih okvirjih (vir posnetkov)
- `prototipi/Trenutno stanje.dc.html`: sedanji videz za primerjavo
- `prototipi/podatki.js`: vzorčni podatki
- `prototipi/support.js`: izvajalnik prototipov (samo za ogled, ne gre v aplikacijo)
- `posnetki/*.png`: referenčni posnetki 1280 × 900 in 390 × 844

Ko končaš, posodobi **DESIGN.md**: razdelek o delovni ploskvi žreba (črna glava, celozaslonsko okno, vlečenje,
odlagališče) in razdelek o strani listkov (tabela skupina × kolo, stranski stolpec, velika številka 104 px).
