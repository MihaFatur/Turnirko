// Vzorčni podatki za prototipe: 48 igralcev, 12 skupin po 4 (skupine + izločilni),
// izločilna mreža 64 mest (16 prostih), listki tekem skupinskega dela.
const IMENA = [
  ['Žiga','Kos'],['Rok','Pirc'],['Urban','Turk'],['Peter','Jerman'],['Grega','Perko'],['Nejc','Sever'],
  ['Gašper','Pungartnik'],['Klemen','Vidmar'],['Andrej','Mlakar'],['Dejan','Petek'],['Jure','Zupančič'],['Jan','Hočevar'],
  ['Aljaž','Tratnik'],['Simon','Drofenik'],['Luka','Golob'],['Anže','Kovačič'],['Blaž','Rozman'],['David','Bizjak'],
  ['Tadej','Kocjančič'],['Matej','Podgoršek'],['Tilen','Kovač'],['Domen','Kralj'],['Marko','Lah'],['Vid','Potočnik'],
  ['Žiga','Kolar'],['Rok','Rebernik'],['Urban','Fras'],['Peter','Novak'],['Grega','Božič'],['Nejc','Kavčič'],
  ['Gašper','Šuštar'],['Klemen','Čeh'],['Andrej','Cerar'],['Dejan','Lesjak'],['Jure','Horvat'],['Jan','Korošec'],
  ['Aljaž','Zajc'],['Simon','Breznik'],['Luka','Žnidar'],['Anže','Jelen'],['Blaž','Bračko'],['David','Zupan'],
  ['Tadej','Hribar'],['Matej','Oblak'],['Tilen','Medved'],['Domen','Vodopivec'],['Marko','Mavrič'],['Vid','Ribič'],
];
const KLUBI = ['NTK Gorica','TTK Velenje','KNT Radlje','ŠD Sežana','NTK Celje','KNT Kajuh','NTK Ptuj','NTK Savinja','NTK Ormož','NTK Krško','NTK Maribor','NTK Žalec'];

export const TURNIR = 'Jesenski turnir NTK Celje';
export const DOGODEK = 'Moški posamezno';
export const KATEGORIJA = 'Moški · Člani';

export const IGRALCI = IMENA.map(([ime, priimek], i) => ({
  id: i + 1,
  ime,
  priimek,
  klub: '',
  rating: 2186 - i * 15 - (i % 3) * 4,
  jakost: i + 1,
}));

export const ST_SKUPIN = 12;

// Kačasti razpored: boben p (0..3) gre v skupine 1..12 oz. 12..1.
export function kacasto(k = ST_SKUPIN, igralci = IGRALCI) {
  const mesta = {};
  igralci.forEach((p, i) => {
    const boben = Math.floor(i / k);
    const j = i % k;
    const skupina = boben % 2 === 0 ? j : k - 1 - j;
    mesta[p.id] = boben < 4 ? { skupina, pozicija: boben + 1 } : { skupina: null, pozicija: 0 };
  });
  return mesta;
}

// Trenutne skupine (po žrebu): kačasto + nekaj zamenjav, kot bi jih dal žreb.
export function trenutneSkupine() {
  const m = kacasto();
  const zamenjaj = (a, b) => { const t = m[a]; m[a] = m[b]; m[b] = t; };
  zamenjaj(14, 17); zamenjaj(27, 30); zamenjaj(38, 44); zamenjaj(20, 22);
  return m;
}

// Klubi so izpeljani iz trenutnih skupin: v vsaki skupini različni, razen ene
// namerne kolizije (skupina 7), ki jo pokaže opozorilo »isti klub«.
{
  const m = trenutneSkupine();
  IGRALCI.forEach((p) => {
    const x = m[p.id];
    p.klub = KLUBI[(x.skupina * 5 + x.pozicija * 3) % 12];
  });
  const s7 = IGRALCI.filter((p) => m[p.id].skupina === 6).sort((a, b) => m[a.id].pozicija - m[b.id].pozicija);
  s7[3].klub = s7[1].klub;
}

export function prazneSkupine() {
  const m = {};
  IGRALCI.forEach((p) => { m[p.id] = { skupina: null, pozicija: 0 }; });
  return m;
}

// Izločilna mreža 64: 16 nosilcev na standardnih mestih, ob njih prosta mesta.
export const MESTA_NOSILCEV = [1, 64, 33, 32, 17, 48, 49, 16, 9, 56, 41, 24, 25, 40, 57, 8];
export function zacetnaMreza() {
  const mesta = Array(64).fill(undefined);
  MESTA_NOSILCEV.forEach((s, i) => {
    mesta[s - 1] = IGRALCI[i].id;
    mesta[s % 2 === 1 ? s : s - 2] = null;
  });
  const ostali = IGRALCI.slice(16).map((p) => p.id);
  // psevdo-naključen, a stalen vrstni red
  const red = ostali.map((id, i) => ({ id, k: (i * 37 + 11) % 97 })).sort((a, b) => a.k - b.k).map((x) => x.id);
  let n = 0;
  for (let i = 0; i < 64; i++) if (mesta[i] === undefined) mesta[i] = red[n++];
  return mesta;
}

// Krožni razpored skupine s štirimi (Berger): kolo -> pari pozicij.
export const KOLA_SKUPINE = [[[1, 4], [2, 3]], [[4, 3], [1, 2]], [[2, 4], [3, 1]]];

// Listki skupinskega dela iz trenutnih skupin. natisnjeno: 'nic' | 'delno'
export function listki(natisnjeno = 'nic') {
  const m = trenutneSkupine();
  const poSkupini = Array.from({ length: ST_SKUPIN }, () => []);
  IGRALCI.forEach((p) => { const x = m[p.id]; if (x.skupina !== null) poSkupini[x.skupina][x.pozicija - 1] = p; });
  const out = [];
  let id = 4101;
  poSkupini.forEach((cl, g) => {
    KOLA_SKUPINE.forEach((pari, k) => {
      pari.forEach(([a, b], t) => {
        const natis = natisnjeno === 'delno' && (k === 0 || (k === 1 && g < 4));
        out.push({
          id: id++,
          skupina: g + 1,
          kolo: k + 1,
          miza: ((g * 2 + t) % 16) + 1,
          igralec1: cl[a - 1],
          igralec2: cl[b - 1],
          natisnjeno: natis ? (k === 0 ? '09:12' : '10:05') : null,
        });
      });
    });
  });
  return out;
}

export const ime = (p) => (p ? `${p.ime} ${p.priimek}` : '—');
export const poId = Object.fromEntries(IGRALCI.map((p) => [p.id, p]));

export function sklonListkov(n) {
  const s = n % 100;
  if (s === 1) return 'listek';
  if (s === 2) return 'listka';
  if (s === 3 || s === 4) return 'listki';
  return 'listkov';
}
export function sklonIgralcev(n) {
  const s = n % 100;
  if (s === 1) return 'igralec';
  if (s === 2) return 'igralca';
  if (s === 3 || s === 4) return 'igralci';
  return 'igralcev';
}
export function sklonListov(n) {
  const s = n % 100;
  if (s === 1) return 'list';
  if (s === 2) return 'lista';
  if (s === 3 || s === 4) return 'listi';
  return 'listov';
}
