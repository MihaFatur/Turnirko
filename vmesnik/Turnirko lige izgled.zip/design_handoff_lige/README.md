# Predaja: Prenova strani lige (smer 1a »Zapisnik«)

## Pregled

Prenova pogleda ene lige (`/lige/:id`) v aplikaciji Turnirko. Cilj: pravila umakniti iz
glave strani, dodati vidno povezanost lig (piramida sezone), lestvico obogatiti s cono
napredovanja/izpada, formo zadnjih petih srečanj in razširljivim kadrom, razpored pa iz
seznama vseh kol spremeniti v listanje po kolih. Postavitev mora zdržati lige različnih
velikosti (4 do 16+ ekip), povezane in samostojne lige ter formate, ki jih še ni
(play-off je že predviden kot zavihek).

## O datotekah v tem paketu

Datoteke `.dc.html` v tem paketu so **oblikovalske reference, narejene v HTML** — prototipi,
ki kažejo želen videz in vedenje. **Niso produkcijska koda za kopiranje.** Naloga je te
zaslone poustvariti v obstoječem okolju repozitorija: React 18 + TypeScript + Vite,
`@tanstack/react-query`, `react-router-dom`, navaden CSS z BEM razredi v slovenščini v
`vmesnik/src/slog.css`. Novih knjižnic (Tailwind, shadcn/ui, CSS-in-JS) **ne dodajaj**.

Zavezujoča pravila oblikovanja so v `vmesnik/turnirko-profil-redesign/project/DESIGN.md`.
Če karkoli v tem dokumentu nasprotuje DESIGN.md, velja DESIGN.md.

**Implementiraj samo smer `1a` (»Zapisnik«)** iz datoteke `Lige — predlog.dc.html` — to je
levi stolpec z značko `1a`. Smer `1b` (»Semafor«) je zavržena in služi le kot primerjava.

## Natančnost

**Visoka (hi-fi).** Barve, tipografija, razmiki in stanja so končni. Vrednosti v prototipu so
zapisane kot literali (prototip ne more brati `slog.css`); v kodi **vedno uporabi obstoječe
CSS spremenljivke**, ne surovih hexov. Preslikava je v razdelku »Oblikovalski žetoni«.

## Zasloni

### 1. Liga — podrobno (`/lige/:id`, `LigaStran.tsx`)

Namen: gledalec vidi stanje lige (lestvica, kolo), organizator upravlja ligo.
Ovoj strani ostane `<section className="liga">` znotraj obstoječe `Postavitev` (masthead,
1 px + 3 px črta, `.vsebina` s `padding: 48px 40px 64px` in `gap: 56px`). Masthead se **ne
spreminja**.

Vrstni red sekcij od zgoraj navzdol:

**a) Glava strani** — `<div className="stran-glava">`, mreža `minmax(0,1fr) 380px`, `gap: 56px`,
`align-items: end` (danes `start`).

- Levo: `.povezava-nazaj` »← Lige«; `h1.naslov-strani.naslov-strani--podstran` z
  `.naslov-strani__nad` (sezona, 44 px / 200) in `.naslov-strani__glavni` (ime lige, 80 px / 800);
  pod njim `p.uvod` z obstoječim nizom `»12 ekip · dvokrožno · 13. od 22 kol odigranih«`
  (`margin-top: 16px`, ne 20 px).
- Desno, nov razred `.liga__stanje-blok` (flex column, `gap: 12px`):
  1. vrstica: `ZnackaStatusa` + `.sekcija__meta` z besedilom `»Naslednje kolo 21. 2.«`
     (če je liga zaključena: `»Končano 16. 5.«`; če ni razporeda: `»Razpored ni generiran«`).
  2. napredek: vrstica `oznaka mono ↔ vrednost mono` (`»Odigrano«` ↔ `»13 / 22«`,
     `padding-bottom: 6px`), pod njo obstoječa `.palica` + `.palica__polnilo`
     (širina = odigrana kola / vsa kola, tu 59 %).
  3. dejanja: `.stran-glava__dejanja` z gumboma `»Pravila«` (`.gumb`) in
     `»Ekipe in kader«` (`.gumb .gumb--majhen`); oba `flex: 1`, `gap: 8px`.
     Gumb »Ekipe in kader« vidi le urejevalec (`smem`).

**b) Piramida sezone** — nova sekcija `.liga__piramida`, vidna **samo če** liga ima
`idVisjaLiga` ali obstajajo lige, ki kažejo nanjo (`stNapreduje > 0 || stIzpade > 0 || visjaLigaIme`).
Sicer se ne izriše (glej primer »Klubska liga Muta« v prototipu).

- Ovoj: `border-top: 1px solid var(--barva-crnilo)`, `padding-top: 16px`, flex column.
- Prva vrstica: `.podnaslov-sekcije` »Piramida sezone« levo, `.sekcija__meta` desno
  (npr. `»Moški · SNTL«`).
- Nato ena vrstica na nivo: `grid-template-columns: 96px minmax(0,1fr) 200px`, `gap: 24px`,
  `padding: 12px 0`, `border-top: 1px solid var(--barva-crta)`.
  - Levo: mono oznaka nivoja (`»1. nivo«`).
  - Sredina: `flex-wrap` vrsta lig istega nivoja; vsaka je `<Link>` `padding: 8px 12px`,
    besedilo 15 px Karla, barva `var(--barva-glavna-tekst)`. **Trenutna liga** ni povezava:
    `background: var(--barva-crnilo)`, `color: var(--barva-papir)`, `font-weight: 700`.
  - Desno: mono opis toka, poravnan desno — `»↓ 2 izpadeta«` (barva `--barva-negativna-tekst`),
    `»↑ 2 · ↓ 2«` (`--barva-crnilo-3`), `»↑ 2 napredujeta«` (`--barva-poudarek-tekst`).

**c) Lestvica / Play-off** — `.naslovna-vrstica` (3 px črta) z `h2` (naslov se menja:
»Lestvica« / »Play-off«) in desno obstoječim `.izbirnik` z dvema gumboma:
`»Redni del«` in `»Play-off«` (`.izbirnik__gumb`, aktiven `--aktiven`).
Zavihek Play-off je viden **samo**, če liga ima definirano fazo play-offa; dokler je
podatkovni model nima, gumb skrij (postavitev je pripravljena, funkcija pride kasneje).

Tabela `.tabela` (obstoječa), stolpci in širine:

| Stolpec | Širina | Poravnava | Slog |
|---|---|---|---|
| `#` | 56 px | desno | `.lestvica__mesto` |
| Ekipa | prosto | levo | 18 px Karla 400; ob kliku 700 |
| Odig. | 64 px | desno | `.lestvica__stevilka` |
| Z | 56 px | desno | `.lestvica__stevilka.lestvica__zmage` |
| N | 56 px | desno | `.lestvica__stevilka` |
| P | 56 px | desno | `.lestvica__stevilka.lestvica__porazi` |
| Tekme | 88 px | desno | `.lestvica__stevilka` |
| Nizi | 96 px | desno | `.lestvica__stevilka` |
| Zadnjih 5 | 132 px | levo | nov `.lestvica__forma` |
| Točke | 88 px | desno | `.lestvica__rating` |

- Cona: obstoječa razreda `.lestvica__vrsta--napreduje` / `--izpade`
  (`box-shadow: inset 4px 0 0` na prvi celici). Meje iz `liga.stNapreduje` / `liga.stIzpade` —
  **nikoli trdo kodirano na 2**.
- **Forma** (nov `.lestvica__forma`): do 5 značk zadnjih srečanj, `display: flex; gap: 4px`.
  Vsaka: `width: 20px; padding: 3px 0; text-align: center`, mono 11 px 600, brez radija.
  Z = `--barva-poudarek-mehko` / `--barva-poudarek-tekst`;
  N = `--barva-polnilo` / `--barva-crnilo-3`;
  P = `--barva-negativna-mehko` / `--barva-negativna-tekst`.
  Vrstni red: najstarejše levo, najnovejše desno. Manj kot 5 odigranih → manj značk.
- **Razširljiva vrstica**: celotna `<tr>` je klikljiva (`cursor: pointer`,
  `aria-expanded`, `role="button"` ali gumb v celici imena — dostopnost obvezna).
  V celici Ekipa desno od imena mono oznaka `»Kader ▾«` / `»Kader ▴«` v
  `var(--barva-glavna-tekst)`, `margin-left: 12px`.
  Odprta vrstica: `background: var(--barva-glavna-mehko)`, ime 700.
  Takoj **za** njo se vrine `<tr><td colSpan={10}>` z blokom
  `border-left: 4px solid var(--barva-glavna)`, `background: var(--barva-glavna-mehko)`,
  `padding: 16px 20px`. V bloku glava (`»Kader — {ime ekipe}«` 18 px 700 + mono meta
  `»Rating · bilanca posamičnih tekem«`) in vrstice igralcev:
  `grid-template-columns: 32px minmax(0,1fr) 88px 88px`, `gap: 16px`, `padding: 10px 0`,
  `border-bottom: 1px solid var(--barva-crta)`; mesto in rating mono, ime 17 px Karla,
  bilanca mono 600. Podatki: `ligeApi.kader(idEkipa)` (lazy — poizvedba se sproži šele ob
  odprtju) + bilanca posamičnih tekem ekipe v tej ligi. Naenkrat je odprta največ ena ekipa.
- Legenda pod tabelo: obstoječa `.legenda`, besedilo pove **ciljno ligo**
  (`»Napreduje v 1. SNTL«`, `»Izpade v 3. SNTL vzhod«`) — ime pride iz piramide, ne generično.
  Desno še mono namig `»Klik na vrstico odpre kader«`.

Zavihek **Play-off** (predviden): odstavek s pojasnilom + dve koloni (`»Za naslov« / mesta 1–4`,
`»Za obstanek« / mesta 9–12`), vsaka z `h3` v slogu `.liga__kolo-naslov` in vrsticami
`grid-template-columns: 88px minmax(0,1fr)`: mono oznaka faze levo, par (`»1. — 4.«`) 17 px
Karla in pod njim sivo `»trenutno NTK Muta — NTK Slovan 2«` (15 px 300).

**d) Razpored** — `.naslovna-vrstica` z `h2` »Razpored« in `.sekcija__meta`
`»22 kol · 13 odigranih«`.

- **Krmar kola**: `grid-template-columns: auto minmax(0,1fr) auto`, `gap: 16px`,
  `margin-top: 24px`, `padding-bottom: 12px`, `border-bottom: 2px solid var(--barva-crnilo)`.
  Levo gumb `»← Prejšnje«`, desno `»Naslednje →«` (`.izbirnik__gumb`, `min-height: 44px`,
  onemogočena na robovih). Na sredini `»14. kolo«` (display 32 px 800) + mono meta
  `»21. 2. 2026 · razpored«` oz. `»· odigrano«`.
- **Srečanja izbranega kola**: vrstice
  `grid-template-columns: minmax(0,1fr) 120px minmax(0,1fr) 120px`, `gap: 24px`,
  `padding: 16px 0`, `border-bottom: 1px solid var(--barva-crta)`.
  Domači 20 px desno poravnano, izid mono 24 px 600 na sredini
  (`background: var(--barva-polnilo)`, `padding: 6px 0`; nedokončano: brez podlage, `»vs«`,
  `--barva-crnilo-3`), gost 20 px levo, skrajno desno mono povezava
  `»Zapisnik«` (odigrano) oz. `»Postava«` (čaka) v `--barva-glavna-tekst`.
  Zmagovalec 700 / črnilo, poraženec `--barva-crnilo-4`. Celotna vrstica vodi na `/srecanja/:id`.
- **Trak vseh kol**: pod naslovom `.podnaslov-sekcije` »Vsa kola«, nato `flex-wrap` gumbi
  `44 × 44 px`, `gap: 4px`, mono 14 px. Odigrano: `background: var(--barva-polnilo)`,
  besedilo črnilo. Izbrano: `background: var(--barva-glavna-polna)`, bela, obroba
  `--barva-glavna`. Prihodnje: brez podlage, obroba `--barva-crta`, besedilo `--barva-crnilo-3`.
  Klik nastavi kolo.

**e) Modalno okno »Pravila«** — obstoječa `ModalnoOkno` (zastor `rgb(20 17 15 / 0.55)`,
okvir `1px solid var(--barva-crnilo)`, glava `border-bottom: 3px`, naslov 28 px 800).
Vsebina: kratek odstavek o zaklenjenosti (`»Zaklenjena, ker je razpored že generiran.
Popravek bi razveljavil odigrana srečanja.«` — pri ligi v pripravi namesto tega gumb
»Uredi pravila«), nato obstoječa `.opis-mreza` z istimi pari kot danes
(Format, Nizi, Konec srečanja, Sistem, Točke, Neodločeno, Dvojna registracija, Šteje v ELO,
Višja liga, Napreduje, Izpade). **Kolofon pravil se s strani odstrani** — to je edini
razlog za prenovo glave.

### 2. Prilagodljivost (obvezno preveri)

- **Majhna liga v pripravi** (primer »Klubska liga Muta«, 4 ekipe): ni piramide, ni lestvice,
  ni razporeda; ostanejo glava, značka `Priprava`, mono opomba `»Samostojna — brez piramide«`,
  sekcija `Ekipe` in gumba `»Generiraj razpored«` (`.gumb--zreb`) in `»Uredi pravila«`.
  Prazne sekcije se **ne** izrisujejo kot prazne mreže.
- **16+ ekip**: tabela ostane ista, `.tabela-ovoj` poskrbi za vodoravni izpis.
- **Mobilno (≤ 720 px)**: glava strani v en stolpec (naslov 40 px / nadnaslov 24 px);
  pod naslovom trije zavihki `Lestvica · Razpored · Pravila` (`.izbirnik`, vsak `flex: 1`,
  `min-height: 44px`); lestvica se skrči na
  `grid-template-columns: 28px minmax(0,1fr) 72px 40px` = mesto, ekipa, forma (kvadratki
  12 × 12 px brez črk), točke; ostali stolpci odpadejo. Razpored: krmar kola kot trije
  gumbi v vrsti.

## Interakcije in vedenje

| Sprožilec | Posledica |
|---|---|
| Klik `»Pravila«` | odpre `ModalnoOkno`; `Escape` in klik zunaj zapreta |
| Klik vrstice lestvice | odpre/zapre kader te ekipe (druga se zapre); poizvedba `kader` lazy |
| Klik `»← Prejšnje« / »Naslednje →«` | kolo −1 / +1, omejeno na 1…N; vsebina razporeda se zamenja |
| Klik številke v traku kol | nastavi to kolo |
| Klik zavihka `Redni del` / `Play-off` | zamenja vsebino sekcije (naslov `h2` se spremeni) |
| Klik vrstice srečanja | navigacija na `/srecanja/:id` |
| Liga `V_TEKU` | `refetchInterval` prek `intervalOsvezevanja` ostane nespremenjen |
| Brez povezave | obstoječi trak `.brez-povezave`; brez sprememb |

Prehodi: samo barva/obroba do 120 ms (DESIGN.md). Razširitev kadra **ni** animirana z višino —
vrstica se preprosto pojavi.

Privzeto stanje ob nalaganju: izbrano je **prvo neodigrano kolo** (če ga ni, zadnje odigrano),
zavihek `Redni del`, noben kader ni odprt, modal zaprt.

## Stanje

Vse lokalno v `LigaStran.tsx` (brez novih globalnih stanj):

```ts
const [faza, nastaviFazo] = useState<'REDNI' | 'PLAYOFF'>('REDNI')
const [kolo, nastaviKolo] = useState<number>(privzetoKolo)   // 1..N
const [odprtaEkipa, nastaviOdprtoEkipo] = useState<number | null>(null)  // idEkipa
const [pravilaOdprta, nastaviPravilaOdprta] = useState(false)
```

Poizvedbe (obstoječe): `ligeApi.najdi`, `ligeApi.srecanja`, `ligeApi.lestvica`,
`ligeApi.ekipe`. Novo: `ligeApi.kader(idEkipa)` z `enabled: odprtaEkipa === e.id`.

Izpeljano brez novih klicev na zaledje:
- `kola` = unikatna `kolo` iz srečanj, urejena naraščajoče;
- `odigranihKol` = kola, kjer je vsako srečanje `KONCANO` (obstoječi izračun);
- **forma** ekipe = zadnjih 5 njenih končanih srečanj po kolu → `Z` / `N` / `P` iz
  `dobljeneDomaci` vs `dobljeneGost` glede na stran. Če zaledje že vrača formo, uporabi njo.
- **piramida** potrebuje seznam lig sezone: `ligeApi.seznam()` (že obstaja), združi po
  `idVisjaLiga` v nivoje. Če je klic predrag, dodaj polje na `LigaDto`, a ne izmišljuj podatkov.

## Oblikovalski žetoni

V prototipu so literali; v kodi uporabi spremenljivke iz `slog.css`:

| Literal | Spremenljivka | Vloga |
|---|---|---|
| `#0088CE` | `--barva-glavna` | črte, palica, obrobe |
| `#0071AB` | `--barva-glavna-polna` / `--barva-glavna-tekst` | polna ploskev pod belim besedilom / besedilo |
| `#EAF3F9` | `--barva-glavna-mehko` | podlaga označene vrstice in bloka kadra |
| `#7BB900` | `--barva-poudarek` | črta cone napredovanja, gumb `Generiraj razpored` |
| `#4A7500` | `--barva-poudarek-tekst` | besedilo `Z`, zmage |
| `#EAF4D6` | `--barva-poudarek-mehko` | podlaga značke `Z` |
| `#B23A1E` | `--barva-negativna` | črta cone izpada, porazi |
| `#8C2B14` | `--barva-negativna-tekst` | besedilo `P` na mehki podlagi |
| `#F8E5DF` | `--barva-negativna-mehko` | podlaga značke `P` |
| `#FBF9F5` | `--barva-papir` | podlaga vsebine |
| `#14110F` | `--barva-crnilo` | besedilo, 3 px črte |
| `#332E29` | `--barva-crnilo-2` | odstavki |
| `#5B534D` | `--barva-crnilo-3` | mono oznake, meta |
| `#6E655E` | `--barva-crnilo-4` | poražena stran |
| `#DED7CE` | `--barva-crta` | hairline |
| `#EDE7DF` | `--barva-polnilo` | podlaga izida, prazen del palice |

Ritem: 8 px (`--r1`…`--r8`); vrstice seznamov 10–20 px navpično.
Tipografija: `--pisava-display` Bricolage Grotesque (h1–h3, izidi), `--pisava-telo` Karla
(odstavki, imena, gumbi), `--pisava-mono` IBM Plex Mono (oznake, številke, značke).
Lestvica: `--tip-vrstica` 18 px za ime, mono 15 px za številke, `--tip-mono` 12 px za glave.
`border-radius: 0` povsod. `box-shadow` samo kot `inset 4px 0 0` za cono in obstoječi
podčrtaj aktivne navigacije. Vsaka klikljiva tarča ≥ 44 px.

## Sredstva

Nobenih novih. Edina ikona ostane logotip (`ZnakTurnirko` v `Postavitev.tsx`).
Puščice `←`, `→`, `↑`, `↓`, `▾`, `▴` so tipografski znaki, ne ikone — uporabljene so ob
besedi, nikoli namesto nje.

## Posnetki zaslonov

V mapi `posnetki/` (2× ločljivost, smer 1a):

- `1a-liga.png` — cela stran lige v izhodiščnem stanju (zavihek Redni del, 14. kolo).
- `1a-kader-odprt.png` — razširjena vrstica s kadrom pod prvo ekipo.
- `1a-playoff.png` — zavihek Play-off.
- `1a-pravila-okno.png` — modalno okno s pravili nad stranjo.
- `1a-mobilno-in-mala-liga.png` — mobilni pogled (390 px) in majhna liga v pripravi (4 ekipe).

Posnetki so referenca za razporeditev; **merodajne vrednosti so v tem dokumentu in v
`DESIGN.md`**, ne odčitane iz slike.

## Datoteke v paketu

- `Lige — predlog.dc.html` — prototip prenove. **Implementiraj samo blok z značko `1a`.**
  Vsebuje tudi mobilni pogled in primer majhne lige v pripravi.
- `Lige — sedanje stanje.dc.html` — rekonstrukcija današnjih zaslonov (`/lige`, `/lige/:id`,
  `/srecanja/:id`) za primerjavo pred/po.
- `support.js` — pogon prototipa (samo za odpiranje HTML v brskalniku; ne prenašaj v aplikacijo).
- `DESIGN.md` — zavezujoč oblikovalski sistem; preberi pred prvo vrstico kode.

## Datoteke v repozitoriju, ki se spremenijo

- `vmesnik/src/strani/LigaStran.tsx` — glavnina dela (glava, piramida, zavihka, lestvica,
  krmar kola, modal pravil).
- `vmesnik/src/slog.css` — razdelek 14 (»Lige, srecanja, postava«): novi razredi
  `.liga__stanje-blok`, `.liga__piramida`, `.liga__piramida-vrstica`, `.lestvica__forma`,
  `.lestvica__forma-znak`, `.liga__krmar`, `.liga__trak-kol`, `.liga__kader-vrstica`;
  `.liga__kola` (dvostolpični izpis vseh kol) se odstrani ali obdrži le za tisk.
- `vmesnik/src/api/zahteve.ts` — samo če piramida potrebuje dodaten klic.

Ne spreminjaj: `Postavitev.tsx`, `SrecanjeStran.tsx`, `LigeStran.tsx` (seznam lig ostane,
kot je — prenova seznama je ločena naloga).
