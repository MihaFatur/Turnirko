# Predaja: prenova strani Lestvica (Turnirko)

## Kaj je to

Prenovljena stran `/lestvica` (globalna lestvica igralcev po klubskem ELO ratingu).
Paket vsebuje **oblikovalsko referenco v HTML** in **posnetke zaslona**, ki so
merodajni izgled. Naloga je izgled implementirati v obstoječi kodi vmesnika
(React + TypeScript + `slog.css`), **ne** kopirati HTML v projekt.

Ciljni datoteki v repozitoriju:

- `vmesnik/src/strani/LestvicaStran.tsx` — stran, ki jo spreminjaš
- `vmesnik/src/slog.css` — razdelek `10. lestvice, skupine, podij` (razredi `.lestvica__*`)

Zavezujoč oblikovalski sistem je `vmesnik/turnirko-profil-redesign/project/DESIGN.md`.
Vse spodaj je z njim skladno: brez zaobljenih robov, brez senc, brez ikon in
odličij, brez emojijev, ritem 8 px, tri pisave.

## Vsebina paketa

```
design_handoff_lestvica/
├── README.md                              ← ta dokument
├── posnetki/
│   ├── 01-lestvica-privzeto.png           ← privzeto stanje (14 igralcev, razvrščeno po ratingu)
│   └── 02-lestvica-filter-clanice.png     ← kategorija "Članice"
└── referenca/
    ├── Lestvica.dc.html                   ← živa referenca (odpri v brskalniku)
    └── support.js                          ← runtime reference, ne kopiraj v projekt
```

`referenca/Lestvica.dc.html` odpri neposredno v brskalniku (dvoklik ali
`open`). Širina zasnove je **1280 px**; posnetki so zajeti pri tej širini in
shranjeni v 2× ločljivosti.

## Fidelity: **high-fidelity**

Barve, tipografija, razmiki in širine stolpcev so končni. Implementacija naj se
z referenco ujema **piksel v piksel** pri širini vsebnika 1280 px, z izjemo
podatkov (referenca ima izmišljene igralce, aplikacija pravi API).

---

## Postopek: primerjaj s posnetki, dokler se ne ujemata

Tega koraka ne preskoči. Delaj v zanki:

1. Implementiraj spremembe v `LestvicaStran.tsx` in `slog.css`.
2. Zaženi vmesnik in odpri `/lestvica` v brskalniku, širina okna naj da vsebniku
   strani natanko 1280 px (`.postavitev` ima največjo širino; po potrebi
   privremeno nastavi `zoom: 1` in preveri z devtools, da je `<section>` širok 1280 px).
3. Zajemi posnetek celotne strani.
4. **Odpri `posnetki/01-lestvica-privzeto.png` in svoj posnetek enega ob drugem
   in ju primerjaj po naslednjih točkah**:
   - vrstni red in poravnava stolpcev (`#`, `Gib.`, `Igralec`, `Klub`, `Z – P`, `Rating`, `Δ 30 dni`)
   - širine stolpcev in položaj desnega roba vsake številke
   - velikosti in teže pisav v glavi tabele, v imenih in v številkah
   - višina vrstice (14 px zgoraj in spodaj) in barva ločilne črte
   - razmik med naslovom `Razvrstitev` in pasom filtrov, ter med pasom in tabelo
   - stanje gumbov (aktiven = črna ploskev, bela mono pisava)
   - poudarjena vrstica prijavljenega igralca (svetlo modra podlaga, krepko ime)
5. Kjer opaziš razliko, popravi CSS in ponovi od 2. Nadaljuj, dokler razlik ni več.
6. Nato ponovi isto z `posnetki/02-lestvica-filter-clanice.png`: klikni filter
   `Članice` in preveri, da se ujema — vključno s tem, da **mesta ostanejo
   globalna** (4, 9, 13), ne preštevilčena.

Če se česa iz posnetka ne da doseči z obstoječimi razredi, dodaj nov razred v
razdelek 10 `slog.css` po istem imenskem vzorcu (`.lestvica__*`), ne inline slogov.

---

## Kaj se spremeni glede na trenutno stanje

| Sprememba | Zakaj |
|---|---|
| Tabela dobi `table-layout: fixed` s `<colgroup>` in fiksnimi širinami | besedilo se ne more več prekrivati; dolga imena in klubi se odrežejo z `text-overflow: ellipsis` |
| Nov stolpec **Gib.** (premik mesta ↑3 / ↓2 / –) | vidno je, kdo napreduje |
| Nov stolpec **Δ 30 dni** (sprememba ratinga) | rating dobi kontekst |
| Odstranjena stolpca **Odigrane** in **Uspešnost** (palica + %) | sprostita prostor; podatek ostane na profilu igralca |
| Stolpec `Z – P` ostane, brez palice in brez besede „Razmerje“ v glavi | uporabnikova zahteva |
| Nov pas filtrov nad tabelo: **Kategorija** in **Razvrsti po** | filtriranje brez odpiranja menijev |
| Glava tabele je lepljiva (`position: sticky; top: 0`) | pri dolgi lestvici se ve, kateri stolpec je kateri |
| Opomba pod tabelo: „Gib. in Δ: primerjava s stanjem pred 30 dnevi“ | brez legende sta stolpca dvoumna |

Iskalnik, števci (`14 igralcev` / `9 klubov`), naslov strani, `sekcija__meta`
(„Prikazanih X od Y“) in namig pod tabelo ostanejo nespremenjeni.

---

## Postavitev strani

Zgradba ostane enaka obstoječi (`<section>` → `stran-glava` → naslovna vrstica →
tabela). Nov je le pas filtrov med naslovno vrstico in tabelo.

### Glava strani (`.stran-glava.stran-glava--dno`) — nespremenjena

- mreža `minmax(0,1fr) 380px`, razmik 56 px, `align-items: end`
- `h1.naslov-strani`: „Klubski ELO“ 48 px / teža 200 / barva `--barva-crnilo-3`,
  pod njo „Lestvica“ 88 px / teža 800 / `--barva-crnilo`, `line-height: .88`,
  `letter-spacing: -.035em`
- `p.uvod`: 20 px / teža 300 / `--barva-crnilo-2`, največ 48ch
- desno `label.obrazec__polje` z `input.iskalnik` (višina ≥ 44 px, obroba 1 px
  `--barva-crnilo`, brez radija) in pod njim `.stevci`

### Naslovna vrstica (`.naslovna-vrstica`) — nespremenjena

- zgornja črta 3 px `--barva-crnilo`, `padding-top: 16px`
- `h2` „Razvrstitev“ 40 px / teža 800 / `letter-spacing: -.03em`
- desno `.sekcija__meta` „Prikazanih X od Y“ (mono 12 px, verzalke, `letter-spacing: .1em`)

### NOVO: pas filtrov

- `margin-top: 24px`, mreža `minmax(0,1fr) auto`, razmik `24px 32px`, `align-items: end`
- levo skupina **Kategorija**, desno skupina **Razvrsti po** (oznaka desno poravnana)
- oznaka skupine: mono 12 px, teža 500, verzalke, `letter-spacing: .08em`, barva `--barva-crnilo-3`, pod njo 8 px razmika
- gumbi: `display: flex; gap: 4px; flex-wrap: wrap`

Gumb (neaktiven):

```css
min-height: 44px;
padding: 8px 12px;
border: 1px solid var(--barva-crta);      /* #DED7CE */
border-radius: 0;
background: none;
color: var(--barva-crnilo-3);             /* #5B534D */
font: 500 12px/1.2 var(--pisava-mono);
letter-spacing: .1em;
text-transform: uppercase;
cursor: pointer;
white-space: nowrap;
```

Gumb (aktiven): `background: var(--barva-crnilo)` (#14110F), `color: #FBF9F5`,
`border-color: var(--barva-crnilo)`.

Vrednosti: Kategorija — `Vsi`, `Člani`, `Članice`, `U19`, `Veterani`.
Razvrsti po — `Rating`, `Uspešnost`, `Odigrane`.

---

## Tabela

Ovoj `.tabela-ovoj` (`overflow-x: auto`), `margin-top: 24px`.
Tabela: `width: 1200px; table-layout: fixed; border-collapse: collapse`.

`<colgroup>` (sedem stolpcev, po vrsti):

| # | Stolpec | Širina | Poravnava |
|---|---|---|---|
| 1 | `#` (mesto) | 56 px | desno |
| 2 | `Gib.` | 64 px | sredina |
| 3 | `Igralec` | preostanek (`auto`) | levo |
| 4 | `Klub` | 280 px | levo |
| 5 | `Z – P` | 112 px | desno |
| 6 | `Rating` | 104 px | desno |
| 7 | `Δ 30 dni` | 88 px | desno |

### Glava (`thead th`)

`font: 500 12px/1.4 var(--pisava-mono)`, `letter-spacing: .1em`,
`text-transform: uppercase`, barva `--barva-crnilo-3`, `padding: 8px 16px 8px 0`
(zadnji stolpec `padding: 8px 0`), spodaj `1px solid var(--barva-crnilo)`,
`white-space: nowrap`, `position: sticky; top: 0; background: var(--barva-papir)`.

### Celice (`tbody td`)

`padding: 14px 16px 14px 0` (zadnji stolpec `14px 0`),
spodaj `1px solid var(--barva-crta)`.

- **Mesto** — `font: 600 17px/1.4 mono`, `tabular-nums`; prva tri mesta
  `--barva-glavna-tekst` (#0071AB), ostala `--barva-crnilo-3`. Razreda
  `.lestvica__mesto` in `.lestvica__mesto--vrh` ostaneta.
- **Gib.** — `font: 500 14px/1.4 mono`, `tabular-nums`, sredinsko.
  Zapis: `↑3` / `↓2` / `–`. Barve: gor `--barva-poudarek-tekst` (#4A7500),
  dol `--barva-negativna` (#B23A1E), brez premika `--barva-crnilo-4` (#6E655E).
- **Igralec** — `<Link>` z razredom `.lestvica__ime`, 18 px, barva
  `--barva-crnilo`; celica `overflow: hidden; text-overflow: ellipsis; white-space: nowrap`.
- **Klub** — 16 px, teža 300, `--barva-crnilo-3`, prav tako z odrezom.
- **Z – P** — `font: 500 16px/1.4 mono`, `tabular-nums`, `white-space: nowrap`;
  zmage `--barva-poudarek-tekst`, ločilo ` – ` `--barva-crnilo-4`, porazi
  `--barva-negativna`. (Razredi `.lestvica__zmage`, `.lestvica__locilo`,
  `.lestvica__porazi` ostanejo; `.lestvica__locilo` naj bo #8C837B.)
- **Rating** — `font: 600 20px/1.4 mono`, `tabular-nums`, `--barva-crnilo`.
- **Δ 30 dni** — `font: 500 15px/1.4 mono`, `tabular-nums`; zapis `+34`,
  `−31` (znak minus U+2212), `±0`; barve enake kot pri Gib.

### Moja vrstica

`.lestvica__vrstica--jaz`: podlaga `--barva-glavna-mehko` (#EAF3F9), ime v teži 700.
Razred ostane nespremenjen.

### Pod tabelo

- vrstica z opombo: zgornja črta 1 px `--barva-crta`, `margin-top: 12px`,
  `padding-top: 12px`, besedilo desno poravnano, mono 12 px verzalke
  `--barva-crnilo-3`: `Gib. in Δ: primerjava s stanjem pred 30 dnevi`
- obstoječi `p.namig` ostane nespremenjen

---

## Obnašanje

### Filtriranje in razvrščanje

1. **Mesto se izračuna pred filtriranjem** (kot že zdaj) — pri razvrstitvi po
   ratingu igralec obdrži svoje globalno mesto tudi v zoženem seznamu
   (glej `posnetki/02`: mesta 4, 9, 13).
2. Ko je izbrano razvrščanje po **Uspešnost** ali **Odigrane**, se stolpec `#`
   preštevilči 1…n glede na trenutni vrstni red (mesto po ratingu takrat ni več smiselno).
3. Vrstni red operacij: `filter(kategorija)` → `filter(iskanje)` → `sort(merilo)`.
4. Iskanje ostane, kot je: `polnoIme + ' ' + klub`, brez upoštevanja velikosti črk.
5. `Prikazanih X od Y` šteje po vseh filtrih; `Y` je vedno število vseh igralcev na lestvici.
6. Merila: `rating` = `rating` padajoče; `uspesnost` = `zmage / odigrane` padajoče
   (igralci z 0 odigranimi na konec); `odigrane` = `odigrane` padajoče.
7. Vsa obdelava je na odjemalcu (`useMemo`), brez novih klicev API.
8. Prazna stanja ostanejo: `Iskanju ne ustreza noben igralec.` — dopolni ga tako,
   da velja tudi za filter kategorije (npr. `Nobenega igralca v tej kategoriji.`).

### Stanje

```ts
const [iskanje, nastaviIskanje] = useState('')
const [kategorija, nastaviKategorijo] = useState<Kategorija>('Vsi')
const [merilo, nastaviMerilo] = useState<'rating' | 'uspesnost' | 'odigrane'>('rating')
```

Filtri se ne shranjujejo v URL ali localStorage (razen če se tako odločiš sam —
takrat uporabi query parametre, da je stanje deljivo).

### Podatki z zaledja

Nova stolpca potrebujeta polji, ki jih odgovor `statistikaApi.lestvica()`
morda še nima. Dopolni tip v `vmesnik/src/api/tipi.ts`:

```ts
premikMesta: number | null       // + = napredoval, − = nazadoval, 0 = brez premika
spremembaRatinga: number | null  // razlika ELO glede na stanje pred 30 dnevi
kategorija: string | null        // 'Člani' | 'Članice' | 'U19' | 'Veterani' …
```

Če zaledje polj (še) ne vrača:

- `premikMesta === null` → v stolpcu `Gib.` izpiši `–` v nevtralni barvi
- `spremembaRatinga === null` → v stolpcu `Δ 30 dni` izpiši `—`
- `kategorija === null` → igralec je viden samo pri izbiri `Vsi`; če noben
  igralec nima kategorije, skupino gumbov **Kategorija** skrij v celoti

Seznam kategorij izpelji iz podatkov (unikatne vrednosti), ne trdo zakodiraj —
`Vsi` je vedno prvi in privzet.

---

## Dostopnost

- Gumbi filtrov so `<button type="button">` z `aria-pressed={aktiven}`,
  združeni v `role="group"` z `aria-label="Kategorija"` oz. `aria-label="Razvrsti po"`.
- Zadetna površina gumba je najmanj 44×44 px (od tod `min-height: 44px`).
- `<caption class="samo-za-bralnik">` ostane; dopolni ga s trenutnim filtrom,
  npr. `Lestvica igralcev po klubskem ratingu ELO — kategorija Članice`.
- Puščici ↑ in ↓ nista edini nosilec pomena: dodaj `aria-label`
  (`Napredoval za 3 mesta` / `Nazadoval za 2 mesti` / `Brez premika`), ker sta
  sicer razlikovana samo z barvo.
- Lepljiva glava mora imeti neprosojno podlago (`--barva-papir`), sicer se
  vrstice pod njo vidijo skozi.
- Fokus ostane kot v `slog.css` (obroba `--barva-glavna`, brez radija).

---

## Oblikovalski žetoni

Vse barve so že v `:root` v `slog.css` — **ne uvajaj novih vrednosti**, uporabi spremenljivke.

| Žeton | Vrednost | Raba tukaj |
|---|---|---|
| `--barva-papir` | `#FBF9F5` | podlaga strani in lepljive glave |
| `--barva-crnilo` | `#14110F` | naslovi, imena, rating, aktiven gumb |
| `--barva-crnilo-2` | `#332E29` | uvodni odstavek |
| `--barva-crnilo-3` | `#5B534D` | klub, glave stolpcev, oznake |
| `--barva-crnilo-4` | `#6E655E` | nevtralno gibanje, ločilo |
| `--barva-crta` | `#DED7CE` | ločilne črte vrstic, obroba neaktivnega gumba |
| `--barva-glavna` | `#0088CE` | črte, poudarki brez besedila |
| `--barva-glavna-tekst` | `#0071AB` | prva tri mesta |
| `--barva-glavna-mehko` | `#EAF3F9` | podlaga moje vrstice |
| `--barva-poudarek-tekst` | `#4A7500` | zmage, pozitivno gibanje, +Δ |
| `--barva-negativna` | `#B23A1E` | porazi, negativno gibanje, −Δ |

Pisave: `--pisava-display` (Bricolage Grotesque) za `h1`/`h2`,
`--pisava-telo` (Karla) za besedilo, `--pisava-mono` (IBM Plex Mono) za vse
številke in oznake. Ritem 8 px (`--r1`…`--r8`). Radij povsod 0, senc ni.

## Sredstva

Nobenih novih sredstev. Ikon, odličij in emojijev v tabeli ni — tako zahteva `DESIGN.md`.

## Zaključni pregled

- [ ] Posnetek moje implementacije se ujema z `posnetki/01-lestvica-privzeto.png`
- [ ] Posnetek s filtrom `Članice` se ujema z `posnetki/02-lestvica-filter-clanice.png`
- [ ] Dolgo ime in dolg klub se odrežeta s `…` in ne prelomita vrstice
- [ ] Vse številke so mono in `tabular-nums`, desni robovi so poravnani
- [ ] Glava tabele ostane vidna med drsenjem
- [ ] Filtri delujejo s tipkovnico in imajo `aria-pressed`
- [ ] Ni novih barv, radijev, senc ali ikon
- [ ] `npm run lint` in obstoječi testi so čisti
