# Handoff: sklop »Kaj prinese tekma« (napoved spremembe ratinga) — različica 1a

## Pregled

Na profilu igralca obstaja zasebni sklop **»Kaj prinese tekma«**
(`vmesnik/src/komponente/NapovedTekme.tsx`): igralec izbere kateregakoli
nasprotnika in vidi, koliko Turnirko ratinga bi mu prinesla zmaga oziroma vzel
poraz, če bi tekmo odigrala zdaj.

Ta paket je **izboljšan izgled tega sklopa**. Zgradba ostane ista (naslovna
vrstica → namig → izbirnik nasprotnika → semafor ratingov → dve veliki številki →
izbirnik ravni → tabela vseh izidov → razlaga). Dodane so štiri stvari:

1. **Verjetnostni pas** pod semaforjem (6 px palica, modro polnilo = tvoja
   pričakovana zmaga) z mono legendo na obeh koncih.
2. **Označen tipičen izid** v tabeli — vrstici 3:1 in 1:3 dobita
   `border-left: 4px` v glavni barvi in mehko modro podlago (obstoječi vzorec
   »označena vrstica podatkov« iz `DESIGN.md`, razdelek 4, točka 6).
3. **Besedni opis izida** ob rezultatu v vrstici (»gladka zmaga«, »tipična
   zmaga«, »tesna zmaga«, »tesen poraz«, »tipičen poraz«, »gladek poraz«) —
   da poudarek ni odvisen samo od barve (WCAG 1.4.1).
4. **Os − 0 +** kot peti stolpec tabele: 1 px vodoravna črta, 1 px navpična
   ničla in 2 px oznaka lege, da se razmerje med tveganjem in dobičkom vidi
   brez branja številk. Nov razred, ki posnema obstoječi primitiv `.os`.

Nič drugega se ne spremeni: besedila, izračuni, poizvedbe in vrstni red
elementov ostanejo taki, kot so danes.

## O datotekah v paketu

Datoteke `*.dc.html` v tem paketu so **oblikovalska referenca, narejena v
HTML** — prototip, ki kaže želen izgled, ne produkcijska koda za kopiranje.
Nalogа je **poustvariti ta izgled v obstoječem okolju Turnirka**: React +
TypeScript, navaden CSS z BEM razredi v slovenščini v `vmesnik/src/slog.css`,
brez Tailwinda in brez knjižnic komponent. Prototip ima vse sloge zapisane
inline (tako deluje orodje, v katerem je narejen) — **v Turnirku morajo iti v
`slog.css` kot novi razredi ob obstoječih `.napoved__*`**.

Zavezujoč oblikovalski sistem je `turnirko-profil-redesign/project/DESIGN.md`.
Če se karkoli v tem paketu z njim ne ujema, velja DESIGN.md.

## Natančnost: visoka (hi-fi)

Posnetki zaslona so referenca na piko: barve, velikosti pisav, teže, odmiki in
širine stolpcev so končni. Implementacija mora biti **pikselsko enaka** — glej
razdelek »Postopek preverjanja« na koncu.

## Kaj se spremeni v kodi

| Datoteka | Sprememba |
|---|---|
| `vmesnik/src/slog.css` | novi razredi `.napoved__pas`, `.napoved__pas-polnilo`, `.napoved__pas-legenda`, `.napoved__opis`, `.napoved__vrstica--tipicna`, `.napoved__os`; spremenjeni `.napoved__vrstica` (5 stolpcev, levi odmik 12 px) in `.napoved__vrstica--glava`; dopolnjeno pravilo v `@media (max-width: 768px)` |
| `vmesnik/src/komponente/NapovedTekme.tsx` | v `Semafor` dodan pas; v vrstico tabele dodan opis izida in os; tipični vrstici dodan razred; v veliki številki nov rating ovit v `<span className="napoved__cilj">` |

Novih poizvedb, novih polj DTO in izračunov na strežniku **ni** — vse, kar je
potrebno, je že v `NapovedStran`/`izidi` (`sprememba`, `rating`,
`spremembaNasprotnika`, `mojiNizi`, `nizovNasprotnika`, `zmaga`,
`pricakovanOdstotek`).

## Zaslon: profil igralca → sklop »Kaj prinese tekma«

### Postavitev (od zgoraj navzdol)

Sklop je `<div>` v `.vsebina > section` (torej v stolpcu s `gap: 56px`,
notranji odmik strani 40 px levo/desno, okvir `max-width: 1280px`).

1. **Naslovna vrstica** — obstoječi `.naslovna-vrstica`:
   `border-top: 3px solid #14110f`, `padding-top: 16px`, flex, `align-items: baseline`,
   `justify-content: space-between`.
   - `h2` »Kaj prinese tekma« — Bricolage Grotesque 800, 40 px,
     `letter-spacing: -0.03em`, `line-height: 1`, `#14110f`.
   - desno `.plosca__zasebno` »Samo zate« — IBM Plex Mono 500, 12 px,
     `letter-spacing: 0.12em`, uppercase, `#0071ab`.
2. **Namig** (`.namig`) — Karla 300, 15 px, `line-height: 1.6`, `#5b534d`,
   `max-width: 74ch`, `margin-top: 16px`. Besedilo nespremenjeno:
   »Izberi kateregakoli igralca in poglej, koliko Turnirko ratinga bi ti prinesla
   zmaga oziroma vzel poraz, če bi tekmo odigrala zdaj.«
3. **Izbira nasprotnika** (`.napoved__izbira`) — grid
   `minmax(240px, 320px) minmax(0, 1fr)`, `align-items: end`, `gap: 24px`,
   `margin-top: 24px`.
   - levo `IzbirnikIgralca` z `vidnaOznaka`: mono oznaka »NASPROTNIK« 12 px
     `letter-spacing: 0.1em` `#5b534d`, pod njo polje `height: 44px`,
     `border: 1px solid #14110f`, `background: #ffffff`, Karla 400 17 px,
     `padding: 0 12px`, `border-radius: 0`.
   - desno `.napoved__nasprotnik` (`padding-bottom: 10px`): ime
     Bricolage 800 `clamp(22px, 2.6vw, 32px)` (na namizju 32 px),
     `letter-spacing: -0.03em`, `line-height: 1`, `#14110f`; pod njim klub
     mono 500 11 px `letter-spacing: 0.06em` uppercase `#5b534d`,
     `margin-top: 8px`.
4. **Semafor** (`.napoved__semafor`) — grid `minmax(0,1fr) auto minmax(0,1fr)`,
   `align-items: center`, `gap: 24px`, `margin-top: 32px`, `padding-top: 16px`,
   `border-top: 1px solid #14110f`.
   - leva/desna stran: mono oznaka 12 px `letter-spacing: 0.08em` uppercase
     `#5b534d` (»TI« / polno ime nasprotnika), pod njo številka Bricolage 800
     32 px `letter-spacing: -0.03em`, `line-height: 1.1`, `tabular-nums`,
     `#14110f`. Desna stran `text-align: right`.
   - sredina (`.napoved__sredina`): `text-align: center`, `padding: 0 24px`,
     `border-left`/`border-right: 1px solid #ded7ce`; odstotek Bricolage 800
     32 px `#0071ab`, pod njim mono »PRIČAKOVANA ZMAGA«.
   - **NOVO — pas** (`.napoved__pas`): `grid-column: 1 / -1`, `margin-top: 16px`;
     palica `height: 6px`, `background: #ede7df`, polnilo
     `background: #0088ce` s širino = `pricakovanOdstotek` %; brez radija, brez
     prehoda. Pod njo legenda (`.napoved__pas-legenda`): flex
     `justify-content: space-between`, `margin-top: 8px`, mono 500 12 px
     `letter-spacing: 0.08em` uppercase `#5b534d` — levo »Tvoja zmaga N %«,
     desno »Njegova zmaga (100−N) %«.
   - poved (`.napoved__razlika`): `grid-column: 1 / -1`, `margin-top: 16px`,
     Karla 300 15 px `#5b534d`, besedilo nespremenjeno
     (»Razlika je 107 točk v njegovo korist.«).
5. **Dve veliki številki** (`.profil__kazalniki.napoved__vrh`) — grid
   dveh enakih stolpcev, `margin-top: 24px`, `max-width: 680px`.
   - prvi `.kazalnik--prvi`: `padding-right: 24px`, brez leve črte;
     drugi: `padding-left: 24px`, `border-left: 1px solid #ded7ce`.
   - vrednost Bricolage 800 48 px `letter-spacing: -0.04em`, `line-height: 1`,
     `tabular-nums`; zmaga `#4a7500`, poraz `#b23a1e`.
   - oznaka mono 500 12 px `letter-spacing: 0.08em` uppercase `#5b534d`,
     `margin-top: 8px`: »ČE ZMAGAŠ 3:1 → 1700« / »ČE IZGUBIŠ 1:3 → 1676«.
     **NOVO:** ciljni rating v `#14110f` (`.napoved__cilj`), ostalo `#5b534d`.
6. **Izbirnik ravni** (`.izbirnik.napoved__ravni`) — flex `gap: 4px`,
   `flex-wrap: wrap`, `margin-top: 32px`. Gumb: `min-height: 44px`,
   `padding: 8px 12px`, `border: 1px solid #ded7ce`, `border-radius: 0`,
   mono 500 12 px `letter-spacing: 0.1em` uppercase, `color: #5b534d`, brez
   ploskve; aktiven: `background: #14110f`, `border-color: #14110f`,
   `color: #fbf9f5`. Vrstni red: Uradno · Klubsko · Rekreativno.
7. **Tabela izidov** — glava + šest vrstic.
   - grid **`minmax(0, 1fr) 116px 100px 152px 130px`**, `gap: 16px`,
     `align-items: center`, `max-width: 760px`,
     `padding: 14px 0 14px 12px` (glava `12px 0 12px 12px`).
   - glava: `margin-top: 16px`, `border-bottom: 1px solid #14110f`, mono 500
     12 px `letter-spacing: 0.08em` uppercase `#5b534d`; naslovi stolpcev:
     »Izid«, »Tvoja sprememba«, »Tvoj rating«, »Njegova sprememba«, »− 0 +«
     (zadnji štirje `text-align: right`).
   - vrstica: `border-bottom: 1px solid #ded7ce`,
     `border-left: 4px solid transparent`, brez podlage.
     **Tipična vrstica** (3:1 in 1:3): `border-left-color: #0088ce`,
     `background: #eaf3f9`.
   - stolpec 1: izid mono 600 17 px `tabular-nums` (zmaga `#4a7500`, poraz
     `#b23a1e`) + **NOVO** opis mono 500 11 px `letter-spacing: 0.06em`
     uppercase `#5b534d`, flex `align-items: baseline`, `gap: 12px`.
   - stolpec 2: lastna sprememba mono 600 20 px `tabular-nums`, barva izida.
   - stolpec 3: tvoj rating mono 500 17 px `tabular-nums` `#14110f`.
   - stolpec 4: njegova sprememba mono 400 14 px `tabular-nums` `#5b534d`.
   - stolpec 5 (**NOVO**, `.napoved__os`): `position: relative`, `height: 14px`;
     vodoravna črta `top: 9px; height: 1px; background: #ded7ce`, raztegnjena
     čez ves stolpec; ničla `width: 1px; top: 5px; bottom: -3px;`
     `background: #ded7ce`; oznaka `width: 2px; height: 14px; top: 0`, barva
     izida. Lege so odstotki: `((v − min) / (max − min)) * 96 + 2` %, kjer sta
     `min`/`max` najmanjša in največja `sprememba` med prikazanimi vrsticami
     (ničla po isti formuli z `v = 0`). Element je okrasen →
     `aria-hidden="true"`.
8. **Razlaga** (`.profil__primerjava`) — Karla 300 15 px, `line-height: 1.6`,
   `#5b534d`, `max-width: 74ch`, `margin-top: 16px`; formula v `<strong>` 700.
   Besedilo in vsi obstoječi `.namig` opozorilni odstavki (BREZ_RATINGA,
   PRVI_DAN …) ostanejo nespremenjeni.

### Interakcije in stanja

- **Izbirnik ravni**: `useState<RavenTekmovanja>` kot danes; klik prepiše
  tabelo in razlago. `aria-pressed` ostane.
- **Izbirnik igralca**: obstoječa komponenta `IzbirnikIgralca` (combobox,
  tipkovnica gor/dol/Enter/Escape, predlogi ležijo čez vsebino).
- **Prazna stanja** (nespremenjena): brez nasprotnika `»Dokler nasprotnik ni
  izbran, ni kaj napovedati.«`; med nalaganjem `»Računam …«`; napaka prek
  `NapakaPoizvedbe`.
- **Prehodi**: samo barva/obroba do 120 ms (`DESIGN.md`, razdelek 5, točka 12).
  Palica in os se ne animirata.
- **Hover**: gumbi ravni `color: #14110f`, `border-color: #14110f`. Vrstice
  tabele nimajo hover stanja.
- **Fokus**: `outline: 2px solid #0088ce`, `outline-offset: 2px`.

### Odzivnost

Obstoječi prelom **`@media (max-width: 768px)`** v `slog.css` (tam, kjer so že
pravila za `.napoved__izbira` in `.napoved__vrstica`) se dopolni:

- `.napoved__vrstica` → `grid-template-columns: minmax(0, 1fr) 88px 72px`,
  `gap: 8px`; skrijeta se **os in njegova sprememba**
  (`.napoved__os, .napoved__nasprotnikova { display: none }`) — vprašanje strani
  je lastna sprememba.
- `.napoved__opis` → `display: none` pod 480 px (v 390 px stolpcu se izid in
  opis ne zložita); označen tipičen izid ostane, ker ga nosi tudi 4 px rob.
- `.napoved__pas-legenda` ostane, mono 12 px je še berljiv.
- semafor: obstoječa pravila (`gap: 16px`, sredina `padding: 0 16px`,
  številke 24 px).

### Temna tema

Nobene nove barve izrecno ne zapisuj — uporabi spremenljivke, da temna tema
deluje sama: `--barva-polnilo` (prazen del pasu), `--barva-glavna` (polnilo
pasu, rob tipične vrstice), `--barva-glavna-mehko` (podlaga tipične vrstice),
`--barva-crta` (os in ničla), `--barva-poudarek-tekst` / `--barva-negativna`
(oznaka na osi). Barva besedila na obarvani podlagi mora biti zapisana izrecno
(`DESIGN.md`, razdelek 5, točka 10).

## Oblikovalski žetoni (vsi so že v `slog.css`)

| Namen | Spremenljivka | Svetla tema |
|---|---|---|
| papir sklopa | `--barva-papir` | `#fbf9f5` |
| črnilo | `--barva-crnilo` | `#14110f` |
| meta/oznake | `--barva-crnilo-3` | `#5b534d` |
| hairline | `--barva-crta` | `#ded7ce` |
| prazen del palice | `--barva-polnilo` | `#ede7df` |
| risoča modra (polnilo pasu, rob vrstice) | `--barva-glavna` | `#0088ce` |
| modro besedilo | `--barva-glavna-tekst` | `#0071ab` |
| podlaga označene vrstice | `--barva-glavna-mehko` | `#eaf3f9` |
| zmaga / pridobitev | `--barva-poudarek-tekst` | `#4a7500` |
| poraz / izguba | `--barva-negativna` | `#b23a1e` |
| polje za vnos | `--barva-bela` | `#ffffff` |

Pisave: `--pisava-display` Bricolage Grotesque (800/200),
`--pisava-telo` Karla (300/400/600/700), `--pisava-mono` IBM Plex Mono
(400/500/600). Ritem 8 px (`--r1`…`--r8`); edina izjema so 14 px navpični
odmiki vrstic tabele. `border-radius: 0` povsod, brez senc, brez gradientov.

## Podatki na posnetkih (za primerjavo)

Igralec 1684 (K 24), nasprotnik Matic Zupan 1791 (K 20), NTK Ljubljana,
pričakovana zmaga 35 %, razlika 107 točk, tekma na tri dobljene nize.
Sprememba = `K × margina × teža × (izid − pričakovano)`, margina 1,15 / 1,00 /
0,85 za razliko treh, dveh oziroma enega niza, teža 1,00 / 0,75 / 0,50.

**Uradno (teža 1,00)** — 3:0 `+18` → 1702 (`−15`) · 3:1 `+16` → 1700 (`−13`) ·
3:2 `+13` → 1697 (`−11`) · 2:3 `−7` → 1677 (`+6`) · 1:3 `−8` → 1676 (`+7`) ·
0:3 `−10` → 1674 (`+8`).

V produkciji vse te številke še naprej računa strežnik
(`NapovedTekmeStoritev`); v vmesniku se ne množi in ne zaokrožuje nič.

## Datoteke v paketu

- `Kaj prinese tekma 1a.dc.html` — **izbrana različica**, prototip sklopa v
  okvirju 1280 px (odpri v brskalniku; potrebuje `support.js` ob sebi).
- `Obe razlicici -1a in 1b-.dc.html` — arhiv obeh predlogov (1b = »ratinška
  lestev«, ni izbrana; le referenca).
- `support.js` — pogon prototipa, ni del izdelka.
- `posnetki/01-uradno.png` — referenca, raven **Uradno** (privzeto stanje).
- `posnetki/02-klubsko.png` — referenca, raven **Klubsko** (teža 0,75).
- `posnetki/03-rekreativno.png` — referenca, raven **Rekreativno** (teža 0,50).

Posnetki so narejeni pri širini vsebine 1280 px in 2× ločljivosti (2492 px
širine).

## Postopek preverjanja — primerjaj s posnetki, dokler se ne ujema

Ta korak ni neobvezen. Implementacija velja za končano šele, ko je razlika
proti posnetkom v `posnetki/` nezaznavna.

1. Implementiraj spremembe v `slog.css` in `NapovedTekme.tsx`.
2. Poženi vmesnik in odpri profil igralca, ki ima izbranega nasprotnika, tako
   da je vidna cela tabela izidov. Okno nastavi na **širino vsebine 1280 px**
   (okvir `--sirina-okvirja`), svetla tema, privzeta raven **Uradno**.
3. Posnemi zaslon **istega izreza** kot referenca: od 3 px črte nad naslovom
   »Kaj prinese tekma« do zadnje vrstice razlage, čez celo širino vsebine.
4. Odpri `posnetki/01-uradno.png` in svoj posnetek **hkrati** in ju primerjaj:
   - položaj in velikost naslova, oznake »SAMO ZATE«, namiga;
   - vrstica z izbirnikom in imenom nasprotnika (poravnava po dnu);
   - semafor: lege treh številk, navpični črti sredine, 6 px pas in legenda;
   - obe veliki številki (48 px), navpična črta med njima, mono oznaki;
   - izbirnik ravni: aktiven gumb je črn s papirjem, ostala dva z 1 px črto;
   - tabela: širine petih stolpcev, 4 px modri rob in mehka podlaga na 3:1 in
     1:3, barve številk, lege oznak na osi;
   - razlaga: prelom vrstic pri `max-width: 74ch`.
5. Za vsako odstopanje popravi **CSS, ne posnetka**, in ponovi korake 3–4.
   Pri odstopanjih nad 1 px v odmikih ali pri drugačni teži/velikosti pisave
   nadaljuj; ustavi se šele, ko se izreza prekrivata.
6. Ponovi primerjavo še za `posnetki/02-klubsko.png` in
   `posnetki/03-rekreativno.png`: klikni ustrezno raven in preveri, da se
   spremenijo **samo** številke (spremembe, ratingi, njegove spremembe, lege
   na osi in teža v razlagi), postavitev pa ostane pikselsko enaka.
7. Na koncu preveri še:
   - ozko okno (≤ 768 px): os in njegova sprememba skriti, ostalo brez
     vodoravnega drsnika;
   - temna tema (`prefers-color-scheme: dark`): pas, rob in podlaga tipične
     vrstice ostanejo berljivi, nobene trdo zapisane barve;
   - tipkovnica: `Tab` po izbirniku, gumbih ravni in povezavah; vidna obroba
     fokusa;
   - `prefers-reduced-motion`: brez prehodov.
