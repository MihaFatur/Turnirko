# Predaja: prenova strani »Kako deluje Turnirko rating« (/o-ratingu)

## Pregled

Prenova javne strani `/o-ratingu` (`vmesnik/src/strani/RazlagaRatingaStran.tsx`). Stran je zdaj ena zgodba v desetih korakih. Vsak korak gradi na prejšnjem in ima svoj interaktivni preizkus: napoved iz krivulje (vleci), sestavine obrazca, K, teža, preizkus tekme, razlaga lastne spremembe iz zapisnika, prvi dan novinca z grafom, odsotnost, uvrstitev na lestvico in vprašanja »Zakaj …?«.

Izbrana smer je »1a Zapisnik«. Korak 01 (napoved) in korak 10 (vprašanja) sta prevzeta iz smeri »1c Instrument«.

## O datotekah v paketu

Datoteke v `prototip/` so **oblikovne reference v HTML**, ne produkcijska koda. Naloga je, da jih **poustvariš v obstoječem vmesniku** (React + TypeScript, Vite, TanStack Query, navaden CSS z BEM razredi v `slog.css`), po vzorcih, ki jih repozitorij že uporablja. Inline slogov iz prototipa ne prepisuj. Pretvori jih v razrede v razdelku »Javna razlaga ratinga (/o-ratingu)« v `vmesnik/src/slog.css` in uporabi obstoječe primitive (`.naslovna-vrstica`, `.izbirnik`, `.gumb`, `.kazalnik`, `.kolofon`, `.obrazec__polje`, `.seznam-preprost`, `.namig` …).

Prototip odpreš tako, da `prototip/Rating - Koncna.dc.html` odpreš v brskalniku. `Maskota.dc.html` in `support.js` morata stati v isti mapi.

**Izračuni v prototipu tečejo v brskalniku** (zrcalo `TurnirkoRatingStoritev`, `UvrstitevNovinca`, `Neaktivnost`), ker prototip nima strežnika. V aplikaciji velja načelo iz PRODUCT.md: *strežnik odloča, vmesnik prikazuje*. Številke morajo priti z zaledja (glej »Podatki in zaledje«).

## Natančnost

**Visoka (hi-fi).** Barve, tipografija, razmiki, vsebina besedil in interakcije so končni. Postavitev mora biti pikselsko enaka posnetkom v `posnetki/` — glej »Primerjava s posnetki (obvezno)«.

---

## Primerjava s posnetki (obvezno)

Implementacija ni končana, dokler se tvoji posnetki ne ujemajo z referenčnimi. Delaj v zanki: **implementiraj → posnemi → primerjaj → popravi → ponovi**, dokler razlike ne izginejo (dovoljena je le razlika v glajenju pisav, < 0,5 % pikslov in brez vidnih zamikov).

### Referenčni posnetki

| Datoteka | Kaj je | Merilo |
|---|---|---|
| `posnetki/namizje-celota.png` | cela stran, namizje, okno 1280 CSS px | 909 px slike = 1280 CSS px (×0,7102); višina 6234 px = 8778 CSS px |
| `posnetki/namizje-01.png` … `namizje-13.png` | zaporedni izrezi iste strani (vidno okno 1280 × 760 CSS px) | ×0,7102; izrez *n* se začne pri `(n−1) × 676` CSS px, zadnji je dno strani |
| `posnetki/namizje-14.png` | korak 10, odprti vprašanji 01 in 06 | ×0,7102 |
| `posnetki/telefon-celota.png` | cela stran, telefon, okno 390 CSS px, **spodnja vrstica skrita** | 1 : 1 (390 × 12310) |
| `posnetki/telefon-prvi-zaslon.png` | vrh strani na telefonu, s spodnjo vrstico | ×2,3308; zajema 390 × 232 CSS px |

Lepljivi elementi (masthead, kazalo korakov, telefonska glava s trakom napredka) so v posnetkih cele strani na **naravnem mestu** (na vrhu oz. ob začetku seznama korakov). Tako jih izriše tudi Playwrightov `fullPage`. V svojem posnetku jih zato ne prestavljaj.

### Kako posneti svojo različico

1. Poženi zaledje (`cd zaledje && mvnw spring-boot:run`) in vmesnik (`cd vmesnik && npm run dev`).
2. Playwright (Chromium), `deviceScaleFactor: 1`:
   - **Namizje:** `viewport { width: 1280, height: 760 }`, odpri `http://localhost:5173/o-ratingu`, počakaj `document.fonts.ready`.
   - **Telefon:** `viewport { width: 390, height: 844 }`. Pred posnetkom skrij spodnjo vrstico (`.spodnja-vrstica { display: none }`), ker je `position: fixed`.
3. **Pred posnetkom podrsaj čez vso stran** v korakih po 600 px in pri vsakem počakaj 1000 ms. Animacije ob prvem prikazu (stolpci krivulje, stolpci K, palice teže, maskote) se sprožijo šele, ko sekcija pride v okno. Nato se vrni na vrh in naredi `page.screenshot({ fullPage: true })`.
4. Namizni posnetek pomanjšaj na širino 909 px (npr. `sharp().resize(909)`), da ima isto merilo kot referenca. Telefonski posnetek primerjaj neposredno.
5. Primerjaj s `pixelmatch` (prag 0,1) in shrani sliko razlik. Ob razliki v višini najprej poravnaj višino strani (presledki med koraki, višine grafov), šele nato podrobnosti.
6. Za vsako območje razlik poišči vzrok (razmik, velikost pisave, širina stolpca, barva), popravi in posnemi znova. Ponavljaj, dokler slika razlik ni prazna.
7. Na koncu ročno preveri še `namizje-14.png` (odprti vprašanji) in `telefon-prvi-zaslon.png` (telefonski posnetek z `deviceScaleFactor: 2.3308`, okno 390 × 232).

**Privzeto stanje ob posnetku** (vsi vnosi, kot jih stran nastavi ob nalaganju):
razlika v krivulji +200; izid nizov »3 : 1«; K-drsnik 4 tekme, brez vrnitve; preizkus tekme 1200 proti 1350, oba »30+«, brez vrnitve, Uradno; razlaga spremembe 1342 / 1484 / Poraz / »−15«; sidro »Rekreativec« (starost 16 skrita), prvi dan Klubsko s tekmami 960 Z, 700 P, 650 P, 1000 Z; odsotnost 8 mesecev; lestvica Moški, »3 ali več«, rating Da, zadnja tekma »Pod 18 mes.«, starost 16; vsa vprašanja zaprta.

Številke na posnetkih izhajajo iz trenutnih pravil (K 48, pribitki +10, teže 100/75/50 %, sidra po migracijah V21 + V40, odbitki 10/25/40). Če strežnik vrača drugačna pravila, se smejo razlikovati številke, postavitev pa ne.

---

## Zasloni in pogledi

Ena stran, dve postavitvi: **namizje** (> 640 px) z obstoječim mastheadom iz `Postavitev.tsx` in **telefon** (≤ 640 px) z `glava-telefon` in `spodnja-vrstica` (na tej poti ni aktivne postavke, poteza je skrita). Kazalo korakov ob strani se pokaže od **1100 px** naprej.

### Ogrodje strani

- `main.vsebina`: `padding 48px 40px 64px`, na telefonu `24px 20px 64px`.
- **Glava strani:** mreža `repeat(auto-fit, minmax(min(320px,100%),1fr))`, `gap 40px 56px`, `align-items: end`, `max-width 1200px`.
  - Levo `.naslov-strani`: nadnaslov »Turnirko rating« (200, `clamp(32px,4vw,48px)`, `#5b534d`), naslov »Kako deluje« (800, `clamp(56px,7.4vw,88px)`, `margin-top: calc(.08em + 6px)`), `line-height .88`, `letter-spacing -.035em`. Pod njim `.uvod` (20/300, `#332e29`, `max-width 48ch`, `margin-top 20px`).
  - Desno `.kolofon` (`border-top 3px #14110f`, `max-width 420px`), pet vrstic (`padding 10px 0`, `border-bottom 1px #ded7ce`, oznaka mono 12/500 verzalke `.08em` `#5b534d`, vrednost mono 600 16): Osnovni K · 48 | Novinec, pod 10 tekem · K 68 | Teža uradno · klub · rekr. · 100 · 75 · 50 % | Odbitek za odsotnost · največ −40 | Spodnja meja · 100.
- **Telo:** `display:flex; gap:56px; align-items:flex-start`.
  - **Kazalo korakov** (≥ 1100 px): `nav`, `position: sticky; top: 104px` (pod mastheadom; uporabi `--visina-glave` + 24 px), `flex: 0 0 208px`. Glava »Koraki« mono 12 z `border-bottom 1px #14110f`, `padding-bottom 8px`. Postavka: povezava `#kN`, `min-height 40px`, `padding 10px 0 10px 12px`, `border-left 4px`, mono 12/500 verzalke `.08em`, številka 600. Stanja: **aktiven** — rob `#0088ce`, podlaga `#eaf3f9`, besedilo `#0071ab`; **mimo** — rob in besedilo `#14110f`; **pred tabo** — rob `#ded7ce`, besedilo `#5b534d`. Prehodi barv 120 ms.
  - **Vsebinski stolpec:** `flex:1; min-width:0; max-width:800px`, koraki v stolpcu z `gap 88px`.
- **Telefon:** pod črto glave je lepljiv **trak napredka** (vstavi ga skozi `GlavaTelefona` → `ciljNaslova`): `padding 10px 20px`, `border-bottom 1px #ded7ce`; levo »03/10« (mono 600 12, `#0071ab`), sredina ime koraka (mono 12 verzalke, odrezano s tropičjem), desno palica 64 × 6 px (`#ede7df`, polnilo `#0088ce` = korak × 10 %, prehod širine 200 ms).

### Glava vsakega koraka

`.naslovna-vrstica`: `border-top 3px #14110f`, `padding-top 16px`, `flex`, `space-between`, `baseline`. Naslov h2 Bricolage 800 `clamp(32px,3.4vw,40px)`, `letter-spacing -.03em`. Desno meta »Korak 0N« (mono 12/500, `.1em`, verzalke, `#5b534d`). Uvodni odstavek: 17/1.55, `#332e29`, `max-width 62ch`, `margin-top 16px`.

Koraki imajo `id` `k1` … `k10` in atribut za opazovalca (prototip: `data-korak`). `IntersectionObserver` z `rootMargin: '-25% 0px -55% 0px'` nastavi aktivni korak (kazalo, trak) in si zapomni, katere je gledalec že videl (sproži animacije prikaza).

### 01 · Napoved pred tekmo (iz smeri 1c)

- Odstavek: »Preden se tekma začne, razlika ratingov napove, kolikšna je možnost zmage. Pri enakem ratingu je 50 : 50; vsakih nekaj sto točk razlike napoved nagne k boljšemu. Povleci po krivulji.«
- **Odčitek** (`flex`, `gap 32px`, `margin-top 32px`, poravnano na dno): velika številka odstotka (Bricolage 800, `clamp(88px,11vw,152px)`, `line-height .8`, `letter-spacing -.06em`, `#0071ab`, znak » %« v 0,45 em) in oznaka »Tvoja možnost«; desno, ločeno z `border-left 1px #ded7ce` in `padding-left 24px`, razlika (»+200«, 800 48 px) z oznako »Točk razlike«. Oznake so mono 12 verzalke `.1em`, `margin-top 12px`.
- **Krivulja:** SVG `viewBox 0 0 1200 380`, `width:100%`, podlaga `#fbf9f5`, `margin-top 32px`. Os: x = razlika −600 … +600 (`x = (d + 600)`), y = `20 + (1 − p) × 320`.
  - vodoravne črte pri p = 0 (`#ede7df`), 0,5 (`#ded7ce`), 1 (`#14110f`), 1 px;
  - **60 stolpcev** za razlike −590, −570 … +590 (korak 20), širina 14, od `y = 340` navzgor do višine `p × 320`. Barve: stolpec ob izbrani razliki (±10) `#0088ce`; levo od nje `#c9dcea`; desno `#ede7df`. Ob prvem prikazu zrastejo iz 0 (prehod 600 ms `cubic-bezier(.2,.8,.2,1)`);
  - krivulja: črna pot, 4 px, vzorčena po 10 točk;
  - izbrana razlika: navpična črta `#0088ce` 2 px (y 0–360) in kvadrat 24 × 24 `#0071ab` z obrobo 3 px `#fbf9f5`.
- Oznake osi x pod grafom (HTML, `bottom:-22px`, mono 12 `#5b534d`): −600, −400, −200, 0, +200, +400, +600; na telefonu samo −400, 0, +400 itd. (vsaka druga in 0).
- Vrstica smeri (`margin-top 40px`, mono 12 verzalke): »← nasprotnik močnejši« · »ti močnejši →«.
- Odstavek pod grafom: »Krivulja je ista za vse tekme. Pri enakem ratingu je 50 : 50, pri 200 točkah razlike boljši zmaga v 76 % tekem, pri 400 v 91 %. Stolpci pod njo so napovedi za vsakih 20 točk razlike.«
- **Interakcija:** `role="slider"`, `tabindex=0`, `aria-valuemin -600`, `aria-valuemax 600`, `aria-valuenow`. Ob `pointerdown` zajemi kazalec (`setPointerCapture`) in razliko nastavljaj ob premiku: `x/širina × 1200 − 600`, zaokroženo na 10, omejeno na ±600. Puščici levo/desno spremenita razliko za ∓10. `touch-action: none`, kazalec `ew-resize`.

### 02 · Sprememba po tekmi

- Odstavek omenja pričakovano iz koraka 01 (»… — 0,76 za razliko +200.«).
- **Pas petih členov:** mreža `repeat(auto-fit, minmax(min(108px,100%),1fr))`, zgoraj in spodaj `1px #14110f`, celice `padding 16px 12px`, `border-left 1px #ded7ce`. Oznaka mono 11 verzalke, vrednost Bricolage 800 32 px, opis 14/300 `#5b534d`. Členi: K 48 (»hitrost · korak 03«), Teža 100 % (»tekmovanje · korak 04«), Izid 1 / 0, **Pričakovano** (podlaga `#eaf3f9`, vrednost `#0071ab`), Sprememba (`#4a7500`, »ob zmagi«).
- **Obrazec:** `border-left 4px #0088ce`, podlaga `#eaf3f9`, `padding 14px 16px`, mono 600 15/1.7: »Zmaga: 48 × 100 % × (1 − 0,76) = **+12**« (zelena `#4a7500`) in »Poraz: … = **−36**« (`#b23a1e`).
- **Zmaga je zmaga** (dvostolpično, `minmax(300px,1fr)`, `gap 32px`, `margin-top 40px`): h3 24/800, odstavek, `.izbirnik` »3 : 0 | 3 : 1 | 3 : 2 | Predaja« (aktiven: polno črnilo / papir), namig »Izid 3 : 1 → **+12**. …«. Desno maskota s tablo »Zmaga je zmaga.« (merilo 1,5).
- Zaključni odstavek: »Kar eden dobi, drugi izgubi: ob tvoji zmagi nasprotnik **−12**, vsota je **0**. To drži, dokler imata enak K — korak 03.«

### 03 · K — kako hitro se premika

Dva stolpca (`minmax(300px,1fr)`, `gap 32px 48px`).
- Levo: drsnik »Odigranih tekem: **4**« (0–60, `height 44px`, `accent-color #0088ce`), potrditveno polje »Vrnitev po več kot 12 mesecih (prvih 15 tekem)«, **61 navpičnih stolpcev** (`height 120px`, `gap 2px`, `border-bottom 1px #14110f`). Višina stolpca je `K(n)/78`; barva: trenutni `#0071ab`, odigrani `#14110f`, prihodnji `#ded7ce`. Ob prvem prikazu zrastejo (600 ms). Pod njimi oznake 0 · 10 · 30 · 60 tekem (mono 11).
- Desno: velika številka K (Bricolage 800 96 px, `line-height .85`, `#0071ab`) z oznako »Tvoj K«, `border-bottom 1px #14110f`. Razčlenitev v štirih vrsticah (Osnova 48 · Manj kot 30 tekem +10 · Manj kot 10 tekem +10 · Vrnitev po odsotnosti +10). Neaktivna vrstica ima vrednost »—« in barvo `#6e655e`. Namig: »Ista zmaga kot v koraku 01 ti s tem K prinese **+16**.«

### 04 · Teža tekmovanja

Vrstice (`grid: 1fr minmax(80px,200px) 64px 64px`, `padding 14px 0`, `border-bottom 1px #ded7ce`, zgoraj `1px #14110f`): ime (18/600) in opis (14/300: »turnirji in lige NTZS«, »npr. Savinja liga«, »rekreativni turnirji in lige«), palica 6 px (`#ede7df` / `#0088ce`, ob prikazu se raztegne v 700 ms), odstotek (mono 600 16), primer spremembe (mono 600 20 `#4a7500`) = zmaga iz koraka 01 s K iz koraka 03.

### 05 · Preizkusi tekmo

Dva stolpca »Ti« (oznaka `#0071ab`) in »Nasprotnik«, vsak z `border-top 1px #14110f`: polje ratinga (mono 600 20, `min-height 52px`, obroba 1 px črnilo, belo), izbirnik »Pod 10 | 10–29 | 30+«, pri »Ti« še polje »Vračam se po več kot 12 mesecih«. Pod njima izbirnik tekmovanja »Uradno | Klubsko | Rekreativno«. Neveljaven vnos: »Rating mora biti med 100 in 3000.« (`#8c2b14`).
Rezultat (`border-top 3px #14110f`, `margin-top 32px`): vrstica »Tvoja možnost 30 %« … »70 % nasprotnik«, dvobarvna palica 6 px (zelena `#7bb900` / rjasta `#b23a1e`, brez prehoda barve), dva `.kazalnik` z velikima številkama (`clamp(56px,6vw,72px)`, +34 zelena, −14 rjasta) in oznakama »Če zmagaš → 1234«, »Če izgubiš → 1186«; račun v mono 13/1.7; namig o nasprotniku (K nasprotnika, vsota 0).

### 06 · Razloži mojo spremembo

- Primer v odstavku: Luka Jereb (NTK Savinja, 1342) izgubi s 1484 in ima ob tekmi −15 (izmišljen igralec).
- Tri polja (»Moj rating pred«, »Nasprotnik pred«, »Sprememba v zapisniku« — sprejme »−15«, »-15«, »+34«, »34«) in izbirnik »Zmaga | Poraz«.
- **Izid:** blok `padding 16px 20px`, `border-left 4px`:
  - ujemanje — rob `#7bb900`, podlaga `#eaf4d6`, naslov »Ujema se: K 48 · uradno 100 %« (24/800), opis igralca (»Ustaljen (30+ tekem). Možnost tvoje zmage je bila 31 %.«), račun mono 600 14 »48 × 1,00 × (0 − 0,31) = −14,70 → −15«;
  - več ujemanj — naslov »Ujema se z N možnostmi« in naštete možnosti;
  - brez ujemanja — rob `#b23a1e`, podlaga `#f8e5df`, naslov »Ne ujema se z navadnim korakom« in razlogi (prvi dan → korak 07, popravek za nazaj, spodnja meja 100, zunanja uvrstitev). Pri napačnem predznaku najprej stavek, da zmaga pri navadnem koraku nikoli ne vzame točk.
- **Mreža vseh možnosti:** 4 vrstice (K 48 / 58 / 68 / 78) × 3 stolpci (Uradno / Klubsko / Rekr.), stolpci `1.6fr 1fr 1fr 1fr`, vrednosti mono 15 desno. Celica, ki se ujema, ima podlago `#0071ab`, besedilo belo in težo 700. Pomen K: 48 ustaljen (30+); 58 neustaljen (10–29) ali ustaljen po vrnitvi; 68 novinec (pod 10) ali neustaljen po vrnitvi; 78 novinec po vrnitvi.

### 07 · Prvi dan novinca

- Izbirnik »Moški | Ženska | Rekreativec«. Pri spolu je drsnik »Starost v sezoni« (8–45). Desno velika številka izhodišča (800 96 px) z oznako (»Rekreativec ob vpisu« ali »Sidro · moški, 16 let«).
- Odstavek o uvrstitvi (prvi dan se ne sešteva; dve navidezni remi tekmi proti izhodišču).
- Izbirnik tekmovanja in maskota »Prvi dan skače.« (desno).
- **Graf:** SVG `viewBox 0 0 720 260`, podlaga bela, obroba `1px #ded7ce`. Os x enakomerno od izhodišča do zadnje tekme (x 40–700), y samodejno (min/max obeh nizov ±40, y 16–236). Pomožne črte `#ede7df`. Črtkana `#6e655e` 1,5 px (`5 5`) = **»Če bi se seštevalo po tekmah«**. Polna `#0088ce` 3 px = **prvi dan (uvrstitev)**. Točke so kvadrati 10 × 10 (izhodišče črnilo, porast `#4a7500`, padec `#b23a1e`, bela obroba 1,5). Nad vsako točko je vrednost (mono 600 12 na beli podlagi). Ključ pod grafom.
- **Seznam tekem:** `ol`, vrstica `grid 28px minmax(72px,96px) auto 1fr 44px`: številka, polje ratinga nasprotnika, Z / P, sprememba → rating in pod njo način (»navaden korak« / »iz vseh izidov«, mono 11 verzalke), gumb × (44 × 44). »+ Dodaj tekmo« (`.gumb`), največ 12 tekem, najmanj 1.
- Namig pod seznamom (prva tekma K 68 × teža …).

### 08 · Ko ne igraš

Drsnik »Mesecev brez tekme« (0–30). **Ravnilo** (višina 120 px): podlaga 6 px `#ede7df` na `top 56px`, polnilo `#0088ce` do trenutnega meseca, 31 črtic (vsaka 6. daljša, 22 px). Mejniki izmenično nad in pod ravnilom: 6 »−10 odbitek«, 12 »−25 vrnitev K+10«, 18 »skrit z lestvice«, 24 »−40 konec«. Doseženi mejnik je `#0071ab`, 18 mesecev `#b23a1e`, nedoseženi `#6e655e`. Spodaj trije kazalniki: odbitek (»−10«, »Odbitek · 1342 → 1332«), »Na javni lestvici« (Da zelena / Ne rjasta), »K 48 / K 58 ob vrnitvi«. Pod njimi namig, ki se spremeni po 12 mesecih.

### 09 · Na kateri lestvici si

Izbirniki: Spol (Moški / Ženska), Tekme na uradnem ali klubskem (0 / 1–2 / 3 ali več), Ima rating (Da / Ne), Zadnja tekma (Pod 18 mes. / 18+ mes.), drsnik starosti (8–70).
**Plošča lestvic:** 5 celic (`minmax(140px,1fr)`): Moški tekmovalci · Ženske tekmovalke · Moški rekreativci · Ženske rekreativke · Ni na lestvici. Izbrana ima `border-top 4px #0088ce` in podlago `#eaf3f9`; pri »Ni na lestvici« `#b23a1e` in `#f8e5df`. Ostale so `#6e655e`. Prehod 200 ms. Pod ploščo razlog (17/600). Pri tekmovalcu so pod razlogom še značke kategorij (U11 … U21, Člani, Veterani). Aktivna je polno črnilo / papir, ostale `#ede7df` / `#6e655e`. Pravila: U*nn*, če starost < *nn*; Člani vedno; Veterani od 40.

### 10 · Zakaj …? (iz smeri 1c)

- Vrstica: odstavek »Vprašanja, ki jih igralci res postavljajo. Vsak odgovor kaže na korak, ki ga razloži.« (levo) in maskota »Vprašaj.« (merilo 1,8, desno).
- Seznam: `border-top 3px #14110f`, vsak `<details>` z `border-bottom 1px #ded7ce`. `summary` je mreža `40px 1fr 24px`, `gap 12px`, `min-height 64px`, `padding 18px 0`: številka (mono 600 13 `#5b534d`, »01« …), vprašanje (Bricolage 800 22/1.15, `-.02em`), znak »+« (mono 600 24 `#0071ab`, ob odprtju zasuk za 45°, 120 ms). Odgovor: `margin 0 0 20px 52px`, 17/1.6, `max-width 62ch`, na koncu povezava na korak (»Korak 07 →«, mono 12 verzalke).
- Deset vprašanj in odgovorov je v prototipu (`vprasanja` v logiki). Besedila prevzemi dobesedno.
- Noga: `border-top 3px`, opomba »Turnirko rating ni uradna jakostna lestvica NTZS. …«, gumba »Na vrh« (`.gumb`) in »Na lestvico« (`.gumb--glavni`, `Link to="/lestvica"`).

### Maskota (korak 02, 07, 10)

Isti lik kot v glavi (`komponente/MaskotaPrizori.tsx`, `Lik` + `Tabla`). Ne riši ga znova, uporabi obstoječe komponente. Statična poza »tabla«: leva roka `rotate(150)`, podlaket `rotate(20)`; desna `rotate(−150)`, podlaket `rotate(−20)`. Lik stoji na 1 px črti črnila. Ko sekcija prvič pride v okno, se dvigne izza črte: `translateY(105%) → 0`, 620 ms `cubic-bezier(.2,.8,.2,1)`. Tabla se poravna iz `rotate(−10deg)` v 520 ms z zamikom 260 ms. Lik je `aria-hidden`. Pri `prefers-reduced-motion: reduce` je takoj v končnem stanju.

## Interakcije in vedenje

- Vsa polja za rating so `StevilskoPolje` (samo števke, največ 3000; veljavno 100–3000). Polje spremembe sprejme predznak (+, -, −).
- Izbirniki so `.izbirnik` / `.izbirnik__gumb--aktiven` z `aria-pressed`. Vse zadetkovne površine so ≥ 44 px.
- Prehodi: barve in obrobe 120 ms, palice in stolpci 600–700 ms `cubic-bezier(.2,.8,.2,1)` samo ob prvem prikazu, maskota kot zgoraj. Vse brez senc, brez radija, brez gradientov (izjema je 8 % polnilo pod krivuljo, ki ga ta različica ne uporablja).
- `html { scroll-behavior: smooth }` za skoke iz kazala. `scroll-padding-top` že nastavlja `Postavitev` (`--visina-glave`).
- Sidra `#k1` … `#k10`. Obstoječe povezave na `#prvi-dan` in `#lestvica` preusmeri na `#k7` in `#k9`, ali pa obdrži stara id-ja kot vzdevka.

## Stanje

Krivulja: `razlika`. Korak 02: `nizi`. Korak 03: `kN`, `kVrn`. Korak 05: `tRating`, `tNasp`, `izk`, `izkN`, `tVrn`, `raven`. Korak 06: `rRating`, `rNasp`, `rZmaga`, `rSpr`. Korak 07: `sSpol`, `sStarost`, `ravenDne`, `tekme[]`. Korak 08: `mes`. Korak 09: `lSpol`, `lTekme`, `lRating`, `lZadnja`, `lStarost`. Stran: `aktivenKorak`, `videniKoraki`. Privzete vrednosti so naštete zgoraj.

## Podatki in zaledje

Vmesnik pravil ne podvaja. Kar je novo, dodaj na zaledje (`RazlagaRatingaStoritev`, `PravilaRatingaDto`) in vsako spremembo pokrij s testom (pravilo repozitorija).

| Potreba | Rešitev |
|---|---|
| Krivulja in 60 stolpcev (razlika na 10 točk) | razširi `napovedi` v `PravilaRatingaDto` na razlike −600 … +600 po 10 (decimalni `p`, ne zaokrožen odstotek). Tabela z 0/50/…/400 ostane izpeljana. |
| Primeri v korakih 02–04 (zmaga pri razliki iz krivulje, s K in težo) | obstoječi `razlagaRatingaApi.izracun` (rating = 1000 + razlika, nasprotnik = 1000, `tekem` 30 / 10 / 0, `vrnitev`). Klice pri vlečenju zakasni (~120 ms) in uporabi `placeholderData: (prej) => prej`. |
| Mreža 4 × 3 v koraku 06 | štirje klici `izracun` (tekem 30 + brez vrnitve = K 48; 10 = K 58; 0 = K 68; 0 + vrnitev = K 78); vsak vrne vse tri ravni za zmago in poraz. |
| Sidro za vsako starost (drsnik 8–45) | v `RazlagaRatingaStoritev.STAROSTI` dodaj vse starosti 6–40 (ali novo polje). Danes jih je samo sedem. |
| Črtkana črta »če bi se seštevalo« | v `PrviDanNovincaDto.Korak` dodaj `ratingSestevek`: rating po navadnih korakih (K novinca × teža) od izhodišča, brez uvrstitve. |
| K po številu tekem, odbitki, pragovi, meje kategorij | iz `pravila` (`kOsnovni`, pribitki, pragovi, `odbitki`, `mesecevDoSkritja`, `pragRekreativca`, `spodnjaMeja`). Meje U11–U21 in veterane 40 dodaj v pravila ali uporabi obstoječe oznake pasov v vmesniku. |

## Oblikovni žetoni (iz `slog.css`, nič novega)

Barve: `#0088ce` glavna (risba), `#0071ab` glavna-polna / tekst, `#005a88` polna-močna, `#eaf3f9` glavna-mehko, `#c9dcea` glavna-črta, `#7bb900` poudarek, `#4a7500` poudarek-tekst, `#eaf4d6` poudarek-mehko, `#c6e28a` poudarek-srednje, `#b23a1e` negativna, `#8c2b14` negativna-tekst, `#f8e5df` negativna-mehko, `#e2a793` negativna-srednje, `#fbf9f5` papir, `#dcd8d1` namizje, `#14110f` črnilo, `#332e29` črnilo-2, `#5b534d` črnilo-3, `#6e655e` črnilo-4, `#ded7ce` črta, `#ede7df` polnilo, `#ffffff` bela.
Pisave: Bricolage Grotesque (200/800), Karla (300/400/600/700), IBM Plex Mono (500/600) — v aplikaciji že vgrajene prek fontsource.
Razmiki: ritem 8 px (8, 16, 24, 32, 40, 48, 56, 64, 88 med koraki). Radij 0. Senc ni.

## Sprememba DESIGN.md

Lastnik je za to stran odobril izjemo (9. 10. 2026). Zapiši jo v `DESIGN.md` kot nov razdelek **5d**:
1. maskota na `/o-ratingu` na treh mestih (korak 02, 07, 10), statična poza s tablo, en nastop ob prvem prikazu sekcije, kot je opisano zgoraj;
2. animirani grafi ob prvem prikazu (stolpci, palice) in vlečenje krivulje;
3. vse ostalo (radij 0, brez senc, hišne barve, tri pisave) velja brez izjeme.

## Datoteke

- `prototip/Rating - Koncna.dc.html` — celotna stran (predloga + logika z vsemi izračuni in besedili).
- `prototip/Maskota.dc.html` — lik s tablo (prirejen po `MaskotaPrizori.tsx`).
- `prototip/support.js` — izvajalnik prototipa (samo za ogled; ne kopiraj v aplikacijo).
- `posnetki/` — referenčni posnetki (glej zgoraj).
