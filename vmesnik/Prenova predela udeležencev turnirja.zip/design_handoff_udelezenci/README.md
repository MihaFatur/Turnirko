# Handoff: prenova pogleda »Udeleženci« (varianta 1a)

Navodila za Claude Code. Preberi do konca, preden karkoli spremeniš.

## 1. Naloga

V repozitoriju `MihaFatur/Turnirko` (mapa `vmesnik/`) zamenjaj izgled pogleda **»Udeleženci«** na strani dogodka (zavihek v pasu pogledov dogodka) z izgledom **1a** iz tega paketa. Spreminjaš samo ta pogled.

**Ne spreminjaj:** masthead, glave strani dogodka (naslov, značka faze, »← Nazaj na turnir«), pasu zavihkov, drugih pogledov, zaledja. Na posnetkih so ti deli narisani samo za kontekst, ker so del iste strani.

Obseg: posamezniki, dvojice (pari + »Brez soigralca«), ekipe s kadri, rezerve (format TOP). Faze: priprava, v teku, zaključen. Namizje (1280 px) in telefon (390 px).

Rezultat naj bo **popolnoma enak posnetkom**. Postopek preverjanja je v razdelku 8 in je obvezen.

## 2. Vsebina paketa

- `screenshots/`: ciljni posnetki (tabela v razdelku 7). Namizje je 1280 px pri 1x, telefon je 780 px pri 2x (390 CSS px).
- `reference/Udelezenci prenova.dc.html`: živa maketa. Odpri v brskalniku, v panelu Tweaks preklapljaš fazo in vrsto. Za varianto 1a glej krog 1, kartico `1a`. Kartici `1b` in `0` ignoriraj (`1b` je zavrnjena drzna različica, `0` je stanje pred prenovo). Hkrati odpri `support.js` iz iste mape.
- `reference/Udelezenci okvir.dc.html`: samo okvir strani za kontekst. Ne implementiraj.
- `fixtures.json`: izmišljeni podatki s posnetkov (36 igralcev, 3 rezerve, 4 brez soigralca, 16 parov, ekipe, izidi po fazah).
- Logika maketa je v metodi `aa()` v `reference/Udelezenci prenova.dc.html`. Uporabi jo kot referenčno implementacijo pravil iz razdelka 5.

## 3. Pravila repozitorija (veljajo, ne krši)

Najprej preberi `vmesnik/turnirko-profil-redesign/project/DESIGN.md` in `PRODUCT.md`. Drži se konvencij kode:

- Slogi v `vmesnik/src/slog.css`, razredi s slovenskimi imeni v obliki `blok__element--modifikator`. **Brez inline slogov** (maketa jih uporablja samo zaradi orodja).
- Uporabi obstoječe CSS spremenljivke (`--barva-papir`, `--barva-crnilo`, `--barva-crta`, `--barva-poudarek`, `--barva-poudarek-tekst`, `--r1`, `--r2` …). Spodnje šestnajstiške vrednosti so cilj. Če obstoječa spremenljivka da isto vrednost, uporabi njo. Če ne obstaja, jo dodaj ob podobnih.
- Brez novih odvisnosti, brez ikon (puščica ▾ je znak v mono pisavi), brez senc, radij 0.
- Tarče dotika najmanj 44 px. Kontrast besedila najmanj 4,5:1.
- Obstoječe komponente (`SeznamPrijavljenih`, `EkipeDogodka`, `IskanjeSeznama`, `PodnavigacijaDogodka`) predelaj ali zamenjaj. Izbriši slogove, ki jih po prenovi nihče več ne uporablja.

Izjema od DESIGN.md (odločitev lastnika): filtri po klubu niso več vrsta gumbov, ampak **dropdown meni**.

## 4. Oblikovalski tokeni

Barve: papir `#FBF9F5`, črnilo `#14110F`, črnilo 2 (sekundarno besedilo) `#5B534D`, črta `#DED7CE`, podlaga palice `#EDE7DF`, poudarek `#0088CE`, poudarek za besedilo `#0071AB`, zelena za besedilo `#4A7500`, izbrana postavka v meniju `#EAF3F9`, bela (polja) `#FFFFFF`.

Pisave: **Bricolage Grotesque** (naslovi, imena v karticah, velika številka ratinga), **Karla** (besedilo), **IBM Plex Mono** (oznake, številke, značke). Vse tri že uporablja stran. Številke: `font-variant-numeric: tabular-nums`.

Mono oznaka (»oznaka«): 500 12px/1.4, `letter-spacing: 0.1em`, `text-transform: uppercase`, barva črnilo 2. Na telefonu 11 px.

## 5. Zgradba in pravila pogleda

Zaporedje v sekciji, od zgoraj: **A** naslovna vrstica, **B** opomba, **C** filtri, **D** kartice nosilcev, **E** skupine, **F** dodatek.

### A. Naslovna vrstica
`border-top: 3px solid #14110F; padding-top: 16px` (telefon 10 px). Levo `h2`: Bricolage 800, 40 px (telefon 32 px), `line-height: 1`, `letter-spacing: -0.03em`. Desno meta v mono oznaki, poravnana desno: `36 prijavljenih · 7 klubov` (pri dvojicah »parov«, pri ekipah »ekip«). Besedilo `h2`: »Udeleženci«. Pri dvojicah v pripravi »Pari«. Pri ekipah »Ekipe«.

### B. Opomba
Karla 300 16 px/1.5 (telefon 15 px), barva črnilo 2, `max-width: 74ch`, 16 px pod naslovno vrstico.
- priprava: »Žreb še ni izveden. Številka je jakostno mesto; po njem se razporedijo nosilci.«
- v teku: »V igri X od Y. Izpadli so zbledeli.«
- zaključen: »Razporeditev je kot ob prijavi (po nosilcih); ob vsakem udeležencu piše, kje je končal.«

### C. Filtri
Namizje: ena vrstica, `align-items: flex-end`, `gap: 16px`: iskanje (320 px), dva dropdowna (po 240 px), skrajno desno števec v mono oznaki `36 od 36`. Vsako polje ima mono oznako 8 px nad poljem (»Iskanje«, »Klub«, »Razvrsti«).
Telefon: iskalno polje čez vso širino, pod njim v vrsti dva dropdowna (`flex: 1 1 0`, razmik 8 px). Oznaka je znotraj gumba nad vrednostjo (mono 10 px), gumb je 48 px visok. Števca ni.

Iskalno polje: najmanj 44 px visoko, `padding: 12px 14px`, `border: 1px solid #14110F`, bela podlaga, radij 0, Karla 15 px (telefon 16 px, da iOS ne povečuje). Placeholder »po priimku« (telefon »išči po priimku«).

Dropdown (lasten, ne nativni `<select>`): gumb najmanj 44 px visok, `padding: 0 16px`, `border: 1px solid #14110F`, bela podlaga, Karla 600 15 px, desno ▾ (mono 12 px, črnilo 2). Plošča: `position: absolute`, bela podlaga, `border: 1px solid #14110F`, `z-index: 30`, namizje: najmanj širina gumba, `width: max-content`, največ 320 px, pod gumbom (na posnetku `top` 72 px od vrha polja z oznako). Telefon: širina 240 px, prvi meni poravnan levo, drugi desno. Postavka: najmanj 44 px visoka, `border-bottom: 1px solid #DED7CE`, levo ime (Karla 400 15 px), desno število v mono 12 px črnilo 2. **Izbrana postavka:** `border-left: 4px solid #0088CE`, podlaga `#EAF3F9`, ime 600, `padding-left` 12 px (neizbrane 16 px).
Obnašanje: klik odpre/zapre. Izbira zapre meni. Odpre se lahko samo en meni. Dodaj še zapiranje ob kliku zunaj in z Escape, `aria-haspopup="listbox"`, `aria-expanded`, `role="listbox"`/`option`, upravljanje s tipkovnico (puščici, Enter). Tega maketa ne kaže, vizualno pa ne sme spremeniti ničesar.

Možnosti:
- **Klub**: »Vsi klubi« (skupno število), nato klubi po abecedi (`localeCompare` z `'sl'`) s številom. Pri dvojicah pare šteje v vsakem klubu igralcev.
- **Razvrsti**: »Po jakosti« (v zaključenem »Po nosilcih«), samo v zaključenem še »Po uvrstitvi«, »Po priimku«, »Po klubu«.

### D. Kartice nosilcev (samo ko je razvrščanje »Po jakosti« IN klub »Vsi klubi« IN iskanje prazno)
Kartice prikazujejo nosilce 1–4, razdeljene v dve skupini po dva: »Nosilca 1 in 2« in »Nosilca 3 in 4«.

Namizje: mreža 4 enako širokih stolpcev. Nad njo naslovna vrstica: dva naslova v mono oznaki (naslov v `#14110F`), vsak čez 2 stolpca, `border-bottom: 1px solid #DED7CE`. Drugi naslov ima `border-left: 1px solid #DED7CE` in `padding-left: 24px`. Telefon: dve skupini ena pod drugo (razmik 24 px), vsaka z lastnim naslovom in mrežo 2 stolpcev.
Kartica (namizje): `padding: 20px 24px 24px`, `border-top: 3px solid`, prva kartica `#0088CE`, ostale `#14110F`. Vsaka razen prve ima `border-left: 1px solid #DED7CE`. Notranji razmik 12 px.
1. Vrstica: levo mono oznaka »NOSILEC n« v črnilu, desno značka stanja (razdelek »Značke«), v mono oznaki.
2. Ime: Bricolage, `line-height: 1`, `letter-spacing: -0.035em`. Ime teže 200 in barve črnilo 2, priimek teže 800 v črnilu. Velikost 32 px (dvojice 22 px, ekipe 26 px). Pri dvojicah dva igralca v dveh vrsticah (razmik 2 px).
3. Klub: mono oznaka 12 px, `letter-spacing: 0.06em`, uppercase, črnilo 2. Pri dvojicah klubi, ločeni z ` · `.
4. Podnapis (samo ekipe): Karla 400 14 px črnilo 2, »Kader: Priimek · Priimek · Priimek«.
5. Rating in palica v vrsti (`gap: 16px`): številka Bricolage 800, 48 px (dvojice 26 px), `line-height: 0.9`, `letter-spacing: -0.03em`. Palica `flex: 1`, višina 6 px, podlaga `#EDE7DF`, polnilo `#0088CE`, širina = `(rating − 1400) / 8` odstotkov, omejeno na 0–100. Pri dvojicah številka kaže `2184 / 2165`, palica povprečje. Pri ekipah povprečje kadra.
Kartica (telefon): `padding: 14px 14px 16px`, razmik 8 px, značka stanja pod oznako »NOSILEC n« (stolpec, razmik 2 px). Ime 24 px (dvojice 15 px, ekipe 19 px), klub mono 11 px, rating 30 px (dvojice 15 px), palica pod ratingom. `border-top` 3 px kot na namizju, `border-left: 1px solid #DED7CE` na desni kartici v vrsti.

### E. Skupine nosilcev (glavni seznam)
Skupine, v tem vrstnem redu, prazne skupine se ne izrišejo:

| Naslov | Nosilci (mesta) |
|---|---|
| Nosilca 1 in 2 | 1–2 (samo kartice) |
| Nosilca 3 in 4 | 3–4 (samo kartice) |
| Nosilci 5–8 | 5–8 (skrajšaj zgornjo mejo na n; če je en sam, »Nosilec 5«) |
| Nosilci 9–16 | 9–16 (enako kot zgoraj, »Nosilec 9«) |
| Nosilci od 17 naprej | 17 in naprej |

Ko kartice niso prikazane (aktiven filter kluba, iskanje, ali razvrščanje ni »Po jakosti«), zgornji dve skupini preideta v seznam kot navadni skupini. Če je razvrščanje »Po jakosti«, skupine ostanejo tudi pri filtru. Pri drugih razvrščanjih seznam ni v skupinah, ampak je ena tabela z vrstico glave (`#`, »Igralec«/»Par«/»Ekipa«, »Rating«, mono oznaka, `border-bottom: 1px solid #14110F`), 1 stolpec do 24 vrstic, sicer 2.

Skupina: razmik med skupinami 32 px (telefon 24 px). Naslovna vrstica skupine: `display: flex; justify-content: space-between`, `padding-bottom: 8px`, `border-bottom: 1px solid #14110F`, mono oznaka s 0,12em razmika. Levo naslov v črnilu. Desno razpon ratinga `RATING 2099 – 2038` (najvišji – najnižji, ena številka za eno osebo). V fazi v teku desno namesto tega `V IGRI 5 / 8`.
Stolpci: skupina s 4 ali več vrsticami gre v **2 stolpca** (`gap: 0 56px`), vrstice razdeljene zaporedno (prva polovica levo, druga desno, `Math.ceil(n/2)`), sicer 1 stolpec. Na telefonu je vedno 1 stolpec.

Vrstica (namizje): mreža `56px minmax(0,1fr) 128px`, `gap: 16px`, `align-items: center`, `padding: 12px 0`, `border-bottom: 1px solid #DED7CE`.
- Stolpec 1: številka nosilca, mono 500 14 px, desno poravnana, črnilo 2.
- Stolpec 2: ime Karla 17 px/1.3, ime teže 300, priimek teže 700. Pod njim klub (Karla 300 14 px, črnilo 2). Pri ekipah še podnapis »Kader: …« (13 px). Pri dvojicah dve vrstici imen.
- Stolpec 3 (desno poravnan, stolpec, razmik 6 px): zgoraj značka stanja nad ratingom (mono 600 11 px, 0,08em, uppercase, `white-space: nowrap`), rating mono 500 15 px; pod tem palica 6 px, polna širina stolpca (isti izračun kot v karticah).
Vrstica (telefon): `44px minmax(0,1fr) 96px`, `gap: 12px`. Številka 13 px, ime 16 px, klub 13 px, značka 10 px (0,04em), rating 14 px.
Vrstice izpadlih v fazi v teku imajo `opacity: 0.62` (tudi kartice).

### F. Dodatek (pod seznamom)
`border-top: 1px solid #14110F`, `padding-top: 16px`, razmik 8 px. Naslov: mono oznaka 12 px, 0,12em, črnilo. Pod njim namig (Karla 300 14 px, črnilo 2) in imena.
- Posamezniki, faza v teku ali zaključen: »Rezerve (3)«, namig »Niso prišli v izbor najboljših. Vrstni red pove, kdo je bil prvi pod črto.«, imena v vrsti (`flex-wrap`, `gap: 8px 32px`), vsako `37. Gregor Habjan · NTK Velenje` (ime 16 px, klub Karla 300 14 px črnilo 2).
- Dvojice, faza priprava: »Brez soigralca (4)«, namig »Dokler ne dobijo para, v žreb ne gredo.«, imena brez številke.
- Drugače dodatka ni. Na telefonu so imena v stolpcu (razmik 6 px, 15 px).
Prazen rezultat filtra: `Noben udeleženec ne ustreza iskanju.` (Karla 300 16 px, črnilo 2).

### Značke stanja (besedilo v kartici in vrstici)
- priprava: brez značke.
- v teku: `V IGRI` v `#4A7500`, `IZPADEL` v `#5B534D`. Izpadli zbledijo (`opacity: 0.62`).
- zaključen: `KONČAL 3.–4.` itd. v `#4A7500` za končno mesto 1–4, drugače `#5B534D`. Oblika: `1.`, `2.`, `3.–4.`, `5.–8.`, `9.–16.`, `17.–n.` (zgornjo mejo skrajšaj na število udeležencev n; če je razpon en sam, npr. »17.«). Zaključen pogled je razporejen po nosilcih, kot ob prijavi, končno mesto pove samo značka. Razvrstitev »Po uvrstitvi« razvrsti po končnem mestu.

## 6. Podatki in zaledje

Vse prikazano že obstaja v `PrijavaDto` (`vmesnik/src/api/tipi.ts`): nosilec (`stNosilca`), ime, klub, rating, končno mesto (`koncnoMesto`). **Preveri imena polj v kodi, ne zaupaj tem.**

Manjka v zaledju (označeno kot »potrebuje zaledje«): stanje **»V igri« / »Izpadel«** med turnirjem. Maketa ga izmisli. Če polja še ni, **ne spreminjaj zaledja**: pripravi pogled tako, da značko prikaže samo, če podatek obstaja, in o tem obvesti lastnika.

Rating v palici: formula `(rating − 1400) / 8 %` je izbrana za podatke na posnetkih. Če ima prava lestvica druge meje, formulo parametriziraj v eni konstanti in o tem poroči. Za vizualno ujemanje s posnetki uporabi to formulo.

## 7. Posnetki zaslona

| Datoteka | Stanje |
|---|---|
| `01`, `02` | priprava, posamezniki, namizje / telefon |
| `03`, `04` | v teku, posamezniki (8 v igri, izpadli zbledeli) |
| `05`, `06` | zaključen, posamezniki (značke »Končal …«, rezerve) |
| `07`, `08` | priprava, dvojice (16 parov, »Brez soigralca«) |
| `09`, `10` | priprava, ekipe |
| `11`, `12` | priprava, posamezniki, odprt meni »Klub« |
| `13`, `14` | priprava, posamezniki, filter klub = »NTK Celje« (brez kartic) |

Vsak posnetek je celotna maketa strani, vključno z mastheadom, glavo strani in pasom zavihkov (obstoječe komponente, ki jih ne spreminjaš). Naslovna vrstica sekcije »Udeleženci« se začne pri desktop `y ≈ 455 px` (3 px črta pod pasom zavihkov). Na telefonu poišči isto črto na posnetku. **Primerjaj samo območje od te črte navzdol**, glava strani v pravi aplikaciji se lahko malenkostno razlikuje od narisane okvirne.

## 8. Postopek preverjanja (obvezen, ponavljaj do popolnega ujemanja)

1. Zaženi aplikacijo lokalno. Podatke iz `fixtures.json` vnesi tako, da pogled dobi točno te igralce (mock API prek Playwrighta `page.route` ali seed). Nastavi fazo, vrsto in stanje filtrov kot v tabeli.
2. Naredi posnetke pogleda s Playwrightom: namizje `viewport 1280×900`, `deviceScaleFactor 1`. Telefon `viewport 390×844`, `deviceScaleFactor 2`. `fullPage: true`. Počakaj na pisave (`document.fonts.ready`) in izklopi animacije.
3. Obreži posnetek na območje od naslovne vrstice sekcije navzdol in primerjaj s ciljnim posnetkom iz `screenshots/` (isti obrez). Primerjaj vizualno (odpri oba posnetka) **in** s številko (`pixelmatch`, prag 0,1; izpiši delež različnih pikslov in shrani diff sliko).
4. Poišči vsako razliko: razmik, velikost ali teža pisave, barva, poravnava, prelom vrstice, višina vrstice, črte, število stolpcev, vrstni red. Popravi v CSS/TSX in ponovi od koraka 2.
5. **Ne ustavi se**, dokler za vseh 14 posnetkov ni izpolnjeno: (a) razlike so samo sub-pikselsko glajenje robov pisave, (b) delež različnih pikslov je pod 0,5 % in ga znaš razložiti, (c) višina obrezane strani se ujema na ±2 px, (d) noben tekst ne prelomi vrstice drugače kot na posnetku. Pri vsaki preostali razliki napiši, zakaj ostane.
6. Preveri še brez posnetkov: konzola brez napak, dropdown deluje s tipkovnico (puščici, Enter, Escape), iskanje in klub skupaj, nobenega vodoravnega drsenja na 390 px, tarče najmanj 44 px.
7. Na koncu v odgovoru izpiši tabelo: posnetek, delež različnih pikslov, preostale razlike. Dodaj diff slike v `design_handoff_udelezenci/diffs/`.

Če je posnetek v nasprotju z DESIGN.md, ima prednost posnetek (odločitev lastnika). Če je posnetek v nasprotju z delovanjem aplikacije (npr. podatek ne obstaja), ne improviziraj: javi lastniku.
