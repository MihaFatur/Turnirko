# Handoff: Organizatorski pregled (smer 1a — zapisniška)

## Pregled
Nova stran pod **Moj profil** za uporabnike z vlogo organizatorja (paket Organizator Basic / Plus / Pro). Organizator na enem mestu vidi:
- kaj čaka njegovo dejanje (rezultati, zapisniki, prijave),
- vse lige in turnirje tekoče sezone, ki jih vodi,
- prihajajoče termine (14 dni),
- arhiv preteklih sezon,
- **porabo paketa** (tekoče lige X / meja, turnirji v sezoni X / meja) + podatke naročnine.

Implementira se **samo smer 1a** (v HTML datoteki sta tudi 1b in 1c — prezri ju).

## O datotekah
Datoteke v tem paketu so **oblikovne reference v HTML** (prototip videza), ne produkcijska koda. Naloga je stran **poustvariti v obstoječem vmesniku** (`vmesnik/`, React + TS, `src/slog.css`) z njegovimi vzorci: `Postavitev.tsx` (glava / spodnja vrstica), razredi v `slog.css` (`.gumb`, `.znacka`, `.palica`, `.kolofon`, `.napredek`, masthead), `MaskotaPrizori.tsx` (lik), `api/tipi.ts` (`OMEJITVE_ORGANIZATORJA`, `StatusTekmovanja`). Inline slogi v HTML-ju so samo zaradi prototipa — v kodi uporabi razrede in CSS spremenljivke iz `slog.css` (`--barva-glavna-polna` #0071AB itd.). Kjer razred že obstaja z enakim videzom, ga uporabi; nove razrede dodaj v `slog.css` po BEM imenovanju (`.org-pregled__…`).

Prototip odpreš tako, da `Organizatorski pregled.dc.html` odpreš v brskalniku (poleg mora biti `support.js` in `Maskota.dc.html`). `Posnetek Plus.dc.html` prikaže isto stran s paketom Plus (polna palica turnirjev).

## Natančnost
**High-fidelity.** Barve, tipografija, razmiki in besedila so končni. Poustvari pixel-perfect.

## ⚠ Obvezen postopek: primerjava s posnetki
V mapi `posnetki/` so referenčni posnetki. Po implementaciji **ponavljaj, dokler se tvoja stran in posnetki ne ujemajo popolnoma**:

1. Zaženi vmesnik (`npm run dev` v `vmesnik/`) z lažnimi podatki iz razdelka »Podatki« spodaj (organizator Marko Kovač, paket Pro, nato Plus).
2. Naredi posnetek zaslona (npr. Playwright: `page.setViewportSize({width:1280,height:900})`, `fullPage:true`; za telefon `390×844`, `deviceScaleFactor:2`).
3. Posnetek primerjaj z referenco **ob strani in s prekrivanjem** (npr. `pixelmatch` ali vizualni diff). Preveri: postavitev sekcij, širine stolpcev, velikosti in teže pisav, razmike med vrsticami, debeline črt (3 px / 1 px), barve, položaj in velikost maskote, prelome besedila.
4. Zapiši vsa odstopanja, jih popravi, ponovi korake 2–4.
5. Ne zaključi, dokler ni vidnih razlik (dovoljeno je le subpikselno glajenje pisav). Vsakič primerjaj vse štiri posnetke strani.

| Posnetek | Stanje |
|---|---|
| `posnetki/1a-namizje-pro.png` | namizje 1280 px, paket Pro (2/5 lig, 7/10 turnirjev) — maskota s tablo »3 prosta mesta« |
| `posnetki/1a-namizje-plus-polno.png` | namizje 1280 px, paket Plus (2/3 lig, 5/5 turnirjev) — maskota sedi na polni palici, »Polno — nadgradi« |
| `posnetki/1a-telefon-pro.png` | telefon 390 px @2x, Pro |
| `posnetki/1a-telefon-plus-polno.png` | telefon 390 px @2x, Plus |
| `posnetki/maskota-prizora.png` | oba prizora maskote povečano @2x |

Posnetki prikazujejo stran v celotni višini (brez lepljive glave). Glava in spodnja vrstica naj v aplikaciji ostaneta kot v `Postavitev.tsx`; v »Moj profil« je aktivna postavka navigacije.

## Zaslon: namizje (≥ 1024 px, referenca 1280 px)
Podlaga strani `#FBF9F5`. Vsebina: `padding: 48px 40px 64px`, sekcije v stolpcu z `gap: 56px`.

### 1. Uvod (dve koloni)
`grid-template-columns: minmax(0,1fr) 380px; gap: 56px; align-items: start`.

**Leva kolona**
- H1 v dveh vrsticah, Bricolage Grotesque, `line-height: .88`, `letter-spacing: -0.035em`:
  - »Organizator« — 200, 48 px, `#5B534D`
  - »Marko Kovač« — 800, 88 px, `#14110F`, `margin-top: calc(.08em + 6px)`
- Podnaslov: Karla 300, 20 px / 1.5, `#332E29`, `max-width: 48ch`, `margin-top: 20px`: »NTK Savinja · organizira od sezone 2023/24 · 31 tekmovanj.« (št. = vsa tekmovanja kadarkoli)
- **Pas sezone**: `margin-top: 40px`, `border-top: 3px solid #14110F`, mreža 3 enakih stolpcev. Celica: `padding: 16px 24px 20px Xpx` (prva 0, ostali 24 px + `border-left: 1px solid #DED7CE`).
  - oznaka: IBM Plex Mono 500, 12 px, `letter-spacing: .1em`, uppercase, `#5B534D`
  - število: Bricolage 800, 64 px / .85, `letter-spacing: -0.04em`, tabular-nums, `#14110F`, `margin-top: 12px`
  - opis: Karla 300, 14 px, `#5B534D`, `margin-top: 8px`
  - Vsebina: TEKMOVANJ `9` »2 ligi · 7 turnirjev« / UDELEŽENCEV `318` »Sezona 2026/27« / ODIGRANIH TEKEM `486` »25 čaka vnos ali potrditev«
- **Vrstica »Naslednje«**: mreža `auto 1fr auto`, `gap: 24px`, `padding: 16px 0 16px 12px`, `border-top: 1px solid #14110F`, `border-bottom: 1px solid #DED7CE`, `border-left: 4px solid #0088CE`.
  - »NASLEDNJE · 4. 10.« mono 12 px `#0071AB`; »Turnir mladih — Braslovče« Karla 700 18 px + » · OŠ Braslovče · 9.00« Karla 300 15 px `#5B534D`; »ODPRI →« mono 12 px `#0071AB`
- **Gumba** (`margin-top: 32px`, `gap: 8px`, `white-space: nowrap`): primarni `.gumb` »+ Nova liga« (`#0071AB`, rob `#0088CE`, bel tekst, Karla 700 15 px, `min-height: 44px`, `padding: 12px 16px`, brez radija) in sekundarni »+ Nov turnir« (rob 1 px `#14110F`, Karla 600).

**Desna kolona — paket (kolofon)**
- Glava paketa: `padding-bottom: 16px; border-bottom: 3px solid #14110F`
  - vrstica: »MOJ PAKET« (mono 12 px, `.12em`, `#5B534D`) ↔ značka »AKTIVEN« (`.znacka`: `padding: 6px 8px`, `#EAF4D6` / `#4A7500`, mono 600 11 px, `.1em`)
  - »Organizator« Bricolage 200, 28 px, `#5B534D`; pod njim ime paketa (»Pro« / »Plus« / »Basic«) Bricolage **800, 80 px, `#0071AB`**, `line-height: .88`, `margin-top: 6px`
- Dve vrstici kvote (`padding: <vrh> 0 12px; border-bottom: 1px solid #DED7CE`):
  - oznaka (»TEKOČE LIGE«, »TURNIRJI V SEZONI 2026/27«) mono 12 px ↔ vrednost »2 / 5« mono 600 16 px `#14110F`
  - palica `.palica`: 6 px, ozadje `#EDE7DF`, polnilo `#0088CE`, širina = uporabljeno / meja, `margin-top: 8px`
  - pod njo `margin-top: 8px`: opomba Karla 300 14 px `#5B534D` — »Še 3 lige v tej sezoni«; če polno: značka »POLNO« (`#F8E5DF` / `#8C2B14`) + »Nov turnir šele z nadgradnjo ali 1. 9. 2027« (Pro: »Nova sezona 1. 9. 2027«)
  - Zgornji odmik vrstice: 12 px; vrstica z maskoto 112 px (tabla) oz. 128 px (sedi), da je prostor za lik.
- Vrstice naročnine (`padding: 10px 0`, hairline): CENA »249,99 € / leto«, STANJE »Aktivna«, OBNOVA »14. 8. 2027« (oznaka mono 12 px, vrednost mono 600 16 px).
- Gumba (`margin-top: 16px`, oba `flex: 1`): »Upravljaj naročnino« (sekundarni) → `/narocnina`; »Nadgradi v Plus/Pro« (primarni) samo, če obstaja višji paket.

### Maskota ob palici (nova izjema k DESIGN.md 5b)
Lik iz `MaskotaPrizori.tsx` (glej `Maskota.dc.html` za točen SVG: viewBox izhodišče okrog (88, 52), bel obraz, zelen trak `#7BB900`, modra majica `#0071AB`, črte `#14110F` 2.8–3 px). Merilo na namizju **1.4**, telefon **1.05**. Lik stoji z nogami na zgornjem robu palice (`position:absolute; bottom: 6px` nad palico).
- Pojavi se **na natanko eni palici**: na prvi polni palici, sicer na palici lig.
- **Tabla** (ni polno): lik stoji na sredini praznega dela palice (`left = pct + (100-pct)/2 %`, `translateX(-50%)`), z iztegnjenimi rokami drži modro tablo (`#0071AB`, rob 2 px `#14110F`, zelena zareza 6 px levo) z napisom Bricolage 800 13 px bel: »N prosta mesta« (sklanjaj: 1 prosto mesto, 2 prosti mesti, 3–4 prosta mesta, 5+ prostih mest).
- **Sedi** (polno): lik na desnem koncu palice (`left: 100%`, `translateX(-100%)`), telo spuščeno za 12 enot, noge visijo čez palico, glava nagnjena −8°, tabla nagnjena −4°: »Polno — nadgradi« (Pro: »Polno do 1. 9.«). Klik na tablo → `/narocnina`.
- Gibanje (ni v posnetkih): vstop izza roba, drži ~4 s, izhod; skupaj ≤ 5 s, enkrat na obisk; `prefers-reduced-motion` → statično.
- V `DESIGN.md` dopolni 5b z novo izjemo (organizatorski pregled, kvota paketa).

### 2. »Čaka te«
Glava sekcije (enaka za vse sekcije): `border-top: 3px solid #14110F; padding-top: 16px`, H2 Bricolage 800 40 px `-0.03em` ↔ desno povzetek mono 12 px `.1em` `#5B534D` (»16 REZULTATOV · 9 PRIJAV«).
Pod njo (`margin-top: 24px`) dve koloni (`gap: 48px`): »REZULTATI IN ZAPISNIKI« in »PRIJAVE ZA POTRDITEV« (mono oznaka, `border-bottom: 1px solid #14110F`, `padding-bottom: 8px`).
Vrstica: mreža `64px 1fr auto`, `gap: 16px`, `padding: 16px 0 16px 12px`, `border-left: 4px solid #0088CE`, hairline spodaj. Število Bricolage 800 40 px `#0071AB`; ime Karla 600 18 px; opis Karla 300 14 px `#5B534D`; sekundarni gumb (»Vnesi rezultate«, »Vnesi zapisnik«, »Preglej prijave«).

### 3. »Sezona 2026/27«
Desno v glavi filtri (mono 12 px, `padding: 8px 12px`, `gap: 4px`): aktivni »VSE · 9« (`#14110F` / `#FBF9F5`), ostala »LIGE · 2«, »TURNIRJI · 7« (rob 1 px `#DED7CE`, `#5B534D`).
Podskupini »LIGE« in »TURNIRJI« (mono oznaka + črta 1 px `#14110F`; druga `margin-top: 32px`).
Vrstica: mreža `minmax(0,1fr) 200px 200px 112px`, `gap: 24px`, `padding: 18px 0 18px 12px`, hairline.
- levi rob 4 px `#0088CE`, **samo če nekaj čaka**; sicer prozoren
- ime Karla 700 20 px; opis Karla 300 15 px `#5B534D`
- stolpec »čaka«: mono 12 px uppercase — `#0071AB` če čaka (»2 ZAPISNIKA ČAKATA«), sicer `#5B534D` (»NASLEDNJE 11. 10.«)
- napredek (`.napredek`): mono oznaka »KOLO 3 / 18« + palica 6 px (`#0088CE`; zaključeno `#7BB900`)
- značka statusa desno: V TEKU `#0071AB`/bel, PRIPRAVA `#EDE7DF`/`#5B534D`, ZAKLJUČEN `#EAF4D6`/`#4A7500`
- zaključena tekmovanja: `opacity: .62`

### 4. »Prihaja« + »Arhiv« (dve koloni, `gap: 48px`)
- **Prihaja** (desno »NASLEDNJIH 14 DNI«): vrstica `88px 1fr auto`, `padding: 14px 0`; datum Bricolage 800 24 px + mono »SOB · OKT«; ime Karla 600 18 px + opis; vrsta mono 12 px s spodnjo črto 2 px (turnir `#0071AB`, ligaško kolo `#5A8A00`). Na dnu povezava »CELOTEN KOLEDAR →«.
- **Arhiv** (desno »PRETEKLE SEZONE«): vrstica `96px 1fr auto`; sezona mono 600 16 px »25/26«; obseg Karla 600 18 px »3 lige · 9 turnirjev«; opis »612 udeležencev · 1.418 tekem«; »ODPRI →« `#0071AB`.

## Zaslon: telefon (< 1024 px, referenca 390 px)
Glava telefona in spodnja vrstica (5 ikon) iz `Postavitev.tsx` / `IkoneNavigacije.tsx`. Vsebina `padding: 32px 20px 48px`, `gap: 40px`.
1. H1: »Organizator« 200 28 px + »Marko Kovač« 800 44 px.
2. Paket: enaka glava kot namizje (Pro 80 px), kvote z maskoto (merilo 1.05, zgornji odmik 84 / 96 px), vrstica OBNOVA. (Brez pasu sezone in gumbov.)
3. »Čaka te« (H2 32 px, desno skupno število): vrstice `44px 1fr 16px`, `min-height: 64px`, število 32 px `#0071AB`, ime Karla 600 16 px, kratko mono 12 px, »→«.
4. »Sezona 26/27«: en seznam (lige, turnirji v teku/pripravi, na koncu zaključeni), vrstica `1fr auto`, `min-height: 56px`, ime + mono napredek, značka desno. Na koncu vrstica »Arhiv · 3 pretekle sezone →«.

## Interakcije
- Vrstice tekmovanj → stran lige / turnirja. Gumbi v »Čaka te« → vnos rezultatov / zapisnika / pregled prijav tega tekmovanja.
- »+ Nova liga« / »+ Nov turnir«: če je ustrezna kvota polna, gumb ostane aktiven, a odpre obvestilo o nadgradnji (ne blokiraj tiho).
- Filtri VSE / LIGE / TURNIRJI filtrirajo seznam sezone.
- Hover/fokus: uporabi obstoječa stanja `.gumb` in povezav iz `slog.css`.
- Prazno stanje »Čaka te«: sekcija se skrije.

## Podatki / stanje
- Paket in meje: `OMEJITVE_ORGANIZATORJA` v `api/tipi.ts` (Basic 1/2, Plus 3/5, Pro 5/10). »Tekoče lige« = lige s statusom `PRIPRAVA` ali `V_TEKU`; »turnirji v sezoni« = vsi turnirji z začetkom v tekoči sezoni (1. 9.–31. 8.).
- Potrebno iz zaledja (`zaledje/`): seznam tekmovanj organizatorja (vloga z organizatorskimi pravicami, vključno s preteklimi), štetje neodigranih/nevnesenih tekem, nepotrjenih prijav, prihajajoči termini, povzetek po sezonah. Če endpoint ne obstaja, ga dodaj.
- Lažni podatki za primerjavo s posnetki so v logiki `Organizatorski pregled.dc.html` (`renderVals`: `vseLige`, `vsiTurnirji`, `vseCaka`, `vsePrihaja`, `arhiv`). Uporabi jih 1:1 za posnetke.

## Oblikovni žetoni
- Papir `#FBF9F5`, črnilo `#14110F`, besedilo 2 `#332E29`, sivo `#5B534D`, hairline `#DED7CE`, polnilo `#EDE7DF`
- Glavna `#0071AB` (tekst/polno), poudarek `#0088CE` (palice, robovi), zelena `#7BB900` / temna `#5A8A00` / na zeleni `#4A7500` na `#EAF4D6`, napaka `#8C2B14` na `#F8E5DF`
- Pisave: Bricolage Grotesque (naslovi, 200/800), Karla (telo, 300/600/700), IBM Plex Mono (oznake, 500/600) — že v projektu
- Črte: 3 px `#14110F` (glave sekcij), 1 px `#14110F` (podskupine), 1 px `#DED7CE` (vrstice), 4 px `#0088CE` levi rob (čaka dejanje)
- Brez radijev in senc. Hit area ≥ 44 px.

## Sredstva
- Logotip: znak s štirimi potezami iz `Postavitev.tsx` (ne iz starih predlog).
- Maskota: `MaskotaPrizori.tsx` — dodaj pozi »tabla« in »sedi« po `Maskota.dc.html`.
- Ikone spodnje vrstice: `IkoneNavigacije.tsx`.

## Datoteke
- `Organizatorski pregled.dc.html` — prototip (smer 1a je prva; 1b/1c prezri)
- `Maskota.dc.html` — lik s tablo (props `napis`, `poza: tabla|sedi`, `merilo`, `crta`)
- `Posnetek Plus.dc.html` — isti prototip s paketom Plus
- `support.js` — izvajalnik prototipa (samo za ogled)
- `posnetki/*.png` — referenčni posnetki za primerjavo
