# Handoff: Koledar Turnirko — prenova (varianta 1A)

## Pregled

Prenova **strani `/koledar`** in **sklopa Koledar na domači strani** v aplikaciji
Turnirko. Cilj je bil pregleden, lahko razumljiv in ne natrpan koledar.

Uporabnik je izbral **varianto 1A**. Varianti 1B (imenovani pasovi) in kateri
koli drugi predlog v izvorni datoteki **nista predmet te implementacije** —
implementiraj samo 1A in 1C.

### Kaj se spremeni glede na obstoječe stanje

| Danes | Po prenovi |
|---|---|
| 6 tonov identitete tekmovanja (`--barva-ton-1…6`), dodeljenih po vrstnem redu pojavitve | **2 pomenska tona**: turnir = `--barva-ton-1` (`#0071ab`), ligaško kolo = `--barva-ton-2` (`#5a8a00`) |
| `LegendaKoledarja` — vrsta žetonov z imeni tekmovanj pod mrežo, zavzame veliko prostora | **Legenda odpade.** Nadomesti jo enovrstični ključ (Turnir · Ligaško kolo · Odigrano) in seznam ob mreži, ki tekmovanja tako ali tako imenuje |
| Večdnevni turnir = kvadratek na vsakem dnevu | **Pas čez dneve** (en element, `grid-column: N / span M`) |
| Kvadratki 8×8 px v celici | **Trakovi**: polna širina celice, višina 7 px, razmik 5 px |
| Mreža omejena na 420 px, legenda pod njo | **Mreža 620 px** (prostor, ki ga je sprostila legenda) |
| Odigrano in prihajajoče izgledata enako | **Odigrano ima 32 % motnost** — prihajajoče takoj izstopa |
| Filtri: vrsta, stanje, organizator, kraj | Dodatno **kategorija** in **klub**; vrsta dobi segmentirani izbirnik Vse / Turnirji / Lige nad mrežo |
| Sklop Koledar je **prvi** na domači strani | Sklop je **pod Lestvico in nad 1 na 1** |

### Referenca

Mesečni pogled **Notion Calendar** (bivši Cron) — od tam sta prevzeta pas čez
dneve namesto podvojenih kartic in disciplina glede gostote celice. Vse ostalo
(tipografija, črte, brez radijev in senc) je obstoječi sistem Turnirka.

---

## O datotekah v paketu

`design/Turnirko - Koledar.dc.html` je **oblikovalska referenca v HTML** —
prototip, ki kaže želeni videz in obnašanje. **Ni produkcijska koda in se je ne
kopira.** Naloga je poustvariti ta videz v obstoječem okolju Turnirka:

- React 18 + TypeScript + Vite, `react-router-dom`, `@tanstack/react-query`
- **navaden CSS z BEM razredi v slovenščini** v `vmesnik/src/slog.css`
- brez Tailwinda, brez shadcn/ui, brez knjižnice komponent

Prototip uporablja vgrajene sloge samo zato, ker je prototip. **V kodi vse
oblikovanje pride v `slog.css`** kot razredi, po pravilu iz `DESIGN.md`
razdelek 4: »Preden napišeš nov razred, preveri, ali obstoječi zadošča.«

Odpri prototip v brskalniku (`design/Turnirko - Koledar.dc.html`, poleg mora
biti `support.js`) in ga primerjaj s posnetki.

## Zvestoba

**Visoka (hi-fi).** Barve, tipografija, odmiki in interakcije so končni.
Poustvari jih **pikselsko natančno** z obstoječimi razredi in spremenljivkami
iz `slog.css`.

---

## ⚠ Obvezen postopek: primerjaj s posnetki, dokler se ne ujema

V `screenshots/` so referenčni posnetki. **Delo ni končano, dokler se tvoja
implementacija z njimi ne ujema.** Ponavljaj ta krog:

1. Implementiraj (ali popravi) zaslon.
2. Zaženi `npm run dev` in odpri ustrezno pot.
3. **Naredi posnetek svoje implementacije** (Playwright / Puppeteer, npr.
   `npx playwright screenshot --viewport-size=1280,2200 http://localhost:5173/koledar moj-01.png`).
   Za telefon uporabi `--viewport-size=390,900`.
4. **Postavi svoj posnetek ob referenčnega in ju poglej** — oba naloži v
   kontekst in ju primerjaj element za elementom, ne na pamet.
5. Za vsako razliko zapiši, kaj je narobe (barva, odmik, velikost pisave,
   poravnava, širina stolpca), popravi in **ponovi od koraka 2**.
6. Nadaljuj, dokler ni razlik. Ne reci »dovolj blizu«.

Kontrolni seznam pri vsaki primerjavi:

- [ ] širine stolpcev (mreža 620 px, seznam ostanek, vrzel 40 px)
- [ ] višina celice 92 px, odmik 6 px
- [ ] trakovi: višina 7 px, navpični razmik 5 px, vodoravni odmik 3 px, prvi 30 px pod vrhom celice
- [ ] vikend ima podlago `--barva-polnilo`, izbrani dan `--barva-glavna-mehko`
- [ ] »danes« je polna črnilna ploskev s papirnatim besedilom
- [ ] večdnevni turnir je **en** pas čez dneve, ne več kvadratkov
- [ ] odigrano ima motnost 0.32 (trakovi) oz. 0.62 (vrstice seznama)
- [ ] ključ pod mrežo ima tri postavke in je 12 px mono uppercase
- [ ] `LegendaKoledarja` **ni več izrisana**
- [ ] telefon: glava 56 px, naslov 36 px, spodnja vrstica 60 px / 11 px mono

### Referenčni posnetki

| Datoteka | Kaj kaže | Pogoji |
|---|---|---|
| `screenshots/01-koledar-namizje.png` | `/koledar`, cel mesec, brez izbranega dne | 1280 px, oktober 2026, danes = 17. 10. 2026 |
| `screenshots/04-koledar-namizje-izbran-dan.png` | `/koledar?dan=2026-10-24` | isto, izbrana 24. oktobra |
| `screenshots/02-koledar-telefon.png` | `/koledar` na telefonu | 390 px |
| `screenshots/03-domaca-stran-sklop.png` | Domača stran: Lestvica → **Koledar** → 1 na 1 | 1280 px; sosednja sklopa sta v posnetku zatemnjena, ker nista predmet prenove |

Podatki na posnetkih so izmišljeni (oktober 2026, 10 tekmovanj). Ne
implementiraj jih — obstoječi `koledarApi.obdobje(od, do)` ostane vir.

---

## Zasloni

### 1. Stran `/koledar` (namizje)

**Namen:** gledalec najde, kdaj in kje se igra; klik na dan odpre njegova srečanja.

**Postavitev** (od vrha, vse znotraj obstoječega `<section>` v `.vsebina`):

1. `.stran-glava.stran-glava--ozka` — nadnaslov 48/200 »Turnirji in lige«,
   naslov 88/800 »Koledar«, uvod. **Nova kopija uvoda:**
   »Kdaj in kje se igra. Moder pas je turnir, zelen ligaško kolo. Klik na dan
   odpre njegova srečanja.«
2. Vrstica krmil `.krmila` — gumb `Filtriraj` + **nov** segmentirani izbirnik
   vrste + mono oznake preostalih skupin; desno števec »N tekmovanj«.
3. `.koledar-stran` — mreža `grid-template-columns: minmax(0, 620px) minmax(0, 1fr)`,
   `gap: 40px`, `align-items: start`.
   - levi stolpec: glava meseca, mreža, ključ
   - desni stolpec: naslovna vrstica + seznam po dnevih

**Sprememba v `slog.css`:** `.koledar-stran` ima danes `minmax(0, 420px)` →
**`minmax(0, 620px)`**.

#### Glava meseca (`.koledar__glava`) — nespremenjena

44×44 px puščici, ime meseca 12 px mono uppercase `0.12em` na sredini,
`border-bottom: 1px solid var(--barva-crta)`, `padding-bottom: 8px`.
Gumb »Danes« ostane, kadar prikazani mesec ni tekoči.

#### Mreža meseca

Ostane teden = vrstica, ponedeljek prvi, prazne celice s prozornimi robovi.
**Ključna sprememba: `<table>` ne more nositi pasov čez dneve.** Vsak teden
postane `position: relative` mreža sedmih celic, nad njo pa absolutno
pozicioniran pas trakov.

```
.koledar__teden      position: relative; display: grid;
                     grid-template-columns: repeat(7, 1fr);

.koledar__celica     min-height: 92px; padding: 6px;
                     border-right/bottom: 1px solid var(--barva-crta);
                     prva v vrstici dobi tudi border-left
                     prazna: border-color: transparent
                     vikend: background: var(--barva-polnilo)
                     izbran: background: var(--barva-glavna-mehko)
                     display: flex; flex-direction: column;
                     align-items: flex-start; justify-content: space-between;
                     gap: 4px; text-align: left;
                     font-family: var(--pisava-mono)

.koledar__stevilka   12px/1 mono 500, tabular-nums, var(--barva-crnilo-3)
        --danes      padding: 3px 6px; background: var(--barva-crnilo);
                     color: var(--barva-papir); font-weight: 600

.koledar__trakovi    position: absolute; left/right: 0;
                     top: 30px; bottom: 6px;
                     display: grid; grid-template-columns: repeat(7, 1fr);
                     grid-auto-rows: 7px; row-gap: 5px;
                     pointer-events: none

.koledar__trak       grid-column: <stolpec> / span <dnevi>;
                     grid-row: <pas + 1>;
                     margin: 0 3px;
                     background: var(--ton-vnosa);
                     pointer-events: auto
        --pretekel   opacity: 0.32
```

- Prazna celica **ni gumb** — ostane `<td>` / `<div>` brez `onClick`
  (v prototipu je `<button disabled>` samo zato, ker je mreža iz `div`-ov).
- Celica z vnosi je gumb, `min-height: 92px` zadošča 44 px dotiku.
- Če v teden ne gre vse: **največ 4 pasovi**, ostalo se prešteje in izpiše
  v celici kot `+N` v 11 px mono `var(--barva-crnilo-3)` (obstoječi
  `.koledar__vec`), poravnano na dno celice.

**Razporeditev trakov v pasove** (na teden, čista funkcija v `pomozno/koledar.ts`):

```
1. za vsak vnos izračunaj presek z ednem: od = max(vnos.datum, prviDanTedna),
   do = min(vnos.datumKonca, zadnjiDanTedna); če je od > do, ga v tem tednu ni
2. stolpec = indeks(od) + 1, razpon = indeks(do) - indeks(od) + 1
3. uredi po razponu navzdol, nato po stolpcu, nato po datumu
   (dolgi pasovi gredo zgoraj — sicer se kratki zataknejo pod njimi)
4. greedy: vsak kos v prvi pas, kjer se ne prekriva z že postavljenim
5. kos s pasom >= 4 ne gre v izris; prišteje se k števcu +N vsakega dne,
   ki ga zaseda
```

#### Ključ pod mrežo (nov, nadomešča `LegendaKoledarja`)

Vrsta treh postavk, `display: flex; gap: 20px; padding-top: 4px`.
Vsaka: 16×7 px ploskev + 12 px mono uppercase `0.1em` `var(--barva-crnilo-3)`.

| Postavka | Ploskev |
|---|---|
| TURNIR | `var(--barva-ton-1)` |
| LIGAŠKO KOLO | `var(--barva-ton-2)` |
| ODIGRANO | `var(--barva-ton-1)`, `opacity: 0.32` |

`LegendaKoledarja` se **ne kliče več** — ne na strani koledarja ne v sklopu na
domači strani. Če je nikjer drugje ne uporabljaš, jo odstrani iz
`komponente/Koledar.tsx`.

> Pogoj 3 iz `DESIGN.md` (»barva ni nikoli edini nosilec podatka«) je izpolnjen:
> ključ stoji pod vsako mrežo, seznam ob mreži pa vsako tekmovanje izpiše z
> imenom.

#### Seznam ob mreži — nespremenjen

`.naslovna-vrstica` (3 px črta) + `.sekcija__naslov--manjsi` (32 px) z imenom
meseca ali polnim datumom izbranega dne, desno `Cel mesec` pri izbranem dnevu.
Nato skupine po dnevih: `.podnaslov-sekcije` + `VrsticaKoledarja`.

**Edina sprememba vrstice:** odigran vnos (`datumKonca < danes`) dobi
`opacity: 0.62`. Levi rob 4 px ostane, le da je zdaj vedno eden od dveh tonov.

### 2. Stran `/koledar` (telefon, ≤ 640 px)

Isti podatki, en stolpec: glava meseca → mreža → ključ → seznam.

- celica `min-height: 60px`, `padding: 4px`, številka 11 px mono
- pas trakov: `top: 28px; bottom: 4px; grid-auto-rows: 5px; row-gap: 3px`
- imena dni 11 px mono, `letter-spacing: 0.06em`, sredinsko
- segmentirani izbirnik vrste `min-height: 40px`, `padding: 8px 10px`
- seznam pokaže **prve štiri** vnose meseca, dokler dan ni izbran

Okvir strani je obstoječi: `.glava-telefon__vrsta` 56 px, `.naslov-mobi__nad`
12 px mono, `.naslov-mobi--seznam` 36 px / 0.95, `.spodnja-vrstica` 60 px
postavke, 11 px mono. **Ne spreminjaj jih.**

> Opomba: `/koledar` ni med `spodnjePovezave` niti v `PODPOTI`
> (`komponente/Postavitev.tsx`), zato na telefonu tu ni označene postavke.
> Predlog (izven obsega, potrdi z naročnikom):
> `PODPOTI['/turnirji'] = ['/dogodki', '/koledar']`.

### 3. Sklop Koledar na domači strani

**Sprememba lege:** v `strani/DomacaStran.tsx` premakni `<KoledarSklop />`
**za sklop Lestvica in pred sklop 1 na 1**. Ostali sklopi ostanejo, kot so.

Vsebina sklopa ostane (mreža tekočega meseca levo, »Naslednje« desno), s
temi popravki:

- `.domov__koledar` `grid-template-columns: minmax(0, 420px) minmax(0, 1fr)`,
  `gap: 56px`
- mreža je kompaktna: celica `min-height: 58px`, `padding: 4px`, številka 11 px;
  trakovi `top: 26px; bottom: 4px; grid-auto-rows: 5px; row-gap: 3px`
- nad mrežo ena vrstica: ime meseca 12 px mono levo, števec »N tekmovanj«
  desno, pod njima `border-bottom: 1px solid var(--barva-crta)`.
  Puščic za listanje tu **ni** (kot doslej)
- pod mrežo isti dvodelni ključ (Turnir · Ligaško kolo) v 11 px mono
- desno `.podnaslov-sekcije` »Naslednje« + tri `VrsticaKoledarja` + gumb
  `Poglej si celoten koledar` (`align-self: start`)
- `LegendaKoledarja` pod obema stolpcema **odpade**

---

## Interakcije in obnašanje

| Sprožilec | Učinek |
|---|---|
| Klik na dan z vnosi | `?dan=YYYY-MM-DD` v naslovu (`replace: true`), seznam se zoži na ta dan, celica dobi `--barva-glavna-mehko` |
| Ponoven klik na isti dan | izbor se sprosti (`nastaviNaslov({}, { replace: true })`) |
| `Cel mesec` | isto kot sprostitev izbora |
| Puščici | `premakniMesec(±1)`; izbrani dan odpade (pripada mesecu) |
| `Danes` | skok v tekoči mesec; viden samo, kadar gledalec ni v njem |
| Vse / Turnirji / Lige | filtrira po `vnos.vrsta`; barve in trakovi se preračunajo; obnaša se kot skupina `vrsta` v `useFiltri` |
| `Filtriraj` | obstoječe `KrmilaSeznama` + `ModalnoOkno` |
| Prehod miške čez dan | `background: var(--barva-vrstica-hover)` |
| Prehod miške čez vrstico seznama | `background: var(--barva-vrstica-hover)` |

Prehodi: samo barva/obroba do 120 ms (`DESIGN.md` razdelek 5.12). Trakovi se ne
animirajo.

### Dostopnost

- celica z vnosi ohrani `aria-pressed` in
  `aria-label="{dan}. — {imena tekmovanj}"`
- prazna celica ni v fokusnem zaporedju
- trak ima `title` s polnim imenom tekmovanja
- kontrast: ton je vedno le ploskev, nikoli podlaga pod besedilom
  (`DESIGN.md` razdelek 2, pogoj 2) — merilo je 3:1, oba tona sta nad 3,7:1

---

## Stanje

Nespremenjeno glede na današnjo kodo, z eno dodatno spremenljivko:

| Kje | Spremenljivka | Vir |
|---|---|---|
| naslov | `dan` | `useSearchParams()` — izbrani dan je KRAJ, deljiv s povezavo |
| stanje strani | `mesec: Mesec` | `useState`, izhodišče `mesecIzIso(izbraniDan ?? danes)` |
| stanje strani | filtri | `useFiltri(vsi, SKUPINE, RAZVRSTITVE)` |
| **novo** | vrsta iz segmentiranega izbirnika | del izbora `useFiltri`, skupina `vrsta` — **ne uvajaj vzporednega stanja** |

Podatki: `useQuery({ queryKey: ['koledar', od, do], queryFn: () => koledarApi.obdobje(od, do) })`.
Sklop na domači strani še naprej nalaga 4 mesece naprej, mreža kaže tekočega.

### Kaj se v `pomozno/koledar.ts` spremeni

```ts
// ODSTRANI: TONOV = 6 in barveTekmovanj() — dodeljevanje tonov po pogledu
// DODAJ:
export function tonVnosa(vnos: KoledarVnosDto): 1 | 2 {
  return vnos.vrsta === 'TURNIR' ? 1 : 2
}
// DODAJ: razporeditev trakov v pasove po tednu (glej algoritem zgoraj)
export function trakoviTedna(
  teden: (string | null)[],
  vnosi: KoledarVnosDto[],
  najvecPasov: number,
): { trakovi: Trak[]; skriti: Map<string, number> }
```

`dneviVnosa`, `poDnevih`, `celiceMeseca`, `prihajajoci`, `kljucTekmovanja`
ostanejo nespremenjeni. `poDnevih` je še vedno vir seznama — večdnevni turnir
se v seznamu upravičeno pojavi pri vsakem svojem dnevu (glej posnetek 01:
Pokal Slovenije stoji pri 3. in 4. oktobru).

`komponente/Koledar.tsx`: `slogTona` sprejme `1 | 2` namesto `number | undefined`
(nevtralnega črnila ni več — vsak vnos ima ton, ker ton pomeni vrsto).

---

## Oblikovalski žetoni

Vsi že obstajajo v `slog.css`. **Ne dodajaj novih barv.**

```css
/* Ploskve koledarja — zdaj pomenske */
--barva-ton-1: #0071ab;   /* turnir       (temna: #4fb3e8) */
--barva-ton-2: #5a8a00;   /* ligaško kolo (temna: #9fd62e) */
/* --barva-ton-3 … -6 v koledarju niso več v rabi. Pustiti jih v :root je
   neškodljivo; če jih nič drugega ne uporablja, jih odstrani skupaj s
   komentarjem »Paleta koledarja« in uskladi DESIGN.md razdelek 2. */

--barva-papir:         #fbf9f5;
--barva-crnilo:        #14110f;
--barva-crnilo-2:      #332e29;
--barva-crnilo-3:      #5b534d;
--barva-crta:          #ded7ce;
--barva-polnilo:       #ede7df;   /* vikend */
--barva-glavna-mehko:  #eaf3f9;   /* izbrani dan */
--barva-vrstica-hover: #f3efe9;

--pisava-display: 'Bricolage Grotesque Variable', 'Bricolage Grotesque', sans-serif;
--pisava-telo:    'Karla Variable', Karla, sans-serif;
--pisava-mono:    'IBM Plex Mono', monospace;
```

Mere (vse večkratniki 8, razen hairline zamikov 3–6 px):

| Kaj | Namizje | Domača stran | Telefon |
|---|---|---|---|
| višina celice | 92 px | 58 px | 60 px |
| odmik celice | 6 px | 4 px | 4 px |
| višina traku | 7 px | 5 px | 5 px |
| razmik med pasovi | 5 px | 3 px | 3 px |
| vrh pasu trakov | 30 px | 26 px | 28 px |
| vodoravni odmik traku | 3 px | 3 px | 3 px |
| največ pasov | 4 | 3 | 3 |
| širina mreže | 620 px | 420 px | 100 % |
| vrzel med stolpcema | 40 px | 56 px | — |

Motnost: trak odigranega 0.32, vrstica odigranega vnosa 0.62.
`border-radius` je povsod 0. `box-shadow` ni nikjer.

---

## Sredstva

Nobenih novih. Edina ikona v vmesniku ostane logotip (`ZnakTurnirko` v
`komponente/Postavitev.tsx`). Pisave so že vgrajene lokalno prek fontsource.

---

## Datoteke

### V tem paketu

- `design/Turnirko - Koledar.dc.html` — prototip; v njem je varianta **1A**
  (namizje + telefon), varianta 1B (**ne implementiraj**) in **1C** (domača stran)
- `design/support.js` — izvajalno okolje prototipa; mora biti poleg HTML

### Ki jih boš spreminjal v repozitoriju

| Datoteka | Kaj |
|---|---|
| `vmesnik/src/pomozno/koledar.ts` | odstrani `barveTekmovanj`/`TONOV`, dodaj `tonVnosa` in `trakoviTedna` |
| `vmesnik/src/komponente/Koledar.tsx` | mreža iz tabele v `grid` s pasovi trakov; `slogTona`; odstrani `LegendaKoledarja` iz rabe |
| `vmesnik/src/komponente/KoledarSklop.tsx` | kompaktna mreža, brez legende, dvodelni ključ |
| `vmesnik/src/strani/KoledarStran.tsx` | segmentirani izbirnik vrste, širši stolpec mreže, nov uvod |
| `vmesnik/src/strani/DomacaStran.tsx` | premakni `<KoledarSklop />` pod Lestvico, nad 1 na 1 |
| `vmesnik/src/slog.css` | razdelek 11: `.koledar__teden`, `.koledar__trakovi`, `.koledar__trak`, `.koledar-kljuc`; popravi `.koledar-stran`, `.domov__koledar`, `.koledar__celica`; odstrani `.koledar-legenda*` |
| `turnirko-profil-redesign/project/DESIGN.md` | razdelek 2 »Paleta koledarja« opisuje šest tonov — po tej prenovi jih je dva in pomenita vrsto tekmovanja; uskladi besedilo in pogoje |

### Ki jih preberi, preden začneš

`turnirko-profil-redesign/project/DESIGN.md` (zavezujoč sistem),
`vmesnik/src/slog.css` razdelek 11 (vrstice ~4370–4730 in telefonski del
~8375–8810), `vmesnik/src/api/tipi.ts` (`KoledarVnosDto`).
