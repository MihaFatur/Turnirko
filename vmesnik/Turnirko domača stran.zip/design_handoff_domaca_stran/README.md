# Handoff: Turnirko — prenova domače strani

## Pregled
Prenova domače strani spletne aplikacije **Turnirko** (vodenje in spremljanje namiznoteniških turnirjev).
Stran združi štiri sklope na eni strani: **Turnirji**, **Moje lige** (uporabnik izbere, katere lige spremlja),
**Lestvica** in **Ena na ena** (medsebojni izid dveh igralcev).

Izbrana je razporeditev, ki jo je naročnik potrdil: turnirji in lige dvoje ob drugo, lestvica čez vso širino,
dvoboj na dnu.

## O datotekah v tem paketu
Datoteke v tem paketu so **oblikovalske reference, narejene v HTML** — prototipi, ki kažejo predviden izgled
in obnašanje, **ne produkcijska koda za kopiranje**. Naloga je te oblike **poustvariti v obstoječem okolju
kodne baze** (React + TypeScript + Vite, mapa `vmesnik/`) z njenimi obstoječimi vzorci:
komponente v `vmesnik/src/komponente/`, strani v `vmesnik/src/strani/`, slogi v enem samem `vmesnik/src/slog.css`
(BEM-ish razredi, brez CSS-in-JS, brez Tailwinda). Inline slogi iz prototipa se **prevedejo v razrede v `slog.css`**.

Zavezujoč oblikovalski sistem je `vmesnik/turnirko-profil-redesign/project/DESIGN.md` — preberi ga pred delom
in mu sledi (papirnati športni zapisnik: brez zaobljenih robov, brez senc, brez gradientov, 8 px ritem).

## Fidelity
**High-fidelity (hifi).** Barve, tipografija, razmiki in stanja so končni. UI poustvari **pixel-perfect**
z obstoječimi vzorci kodne baze.

## OBVEZEN POSTOPEK PREVERJANJA (primerjava s posnetki)
V mapi `screenshots/` sta referenčna posnetka:

- `01-namizni-1280.png` — namizni pogled, širina 1280 px (posnet pri 2x, torej 2560 px širine)
- `02-mobilni-390.png` — mobilni pogled, širina 390 px (posnet pri 2x)

Po implementaciji **iterativno primerjaj svoj rezultat s tema posnetkoma, dokler se popolnoma ne ujemata**:

1. Zaženi aplikacijo in odpri domačo stran.
2. Nastavi okno brskalnika na širino **1280 px** (in nato **390 px** za mobilni pogled).
3. Naredi posnetek zaslona svoje implementacije (npr. Playwright / Puppeteer MCP, ali ročno).
4. **Odpri oba posnetka in ju vizualno primerjaj** — referenčnega in svojega. Preveri po vrsti:
   - vrstni red in navpične razmike sklopov,
   - velikosti in teže pisav (naslovi 40 px Bricolage 800, telo 15–19 px Karla, mono oznake 11–13 px),
   - debeline in barve ločnic (3 px črna nad naslovom sklopa, 1 px #DED7CE med vrsticami),
   - poravnave stolpcev lestvice in tabelarne številke,
   - barve značk stanja in poudarjeno lastno vrstico v lestvici.
5. Popravi odstopanja in **ponovi koraka 3–4**, dokler ni razlik. Ne končaj po prvi iteraciji.
6. Če česa ni mogoče doseči brez odstopanja od `DESIGN.md`, to zapiši in vprašaj — ne improviziraj.

## Zasloni

### 1. Domača stran — namizni (1280 px)
**Namen:** prijavljen igralec ali gost v enem pogledu vidi turnirje, svoje lige, lestvico in medsebojni izid.

**Postavitev (od zgoraj navzdol):**
1. **Masthead** — `padding: 24px 40px 0`. Vrstica: logotip levo, navigacija na sredini, ime uporabnika desno;
   `padding-bottom: 8px`, spodaj `1px solid #14110F`, pod njo `3px` črn trak (`height:3px;background:#14110F;margin-top:2px`).
   **Pod mastheadom NI vrstice s sezono in števci** — naročnik jo je izrecno odstranil.
2. **Turnirji | Moje lige** — `padding: 40px 40px 0`, `display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr); gap:56px; align-items:start`.
3. **Lestvica** — `padding: 48px 40px 0`, čez vso širino.
4. **Ena na ena** — `padding: 48px 40px 64px`.

**Naslov sklopa (ponovljiv vzorec):** `border-top:3px solid #14110F; padding-top:16px`, znotraj flex vrstica
`align-items:baseline; justify-content:space-between`; `h2` = Bricolage Grotesque 800 / 40 px / letter-spacing -0.03em;
desno mono povezava 12 px, letter-spacing 0.1em, uppercase, barva #0071AB.

**Turnirji — vrstica (v teku):** `padding:16px 0; border-bottom:1px solid #DED7CE`.
- ime: Karla 700 / 19 px; značka stanja desno
- podnaslov: Karla 300 / 15 px / #5B534D — "Ljubljana · 32 igralcev · četrtfinale"
- napredek: `height:6px; background:#EDE7DF`, polnilo `background:#0088CE`, širina = odstotek odigranih tekem
- pod njim mono 12 px vrstica: levo "23 od 32 tekem", desno "Zadnji izid: Vrhovnik 3:1 Kramar"
- vrstice brez napredka (priprava/zaključen) so enovrstične: ime + podnaslov levo, značka desno

**Značke stanja** (mono 600 / 11 px / letter-spacing 0.1em / uppercase / `padding:6px 8px`, brez radija):
- V teku — `background:#0071AB; color:#fff`
- Priprava — `background:#EDE7DF; color:#5B534D`
- Zaključen — `background:#EAF4D6; color:#4A7500`

**Moje lige — kartica lige:** `padding:16px 0; border-bottom:1px solid #DED7CE`.
- glava: kvadratek 16×16 `background:#7BB900; border:1px solid #4A7500` (= spremljam) + ime lige Karla 700 / 19 px;
  desno mono 12 px "7. od 10 kol"
- mini razpredelnica ekip: `grid-template-columns:24px minmax(0,1fr) 40px 40px; gap:12px`, glava M./Ekipa/Sr./Toč.
  (mono 11 px uppercase #5B534D), vrstice `padding:8px 0; border-bottom:1px solid #DED7CE`;
  mesto mono 600 / 14 px #0071AB, ekipa Karla 400 / 16 px, točke mono 600 / 14 px desno
- na dnu mono 12 px uppercase: "Naslednje kolo 19. avg · Ljubljana – Kranj"
- zadnja vrstica sklopa: besedilo "Ne spremljaš 4 lig, ki so v teku." + gumb "Dodaj ligo"

**Spremljanje lig:** kvadratek ob imenu lige je preklopno stanje (poln zelen = spremljam, prazen z obrobo #5B534D = ne).
Klik doda/odstrani ligo iz uporabnikovega izbora; sklop "Moje lige" prikaže samo spremljane.

**Lestvica:**
- filtri: gumbi "Vsi igralci" (aktiven: `background:#14110F; color:#FBF9F5`), "Moje lige", "Moj klub"
  (neaktivni: `border:1px solid #DED7CE`, brez ozadja, #5B534D); `min-height:44px`; desno povezava "Cela lestvica →"
- mreža: `grid-template-columns:44px 44px minmax(0,1fr) 220px 140px 96px; gap:16px`
- stolpci: **Mesto · Premik · Igralec · Klub · Elo 12 mesecev · Rating**
- **Stolpca "Razred" NI** — razredi igralcev v Turnirku ne obstajajo; ne dodajaj ga.
- glava: mono 500 / 11 px / letter-spacing 0.08em / uppercase / #5B534D, `border-bottom:1px solid #DED7CE`
- vrstica: `padding:14px 0; border-bottom:1px solid #DED7CE`; mesto mono 600 / 16 px (prva tri #0071AB, ostala #5B534D),
  ime Karla 600 / 18 px, klub Karla 300 / 16 px #5B534D, rating mono 600 / 18 px desno, `font-variant-numeric:tabular-nums`
- **premik**: mono 500 / 13 px — "▲ 1" #4A7500 (gor), "▼ 1" #B23A1E (dol), "–" #5B534D (brez spremembe)
- **sparkline**: SVG 140×24, `polyline` `stroke:#0088CE; stroke-width:1.5; fill:none`, 7 točk = ELO v zadnjih 12 mesecih
- **lastna vrstica**: `border-left:4px solid #0088CE; background:#EAF3F9; padding-left:12px; margin-left:-16px`,
  za imenom mono oznaka "ti" v #0071AB

**Ena na ena** (par igralcev je **naključen** — spremenil se je le izgled):
- mreža `minmax(0,1fr) 360px minmax(0,1fr); gap:32px; align-items:start`
- **stranska stolpca po vrsti od zgoraj navzdol:** (1) ikona človečka SVG 40×40 (`circle cx20 cy13 r7.5` + rame,
  `stroke:#14110F; stroke-width:2; fill:none`), (2) ime igralca Bricolage 800 / 48 px / line-height 0.9,
  (3) **izbirnik pod imenom** (`height:44px; border:1px solid #14110F; border-radius:0; background:#fff`),
  (4) meta vrstica Karla 400 / 16 px #5B534D — "NTK Ljubljana · 4. mesto · rating 1842".
  Desni stolpec je zrcaljen (`text-align:right`, vsebina poravnana desno).
- **sredinski stolpec:** `border-left/right:1px solid #DED7CE; padding:0 24px`; naslov mono "Medsebojno · vsa tekmovanja";
  izid Bricolage 800 / 96 px, levo število #4A7500, dvopičje #DED7CE, desno #B23A1E; pod njim mono "6 tekem · 15 : 12 v nizih";
  seznam medsebojnih tekem (datum + tekmovanje levo, izid desno, zmaga #4A7500 / poraz #B23A1E), nato povezava "Vseh 6 tekem →".
- **Pod povezavo "Vseh 6 tekem →"**: `border-top:1px solid #DED7CE; padding-top:16px`, nato **eno pod drugim**
  mono oznaka "Naključni par" in gumb "Zamenjaj par" (polna širina). Ta blok je bil premaknjen z vrha sklopa — ne vračaj ga nazaj.

### 2. Domača stran — mobilni (390 px)
Isti vrstni red sklopov, en stolpec, `padding: 20px` vodoravno.
- masthead brez glavne navigacije v vrsti; pod njim vodoravna vrstica zavihkov (mono 12 px uppercase)
- naslovi sklopov Bricolage 800 / 28 px
- lestvica: `grid-template-columns:28px 20px minmax(0,1fr) 56px`, klub kot druga vrstica pod imenom, brez sparklina
- ena na ena: `minmax(0,1fr) 96px minmax(0,1fr)`, ikona + ime (v dveh vrsticah) + izbirnik pod imenom,
  na sredini izid 48 px; seznam tekem, "Vseh 6 tekem →", nato "Naključni par" + gumb pod ločnico

## Interakcije in obnašanje
- **Navigacija:** klik na turnir/ligo → stran tekmovanja; klik na igralca v lestvici → profil igralca;
  "Cela lestvica →" → stran lestvice; "Vsi →" / "Uredi izbor →" → seznam turnirjev / urejanje spremljanih lig.
- **Spremljanje lige:** klik na kvadratek preklopi stanje in takoj shrani (optimistična posodobitev, ob napaki povrni).
- **Filtri lestvice:** "Vsi igralci" / "Moje lige" / "Moj klub" — filtriranje brez ponovnega nalaganja strani.
- **Zamenjaj par:** izbere nov naključen par igralcev in ponovno naloži medsebojno statistiko.
- **Izbirnika igralcev:** sprememba katerega koli izbirnika takoj osveži izid, seznam tekem in meta vrstici.
- **Prehodi:** brez animacij razen `transition: background-color .12s ease` na gumbih/vrsticah (kot v obstoječem `slog.css`).
- **Hover:** vrstice seznamov dobijo `background:#F3EFE9`; povezave podčrtane; gumbi `border-color:#14110F`.
- **Gost (neprijavljen):** namesto spremljanih lig se prikažejo zadnje ogledane lige; kvadratki za spremljanje vodijo na prijavo.
- **Dostopnost:** vse tarče `min-height:44px`; SVG ikone `aria-hidden="true"`; premik mesta naj ima besedilno alternativo
  (npr. `aria-label="napredoval za 1 mesto"`).

## Stanja
- **Nalaganje:** skeletne vrstice v višini pravih (ozadje #EDE7DF), brez vrtavk.
- **Prazno:** "Ni turnirjev v teku." / "Ne spremljaš še nobene lige." + povezava na seznam; mono 12 px uppercase #5B534D.
- **Napaka:** enovrstično sporočilo v #B23A1E + gumb "Poskusi znova".

## Stanje (state)
- `spremljaneLige: number[]` — id-ji lig, ki jih uporabnik spremlja (persistira na strežniku pri prijavljenem uporabniku)
- `filterLestvice: 'vsi' | 'mojeLige' | 'mojKlub'`
- `igralecA: number | null`, `igralecB: number | null` — inicializirana naključno
- podatki: seznam turnirjev, seznam lig z razpredelnico, lestvica z zgodovino ELO (12 točk), medsebojna statistika para

## Oblikovalski žetoni
**Barve**
- papir/ozadje strani: `#DCD8D1`; ploskev vsebine: `#FBF9F5`; črnilo: `#14110F`; sekundarno besedilo: `#5B534D`
- ločnica: `#DED7CE`; polnilo tirnic: `#EDE7DF`; poudarek vrstice: `#EAF3F9`
- modra: `#0088CE` (grafika) / `#0071AB` (besedilo, gumbi)
- zelena: `#7BB900` (grafika) / `#4A7500` (besedilo), svetlo ozadje `#EAF4D6`
- rdeča: `#B23A1E` (besedilo) / `#8C2B14` (na svetlem), svetlo ozadje `#F8E5DF`

**Tipografija**
- prikazna: **Bricolage Grotesque** 800 — 40 px (sklop, namizni), 28 px (mobilni), 48 px (ime igralca), 96 px (izid)
- besedilo: **Karla** — 300 (podnaslovi 15–16 px), 400 (16–17 px), 600–700 (17–19 px imena)
- mono: **IBM Plex Mono** 500/600 — 11–13 px, letter-spacing 0.08–0.12em, uppercase (oznake, števila, datumi)

**Razmiki** — 8 px ritem: 4, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 56, 64
**Robovi** — `border-radius: 0` povsod. **Sence** — nobene. **Gradienti** — nobeni.
**Ločnice** — 3 px `#14110F` (sklop), 1 px `#DED7CE` (vrstice), 4 px `#0088CE` (levi poudarek lastne vrstice)

## Sredstva (assets)
- Logotip Turnirko: inline SVG (žogica #0088CE, manjša #7BB900, ročica lopara #14110F) — enak kot v obstoječem vmesniku.
- Ikona človečka v sklopu "Ena na ena": inline SVG (krog + rame), `stroke:#14110F`.
- Sparkline: inline SVG `polyline`, generiran iz podatkov ELO — ne slika.
- Pisave: Google Fonts (Bricolage Grotesque, Karla, IBM Plex Mono). Če jih kodna baza že nalaga, uporabi obstoječi način.

## Datoteke v paketu
- `Turnirko - Domov (končno).dc.html` — referenčni prototip (namizni 1280 + mobilni 390). Odpri v brskalniku.
- `support.js` — izvajalno okolje prototipa; potrebno le za ogled HTML-ja, **ne prenašaj ga v kodno bazo**.
- `screenshots/01-namizni-1280.png`, `screenshots/02-mobilni-390.png` — referenca za primerjavo.

## Datoteke v kodni bazi, ki jih to zadeva
- `vmesnik/src/strani/DomacaStran.tsx` — glavna stran (prenova)
- `vmesnik/src/komponente/EnaNaEna.tsx` — sklop "Ena na ena" (prenova izgleda, logika naključnega para ostane)
- `vmesnik/src/komponente/Postavitev.tsx` — masthead (odstrani vrstico "Namizni tenis / Pregled")
- `vmesnik/src/slog.css` — vsi novi slogi (BEM razredi, po vzoru obstoječih `.domov__*`, `.enanaena__*`)
- `vmesnik/turnirko-profil-redesign/project/DESIGN.md` — zavezujoč oblikovalski sistem

## Reference s spleta
Za sklop "Ena na ena" in lestvico sta bila pregledana ITTF/WTT statistični portal (results.ittf.link — head-to-head
primerjava dveh igralcev, profili, svetovna lestvica) in Ratings Central (prikaz gibanja ratinga skozi čas).
Prevzeta sta simetrični blok "A proti B" z velikim medsebojnim izidom in prikaz gibanja ELO ob vrstici lestvice.
