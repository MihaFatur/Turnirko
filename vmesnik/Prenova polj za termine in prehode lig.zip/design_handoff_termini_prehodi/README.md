# Handoff: Termini kol in Prehodi/piramida (Turnirko, vmesnik)

## Pregled

Prenova treh polj v vmesniku Turnirko, da so pregledna in lahka za izpolnjevanje:

| Oznaka | Kje je zdaj | Nova oblika |
|---|---|---|
| **2a** Termini kol (okno) | `vmesnik/src/komponente/TerminiOkno.tsx` | tabela kol z dnevom v tednu in razmikom, orodje za polnjenje, iskalnik za prestavitve, noga s številom sprememb |
| **2b** Termini kol (polje v obrazcu »Nova liga«) | fieldset »Termini kol« v `LigaObrazecOkno.tsx` | trije koraki + predogled prvih treh kol |
| **2c** Prehodi in piramida | `PrehodiOkno.tsx` (`PrehodiPolja`, deli ga tudi obrazec nove lige) | diagram piramide: višja liga → napredovanje → ta liga (pasovi lestvice) → izpad → nižje lige |

Zaledje (`zaledje/`) se NE spreminja. API (`ligeApi.termini`, `ligeApi.prehodi`), oblike vnosov (`TerminiVnos`, `PrehodiVnos`), `sestaviVnos`, `zacetnoStanje`, `zacetniPrehodi`, `vPrehodiVnos`, `prehodiPrazni` ostanejo enaki. Spreminja se prikaz, vrstni red polj in nekaj lokalnega stanja prikaza.

## O datotekah v paketu

Datoteke v `referenca/` so **oblikovalska referenca v HTML** (prototip videza in obnašanja), **ne produkcijska koda**. Nalogo je treba **na novo zgraditi v obstoječem vmesniku** (React 19 + TypeScript + Vite, en velik `slog.css`, slovenska imena razredov in komentarjev), z obstoječimi komponentami (`ModalnoOkno`, `IskalniIzbirnik`, `StevilskoPolje`, `.gumb`, `.izbirnik`, …). HTML ne kopiraj v projekt.

## Zvestoba: visoka (hi-fi)

Barve, tipografija, mere in razmiki so končni. Izvedba mora biti **do piksla enaka** referenci (glej `NAVODILA_ZA_CLAUDE_CODE.md` – obvezna zanka primerjave). Uporabi obstoječe spremenljivke iz `slog.css` (tabela v razdelku Design tokens); heksadecimalne vrednosti spodaj so samo za preverjanje.

## Vsebina paketa

```
README.md                         ta dokument (specifikacija)
NAVODILA_ZA_CLAUDE_CODE.md        postopek dela + obvezna primerjava s posnetki
predlog-slog.css                  pripravljeni CSS za vse nove razrede (vstavi v slog.css)
posnetki/                         PNG posnetki (2×) vseh stanj: 2a-*, 2b-*, 2c-* (novo) in zdaj-* (staro)
referenca/                        delujoča HTML referenca (odpri v brskalniku)
  Termini in prehodi lig.dc.html  celotna referenca, nova in stara izvedba
  posnetki-stanja.dc.html         ista, s kavlji za programsko nastavljanje stanj (za primerjalno skripto)
  support.js                      zagonska koda reference (ne spreminjaj)
primerjava/
  primerjaj.mjs                   Playwright + pixelmatch: zajem reference in izvedbe, razlike
  primer-podatkov.json            natančni vzorčni podatki za vsa stanja
```

Referenco odpri z `file://…/referenca/Termini in prehodi lig.dc.html` (potrebuje internet za Google Fonts; v izvedbi so pisave že lokalne prek fontsource). Zgoraj (sklop 2) je novo, spodaj (sklop 1) trenutno stanje.

## Spremembe po datotekah

1. **`slog.css`** – dodaj razrede iz `predlog-slog.css`; pobriši nadomeščena stara `.termini*` pravila (seznam je v glavi predloga).
2. **`ModalnoOkno.tsx`** – nov neobvezen prop `srednje?: boolean` → razred `modal--srednje` (max-width 640 px). Podnaslov (`podnaslov`) že obstaja.
3. **Nova `StevilskiKorak.tsx`** – `[−] n [+]` (glej spodaj). Notranje polje uporablja `StevilskoPolje`.
4. **`TerminiOkno.tsx`** – nov prikaz (2a). Poslovna logika nespremenjena.
5. **`LigaObrazecOkno.tsx`** – izvleči fieldset »Termini kol« v izvožen `TerminiPolja` (2b); vsa stanja ostanejo v `LigaObrazecOkno`.
6. **`PrehodiOkno.tsx`** – `PrehodiPolja` dobi nov prikaz (2c) in nov prop `imeLige: string` (ime »te« lige v črnem bloku; pri novi ligi ime iz obrazca ali »Nova liga«); sezono že dobi prek obstoječega propa `sezona`. `PrehodiOkno` uporabi `ModalnoOkno srednje podnaslov=…`.
7. **Dev harness** (`vmesnik/src/dev/PosnetkiOkna.tsx`, samo `import.meta.env.DEV`) – glej `NAVODILA_ZA_CLAUDE_CODE.md`.

## Skupni gradniki

### Okno in noga
- `ModalnoOkno srednje naslov="Termini kol" podnaslov="Savinja liga B · 2026/27"` → `.modal` 640 px, glava kot obstoječa (padding 20/24, spodaj 3 px črna črta, h2 28 px/800, podnaslov mono 12 px).
- Telo: obstoječi `.modal__telo` (padding 24), `.modal--srednje .obrazec { gap: 24px }`.
- **Noga** (`.obrazec__noga`, mora biti zadnji otrok `<form>`): čez vso širino okna, `border-top: 1px solid crnilo`, padding 16/24, levo mono status, desno gumba. Levo: `Ni neshranjenih sprememb` (barva `--barva-crnilo-4`) ali `Neshranjeno: 2 kola · 1 prestavitev` (barva `--barva-negativna-tekst`). Desno: `Prekliči` (`.gumb`) in `Shrani termine` / `Shrani prehode` (`.gumb.gumb--glavni`). **Shrani je onemogočen, dokler ni spremembe** (in med shranjevanjem). Vsi gumbi `white-space: nowrap`.
- Za prehode status je `Ni neshranjenih sprememb` / `Neshranjene spremembe` (primerjava stanja z začetnim, `JSON.stringify`).

### StevilskiKorak
Props: `vrednost: number`, `naSpremembo(n: number)`, `najmanj = 0`, `najvec = 10`, `oznaka: string` (aria-label polja), `oznakaManj`, `oznakaVec`. Struktura: `.korak` → `button.korak__gumb` (`−` = U+2212) · `StevilskoPolje.korak__vnos` · `button.korak__gumb` (`+`). Gumba 44×44, polje 56 px, polje ima `margin: 0 -1px` (obrobe se prekrivajo), vsi trije 1 px črna obroba, bela podlaga, mono 600. Tipkanje dovoljeno (samo števke), prazno polje = `najmanj`, vrednosti se stisnejo v [najmanj, najvec]. Gumba nista onemogočena na mejah (vrednost se le stisne). **Preveri mejo v zaledju** (pravila v `LigaStoritev`): če je dovoljenih več kot 10 napredovanj/izpadov, `najvec` uskladi z zaledjem; posnetki kažejo vrednosti ≤ 10.

### Segmentirani izbirnik
Obstoječi `.izbirnik` / `.izbirnik__gumb` / `.izbirnik__gumb--aktiven` (črn aktivni gumb, svetla obroba neaktivnih) + `.izbirnik__gumb--polje` (višina 48 px, poravnano z datumskim poljem). `gap: 4px`.

### Polja
Obstoječa globalna pravila za `input/select` (min. višina 44, padding 12/14, 1 px črna obroba, modri fokus 2 px, odmik −2 px). Izjema: polja znotraj tabele kol (`.termini__vnos`) imajo svetlo obrobo `--barva-crta`, črno ob miški, padding `10px 10px 10px 12px`, pisava 16 px.

---

## 2a · Termini kol (okno) – `TerminiOkno.tsx`

Posnetki: `2a-termini-okno-privzeto.png`, `…-odigrana-prikazana.png`, `…-urejevalnik-prestavitve.png`, `…-iskanje-srecanja.png`, `…-vec-srecanj-na-kolo.png`. Širina 640 px.

Vrstni red v telesu (razmik 24 px):

**1. Uvod** (`p.termini__uvod`, 17 px/300, `--barva-crnilo-3`):
- ena ura na kolo: »Termin velja za vsa srečanja kola. Urejaš jih lahko tudi med sezono.«
- liga z urami: »Dan velja za vsa srečanja kola, ura pa za vsak krog posebej. Urejaš jih lahko tudi med sezono.«

**2. Orodje »Napolni po razmiku«** (`.termini__orodje`: podlaga `--barva-vrstica-hover`, 1 px `--barva-crta`, padding 16, razmik 16)
- Naslov: mono 12 px, `letter-spacing .12em`, velike črke: `Napolni po razmiku`.
- Vrstica polj (flex, wrap, razmik 16, poravnava dno):
  - `Prvo kolo` – datum, širina 168 px.
  - ena ura: `Ura` – čas, 128 px. Liga z urami: za vsako uro kola eno polje `1. krog`, `2. krog`, … (120 px) – to so obstoječe `odUr`.
  - `Razmik` – segmentirani izbirnik `7 dni` | `14 dni` | `Drugo`. Aktiven je ustrezni gumb; `Drugo` je aktiven, kadar razmik ni 7/14 ali ga je uporabnik izbral. Pri `Drugo` se desno pojavi polje `Dni` (88 px, `StevilskoPolje`, največ 365, sredinsko, mono 600).
- Dejanja: `Napolni vsa kola` (`.gumb`, onemogočen brez datuma prvega kola), `Zbriši vse` (`.gumb.gumb--majhen`) in opomba (14 px/300): »Prepiše datume vseh kol; prestavljena srečanja ostanejo.«
- Vedenje `napolni()` in `pobrisi()` ostane **kot zdaj** (datum_i = prvo kolo + i × razmik; pri ligi z urami i-to srečanje kola dobi i-to uro; prestavljena srečanja ostanejo).
- Začetne vrednosti: prvo kolo / ura kot zdaj (`zacetno.kola[0]` oz. `liga.zacetekPrvegaKola`), razmik `liga.razmikDni ?? 7`.

**3. Razdelek »Kola«**
- Glava razdelka (`.termini__razdelek`): levo `Kola`, desno povzetek (`letter-spacing .06em`, `--barva-crnilo-3`): `10 kol · odigrano 3 · 3. 10. – 12. 12. 2026` ali `10 kol · brez terminov`. Datumi: prvi in zadnji vpisani datum (kratko `d. m.`, zadnji z letnico).
- Glava stolpcev (`.termini__glava`, mono 11 px, barva `--barva-crnilo-4`): `Kolo | Datum | Dan | Ura` (liga z urami: `Ure krogov`). Mreža `96px 160px 80px minmax(0,1fr)`, razmik 12 px – ista mreža za vrstice.
- **Odigrana kola so privzeto skrita** (če obstaja vsaj eno): vrstica `.termini__skrita` (min. 48 px): »3 odigrana kola skrita« + gumb `Pokaži` (`.gumb--majhen`); po kliku »Odigrana kola prikazana« + `Skrij`. Skrita kola se še vedno shranijo.
- **Vrstica kola** (`.termini__vrstica`, spodaj 1 px `--barva-crta`; mreža, padding 6/0, poravnava sredina):
  1. Stolpec 1 (flex, navpično, razmik 4): `N. kolo` (mono 600 12 px, velike črke; odigrano = `--barva-crnilo-4`), pod njim oznaka: `odigrano` (podlaga `--barva-polnilo`, besedilo `--barva-crnilo-3`) ali `naslednje` (podlaga `--barva-glavna-polna`, bel tekst; **prvo kolo, ki ni v celoti odigrano**). Oznaka: padding 3/6, mono 600 10 px, `letter-spacing .1em`, velike črke. Pri ligi z urami še gumb `N srečanj ▾` / `Skrij ▴` (mono 500 11 px, `--barva-glavna-tekst`, brez obrobe).
  2. Datum: `<input type="date">`, `aria-label="Datum N. kola"`.
  3. Dan: kratica dneva (`ned pon tor sre čet pet sob`, mono 600 12 px, velike črke) in pod njo razmik od prejšnjega kola `+7 dni` (`+1 dan`; mono 500 11 px, `--barva-crnilo-3`). Prvo kolo razmika nima; brez datuma `—`. **Rjava barva** (`--barva-negativna-tekst`) za dan, ki ni najpogostejši dan v seznamu, in za razmik, ki ni najpogostejši razmik (modus; računaj čez vsa kola, tudi skrita; datume računaj v UTC kot obstoječi `prestej`).
  4. Ura: ena ura → `<input type="time">` 128 px (`aria-label="Ura N. kola"`). Liga z urami → eno polje na krog (106 px, razmik 8; `aria-label="K. krog N. kola"`).
- Pod seznamom, če je kaj rjavega: `Rjavo: dan ali razmik odstopa od običajnega (sob, na 7 dni).` (mono 500 11 px, `--barva-negativna-tekst`).
- **Liga z urami – ure po srečanjih**: polje kroga **prebere** uro prvega neprestavljenega srečanja kola s tem `uraVKolu` in jo ob spremembi **zapiše vsem neprestavljenim srečanjem tega kola in kroga**. Razširjena vrstica (`.termini__srecanja`, odmik 108 px, leva črta 2 px `--barva-crta`) kaže vsako srečanje: polje ure (106 px) | `K. krog` | `Domači – Gost` + po potrebi `iz N. kola` (modro). To je obstoječa funkcija »polnilo vzame uro kroga, organizator jo sme srečanju prestaviti«, samo drugače razporejena. Če v kolu ni neprestavljenega srečanja s tem krogom, je polje kroga prazno in onemogočeno.

**4. Razdelek »Prestavitve«** (`.termini__prestavitve`, razmik 16)
- Glava razdelka: `Prestavitve`, desno število prestavljenih (ali prazno).
- Opis (15 px/300/1.6): »Srečanje, ki se ne igra v svojem kolu, premakni v kolo, kjer se bo igralo; v razporedu stoji samo tam. Če novi dan še ni znan, ga pusti brez termina.«
- **Iskalnik** namesto spustnega seznama: `IskalniIzbirnik vObrazcu` v dejanju (brez `izbrano`), oznaka `Prestavi srečanje`, namig `Vpiši ekipo ali kolo, npr. »velenje« ali »7«`. Možnosti: neprestavljena srečanja; `ime` = `Domači – Gost`, `podrobnost` = `N. kolo` (+ ` · odigrano`). Iskalno besedilo `domači gost kolo N`; brez vpisa ni predlogov. Izbira odpre urejevalnik (`nastaviUrejano(id)`).
- **Urejevalnik** (neposredno pod iskalnikom; obstoječi `.termini__prestavitev` – modra črta 4 px, `--barva-glavna-mehko`, padding 16, razmik 16): naslov `Domači – Gost` (17 px/600) + mono `po žrebu N. kolo`; `Igra se v` (select, možnosti `N. kolo · d. m.` s pripisom ` (po žrebu)`, in `Termin še ni znan`, če srečanje sme čakati); `Dan` + `Ura` v dveh stolpcih (samo če kolo ni null; ura onemogočena brez dneva); namig o uri (obstoječa besedila); `Razlog (neobvezno)` z mono števcem `n/200` desno od oznake, placeholder `npr. dvorana zasedena` in pod njim »Razlog vidijo vsi obiskovalci. Brez osebnih podatkov (zdravje, naslovi).«; gumba `Vrni v N. kolo` (samo če je prestavljeno; bela podlaga, obroba `--barva-crta`) in `Končano` (`.gumb`). Logika `premakni`/`vrni`/`urediSrecanje` ostane.
- **Seznam prestavljenih** (`.termini__prestavljena`): vrstica = `Domači – Gost` (16 px/600) + mono `iz 4. v 6. kolo` oz. `iz 4. kola · čaka na termin`, pod njo razlog (14 px/300); desno `Uredi`/`Zapri` (`.gumb--majhen`). Brez prestavitev in brez urejevalnika: »Ni prestavljenih srečanj.«

**5. Noga** – glej Skupni gradniki. »Neshranjeno« šteje: število kol z drugačnim datumom/uro od začetnih + število srečanj, ki so (bila) prestavljena in se razlikujejo od začetnega stanja (`kolo`, `datum`, `ura`, `razlog`).

---

## 2b · Termini kol (polje v obrazcu »Nova liga«)

Posnetki: `2b-termini-obrazec-1-srecanje.png`, `…-3-srecanja.png`, `…-razmik-po-meri.png`, `…-brez-datuma.png`. Primerjaš samo **skupino** (`[role="group"][aria-label="Termini kol"]`, 512 px široka v oknu 560 px); naslov »Nova liga« in oznaka »izsek obrazca« v referenci sta samo okvir.

- Skupina: `<div role="group" aria-label="Termini kol" className="obrazec__skupina termini__obrazec">` – **div, ne fieldset** (legend v fleksibilnem fieldsetu sedi na robu in prereže podlago). Zelena skupina kot obstoječa (`border-left 4px poudarek`, `--barva-poudarek-mehko`, padding 16), razmik 20 px. Naslov: `span.termini__obrazec-naslov` »Termini kol« (mono 12 px, `--barva-crnilo`).
- **Kdaj je prvo kolo** (oznaka mono 12 px `--barva-crnilo-3`): datum 184 px (`aria-label` »Datum prvega kola«); če je 1 srečanje na kolo: mono `ob` + čas 128 px (`aria-label` »Ura prvega kola«).
- **Vsako naslednje kolo**: segmentirani izbirnik `Vsak teden` (7) | `Na 2 tedna` (14) | `Po meri`, neaktivni gumbi **bela** podlaga. Pri `Po meri` desno polje 72 px (`aria-label` »Razmik v dneh«, mono 600, sredinsko, največ 365) + besedilo `dni po prejšnjem` (15 px). Brez datuma prvega kola je ves blok `opacity .45; pointer-events: none` (nadomesti `disabled`).
- **Srečanj vsake ekipe na kolo**: `StevilskiKorak` 1–10 (`oznaka` »Število srečanj na kolo«, gumba »Manj srečanj« / »Več srečanj«) + beseda (`srečanje`, `srečanji`, `srečanja` za 3–4, `srečanj` od 5) 15 px, levi odmik 12. Nadomesti `<select>` z 1–10. Obnašanje `zamenjajSrecanjVKolu` ostane (n = 1 → `ure = null`, ura prvega kola se ohrani). Pri n > 1: mreža `repeat(auto-fill, minmax(112px, 1fr))`, razmik 12, polja `N. srečanje`. Pod tem pojasnilo (14 px/300): n = 1 »Vsa srečanja kola se začnejo ob isti uri.«; sicer »Vsaka ekipa v kolu odigra {n} {srečanj}, ob vsaki uri vse ekipe hkrati; kol je zato {pol manj | n-krat manj}. Prazna ura pomeni, da ura ni določena.«
- **Predogled** (`.termini__predogled`, bela podlaga, 1 px `--barva-crta`, padding 12/16): naslov mono 11 px `Tako bo videti razpored`; tri vrstice (mreža `72px 96px 1fr`, črta zgoraj `--barva-polnilo`): `N. kolo` · `sob 3. 10.` (15 px/600) · ure (`18:00` ali `18:00 · 19:30`; prazna ura `—`, pri eni uri brez vpisa `ura ni določena`); vrstica »… in tako naprej; število kol in vse datume izračuna žreb.« (14 px/300). Brez datuma namesto vrstic: »Brez datuma prvega kola razpored pri neodigranih kolih pokaže samo oznako »razpored«. Datume lahko vpišeš tudi pozneje, na strani lige pod »Termini«.«
- Dolgi opisi iz stare izvedbe (»Vsako kolo se odigra teden za prejšnjim …«) odpadejo – nadomesti jih predogled.

---

## 2c · Prehodi in piramida – `PrehodiOkno.tsx` / `PrehodiPolja`

Posnetki: `2c-prehodi-okno-privzeto.png`, `…-opozorila.png`, `…-brez-visje-iskanje.png`, `…-iskanje-nizje.png`. Širina 640 px.

Telo (razmik 24): uvod (»Povezavo vpiši z ene strani, nasprotna se uredi sama. Prehode lahko urejaš tudi, ko liga že teče.«), **diagram** (`.prehodi`, razmik 8 px med bloki), opozorila, namig, noga (`Shrani prehode`).

Bloki diagrama, od zgoraj navzdol:

1. **Višja liga** – oznaka mono 12 px »Višja liga · kamor se napreduje«. Če je izbrana: kartica `.prehodi__liga` (min. 56 px, bela podlaga, 1 px **črna** obroba, padding 6/8/6/16): ime 17 px/600, pod njim mono 11 px sezona; desno `Odstrani` (`.gumb--majhen.gumb--nevaren`). Če ni: `IskalniIzbirnik` (vrednost ne, dejanje; `oznaka="Višja liga"`, namig `Brez (najvišja liga) · vpiši ime`), polje 44 px, padding 12/14 (glej `.prehodi .iskalni-izbirnik__vnos`).
2. **Napredovanje** – `.prehodi__tok` (levi rob 16 px, črta 4 px `--barva-poudarek`, podlaga `--barva-poudarek-mehko`, padding 16). Glava: `↑ Napredovanje` (mono 600 12 px, `--barva-poudarek-tekst`) levo, `v {ime višje lige}` ali `višje lige ni` desno (mono 11 px, `--barva-crnilo-3`). Dve polji (wrap, razmik 16/32, min. širina 168): **Napreduje** (vzorec 12×12 `--barva-poudarek`, `StevilskiKorak`, »ekip gre neposredno v višjo«) in **Kvalifikacije** (vzorec `--barva-poudarek-srednje` z obrobo `--barva-poudarek`, »ekip igra za mesto v višji«). Vezano na `stanje.napreduje` in `stanje.kvalGor`; `aria-label` »Napreduje (ekip)« in »Kvalifikacije za napredovanje (ekip)«.
3. **Ta liga** – črn blok (`.prehodi__ta`, `--barva-crnilo`, besedilo `--barva-papir`, padding 16): ime `{ime} · {sezona}` (18 px/700) in desno mono `ta liga` (`--barva-na-crnilu-2`). Pod njim **pasovi lestvice** (10 celic, višina 40 px, razmik 2 px, številka mesta mono 600 12 px) in mono opis »Mesta na lestvici · primer za 10 ekip«. Barva celice po mestu `r` (prioriteta od zgoraj): `r ≤ napreduje` → `--barva-poudarek` / besedilo `--barva-na-poudarku`; `r ≤ napreduje + kvalGor` → `--barva-poudarek-srednje`; `r > 10 − izpade` → `--barva-negativna` / bel tekst; `r > 10 − izpade − kvalDol` → `--barva-negativna-srednje`; sicer `--barva-polnilo` / `--barva-crnilo-3`. Število ekip (10) je stalen **primer**, ne podatek lige – posodablja se sproti ob spremembi števil. Pasovi so vedno vidni (v referenci je to Tweak samo za pregled).
4. **Izpad** – `.prehodi__tok--dol`: rjava črta `--barva-negativna`, podlaga `--barva-negativna-mehko`. Glava `↓ Izpad` (`--barva-negativna-tekst`), desno `v {imena nižjih lig, ločena z vejico}` ali `nižjih lig ni`. Polji **Izpade** (vzorec `--barva-negativna`, »ekip gre neposredno v nižjo«) in **Kvalifikacije** (vzorec `--barva-negativna-srednje` z obrobo `--barva-negativna`, »ekip igra za obstanek«); `stanje.izpade`, `stanje.kvalDol`; `aria-label` »Izpade (ekip)« in »Kvalifikacije za obstanek (ekip)«.
5. **Nižje lige** – oznaka mono »Nižje lige · od koder se napreduje sem«; za vsako izbrano nižjo ligo kartica (kot višja); če liga trenutno stoji pod drugo ligo, vrstica 14 px/300 `--barva-negativna-tekst`: »zdaj pod: {liga}; ob shranitvi se premakne sem«; spodaj `IskalniIzbirnik` v dejanju (`oznaka="Dodaj nižjo ligo"`, namig `Dodaj nižjo ligo · vpiši ime`). Če drugih lig ni: »Drugih lig ni.«

**Opozorila** (`.prehodi__opozorilo`, pod diagramom, vsako v svojem odstavku; vsebina/pogoji so že v kodi – samo prikaz):
- neujemanje kvalifikacij: »Število kvalifikacijskih mest se ne ujema ({…}). Ena tekma ali serija zahteva enako ekip z obeh strani, sicer se kvalifikacije lahko igrajo le kot mala liga (vsak z vsakim).«
- razhajanje sezon: »Povezane lige nimajo iste sezone kot ta ({sezona}). Povezava bo delovala, piramida pa bo mešala sezone; če gre za isto sezono, jo poenoti.«
- vsota prehodnih mest > 10: »Skupaj je več prehodnih mest, kot ima primer ekip (10); pasovi se prekrivajo.«

Nato namig (`.prehodi__namig`): »Kvalifikacije igrajo ekipe tik pod mesti napredovanja oz. tik nad mesti izpada, s sosednjo ligo (npr. 9. iz A proti 3. iz B). Ko je redni del obeh lig odigran, jih organizator višje lige ustvari na strani lige.«

**Obrazec nove lige** uporablja isti `PrehodiPolja` pod naslovom »Piramida in prehodi«. Ni posebej oblikovan v posnetkih: zeleni `fieldset.obrazec__skupina` okoli diagrama zamenjaj z navadnim razdelkom (mono naslov + 1 px črta, kot `.podnaslov-sekcije`), da barvni bloki ne stojijo na zeleni podlagi; diagram je v 560 px oknu uporaben, ker se polja prelomijo.

---

## Interakcije in obnašanje

- Vsak vnos takoj posodobi stanje in predogled (pasovi, dan v tednu, razmik, števec sprememb) – brez zakasnitev in animacij. Edine animacije: barva/obroba 120 ms (obstoječe pravilo).
- Iskalniki: obstoječe obnašanje `IskalniIzbirnik` (gor/dol, Enter, Escape zapre predloge, klik izven zapre).
- Tipkovnica: Tab po vrsti od zgoraj navzdol; stepper polje sprejme števke; Enter v poljih obrazca ne sme sprožiti shranjevanja pri odprtem iskalniku (že rešeno v `IskalniIzbirnik`).
- Napake: `SporociloNapake` ostane tik nad nogo (ni v posnetkih).
- Mobilna različica **ni oblikovana** – namizne mere ne spreminjaj; za ≤ 480 px sam presodi (predlogi na koncu `predlog-slog.css`).
- Dostopnost: vsa polja imajo vidno ali `aria-label` oznako (seznam zgoraj); barve niso edini nosilec (rjava ima vedno tudi besedilo).

## Stanje

- `TerminiOkno`: obstoječe `kola`, `vnosi`, `urejano`, `odDatuma`, `odUre`, `odUr`, `razmik` + novo: `razmikPoMeri: boolean` (init: `razmik ∉ {7, 14}`), `pokaziOdigrana: boolean` (init false), `odprtaKola: Set<number>` (srečanja pod vrstico), `iskanje` (v `IskalniIzbirnik`). Izpeljano: modus dneva/razmika, `naslednje`, štetje sprememb (primerjava z `zacetno`).
- `LigaObrazecOkno`: nov `razmikPoMeri: boolean`; ostalo kot zdaj.
- `PrehodiPolja`: brez novega stanja; števila gredo prek `StevilskiKorak` v `popravi({ napreduje: … })` itd.

## Design tokens

Uporabi spremenljivke iz `slog.css` (hex samo za preverjanje):

| Uporaba | Spremenljivka | Hex |
|---|---|---|
| papir (ozadje okna) | `--barva-papir` | #fbf9f5 |
| črnilo | `--barva-crnilo` / `-2` / `-3` / `-4` | #14110f / #332e29 / #5b534d / #6e655e |
| črta, svetla obroba | `--barva-crta` | #ded7ce |
| polnilo oznake | `--barva-polnilo` | #ede7df |
| podlaga orodja | `--barva-vrstica-hover` | #f3efe9 |
| modra: polna / besedilo / mehka / ostra | `--barva-glavna-polna` / `-tekst` / `-mehko` / `--barva-glavna` | #0071ab / #0071ab / #eaf3f9 / #0088ce |
| zelena: ostra / tekst / mehka / srednja | `--barva-poudarek` / `-tekst` / `-mehko` / `-srednje` | #7bb900 / #4a7500 / #eaf4d6 / #c6e28a |
| rjava: ostra / tekst / mehka / srednja | `--barva-negativna` / `-tekst` / `-mehko` / `-srednje` | #b23a1e / #8c2b14 / #f8e5df / #e2a793 |
| sivina na črnem | `--barva-na-crnilu-2` | #b9b0a6 |
| pisave | `--pisava-display` Bricolage Grotesque · `--pisava-telo` Karla · `--pisava-mono` IBM Plex Mono | |

Tipografija: telo 17 px/1.5 (300 za pojasnila), mono oznake 12 px (`letter-spacing .08em`, velike črke), mikro mono 10–11 px, `h2` modala 28 px/800/−0.03em. Razmiki: 4, 8, 12, 16, 24, 32 px (+ 6 px v vrstici tabele); polja 44/48 px; **border-radius 0 povsod, brez senc**.

## Assets

Brez slik in ikon. Edini znaki so besedilni: `↑ ↓ ▾ ▴ − + ✕`. Pisave so že v projektu (fontsource).

## Datoteke

`referenca/Termini in prehodi lig.dc.html` (nova izvedba: sklop 2; staro stanje: sklop 1), `referenca/posnetki-stanja.dc.html`, `posnetki/*.png`, `predlog-slog.css`, `primerjava/primerjaj.mjs`, `primerjava/primer-podatkov.json`.

### Seznam posnetkov in kako ponoviti stanje

| Datoteka | Stanje |
|---|---|
| `2a-termini-okno-privzeto` | ena ura na kolo, vzorčni podatki, odigrana kola skrita |
| `2a-termini-okno-odigrana-prikazana` | kliknjen `Pokaži` |
| `2a-termini-okno-urejevalnik-prestavitve` | kliknjen `Uredi` ob prestavljenem srečanju |
| `2a-termini-okno-iskanje-srecanja` | v iskalnik vpisano `vel` |
| `2a-termini-okno-vec-srecanj-na-kolo` | liga z urami 18:00 in 19:30, razmik 14, razširjeno prvo prikazano kolo |
| `2b-termini-obrazec-1-srecanje` | datum 2026-10-03, ura 18:00, razmik 7, 1 srečanje |
| `2b-termini-obrazec-3-srecanja` | 3 srečanja (ure 18:00, 19:30, 20:30) |
| `2b-termini-obrazec-razmik-po-meri` | `Po meri`, 10 dni |
| `2b-termini-obrazec-brez-datuma` | prazen datum prvega kola |
| `2c-prehodi-okno-privzeto` | višja A, nižja C, 2+1 gor, 2+1 dol |
| `2c-prehodi-okno-opozorila` | nižje C, Zasavska, Koroška; kvalifikacije gor 2, izpade 3 |
| `2c-prehodi-okno-brez-visje-iskanje` | višja odstranjena, nižje odstranjene, vse 0, v iskalniku `sav` |
| `2c-prehodi-okno-iskanje-nizje` | v »Dodaj nižjo ligo« vpisano `zas` |
| `zdaj-1a/1b/1c-…` | trenutno stanje (samo za primerjavo prej/potem; NI cilj) |

Posnetki so 2× (1280 px = 640 CSS px). Podatki: `primerjava/primer-podatkov.json`.
