#!/usr/bin/env node
/* Primerjava izvedbe z referenčnim oblikovanjem (Playwright + pixelmatch).

   PRIPRAVA (v mapi vmesnik/, enkrat):
     npm i -D playwright pngjs pixelmatch && npx playwright install chromium

   UPORABA (zaženi iz mape vmesnik/, dev strežnik mora teči – npm run dev):
     node <pot>/primerjava/primerjaj.mjs                      # referenca + izvedba + primerjava vseh stanj
     node <pot>/primerjava/primerjaj.mjs referenca            # samo zajem reference
     node <pot>/primerjava/primerjaj.mjs izvedba --samo=2c-privzeto
     node <pot>/primerjava/primerjaj.mjs --url=http://localhost:5173

   Referenca se ne vzame iz mojih PNG-jev v mapi posnetki/ (te so za oči), ampak se IZRIŠE
   v istem Chromiumu iz referenca/posnetki-stanja.dc.html – tako ima isti pisalni stroj,
   iste nativne kontrole (date/time) in iste razdalje kot izvedba.

   IZHOD (mapa izhod/ ob skriptu):
     referenca/*.png + *.json   izris in meritve elementov reference
     izvedba/*.png  + *.json    izris in meritve izvedbe
     razlika/*.png              rdeče = piksli, ki se ne ujemajo
   Skripta vrne kodo 1, dokler se KATERO KOLI stanje ne ujema. */
import { chromium } from 'playwright'
import { PNG } from 'pngjs'
import pixelmatch from 'pixelmatch'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const MAPA = path.dirname(fileURLToPath(import.meta.url))
const REF_HTML = pathToFileURL(path.join(MAPA, '..', 'referenca', 'posnetki-stanja.dc.html')).href
const IZHOD = path.join(MAPA, 'izhod')
const args = process.argv.slice(2)
const nacin = args.find((a) => !a.startsWith('--')) ?? 'oboje'
const baza = (args.find((a) => a.startsWith('--url=')) ?? '--url=http://localhost:5173').slice(6)
const samo = (args.find((a) => a.startsWith('--samo=')) ?? '').slice(7)
/* Dovoljeno razmerje različnih pikslov. Cilj je 0: vsak piksel, ki ostane, mora imeti
   ugotovljen vzrok (npr. obstoječa glava .modal__glava, ki je ne smeš spreminjati). */
const DOVOLJENO = Number(process.env.DOVOLJENO_RAZMERJE ?? 0)

/* Stanje reference: najprej RESET, nato `ref` (kodo izvede referenčna stran – glej razred
   Component v posnetki-stanja.dc.html). Stanje izvedbe: harness (glej README, razdelek
   »Harness za posnetke«) in `korak` – kar naredi uporabnik z miško/tipkovnico. */
const RESET = `(() => { const d = window.__dc; window.__zU = false;
  d.setState({ n: d.mk(false), u: d.mk(true), cb: { q: '', o: false },
    f2: { datum: '2026-10-03', ura: '18:00', razmik: 7, poMeri: false, n: 1, ure: ['18:00','19:30','20:30','','','','','','',''] },
    pr: { visja: 1, nizje: [2], nap: 2, kg: 1, izp: 2, kd: 1 }, cbV: { q: '', o: false }, cbN: { q: '', o: false } });
  d.forceUpdate(); })()`

const REF_OKNO = (id) => `[id="${id}"] > div:last-child`
const REF_SKUPINA = '[id="2b"] [role="group"]'
const APP_OKNO = '.modal'
const APP_SKUPINA = '[role="group"][aria-label="Termini kol"]'

const pocakaj = (p, ms = 250) => p.waitForTimeout(ms)
const STANJA = [
  { id: '2a-termini-okno-privzeto', ref: '', refSel: REF_OKNO('2a'), appSel: APP_OKNO,
    app: { pot: '/dev/posnetki?okno=termini', korak: async () => {} } },
  { id: '2a-termini-okno-odigrana-prikazana', ref: `__dc.setState(s => ({ n: { ...s.n, pokazi: true } }))`, refSel: REF_OKNO('2a'), appSel: APP_OKNO,
    app: { pot: '/dev/posnetki?okno=termini', korak: async (p) => { await p.getByRole('button', { name: 'Pokaži' }).click() } } },
  { id: '2a-termini-okno-urejevalnik-prestavitve', ref: `__dc.setState(s => ({ n: { ...s.n, urejano: 10 } }))`, refSel: REF_OKNO('2a'), appSel: APP_OKNO,
    app: { pot: '/dev/posnetki?okno=termini', korak: async (p) => { await p.getByRole('button', { name: 'Uredi', exact: true }).click() } } },
  { id: '2a-termini-okno-iskanje-srecanja', ref: `__dc.setState({ cb: { q: 'vel', o: true } })`, refSel: REF_OKNO('2a'), appSel: APP_OKNO,
    app: { pot: '/dev/posnetki?okno=termini', korak: async (p) => { await p.getByRole('combobox', { name: /Prestavi srečanje/ }).fill('vel') } } },
  { id: '2a-termini-okno-vec-srecanj-na-kolo', ref: `window.__zU = true; __dc.setState(s => ({ u: { ...s.u, odprta: { 2: true } } })); __dc.forceUpdate()`, refSel: REF_OKNO('2a'), appSel: APP_OKNO,
    app: { pot: '/dev/posnetki?okno=termini&ure=1', korak: async (p) => { await p.getByRole('button', { name: /srečanj ▾/ }).first().click() } } },

  { id: '2b-termini-obrazec-1-srecanje', ref: '', refSel: REF_SKUPINA, appSel: APP_SKUPINA,
    app: { pot: '/dev/posnetki?okno=obrazec-termini', korak: async () => {} } },
  { id: '2b-termini-obrazec-3-srecanja', ref: `__dc.setState(s => ({ f2: { ...s.f2, n: 3 } }))`, refSel: REF_SKUPINA, appSel: APP_SKUPINA,
    app: { pot: '/dev/posnetki?okno=obrazec-termini', korak: async (p) => { const plus = p.getByRole('button', { name: 'Več srečanj' }); await plus.click(); await plus.click() } } },
  { id: '2b-termini-obrazec-razmik-po-meri', ref: `__dc.setState(s => ({ f2: { ...s.f2, n: 1, poMeri: true, razmik: 10 } }))`, refSel: REF_SKUPINA, appSel: APP_SKUPINA,
    app: { pot: '/dev/posnetki?okno=obrazec-termini', korak: async (p) => { await p.getByRole('button', { name: 'Po meri' }).click(); await p.getByLabel('Razmik v dneh').fill('10') } } },
  { id: '2b-termini-obrazec-brez-datuma', ref: `__dc.setState(s => ({ f2: { ...s.f2, datum: '' } }))`, refSel: REF_SKUPINA, appSel: APP_SKUPINA,
    app: { pot: '/dev/posnetki?okno=obrazec-termini', korak: async (p) => { await p.getByLabel('Datum prvega kola').fill('') } } },

  { id: '2c-prehodi-okno-privzeto', ref: '', refSel: REF_OKNO('2c'), appSel: APP_OKNO,
    app: { pot: '/dev/posnetki?okno=prehodi', korak: async () => {} } },
  { id: '2c-prehodi-okno-opozorila', ref: `__dc.setState({ pr: { visja: 1, nizje: [2, 4, 5], nap: 2, kg: 2, izp: 3, kd: 1 } })`, refSel: REF_OKNO('2c'), appSel: APP_OKNO,
    app: { pot: '/dev/posnetki?okno=prehodi', korak: async (p) => {
      for (const [vpis, ime] of [['zas', 'Zasavska liga'], ['koro', 'Koroška liga']]) {
        await p.getByRole('combobox', { name: 'Dodaj nižjo ligo' }).fill(vpis)
        await p.getByRole('option', { name: new RegExp(ime) }).click()
      }
      await p.getByLabel('Kvalifikacije za napredovanje (ekip)').fill('2')
      await p.getByLabel('Izpade (ekip)').fill('3')
    } } },
  { id: '2c-prehodi-okno-brez-visje-iskanje', ref: `__dc.setState({ pr: { visja: null, nizje: [], nap: 0, kg: 0, izp: 0, kd: 0 }, cbV: { q: 'sav', o: true } })`, refSel: REF_OKNO('2c'), appSel: APP_OKNO,
    app: { pot: '/dev/posnetki?okno=prehodi', korak: async (p) => {
      await p.getByRole('button', { name: 'Odstrani' }).first().click()
      await p.getByRole('button', { name: 'Odstrani' }).first().click()
      for (const ime of ['Napreduje (ekip)', 'Kvalifikacije za napredovanje (ekip)', 'Izpade (ekip)', 'Kvalifikacije za obstanek (ekip)']) await p.getByLabel(ime).fill('0')
      await p.getByRole('combobox', { name: 'Višja liga' }).fill('sav')
    } } },
  { id: '2c-prehodi-okno-iskanje-nizje', ref: `__dc.setState({ cbN: { q: 'zas', o: true } })`, refSel: REF_OKNO('2c'), appSel: APP_OKNO,
    app: { pot: '/dev/posnetki?okno=prehodi', korak: async (p) => { await p.getByRole('combobox', { name: 'Dodaj nižjo ligo' }).fill('zas') } } },
].filter((s) => !samo || s.id.includes(samo))

/* Meritve: položaj in velikost vsakega besedila/polja glede na koren. Ključ = oznaka +
   besedilo + zaporedna številka; razlika v px pove, KJE se postavitev razhaja. */
function izmeri(page, sel) {
  return page.evaluate((s) => {
    const koren = document.querySelector(s)
    const k = koren.getBoundingClientRect()
    const stevec = {}
    const seznam = []
    for (const e of koren.querySelectorAll('button,input,select,label,span,p,h2,li,a')) {
      const r = e.getBoundingClientRect()
      if (!r.width || !r.height) continue
      const besedilo = (e.getAttribute('aria-label') || e.placeholder
        || [...e.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent.trim()).join(' ')).slice(0, 32)
      if (!besedilo && !['INPUT', 'SELECT'].includes(e.tagName)) continue
      const kljuc = `${e.tagName}|${besedilo}`
      stevec[kljuc] = (stevec[kljuc] ?? 0) + 1
      seznam.push({ kljuc: `${kljuc}#${stevec[kljuc]}`, x: +(r.left - k.left).toFixed(1), y: +(r.top - k.top).toFixed(1), w: +r.width.toFixed(1), h: +r.height.toFixed(1) })
    }
    return { koren: { w: +k.width.toFixed(1), h: +k.height.toFixed(1) }, elementi: seznam }
  }, sel)
}

async function zajemi(kje, odpri) {
  const brskalnik = await chromium.launch()
  const kontekst = await brskalnik.newContext({
    viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 2, locale: 'sl-SI', timezoneId: 'Europe/Ljubljana', reducedMotion: 'reduce',
  })
  const p = await kontekst.newPage()
  const mapa = path.join(IZHOD, kje)
  fs.mkdirSync(mapa, { recursive: true })
  for (const s of STANJA) {
    const sel = await odpri(p, s)
    await p.evaluate(() => document.fonts.ready)
    await pocakaj(p, 300)
    await p.locator(sel).first().screenshot({ path: path.join(mapa, `${s.id}.png`), animations: 'disabled', caret: 'hide' })
    fs.writeFileSync(path.join(mapa, `${s.id}.json`), JSON.stringify(await izmeri(p, sel), null, 1))
    console.log(`[${kje}] ${s.id}`)
  }
  await brskalnik.close()
}

const zajemiReferenco = () => zajemi('referenca', async (p, s) => {
  if (!p.url().startsWith('file:')) { await p.goto(REF_HTML); await p.waitForSelector('[id="2a"]'); await pocakaj(p, 800) }
  await p.evaluate(RESET); await pocakaj(p)
  if (s.ref) { await p.evaluate(s.ref); await pocakaj(p) }
  return s.refSel
})

const zajemiIzvedbo = () => zajemi('izvedba', async (p, s) => {
  await p.goto(baza + s.app.pot)
  await p.waitForSelector(s.appSel)
  await pocakaj(p, 400)
  await s.app.korak(p)
  await pocakaj(p)
  return s.appSel
})

function primerjaj() {
  let slabo = 0
  fs.mkdirSync(path.join(IZHOD, 'razlika'), { recursive: true })
  for (const s of STANJA) {
    const a = PNG.sync.read(fs.readFileSync(path.join(IZHOD, 'referenca', `${s.id}.png`)))
    const b = PNG.sync.read(fs.readFileSync(path.join(IZHOD, 'izvedba', `${s.id}.png`)))
    const ma = JSON.parse(fs.readFileSync(path.join(IZHOD, 'referenca', `${s.id}.json`), 'utf8'))
    const mb = JSON.parse(fs.readFileSync(path.join(IZHOD, 'izvedba', `${s.id}.json`), 'utf8'))
    const vrstice = []
    if (a.width !== b.width || a.height !== b.height) {
      vrstice.push(`  VELIKOST: referenca ${a.width / 2}×${a.height / 2} px, izvedba ${b.width / 2}×${b.height / 2} px`)
    }
    const poKljucu = new Map(mb.elementi.map((e) => [e.kljuc, e]))
    for (const e of ma.elementi) {
      const o = poKljucu.get(e.kljuc)
      if (!o) { vrstice.push(`  MANJKA v izvedbi: ${e.kljuc} (referenca x${e.x} y${e.y} ${e.w}×${e.h})`); continue }
      const d = ['x', 'y', 'w', 'h'].map((k) => +(o[k] - e[k]).toFixed(1))
      if (d.some((v) => Math.abs(v) > 0.6)) vrstice.push(`  RAZLIKA ${e.kljuc}: dx${d[0]} dy${d[1]} dw${d[2]} dh${d[3]}  (referenca x${e.x} y${e.y} ${e.w}×${e.h})`)
    }
    let razmerje = 1
    if (a.width === b.width && a.height === b.height) {
      const razlika = new PNG({ width: a.width, height: a.height })
      const n = pixelmatch(a.data, b.data, razlika.data, a.width, a.height, { threshold: 0.1 })
      razmerje = n / (a.width * a.height)
      fs.writeFileSync(path.join(IZHOD, 'razlika', `${s.id}.png`), PNG.sync.write(razlika))
      vrstice.unshift(`  različnih pikslov: ${n} (${(razmerje * 100).toFixed(3)} %)`)
    }
    const ok = razmerje <= DOVOLJENO && vrstice.filter((v) => !v.includes('različnih pikslov')).length === 0
    if (!ok) slabo++
    console.log(`${ok ? 'OK    ' : 'RAZLIKA'} ${s.id}`)
    if (!ok) console.log(vrstice.join('\n'))
  }
  console.log(slabo === 0 ? '\nVSA STANJA SE UJEMAJO.' : `\n${slabo} od ${STANJA.length} stanj se NE ujema. Odpri izhod/razlika/*.png in popravi.`)
  process.exit(slabo === 0 ? 0 : 1)
}

if (nacin === 'referenca' || nacin === 'oboje') await zajemiReferenco()
if (nacin === 'izvedba' || nacin === 'oboje') await zajemiIzvedbo()
if (nacin === 'oboje' || nacin === 'primerjaj') primerjaj()
