# Navodila za Claude Code: implementacija in obvezna primerjava s posnetki

Prilepi to v Claude Code (v korenu repozitorija, kjer sta `vmesnik/` in `zaledje/`) skupaj z potjo do mape `design_handoff_termini_prehodi/`.

---

Implementiraj prenovo polj **Termini kol** (okno + polje v obrazcu nove lige) in **Prehodi in piramida** v `vmesnik/`, natanko po `design_handoff_termini_prehodi/README.md`. Zaledja ne spreminjaj.

## 1. Pred delom (obvezno)

1. Preberi `README.md` do konca in `predlog-slog.css`.
2. **Odpri in dejansko poglej vse slike v `posnetki/`** (`2a-*`, `2b-*`, `2c-*`; `zdaj-*` je staro stanje za primerjavo). Posnetki so 2× (1280 px širine = 640 CSS px). To je cilj; kar ni na posnetku, ni cilj.
3. Preberi obstoječo kodo: `TerminiOkno.tsx`, `PrehodiOkno.tsx`, `LigaObrazecOkno.tsx`, `ModalnoOkno.tsx`, `IskalniIzbirnik.tsx`, `StevilskoPolje.tsx` in ustrezne dele `slog.css` (`.obrazec*`, `.termini*`, `.izbirnik*`, `.modal*`, `.gumb*`). Obstoječe obnašanje (logika `napolni`, `premakni`, `vrni`, `sestaviVnos`, `zacetnoStanje`, validacije, API) mora ostati nespremenjeno – spreminjaš prikaz.
4. Ne izumljaj: vsaka mera, barva, besedilo in razmik mora izhajati iz README/CSS predloga ali obstoječih spremenljivk v `slog.css`. Če česa ni, vprašaj ali jasno označi odločitev.

## 2. Implementacija

Sledi seznamu sprememb v README (razdelek »Spremembe po datotekah«): `slog.css`, `ModalnoOkno` (`srednje`), nova `StevilskiKorak`, `TerminiOkno`, `TerminiPolja` v `LigaObrazecOkno`, `PrehodiPolja`/`PrehodiOkno`. Besedila (slovenščina, šumniki, narekovaji »…«) prepiši dobesedno iz README.

## 3. Harness za posnetke

Naredi `vmesnik/src/dev/PosnetkiOkna.tsx` in ga v `App.tsx` registriraj na poti `/dev/posnetki` **samo, če je `import.meta.env.DEV`**. Brez prijave in brez omrežja (mock `ligeApi.termini` / `ligeApi.prehodi` v no-op; lasten `QueryClientProvider`). Query parametri:

- `okno=termini` → `<TerminiOkno liga={…} srecanja={…} onZapri onShranjeno />`; `ure=1` uporabi varianto `vec_ur_na_kolo`, privzeto `ena_ura_na_kolo` (`primerjava/primer-podatkov.json`).
- `okno=prehodi` → `<PrehodiOkno liga vse onZapri onShranjeno />` z `lige` iz JSON (+ ta liga z id 100: višja = id 1, napreduje 2, kval. gor 1, izpade 2, kval. dol 1).
- `okno=obrazec-termini` → samo `TerminiPolja` z začetnim stanjem: datum `2026-10-03`, ura `18:00`, razmik 7, 1 srečanje; ovito v `div` širine **512 px**.

Podatke iz JSON preslikaj v `LigaDto`/`SrecanjeDto` po dejanskih tipih iz `api/tipi.ts` (`predvidenZacetek` = datum kola + `T` + ura srečanja; prestavljeno srečanje ima `kolo ≠ izvirnoKolo`, `razlogPrestavitve`; `status` = `KONCANO` ali `RAZPORED`). Uporabi **točno te podatke**, sicer se posnetki ne bodo ujemali.

## 4. Obvezna zanka primerjave (ne končaj, dokler ni zaključena)

Pripravi: `cd vmesnik && npm i -D playwright pngjs pixelmatch && npx playwright install chromium`, zaženi `npm run dev`.

Skripta `primerjava/primerjaj.mjs`:
- **izriše referenco** iz `referenca/posnetki-stanja.dc.html` v istem Chromiumu kot izvedbo (isti pisalni stroj, iste nativne kontrole date/time) – to je merodajna referenca za piksle; moji PNG-ji v `posnetki/` so za oko in so nastali z drugim izrisovalnikom, zato se lahko v podrobnostih (anti-aliasing) razlikujejo od Chromiumovega izrisa;
- **izriše izvedbo** (harness + korake, ki uporabnika posnemajo: klik, vpis);
- za vsako od 13 stanj izpiše **VELIKOST** (če višina/širina ni enaka), **MANJKA/RAZLIKA** (položaj in velikost vsakega elementa v px) ter število različnih pikslov in shrani `izhod/razlika/*.png`.

```
node ../design_handoff_termini_prehodi/primerjava/primerjaj.mjs            # vsa stanja
node ../design_handoff_termini_prehodi/primerjava/primerjaj.mjs izvedba --samo=2c      # samo en sklop
```
(Skripto lahko skopiraš v repozitorij, npr. `vmesnik/scripts/`, in popraviš poti; če se `import` ne razreši, jo poženi iz `vmesnik/`.)

**Postopek v zanki – ponavljaj do konca:**

1. Zaženi skripto.
2. Za vsako stanje z RAZLIKO: najprej reši **VELIKOST** (višina/širina okna), nato **MANJKA/RAZLIKA** (od zgoraj navzdol – prvi zamik potegne za seboj vse nižje), šele nato različne piksle.
3. Odpri `izhod/razlika/<stanje>.png` **in** `izhod/izvedba/<stanje>.png` ter ustrezen posnetek iz `posnetki/` (z `view_image` oz. kakor pač gledaš slike) in **opiši, kaj se razlikuje** (npr. »gumb Zbriši vse je 2 px nižje«), preden karkoli popraviš. Ne popravljaj na slepo.
4. Popravi kodo/CSS. Vrednosti jemlji iz README in `predlog-slog.css`; če se vrednost v README in referenci ne ujemata, velja **referenca** (`referenca/*.dc.html`) – odpri jo in preberi dejanski slog elementa (DevTools).
5. Ponovno zaženi. Konec je šele, ko skripta izpiše **»VSA STANJA SE UJEMAJO.«** (koda izhoda 0) – vseh 13 stanj, 0 različnih pikslov.

**Dovoljene izjeme** (smeš jih sprejeti samo, če jih natančno dokumentiraš v končnem poročilu s piksli in vzrokom):
- obstoječa glava `ModalnoOkno` (`.modal__glava`: naslov, podnaslov, ✕), če se razlikuje zaradi obstoječega sloga ali pisave (npr. optična os Bricolage Grotesque) – **globalnih pisav in glave modala zaradi tega ne spreminjaj**;
- anti-aliasing posameznih pikslov besedila, ki ga `pixelmatch` ne ujame z `threshold 0.1` – prag lahko povišaš samo za tako stanje, in le skozi `DOVOLJENO_RAZMERJE` (npr. `0.0005`).
Vse ostalo (razmiki, višine, barve, besedila, vrstni red, velikosti polj) se mora ujemati točno.

## 5. Preverjanje obnašanja (poleg slik)

Ročno ali s Playwrightom preveri: napolni/zbriši, preklop odigranih kol, rjavi dan/razmik, iskalnik + urejevalnik prestavitve (izbira → sprememba kola → vrnitev), števec sprememb in onemogočen »Shrani« brez sprememb, stepper (tipkanje, − in +, meje), segmentirani razmik (7/14/Drugo), predogled v obrazcu, pasovi lestvice, odstranitev/dodajanje višje in nižjih lig, vsa tri opozorila. Shranjevanje mora pošiljati **iste vnose** kot prej (`TerminiVnos`, `PrehodiVnos`) – primerjaj payload pred in po prenovi za iste vnose. Zaženi obstoječe teste (`npm test`, `tsc`, lint), če obstajajo.

## 6. Končno poročilo

Navedi: seznam spremenjenih datotek; izpis skripte z »VSA STANJA SE UJEMAJO« (ali seznam dovoljenih izjem s piksli); odločitve, ki jih README ni pokril (npr. mobilni pogled, oblika razdelka »Piramida in prehodi« v obrazcu nove lige, `najvec` za StevilskiKorak glede na zaledje); dev-only datoteke (harness) in ali jih pustiš v repozitoriju.
