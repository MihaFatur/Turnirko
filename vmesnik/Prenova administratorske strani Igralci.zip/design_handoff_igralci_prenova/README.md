# Handoff: Prenova strani »Igralci« (admin)

Repo: `MihaFatur/Turnirko`, stran `vmesnik/src/strani/IgralciStran.tsx` (+ okna v isti datoteki).
Izbrana smer: **1a »Zapisnik, očiščen«** (gostota **udobno**) + **1c »Okna in obrazci«**. Različica 1b je v referenčni datoteki, vendar je **ni treba implementirati**.

## Overview
Celovita prenova admin strani »Igralci«: nov kolofon s števci, filtri, razvrščanje po stolpcih, črkovni ločevalniki, paginacija (seznam je lahko 300–1000+ igralcev), dejanja v meniju »⋯«, nov pogled »Čistka duplikatov«, javni izpis za organizatorja in prenovljena okna (Nov/Uredi igralca, opozorilo o podobnih igralcih, Začetni rating, Zunanja uvrstitev, Arhiviranje). Vizualni jezik ostaja »športni zapisnik na papirju« iz `DESIGN.md`.

## About the Design Files
Datoteke v `reference/` so **oblikovalske reference v HTML** (prototipi videza in vedenja), **ne produkcijska koda**. Nalogo opraviš tako, da jih **poustvariš v obstoječem React + CSS (BEM, slovenska imena) okolju** repozitorija: `slog.css`, komponente iz `vmesnik/src/komponente/`, `@tanstack/react-query`, `useAvtentikacija`. HTML-ja ne kopiraj v aplikacijo.

## Fidelity
**High-fidelity.** Barve, pisave, velikosti, razmiki in vedenje so končni. Poustvari pikselno natančno (postopek preverjanja je spodaj, v razdelku »Primerjava s posnetki«).

## Pred začetkom preberi
1. `DESIGN.md` (zavezujoč; tudi v `turnirko-profil-redesign/project/DESIGN.md` v lokalni mapi), `CLAUDE.md`, `vmesnik/src/slog.css` (obstoječi primitivi `.tabela`, `.gumb`, `.obrazec__*`, `.znacka`, `.izbirnik`…).
2. `IgralciStran.tsx` v celoti: **vso poslovno logiko ohrani** (poizvedbe `igralciApi.seznam`/`seznamPodrobno`, ključ `['igralci', jeAdmin ? 'podrobno' : 'javno']`, mutacije, `PROVIZORICNO_DO = 10`, `zVelikoZacetnico`, preverjanje podobnih, validacije 100–3000, `PotrditvenoOkno`, `ModalnoOkno`, `IzbirnikKluba`, `IzbirnikKraja`, `StevilskoPolje`, `SporociloNapake`). Spreminja se **predstavitev**, ne tok podatkov.
3. Obstoječi odločitvi, ki ju prenova **namerno** spremeni: (a) glava strani (nadnaslov + naslov + kolofon) se vrne, čeprav je komentar v kodi pravil »glave ni«; (b) dejanja iz vrstice gredo v meni »⋯«. Če kdo v `CLAUDE.md` to izrecno prepoveduje, naj uporabnik potrdi.

## Datoteke v paketu
- `screenshots/` – cilj, s katerim se moraš ujemati (glej tabelo spodaj).
- `reference/Igralci prenova.dc.html` – prototip (artboardi 1a, 1b, 1c). Za 1a: `[data-screen-label="1a Namizje"]`, `[data-screen-label="1a Mobilno"]`.
- `reference/Igralci okna.dc.html` – okna (1c), prop `okno`: `uredi | nov | podobni | zacetni | zunanja | arhiv`.
- `reference/support.js` – runtime prototipa.
- Prototip odpri prek HTTP (`cd reference && python3 -m http.server 8000`, nato `http://localhost:8000/Igralci%20prenova.dc.html`); prek `file://` se `dc-import` ne naloži.
- **Podatki prototipa so deterministični**: funkcija `gen()` v `Igralci prenova.dc.html` (seeded PRNG, 640 igralcev + 7 parov duplikatov). Prenesi jo v razvojni fixture (mock odgovor `igralciApi.seznamPodrobno`), da bodo vrstice v tvoji aplikaciji **enake** kot na posnetkih.

## Posnetki (cilj)
| Datoteka | Velikost | Kaj kaže |
|---|---|---|
| `01-seznam-admin-desktop.png` | 1280×2259 @1x | Seznam, admin, privzeto stanje (stran 1 od 33) |
| `02-seznam-mobilno.png` | 780×1800 (=390×900 @2x) | Seznam na telefonu |
| `03-seznam-meni-dejanj.png` | 1280×2259 | Odprt meni »⋯« na 3. vrstici |
| `04-cistka-duplikatov.png` | 1280×2188 | Pogled Čistka duplikatov (7 parov) |
| `05-seznam-organizator.png` | 1280×1780 | Javni izpis za organizatorja |
| `06-okno-uredi-igralca.png` | 760×1096 | Okno Uredi igralca |
| `07-okno-nov-igralec-podobni.png` | 760×1410 | Nov igralec + opozorilo o podobnih |
| `08-okno-zacetni-rating.png` | 760×553 | Začetni rating |
| `09-okno-zunanja-uvrstitev.png` | 760×813 | Zunanja uvrstitev |
| `10-okno-arhiviranje.png` | 760×361 | Potrditev arhiviranja |

Posnetki oken 06–10 so slikani na sivem okviru (`#DCD8D1`, 40 px roba, nad njimi mono oznaka); **okno samo je široko 680 px** in se začne pri x=40. Primerjaj samo okno.

---

## Design tokens (iz `DESIGN.md`, nič novega)
**Pisave:** Display `'Bricolage Grotesque'` (200/800), Body `Karla` (300/400/600/700), Mono `'IBM Plex Mono'` (400/500/600). Rezerva samo `sans-serif`/`monospace`.
**Barve:** glavna `#0088CE`, glavna-tekst `#0071AB`, glavna-mehko `#EAF3F9`; poudarek `#7BB900`, poudarek-tekst `#4E7A00`, poudarek-mehko `#EAF4D6`; negativna `#B23A1E`; papir `#FBF9F5`, namizje `#DCD8D1`, črnilo `#14110F`, črnilo-2 `#332E29`, črnilo-3 `#5B534D`, črnilo-4 `#6E655E`, črta `#DED7CE`, polnilo `#EDE7DF`, bela `#FFFFFF`.
**Pravila:** `border-radius: 0` povsod, brez senc, brez gradientov, brez emojijev; zadetna površina ≥ 44 px; najmanjša velikost besedila 12 px; ritem 8 px; tabelarične številke (`font-variant-numeric: tabular-nums`) za vse številke v stolpcu; prehodi samo barva/obroba ≤ 120 ms. Ikon ni: znaka »⋯« in puščice (← → ↑ ↓) so besedilni znaki.
Mono oznaka (privzeto): `500 12px 'IBM Plex Mono'`, `letter-spacing: .1em`, `text-transform: uppercase`.
Poudarjena vrednost `--barva-papir` = podlaga celotne vsebine.

## Primitivi (ponavljajo se)
- **Primarni gumb:** `min-height 44px; padding 0 20px; background #0088CE; color #fff; font 700 15px Karla`.
- **Sekundarni gumb:** `min-height 44px; padding 0 20px; border 1px solid #14110F; font 600 15px Karla; ozadje prosojno`.
- **Nevaren gumb (potrditev):** kot primarni, `background #B23A1E`.
- **Vnos / select:** `min-height 44px; padding 12px 14px; border 1px solid #14110F; background #fff; font 400 16px Karla; color #14110F`. Mono (licenca, telefon, datum): `font 400 16px 'IBM Plex Mono'`.
- **Segmentiran izbirnik:** mono 12 px, `padding 0 14px`, vsak segment `1px` obroba (sosednji `border-left:0`); aktiven `background #14110F; color #FBF9F5; border-color #14110F`; neaktiven `transparent; color #5B534D; border-color #DED7CE`.
- **Filter čip (preklop):** kot segment, `min-height 44px; padding 0 12px`, samostojen.
- **Značke (mono 12px, ls .08em, uppercase):** `REKR.` `padding 3px 6px; background #EAF4D6; color #4E7A00` (title »Rekreativec — začetni rating 800«); `DUPLIKAT?` `padding 2px 6px; border 1px solid #14110F`; `★ 2/10` (provizorični) `padding 3px 6px; background #EDE7DF; color #332E29` (title »Provizoričen rating«).

---

## Screen 1: Seznam igralcev (admin) – `01`, `03`
Širina vsebine 1280, odmik levo/desno 40 px. Masthead (logotip, navigacija, `1px` + `3px` črta) **ostane kakršen je v aplikaciji**; na posnetku vidno stikalo »ADMIN | ORGANIZATOR« v mastheadu je pripomoček prototipa – **ne implementiraj** (vloga prihaja iz `useAvtentikacija().jeAdmin`).

### Glava
`padding: 40px 40px 0; display: grid; grid-template-columns: minmax(0,1fr) 440px; gap: 56px; align-items: end`.
- **Levo `h1`** (`line-height .88; letter-spacing -.035em`, Bricolage): vrstica 1 »Kartoteka« `200 44px #5B534D`, vrstica 2 »Igralci« `800 88px`.
- **Desno: kolofon** (stolpec, mono 12 px, uppercase, `letter-spacing .1em`, oznaka `#5B534D`, vrednost `#14110F` tabelarično, vsaka vrstica `display:flex; justify-content:space-between; padding 8px 0; border-bottom 1px solid #DED7CE`):
  1. IGRALCEV – število (ne arhiviranih, **neodvisno od filtrov**)
  2. KLUBOV – število različnih klubov
  3. Z RATINGOM
  4. *(samo admin)* PROVIZORIČNI (★ POD 10 TEKEM)
  5. *(samo admin)* MOŽNIH DUPLIKATOV – oznaka in vrednost `#0071AB`, teža 600, spodnja črta `1px solid #14110F`, vrednost »7 · pregled →«; klik odpre pogled Čistka (screen 3). Vrednost = število **parov**.
  - Pod kolofonom (`margin-top 16`): primarni gumb **»+ Nov igralec«** (`flex:none; white-space:nowrap`). Odpre okno Nov igralec.

### Sekcija »Vsi igralci«
`padding: 48px 40px 40px`. Naslov sekcije: `border-top 3px solid #14110F; padding-top 16px; flex, baseline, space-between`; `h2` »Vsi igralci« `800 40px Bricolage; ls -.03em`; desno mono 12 px `#5B534D`: »PRIKAZANIH 1–20 OD 647«.

**Filtri** (`margin-top 24px`): `display:grid; grid-template-columns: minmax(0,1fr) auto 200px 200px; gap 8px`
1. Iskalnik: `min-height 44px; padding 0 16px; border 1px solid #14110F; background #fff; font 300 17px Karla`; placeholder »Išči po imenu ali klubu …« (isto iskanje kot zdaj: ime + priimek + klub, brez razlike v velikosti črk).
2. Segmentiran izbirnik spola: VSI · MOŠKI · ŽENSKI (ponovni klik na aktivnega = VSI).
3. Select kluba: »Vsi klubi«, »Brez kluba«, nato klubi po abecedi (slovenska kolacija).
4. Select pasu: »Vsi pasovi«, U11, U13, U15, U17, U19, U21, člani, veterani (kratke oznake `OZNAKE_PASU_KRATKO`; pas se izpelje iz letnice kot že v kodi; tu filtriraš na **natančen pas** igralca).

**Vrstica čipov** (`margin-top 12px; display flex; gap 8px; flex-wrap; align-items center`): »BREZ RATINGA · 88«, »★ PROVIZORIČNI · 200«, *(admin)* »MOŽNI DUPLIKATI · 14« (število **igralcev** v nerazrešenih parih; kolofon šteje pare – razlika je namerna). Ko je aktiven kak filter, se pojavi povezava »POČISTI FILTRE« (`#0071AB`, podčrtana, `min-height 44px`). Skrajno desno legenda mono 12 px `#5B534D`, `ls .06em`: »★ = PROVIZORIČEN RATING (MANJ KOT 10 TEKEM)«. Vsak filter ponastavi na stran 1.

**Glava stolpcev** (`margin-top 24px; display grid; gap 16px; align-items end; padding 8px 0; border-bottom 1px solid #14110F`; mono 12 px, `#5B534D`):
- Stolpci (admin): `grid-template-columns: minmax(0,2.3fr) minmax(0,1.7fr) 56px 150px 112px 170px 44px` → IGRALEC · KLUB · SPOL · LETNIK · PAS · LICENCA NTZS · RATING (desno) · (prazno).
- Razvrščljivi: IGRALEC (barva `#14110F`), KLUB, LETNIK · PAS, RATING. Aktiven kaže » ↑« ali » ↓«. Klik na aktivnega obrne smer; klik na novega: naraščajoče (rating: padajoče). **Privzeto: priimek ↑, nato ime**, `localeCompare(…, 'sl')`. Igralci brez ratinga so pri razvrščanju po ratingu na koncu (vrednost −1).

**Črkovni ločevalnik** (samo ko je razvrščanje po priimku): vrstica pred prvim priimkom na novo začetnico: `padding 24px 0 8px; font 800 24px Bricolage; ls -.02em; border-bottom 1px solid #DED7CE`.

**Vrstica igralca** (`display grid`, iste stolpci, `gap 16; align-items center; padding 14px 0; border-bottom 1px solid #DED7CE; position relative`):
- IGRALEC: `flex; baseline; gap 6px 8px; wrap` – priimek `600 18px Karla`, ime `300 18px Karla`, nato značke `REKR.` (če rekreativec) in `DUPLIKAT?` (admin, igralec je v nerazrešenem paru).
- KLUB: `300 16px Karla; #332E29`; brez kluba: »brez kluba« `#6E655E`.
- SPOL: `500 13px mono; #5B534D`; »M« / »Ž«.
- LETNIK · PAS: `400 14px mono; #5B534D`, npr. »2012 · U15«.
- LICENCA NTZS: `400 14px mono; #5B534D`, ali »—«.
- RATING: `flex; justify-content flex-end; baseline; gap 8px`: najprej (če provizoričen) značka `★ {steviloTekem}/10`, nato število `600 18px mono` tabelarično. Barva števila: stabilen `#14110F`, provizoričen `#5B534D`, brez ratinga »—« `#6E655E`. Provizoričen = `rating != null && steviloTekem < 10`.
- Gumb **»⋯«** (`aria-label="Dejanja"`): `44×44; border 1px solid #DED7CE; font 600 18px Karla`. Odprt: `background #EDE7DF; border-color #14110F`.

**Meni dejanj** (`03`): `position:absolute; right:0; top:52px; width:248px; background:#fff; border:1px solid #14110F; z-index 30; brez sence`. Postavke `min-height 44px; padding 0 16px; font 400 15px Karla; border-bottom 1px solid #DED7CE`: 1) **Uredi**; 2) **Postavi začetni rating** (ali **Popravi začetni rating**, če rating že obstaja) – **samo če `steviloTekem === 0`**; 3) **Zunanja uvrstitev** (vedno); 4) **Arhiviraj** (`font 600; color #B23A1E`, brez spodnje črte). Zadnje 4 vrstice na strani odpirajo meni navzgor (višina menija 152 px ali 196 px s 4. postavko). Klik zunaj (prosojen sloj čez stran) ali na postavko meni zapre. Dejanja odprejo okna iz Screen 4–8.

**Paginacija** (`margin-top 24px; flex; space-between; align-items center`; mono 12 px `#5B534D`): levo »STRAN 1 OD 33«; desno gumba `min-height 44px; padding 0 20px; border 1px solid #14110F; color #14110F`: »← PREJŠNJA«, »NASLEDNJA →«; onemogočen `opacity .35`. **20 vrstic na stran**, razdeljevanje na odjemalcu (seznam že prihaja v celoti).

**Stanja:** nalaganje »Nalaganje …«, napake prek `SporociloNapake` in prazna stanja ohrani iz kode. Brez zadetkov: »Iskanju ne ustreza noben igralec.« (`300 17px Karla; #5B534D; margin 32px 0`).

## Screen 2: Čistka duplikatov (admin) – `04`
Zamenja sekcijo »Vsi igralci« (glava s kolofonom ostane). Sekcija: ista črta/naslov kot zgoraj: `h2` »Čistka duplikatov«, desno povezava »← NAZAJ NA SEZNAM« (mono 12, `#0071AB`, podčrtana). Pod naslovom `margin-top 16`: odstavek `300 17px/1.55 Karla; #332E29; max-width 62ch`: »Isto ime imata lahko dve osebi, zato odloči človek. Klub, rating in datum rojstva zadostujejo, da ugotoviš, ali gre za isto osebo. Pri združitvi se tekme prenesejo na obdržanega igralca, drugi zapis se arhivira.« Nato mono 12 »PREOSTALIH PAROV: 7«.
**Par:** `padding 24px 0; border-top 1px solid #14110F; display grid; grid-template-columns: minmax(0,1fr) 220px minmax(0,1fr); gap 32px; align-items start`.
- Leva/desna stran (stolpec, gap 8): ime »Priimek Ime« `800 28px Bricolage; ls -.02em`; klub `300 16px Karla #332E29` (ali »brez kluba«); `r. 27. 12. 1980 · lic. 24595` in `rating 1772 · 15 tekem` `400 13px mono #5B534D` (manjkajoče »—«); gumb **»Obdrži tega, združi«** (primarni, `margin-top 8`).
- Sredina (centrirano, stolpec, gap 12): značka ujemanja `500 12px mono; ls .08em; padding 4px 8px; background #14110F; color #FBF9F5`: »ISTO IME IN PRIIMEK« / »IME IN PRIIMEK ZAMENJANA« / »PODOBNO IME« (iste vrednosti kot `OZNAKE_UJEMANJA`); pod njo mono 12 vrstica datuma: »ENAK DATUM ROJSTVA — SKORAJ GOTOVO ISTI IGRALEC« (`#B23A1E`), »PODOBEN DATUM ROJSTVA«, »DRUG DATUM ROJSTVA« (`#5B534D`); nato sekundarni gumb **»Ni duplikat«**.
- Prazno: »Vse čisto. Ni več možnih duplikatov.« (`800 32px Bricolage; ls -.03em; margin 32px 0`).
- ⚠ **Zaledje:** koda danes pozna samo preverjanje podobnih ob dodajanju (`igralciApi.podobni*`). Seznam parov, »Združi« in »Ni duplikat« zahtevajo nove končne točke. **Preglej `zaledje/` in če jih ni, vprašaj uporabnika, preden jih izmisliš**; zaenkrat lahko pogled in značka `DUPLIKAT?` izpelješ iz obstoječega klica ali ju pustiš skrita za zastavico.

## Screen 3: Javni izpis (organizator) – `05`
Isti izgled, ampak (po `jeAdmin`): kolofon ima samo vrstice 1–3; čip »MOŽNI DUPLIKATI« in značka `DUPLIKAT?` ne obstajata; stolpci: `grid-template-columns: minmax(0,2.5fr) minmax(0,2fr) 72px 190px` → IGRALEC · KLUB · SPOL · RATING; brez LETNIK·PAS, LICENCE in gumba »⋯«. Poleg gumba »+ Nov igralec« (organizator sme dodati igralca) stoji opomba `300 14px/1.4 Karla; #5B534D`: »Javni izpis: brez letnika, licence in dejanj. Dodaš lahko samo novega igralca.«

## Screen 4: Mobilni seznam (≤ 640 px) – `02`
Širina 390, `padding 0 20px`. Od zgoraj: masthead (logotip 22 px + »MENI« mono 12, spodaj `1px`+`3px` črta); `h1` (»Kartoteka« `200 24px`, »Igralci« `800 56px`); mono 12 vrstica »647 IGRALCEV · 16 KLUBOV · ★ 200« (`ls .08em; #5B534D`); iskalnik (`min-height 44px`); vrsta čipov (`gap 8; overflow hidden/scroll; min-height 44`): VSI · BREZ RATINGA · ★ PROV. · DUPLIKATI; glava »PRIIMEK IN IME … RATING« (mono 12, spodaj `1px solid #14110F`); vrstice `display grid; grid-template-columns: minmax(0,1fr) auto 44px; gap 12px; min-height 68px; border-bottom 1px solid #DED7CE`: levo priimek `600 18px` + ime `300 18px` (+ `REKR.`), pod tem `300 14px Karla` »klub · letnik · pas«; sredina rating `600 18px mono` in pod njim »★ 2/10« mono 12; desno gumb »⋯« 44×44 (`border 1px solid #DED7CE`). Spodaj lepljiva vrstica: `border-top 3px solid #14110F; padding 12px 20px 20px; background #FBF9F5` s polnoširokim primarnim gumbom »+ Nov igralec« (`min-height 48px; font 700 16px`).
Filtri spol/klub/pas na mobilnem **niso narisani**: uporabi iste selecte pod iskalnikom v zložljivem bloku »Filtri«, enake sloge; brez novih elementov. Meni »⋯« na telefonu enak kot na namizju.

---

## Okna (1c) – skupno
Uporabi obstoječa `ModalnoOkno` / `PotrditvenoOkno` (prekrivni sloj, Esc, fokus ostanejo kot so; sloj `rgba(20,17,15,.55)`). **Prenovi vsebino in okvir:**
- Okvir: `width 680px` (na ozkem `calc(100vw - 32px)`); `background #FBF9F5; border 1px solid #14110F; border-top 3px solid #14110F`; brez radija in sence.
- Glava: `padding 24px 32px 8px; flex; baseline; space-between; gap 24`. Naslov `h3` `800 24px Bricolage; ls -.02em`; desno »ZAPRI ×« (mono 12, `ls .1em`, `#5B534D`, `min-height 44px`, `padding 0 0 0 16px`).
- Telo: `padding 0 32px 32px` (pri oknih brez obrazca `8px 32px 32px`).
- Noga: `display flex; justify-content flex-end; gap 8px; margin-top 32px`: »Prekliči« sekundarni, nato primarni.
- Naslov sklopa v obrazcu: mono 12 `#5B534D; ls .1em; padding-bottom 8px; border-bottom 1px solid #14110F`; `margin 16px 0` (prvi), `32px 0 16px` (ostali). Polja v mreži `1fr 1fr; gap 16px`; oznaka polja `600 14px Karla`, `gap 8px` do vnosa.

### Uredi igralca / Nov igralec – `06`, `07`
Naslov »Uredi igralca« / »Nov igralec«. Sklopi in polja po vrsti:
- **OSNOVNO:** Ime *, Priimek * · Spol * (select Moški/Ženski), Datum rojstva * (`type=date`, mono) · potrditveno polje 24×24 (`accent-color #0088CE`, vrstica `min-height 44`) »**Rekreativec — začetni rating 800**« (`600 16px Karla`) · namig `300 14px/1.5 Karla; #5B534D; max-width 58ch`: »Brez oznake novinec začne pri povprečju registriranih igralcev svoje starosti (odrasel okoli 1500). Po prvem dnevu ga v obeh primerih uvrstijo izidi.« (Obstoječe opozorilo `obvestilo--opozorilo` »Igralec že ima odigrane tekme …« ohrani pod namigom.)
- **KLUB IN LICENCA:** Klub (`IzbirnikKluba`, »Brez kluba«), Licenca NTZS (mono) · Igralna roka (»— ni podatka —«, Leva, Desna), Državljanstvo (placeholder »npr. slovensko«).
- **KONTAKT:** E-pošta, Telefon (mono) · Naslov, Kraj (`IzbirnikKraja`).
- Gumbi: »Prekliči«, [»Popravi vnos« – samo pri opozorilu], primarni: »Shrani spremembe« (uredi) / »Dodaj igralca« / »Preverjam …« (med preverjanjem) / »Vseeno dodaj igralca« (po opozorilu) – **besedila in logika kot v kodi**.
- **Opozorilo o podobnih (`07`):** pod KONTAKT, `margin-top 32px; padding 20px; border 2px solid #14110F; background #EDE7DF`. Naslov `800 20px Bricolage; ls -.02em` (»V bazi že obstaja podoben igralec.« / »… obstajajo podobni igralci.«). Seznam (gap 16, med elementi `1px solid #14110F`): ime `600 18px Karla` + značka ujemanja mono 12 (`ISTO IME IN PRIIMEK` poln `#14110F`/`#FBF9F5`; ostali z `1px` obrobo); pod njim `400 13px mono #332E29` »klub · pas · rating N · N tekem« (+ »arhiviran«); admin še vrstica datuma `400 13px mono` (`#B23A1E` za ENAK, sicer `#5B534D`). Zadnji odstavek `300 15px Karla; #332E29`: »Preveri, ali vpisani igralec ni isti kot kdo od teh.«

### Začetni rating – `08`
Naslov »Začetni rating — Ime Priimek«. Uvod `300 17px/1.55 Karla; #332E29; max-width 54ch`: »Močnemu novincu lahko postaviš vstopni rating, da mu ni treba plezati z 1000. Mogoče je le pred prvo odigrano tekmo; nato rating določajo rezultati.« Blok `margin-top 32px; border-top 3px solid #14110F; padding-top 16px; flex; align-items flex-end; gap 32px`: levo oznaka mono 12 »TURNIRKO RATING (100–3000)« in vnos `width 260px; padding 8px 14px; border 1px solid #14110F; font 800 64px/1 Bricolage; ls -.04em; tabular-nums` (`StevilskoPolje`); desno oznaka »HITRA IZBIRA« in trije gumbi (`padding 12px 14px; border 1px solid #14110F; mono 500 13px`): »800 · rekreativec«, »1000 · privzeto«, »1500 · odrasel« (vpišejo vrednost). Gumbi: »Prekliči«, »Shrani rating« (onemogočen, dokler ni celo število 100–3000).

### Zunanja uvrstitev – `09`
Naslov »Zunanja uvrstitev — Ime Priimek«. Uvod (enak slog kot zgoraj, `max-width 56ch`): »Za redkega gosta, ki pri nas odigra premalo tekem, da bi ga lestvica sama uvrstila. Možna je tudi po odigranih tekmah.« Blok `margin-top 24px; display grid; grid-template-columns: 200px minmax(0,1fr); gap 24px; border-top 3px solid #14110F; padding-top 16px`:
- Levo: oznaka mono 12 »TRENUTNO«, rating `800 56px/.9 Bricolage; ls -.04em; #5B534D` (ali »—«), pod njim `400 13px mono #5B534D` »po 3 tekmah« / »brez ratinga«.
- Desno (stolpec, gap 16): »Turnirko rating (100–3000)« (`width 160px; font 600 20px mono`), »Vir *« (placeholder »npr. ITTF svetovna lestvica, september 2026«, `maxLength 200`), »Pojasnilo *« (`textarea rows 3`, `maxLength 500`, placeholder »npr. Igra skoraj samo mednarodno, pri nas dve tekmi na leto.«).
- Pod blokom `margin-top 24px; padding 16px; background #EDE7DF`: mono 12 »JAVNO — IZPIŠE SE NA PROFILU POD GRAFOM« + `300 15px/1.5 Karla; #332E29`: »Vir in pojasnilo vidi vsak obiskovalec. Ročno vpisana številka brez zapisanega vira je na javni lestvici videti kot naklonjenost; z virom je trditev, ki jo lahko vsak preveri.«
- Gumbi: »Prekliči«, »Vpiši uvrstitev« (onemogočen, dokler vrednost ni 100–3000 in sta vir in pojasnilo neprazna).

### Arhiviranje – `10`
Naslov »Arhiviranje igralca«. Besedilo `300 18px/1.55 Karla; #332E29; max-width 50ch`: »Igralec **Ime Priimek** bo izginil s seznamov, zgodovina njegovih tekem pa ostane. Arhiviram?« (ime `600 #14110F`). Gumbi: »Prekliči«, **»Arhiviraj«** (nevaren, `#B23A1E`).

---

## Interakcije in stanje
- Stanje strani: `iskanje`, `spol`, `klub`, `pas`, `brezRatinga`, `provizorični`, `duplikati`, `razvrscanje {stolpec, smer}`, `stran`, `odprtMeni (id)`, `pogled: 'seznam' | 'cistka'`, `urejanje | arhiviranec | postavljanec | zunanjiGost` (kot zdaj). Filtriranje, razvrščanje in paginacija so izpeljani (`useMemo`).
- Odpiranje oken: »+ Nov igralec« → Nov; meni »⋯« → ostala okna; Esc/»ZAPRI ×«/ozadje zapre okno (obstoječe vedenje `ModalnoOkno`).
- Prehodi: samo barva/obroba ≤ 120 ms. **Nobenih drugih animacij** (to je različica 1a; gibanje v 1b se ne uvaja).
- Odzivnost: ≤ 640 px mobilni pogled (Screen 4), nad tem namizni.

## Primerjava s posnetki (OBVEZNO – ponavljaj do popolnega ujemanja)
Uporabnik želi, da se tvoja izvedba **popolnoma** ujema s posnetki v `screenshots/`. Postopek:
1. **Priprava.** Zaženi aplikacijo (`vite`) kot admin. V razvojnem načinu nadomesti odgovor `igralciApi.seznamPodrobno` s fixture, ustvarjenim s prenesenim `gen()` iz prototipa (isti igralci, iste vrstice, isti pari duplikatov). Prototip streži prek HTTP (zgoraj) kot drugi vir resnice.
2. **Zajem.** Z Playwright/Puppeteer (headless Chromium, `deviceScaleFactor` 1, mobilni 2) posnemi enake poglede: 01 (viewport širine 1280, celotna stran, stran 1), 02 (390×900 @2x), 03 (odprt meni na 3. vrstici), 04 (pogled Čistka), 05 (organizator), 06–10 (samo okno, 680 px). Počakaj na `document.fonts.ready`.
3. **Primerjava.** Za vsak par odpri **oba** posnetka (`view_image`) in ju primerjaj po delih: glava, kolofon, filtri, glava stolpcev, 3–4 vrstice, noga; nato izvedi **pikselno razliko** (npr. `pixelmatch` ali ImageMagick `compare -metric AE`) in si oglej sliko razlik. Preveri še `getComputedStyle` ključnih elementov proti številkam v tem dokumentu (velikosti pisav, `letter-spacing`, barve, višine 44 px, širine stolpcev, razmiki).
4. **Popravi in ponovi.** Vsako odstopanje (premik za 1 px, drugačna teža, barva, prelom besedila, razmik) popravi in ponovi korake 2–3. **Ne končaj**, dokler: (a) se na nobenem od 10 posnetkov s prostim očesom ne vidi razlike, (b) pikselna razlika ostane le na robovih črk (sglajevanje) in je pod ~0,5 % površine, (c) višina strani 01/03 = 2259 px, 04 = 2188 px, 05 = 1780 px, okna so visoka 1096 / 1410 / 553 / 813 / 361 px.
5. **Poročilo.** Na koncu naštej, kaj si primerjal, koliko iteracij je bilo potrebnih in morebitna preostala odstopanja z razlogom (npr. pisave nenaložene, drugačen render izbirnika `<select>`).

## Znana odstopanja in opombe
- Prototip uporablja izmišljene podatke in imena klubov; v aplikaciji vzemi prave.
- Gumbi »Shrani« v prototipu le zaprejo okno; v aplikaciji ohrani obstoječe mutacije in validacije.
- Čistka duplikatov (Screen 2) je edina funkcija brez znanega zaledja – glej opozorilo zgoraj.
- Posnetki so v Chromiumu; videz nativnih `<select>` in `type=date` je odvisen od platforme.
- Po implementaciji dodaj razdelek o tej strani v `DESIGN.md` (kolofon, vrstica podatkov z mono značkami, meni »⋯«, pogled Čistka), da ne ostanejo nove vizualne odločitve brez zapisa.
