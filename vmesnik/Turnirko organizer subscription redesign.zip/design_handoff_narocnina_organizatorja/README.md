# Predaja: stran »Naročnina« za organizatorja

## Pregled

Nova podoba strani `/narocnina`, ki jo vidi prijavljen **organizator** (`uporabnik.vloga === 'ORGANIZATOR'`), ko v uporabniškem meniju klikne »Naročnina«. Zamenja sedanji organizatorski del `vmesnik/src/strani/NarocninaStran.tsx` (seznam treh paketov z gumbom »Izberi«). Igralčev del (`NarocninaIgralec.tsx`) ostane, kot je.

Stran pokaže:
- trenutni paket (Basic / Plus / Pro), dni do obnove, začetek naročnine, trenutno letno obdobje, naslednjo obnovo in porabo paketa v sezoni;
- primerjavo treh paketov in njihove prednosti, z nadgradnjo (takoj, s sorazmernim doplačilom) ali znižanjem (ob obnovi);
- preklic (s potrditvijo) in obnovo preklicane naročnine;
- stanje »brez paketa« z izbiro paketa in plačilom prek Stripe.

**Vsi organizatorski paketi so letni.** Mesečnega plačevanja za organizatorje ni, zato na strani ni izbirnika Mesečno/Letno.

## O datotekah v paketu

Datoteke v `prototip/` so **oblikovalske reference v HTML**: prototip, ki kaže želeni izgled in obnašanje. **Niso** koda za produkcijo. Naloga je stran **na novo izdelati v obstoječem vmesniku** (React + TypeScript + Vite, navaden CSS z BEM razredi v slovenščini v `vmesnik/src/slog.css`, podatki prek `@tanstack/react-query`). Upoštevaj vzorce, ki že obstajajo.

Prototip ima vse sloge zapisane inline s hex vrednostmi. V kodi uporabi **CSS spremenljivke in obstoječe razrede** iz `slog.css` (preslikava je spodaj).

`prototip/Narocnina organizatorja.dc.html` odpreš neposredno v brskalniku (potrebuje sosednji `support.js`). Na širini ≤ 640 px se preklopi na telefonski pogled.

## Natančnost

**Visoka (hi-fi).** Barve, pisave, mere, razmiki in besedila so končni. Stran naj se s posnetki zaslona v `posnetki/` ujema do piksla (glej »Postopek primerjave«).

## Obvezen postopek primerjave s posnetki

To ni neobvezno. Delo ni končano, dokler se tvoja stran s posnetki ne ujema.

1. Izdelaj stran.
2. Zaženi vmesnik (`npm run dev` v `vmesnik/`) in se prijavi kot organizator (ali stanje začasno ponaredi z lažnim `NarocninaDto`, da prideš do vseh sedmih stanj).
3. Za **vsako** stanje spodaj naredi posnetek celotne strani (full-page) pri:
   - **namizju**: širina okna **1280 px**;
   - **telefonu**: širina okna **390 px**.
   Uporabi Playwright ali Puppeteer z `fullPage: true` in `deviceScaleFactor: 1`.
4. Svoj posnetek postavi ob pripadajočega iz `posnetki/` (ali ju prekrij s 50 % prosojnostjo) in popravi vsako razliko: postavitev, razmike, velikosti in teže pisav, barve, črte, prelome vrstic in besedila.
5. **Točke 3–4 ponavljaj, dokler se posnetka popolnoma ne ujemata.** Po vsakem popravku posnemi znova. Ne ustavi se pri »približno«.

Posebnosti posnetkov, ki jih upoštevaj pri primerjavi:
- Glava (masthead) in telefonska spodnja vrstica sta na posnetkih **statični**, ker gre za posnetek cele strani. Na namizju je glava zgoraj, na telefonu je spodnja vrstica na dnu strani. V aplikaciji ostaneta taki, kot sta zdaj (`.glava` lepljiva, `.spodnja-vrstica` fiksna). Pri posnetku ju začasno nastavi na `position: static` ali primerjaj samo vsebino med njima.
- Podatki na posnetkih so vzorčni: današnji datum 29. 9. 2026, obdobje 14. 10. 2025 – 14. 10. 2026 (še 15 dni), poraba 2 od 3 lig in 4 od 5 turnirjev, uporabnik »Matej Zupan«. Za primerjavo nastavi enake podatke.

### Stanja in posnetki

| # | Stanje | Namizje | Telefon |
|---|---|---|---|
| 01 | Aktivna naročnina, paket Plus | `posnetki/namizje-01-aktivna.png` | `posnetki/telefon-01-aktivna.png` |
| 02 | Aktivna, v primerjavi izbran višji paket (Pro), predogled nadgradnje | `namizje-02-nadgradnja-pro.png` | `telefon-02-nadgradnja-pro.png` |
| 03 | Aktivna, izbran nižji paket (Basic), predogled znižanja z opozorili o porabi | `namizje-03-znizanje-basic.png` | `telefon-03-znizanje-basic.png` |
| 04 | Znižanje potrjeno: obvestilo z »Razveljavi«, vrstica »Paket od obnove« | `namizje-04-prehod-zabelezen.png` | `telefon-04-prehod-zabelezen.png` |
| 05 | Klik »Prekliči naročnino«: rjasta potrditev | `namizje-05-potrditev-preklica.png` | `telefon-05-potrditev-preklica.png` |
| 06 | Preklicana naročnina (velja do konca obdobja), sklop »Obnova« | `namizje-06-preklicana.png` | `telefon-06-preklicana.png` |
| 07 | Brez paketa: izbira paketa, privzeto Plus | `namizje-07-brez-paketa.png` | `telefon-07-brez-paketa.png` |

## Zgradba strani

Stran ponovi zgradbo in razrede `NarocninaIgralec.tsx`, torej jezik razdeljenega okna registracije (`RegistracijaTok.tsx`, razdelka »Registracija« in »Naročnina igralca« v `slog.css`). **Najprej ponovno uporabi razrede `.registracija__*` in `.narocnina__*`.** Nove razrede dodaj samo za tisto, česar tam ni: primerjalno tabelo s tremi stolpci in okvir razlike med paketoma.

Stran je en `<section>` v `.vsebina` (namizje: padding 48/40/64, gap 56; telefon `.vsebina--telefon`: 20/20, gap 32). Po vrsti:

### 1. Glava strani — `.narocnina__glava`
- Levo `h1.naslov-strani` v dveh vrsticah:
  - nadnaslov »Naročnina«: Bricolage 200, `clamp(28px, 5vw, 48px)`, −0.03em;
  - naslov »Organizator Plus« (oz. »Organizator« brez paketa): Bricolage 800, `clamp(44px, 8vw, 88px)`, −0.035em, line-height 0.88. Na 1280 px je v eni vrstici, na telefonu se prelomi.
- Desno (`.narocnina__glava-stanje`, max 380 px):
  - **aktivna**: `.narocnina__blok` (polna modra `#0071AB`): število dni 96 px, »dni do obnove«, spodaj »Obnova 14. 10. 2026« | »169,99 €«;
  - **preklicana**: `.narocnina__blok--preklicano`: »dni paket še velja«, »Velja do …« | »Brez obnove« (rjasto);
  - **brez**: `.narocnina__kolofon--crn` z vrsticami Paket: Brez / Basic: 89,99 € / leto / Pro: 249,99 € / leto.

### 2. Plošča — `.registracija.narocnina__plosca` (obroba 1 px črnilo, papir)
**Namizje (> 640 px):** levi temni stolpec `.registracija__stolpec` (280 px):
- logotip (`ZnakTurnirko` 24, poteze v papirju);
- glava seznama `.registracija__seznam-glava`: »Plus · vključeno« / »Plus · do 14. 10.« (preklicana) / »Plus · kaj dobiš« (brez; ime izbranega paketa);
- osem vrstic `.registracija__korak`: prvi dve sta obseg paketa (»3 tekoče lige«, »5 turnirjev na sezono«) z **modro levo črto 3 px in težo 700**, sledi šest funkcij. Pri aktivni/preklicani je številka »OK« zelena (`#7BB900`), pri »brez« so številke 01–08 (`--barva-na-crnilu-3`), obseg v papirju, funkcije v `--barva-na-crnilu-2`;
- spodaj `.registracija__izbira` »Tvoja naročnina«: Paket / Plačevanje (Letno) / Cena.

**Telefon (≤ 640 px, `useTelefon()`):** namesto stolpca trak `.registracija__trak`: znak 20 px, status »Naročnina · aktivna« (odrezan z elipso), desno cena »169,99 € / leto« (`--barva-na-glavni-2`), pod njim 12 segmentov obdobja (pretečeni modri).

**Desni stolpec** `.registracija__desni`:
- Glava: na namizju vrstica statusa (»Naročnina · aktivna« | »Obnova 14. 10. 2026«, mono 12, `--barva-crnilo-3`, min-height 44), naslov plošče 48 px 800 (»Tvoja naročnina« / »Brez obnove« / »Izberi paket«), nato napredek obdobja: »Obdobje 14. 10. 2025 – 14. 10. 2026« | »Še 15 dni« (+ », nato brez paketa« pri preklicani) in 12 segmentov po 6 px (gap 4, pretečeni `#0088CE`, ostali `--barva-polnilo`). Število pretečenih je `round((1 − dni/dniObdobja) × 12)`.
- Telo (gap 24; sklopi med seboj gap 32):
  1. **Obvestilo** (če je): `.registracija__obvestilo--uspeh` + gumb »Razveljavi« (`.narocnina__obvestilo-gumb`).
  2. **Kolofon** (`.registracija__kolofon--rob-zgoraj`, ni ga pri »brez«): Naročen od · Paket »Plus · 3 / 5« · Plačevanje »Letno · 169,99 €« · Trenutno obdobje · Poraba v sezoni »2/3 lig · 4/5 turn.« · Naslednja obnova »14. 10. 2026 · 169,99 €« (pri preklicani »Velja do« v `--barva-negativna-tekst`). Po potrjenem znižanju še »Paket od obnove: Basic · 89,99 € / leto« v `--barva-poudarek-tekst`.
  3. **Sklop paketa**: glava `.registracija__zapis-glava` »Zamenjaj paket« / »Paket ob obnovi« / »Paket«. Pod njo:
     - **Primerjalna tabela** (nov razred, izpeljan iz `.registracija__primerjava`). Mreža `minmax(0,1fr) repeat(3, min(24%, 132px))`, gap 0 8 px. Glava stolpcev so gumbi (`.registracija__stolp`): ime 14/700, cena Bricolage 800 `clamp(17px, 2.6cqw, 30px)` nowrap, enota »Na leto«, oznaka. Vrstice: Tekoče lige 1/3/5 in Turnirji na sezono 2/5/10 (mono 600 18 px), »Vse funkcije spodaj« DA (mono 12, `--barva-poudarek-tekst`).
       - Trenutni paket: zgornja črta 3 px **črnilo**, podlaga `--barva-vrstica-hover` (`#F3EFE9`), oznaka »Trenutno« (»Do 14. 10.« pri preklicani) v črnilu.
       - Izbran ciljni paket: zgornja črta `#0088CE`, podlaga `--barva-glavna-mehko`, oznaka »Izbrano« v `--barva-glavna-tekst`.
       - Ostali: črta `--barva-crta`, brez podlage, oznaka »Nadgradi« (višji) / »Zamenjaj« (nižji) / »Izberi« (brez paketa) / »Od obnove« (že zabeleženo znižanje), v `--barva-crnilo-3`.
       - Podlaga stolpca teče skozi vse celice stolpca.
       - Klik na trenutni paket izbiro počisti.
     - **Okvir razlike** (ko je izbran drug paket): levi rob 4 px + podlaga. Nadgradnja in izbira (brez): `#0088CE` / `#EAF3F9`, notranje črte `#C9DCEA`. Znižanje: `#6E655E` / `#EDE7DF`, črte `--barva-crta`. Vsebina: naslov 24/800 (»Kaj pridobiš s paketom Pro« / »Kaj se spremeni s paketom Basic« / »Kaj dobiš s paketom Plus«), opis »za koga« (15/300), kolofon (Tekoče lige »3 → 5 · +2«, Turnirji »5 → 10 · +5«, Cena »169,99 € → 249,99 € / leto«; razlike zelene pri nadgradnji, rjaste pri znižanju). Pri znižanju sledijo opozorila (14 px, `--barva-negativna-tekst`), kadar poraba presega novo mejo.
     - **Predogled menjave** (samo pri aktivni): odstavek (`.registracija__uvod`), znesek `.narocnina__znesek` (črta 3 px nad njim; št. Bricolage 800 `clamp(36px, 5vw, 56px)`, **white-space: nowrap**), dva gumba `.narocnina__dejanja`: glavni »Nadgradi v Pro · 3,29 €« / »Preidi na Basic ob obnovi« in drugi »Ostani pri Plus«.
     - Sicer pojasnilo (`.registracija__pojasnilo`): »Vsi paketi so letni in se razlikujejo samo po obsegu. Lige štejejo tekoče (hkrati odprte), turnirji na sezono.«
  4. **Preklic** (aktivna) ali **Obnova** (preklicana): isto kot pri igralcu (`.narocnina__potrditev`, `.narocnina__gumb--preklic`, `.narocnina__gumb--papir`, `.narocnina__dejanje--obnova`), besedila spodaj.
- Noga `.registracija__noga`: levo »Plačilo prek Stripe« (`.registracija__placilo-pripis`), desno »Kartica in računi v Stripe« (`.gumb`, Stripe Billing Portal) oz. pri »brez« glavni gumb »Nadaljuj na plačilo · 169,99 €«.

### 3. »V vsakem paketu« — `.narocnina__prednosti`
Naslov 40 px, meta desno »6 od 6 vključeno« (pri »brez«: »Od 89,99 € / leto«). Šest vrstic `.narocnina__prednost` (številka zelena pri aktivnem paketu, ime 24/800, opis, povezava mono modra; pri »brez« oznaka »Vsi paketi« v `--barva-crnilo-4`):

| # | Ime | Opis | Povezava |
|---|---|---|---|
| 01 | Turnirji s skupinami in mrežo | Skupine, nosilci in izločilna mreža do finala. Žreb samodejno ali ročno. | Turnirji → `/turnirji` |
| 02 | Ekipne lige in zapisniki | Kola, postave in zapisniki ekipnih dvobojev; lestvica lige se izračuna sama. | Lige → `/lige` |
| 03 | Vnos rezultatov v dvorani | Rezultat po nizih kar s telefona. Lestvica, mreža in koledar se osvežijo takoj. | Plošča → `/moj-profil` |
| 04 | Listki in zapisnik za tisk | Listki za mize in zapisnik NTZS, pripravljeni za tiskalnik v dvorani. | Turnirji → `/turnirji` |
| 05 | Rating po vsaki tekmi | Odigrane tekme štejejo v rating igralcev brez ročnega uvoza. | Lestvica → `/lestvica` |
| 06 | Nadzorna plošča sezone | Kaj čaka vnos ali žreb, termini 14 dni naprej, poraba paketa in arhiv sezon. | Plošča → `/moj-profil` |

Opisi »za koga«:
- **Basic**: Za klub z eno ligo in dvema turnirjema na sezono.
- **Plus**: Za večji klub ali regijo: tri lige hkrati in turnir skoraj vsak drugi mesec.
- **Pro**: Za zvezo ali organizatorja cele sezone: pet lig hkrati in deset turnirjev.

## Obnašanje

- **Izbira paketa v tabeli**: pri aktivni naročnini klik na drug paket pokaže razliko in predogled; klik na trenutnega ali »Ostani pri Plus« izbiro počisti. Pri preklicani izbira določi paket obnove (brez predogleda, gumb »Obnovi Pro · 249,99 € / leto«). Pri »brez« je privzeto izbran Plus.
- **Nadgradnja** (višji paket): velja takoj. Doplačilo = `(cena_novi − cena_stari) × preostali_dni / dni_obdobja` (v prototipu 80 € × 15/365 = 3,29 €). Končni znesek izračuna Stripe (proration). Po uspehu: obvestilo »Pro je vklopljen. Stripe je zaračunal doplačilo 3,29 €.«
- **Znižanje** (nižji paket): velja ob obnovi, danes se ne plača nič. Po potrditvi: obvestilo »Od 14. 10. 2026 imaš paket Basic, 89,99 € / leto.« z »Razveljavi«, vrstica »Paket od obnove« v kolofonu in oznaka »Od obnove« v tabeli.
  - Opozorila, če poraba presega mejo nižjega paketa:
    - »Odprti imaš 2 tekoči ligi, Basic dovoli 1. Obstoječe tečejo naprej; novo odpreš, ko ena konča.«
    - »V tej sezoni imaš 4 turnirje, Basic jih dovoli 2. Novih do nove sezone ne ustvariš.«
  - Sklanjaj pravilno (lig/turnirjev/dni; glej pomagala v `pomozno/organizatorPregled.ts` in `sklonDni` v `pomozno/oblikovanje.ts`).
- **Preklic**:
  - Gumb »Prekliči naročnino« (`.gumb--nevaren`) odpre potrditev z naslovom »Prekličem naročnino?« in besedilom »Obnove 14. 10. 2026 ne bo. Čez 15 dni ustvarjanje lig in turnirjev zaklenemo. Do takrat naročnino obnoviš brez plačila.« Gumba: »Da, prekliči« in »Obdrži paket«.
  - Besedilo sklopa: »Plus ostane do konca plačanega obdobja, 14. 10. 2026. Potem novih lig in turnirjev ne moreš ustvariti; obstoječa tekmovanja, rezultati in arhiv sezon ostanejo.«
  - Po potrditvi: obvestilo »Naročnina je preklicana. Plus velja do 14. 10. 2026.«
- **Obnova**: »Obnova ne stane nič do 14. 10. 2026. Takrat se obdobje nadaljuje z izbranim paketom in plačevanjem.« Po uspehu: »Naročnina je obnovljena. Naslednja obnova 14. 10. 2026.«
- **Brez paketa**: »Nadaljuj na plačilo · 169,99 €« zažene `placilaApi.nadgradnja({ paket, ciklus: 'LETNO' })` in preusmeri na Stripe Checkout. Vrnitev (`?stanje=uspeh|preklic`) obravnavaj enako kot `NarocninaIgralec` (poizvedovanje po vrnitvi, obvestilo »Stripe je potrdil plačilo 169,99 €. Paket Plus je vklopljen.«).
- Stanja nalaganja in napak: `NapakaPoizvedbe`, »Nalagam naročnino …«, napaka dejanja v `.napaka` pod glavo strani (kot pri igralcu). Med dejanjem so gumbi onemogočeni (`isPending`).
- Gibanja ni, razen prehodov barve in obrobe do 120 ms (DESIGN.md, točka 12). Radij je povsod 0, senc ni.
- Vse klikljive površine so vsaj 44 px visoke.

## Podatki in zaledje

To je treba preveriti v `zaledje/` (NarocninaStoritev, PlacilaStoritev) in po potrebi dodati:
- `NarocninaDto` za organizatorja: `paket`, `aktivna`, `preklicana`, `narocenOd`, `obdobjeOd`, `obdobjeDo`, `cena`, **`naslednjiPaket`** (zabeleženo znižanje ob obnovi).
- Poraba: `lige` in `turnirji` (`KvotaDto { uporabljeno, meja }`) iz organizatorskega pregleda (isti vir kot palica paketa na nadzorni plošči).
- Končne točke za organizatorja:
  - nadgradnja paketa s sorazmernim doplačilom (Stripe subscription update, `proration_behavior`);
  - znižanje ob obnovi in njegova razveljavitev (Stripe subscription schedule);
  - preklic ob koncu obdobja (`cancel_at_period_end`) in obnova.
  Kjer je mogoče, razširi obstoječe `narocninaApi.preklici/obnovi`.
- Cene in meje ostanejo v `api/tipi.ts` (`CENA_ORGANIZATOR_LETNO`, `OMEJITVE_ORGANIZATORJA`). Nikoli jih ne vtipkaj v komponento.

## Oblikovalski žetoni (preslikava prototip → `slog.css`)

| Hex v prototipu | Spremenljivka |
|---|---|
| `#FBF9F5` | `--barva-papir` |
| `#DCD8D1` | `--barva-namizje` |
| `#14110F` | `--barva-crnilo` |
| `#332E29` | `--barva-crnilo-2` (tudi `--barva-crta-na-crnilu`) |
| `#5B534D` | `--barva-crnilo-3` |
| `#6E655E` | `--barva-crnilo-4` |
| `#DED7CE` | `--barva-crta` |
| `#EDE7DF` | `--barva-polnilo` |
| `#F3EFE9` | `--barva-vrstica-hover` |
| `#0088CE` | `--barva-glavna` |
| `#0071AB` | `--barva-glavna-polna` / `--barva-glavna-tekst` |
| `#005A88` | `--barva-glavna-polna-mocna` |
| `#EAF3F9` | `--barva-glavna-mehko` |
| `#E8F5C4` | `--barva-na-glavni-2` |
| `#7BB900` | `--barva-poudarek` |
| `#4A7500` | `--barva-poudarek-tekst` |
| `#EAF4D6` | `--barva-poudarek-mehko` |
| `#B23A1E` | `--barva-negativna` |
| `#8C2B14` | `--barva-negativna-tekst` |
| `#F8E5DF` | `--barva-negativna-mehko` |
| `#B9B0A6` / `#9A9189` | `--barva-na-crnilu-2` / `--barva-na-crnilu-3` |
| `#4A433D` | `--barva-crta-na-crnilu-2` |
| `#C9DCEA` | **nov** — notranja črta v modrem okviru razlike; dodaj kot `--barva-glavna-crta` ali uporabi `--barva-crta` |

Pisave: `--pisava-display` (Bricolage Grotesque 200/800), `--pisava-telo` (Karla 300/400/600/700), `--pisava-mono` (IBM Plex Mono 500/600). Razmiki so ritem 8 px (`--r1` … `--r8`). Radij je 0, senc ni.

## Sredstva

Novih sredstev ni. Logotip je `ZnakTurnirko` iz `Postavitev.tsx`. Ikone spodnje vrstice so obstoječe `IkoneNavigacije.tsx` (Lucide). Glava, uporabniški meni in spodnja vrstica so obstoječa `Postavitev`; stran jih ne spreminja.

## Datoteke

- `prototip/Narocnina organizatorja.dc.html` — interaktiven prototip vseh stanj (logika v razredu `Component`: cene, meje, besedila in izračuni). Odpri ga v brskalniku ob `support.js`.
- `prototip/support.js` — izvajalno okolje prototipa (ni za vmesnik).
- `posnetki/namizje-*.png` (1280 px) in `posnetki/telefon-*.png` (390 px) — referenca za primerjavo.

Datoteke v repozitoriju, ki se jih to tiče:
- `vmesnik/src/strani/NarocninaStran.tsx`
- `vmesnik/src/komponente/NarocninaIgralec.tsx` (vzorec)
- `vmesnik/src/komponente/RegistracijaTok.tsx`
- `vmesnik/src/slog.css` (razdelka »Registracija« in »Naročnina igralca«)
- `vmesnik/src/api/tipi.ts`
- `vmesnik/src/api/zahteve.ts`
- `vmesnik/src/pomozno/organizatorPregled.ts`
- `vmesnik/turnirko-profil-redesign/project/DESIGN.md` (zavezujoča pravila)
