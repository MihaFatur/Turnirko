/* Vzorčni podatki za maketo »Dostopi« (oblika = RacunIgralcaDto). Polja z oznako (novo) API danes ne vrača. */
const DANES = new Date('2026-10-11T12:00:00');
export const KLUBI = ['NTK Savinja', 'NTK Celje', 'KNTK Žalec', 'NTK Velenje', 'NTK Maribor', 'NTK Ptuj', 'NTK Laško', 'NTK Slovenske Konjice', 'NTK Kranj', 'NTK Ljubljana'];
const IM_M = ['Jan', 'Luka', 'Nejc', 'Žiga', 'Matej', 'Andraž', 'Tilen', 'Rok', 'Gašper', 'Urban', 'Anže', 'Blaž', 'Domen', 'Miha', 'Primož', 'Marko', 'Peter', 'Janez', 'Franc', 'Aljaž', 'Klemen', 'Timotej'];
const IM_Z = ['Ana', 'Maja', 'Eva', 'Nina', 'Tina', 'Katja', 'Sara', 'Lara', 'Špela', 'Mojca', 'Urška', 'Neža', 'Petra', 'Jerneja'];
const PRI = ['Petrič', 'Novak', 'Horvat', 'Kovač', 'Krajnc', 'Zupančič', 'Potočnik', 'Mlakar', 'Vidmar', 'Kos', 'Golob', 'Turk', 'Božič', 'Korošec', 'Bizjak', 'Zupan', 'Hribar', 'Kotnik', 'Kavčič', 'Rozman', 'Kolar', 'Jerman', 'Lah', 'Pirc', 'Šegula', 'Čeh', 'Žnidar', 'Vrhovnik', 'Oblak', 'Marolt', 'Medved', 'Škof', 'Debelak', 'Zorko'];
const DOM = ['gmail.com', 'gmail.com', 'gmail.com', 'siol.net', 't-2.net', 'outlook.com'];
const MAX = { ORGANIZATOR_BASIC: { lig: 1, turnirjev: 2 }, ORGANIZATOR_PLUS: { lig: 3, turnirjev: 5 }, ORGANIZATOR_PRO: { lig: 5, turnirjev: 10 } };
export const OZ_VLOGA = { ADMIN: 'Administrator', ORGANIZATOR: 'Organizator', IGRALEC: 'Igralec' };
export const OZ_PAKET = { BREZPLACNO: 'Igralec Free', PREMIUM: 'Igralec Premium', ORGANIZATOR_BASIC: 'Organizator Basic', ORGANIZATOR_PLUS: 'Organizator Plus', ORGANIZATOR_PRO: 'Organizator Pro' };

function rng(s) { return () => { s |= 0; s = (s + 0x6d2b79f5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const asc = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');
const dan = (n) => { const d = new Date(DANES); d.setDate(d.getDate() - n); return d.toISOString().slice(0, 10); };
const cas = (n, h, m) => dan(n) + 'T' + String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
const naprej = (n) => dan(-n);
export const datum = (iso) => { if (!iso) return '—'; const d = new Date(iso); return Number.isNaN(d.getTime()) ? '—' : d.getDate() + '. ' + (d.getMonth() + 1) + '. ' + d.getFullYear(); };
export const ura = (iso) => { const d = new Date(iso); return datum(iso) + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };
export const dniOd = (iso) => Math.max(0, Math.round((DANES - new Date(iso)) / 864e5));
export const dniDo = (iso) => Math.round((new Date(iso) - DANES) / 864e5);
export const rel = (iso) => { if (!iso) return 'nikoli'; const n = dniOd(iso); if (n === 0) return 'danes'; if (n === 1) return 'včeraj'; if (n < 14) return 'pred ' + n + ' d'; if (n < 60) return 'pred ' + Math.round(n / 7) + ' t'; return 'pred ' + Math.round(n / 30) + ' m'; };
export const danesIso = () => dan(0) + 'T12:00';

export function imeNar(n) { if (n.paket === null) return 'Brez paketa'; if (n.paket === 'BREZPLACNO') return 'Brezplačno'; return OZ_PAKET[n.paket].replace(/^(Igralec|Organizator) /, ''); }
export function stanjeNar(n) {
  if (n.paket === null || n.paket === 'BREZPLACNO' || n.status === null) return null;
  const doD = n.obdobjeDo ? 'do ' + datum(n.obdobjeDo) : null;
  if (n.status === 'AKTIVNA') return [n.ciklus === 'LETNO' ? 'letno' : 'mesečno', doD].filter(Boolean).join(' ');
  if (n.status === 'PREKLICANA') return n.veljavna ? ['preklicana', doD].filter(Boolean).join(' ') : 'potekla';
  if (n.status === 'ZAPADLA') return 'zapadla';
  return 'čaka plačilo';
}
export const opisNar = (n) => { const s = stanjeNar(n); return s ? imeNar(n) + ', ' + s : imeNar(n); };
export const cakajoc = (r) => r.status === 'CAKA' && r.emailPotrjen && r.skrbnikPotrjen !== false;

function dnevnik(r, R) {
  const d = [{ ob: r.ustvarjenOb + 'T' + '09:' + String(10 + Math.floor(R() * 40)), t: 'Registracija (' + OZ_VLOGA[r.vloga].toLowerCase() + ')' }];
  if (r.emailPotrjen) d.push({ ob: r.ustvarjenOb + 'T10:' + String(10 + Math.floor(R() * 40)), t: 'E-pošta potrjena s kodo' });
  if (r.status === 'POTRJEN') d.push({ ob: (r.povezanOb || r.ustvarjenOb) + 'T11:' + String(10 + Math.floor(R() * 40)), t: r.vloga === 'ORGANIZATOR' ? 'Administrator potrdil organizatorja' + (r.klub ? ' (' + r.klub + ')' : '') : r.vir === 'SAMODEJNO' ? 'Samodejno povezan z igralcem ' + r.imeIgralca : 'Administrator povezal z igralcem ' + r.imeIgralca });
  if (r.status === 'ZAVRNJEN') d.push({ ob: dan(Math.max(0, dniOd(r.ustvarjenOb) - 1)) + 'T14:20', t: 'Administrator zavrnil zahtevo' });
  if (r.nar && r.nar.paket && r.nar.paket !== 'BREZPLACNO' && r.nar.status) d.push({ ob: r.ustvarjenOb + 'T12:' + String(10 + Math.floor(R() * 40)), t: 'Plačilo: ' + imeNar(r.nar) + (r.nar.ciklus ? ', ' + (r.nar.ciklus === 'LETNO' ? 'letno' : 'mesečno') : '') });
  if (r.geslo) d.push({ ob: r.geslo + 'T16:05', t: 'Administrator nastavil geslo' });
  if (!r.aktiven) d.push({ ob: dan(9) + 'T08:40', t: 'Administrator izklopil račun' });
  return d.sort((a, b) => (a.ob < b.ob ? 1 : -1));
}

export function racuni() {
  const R = rng(2610);
  const out = [];
  const nar0 = { paket: 'BREZPLACNO', status: null, ciklus: null, obdobjeDo: null, veljavna: true };
  const ro = (o) => Object.assign({ id: 0, email: '', vloga: 'IGRALEC', ime: '', priimek: '', klubZelja: null, klub: null, status: 'POTRJEN', aktiven: true, idIgralec: null, imeIgralca: null, rojstvo: null, emailPotrjen: true, skrbnikPotrjen: null, vir: null, povezanOb: null, ustvarjenOb: dan(30), nar: nar0, predlogi: [], zadnjaPrijava: null, prijav30: 0, poraba: null, geslo: null }, o);
  const ruce = [
    ro({ email: 'tilen.zupan@gmail.com', ime: 'Tilen', priimek: 'Zupan', klubZelja: 'NTK Savinja', status: 'CAKA', rojstvo: '2004-04-02', ustvarjenOb: dan(1), predlogi: [{ id: 2101, ime: 'Tilen Zupan', klub: 'NTK Savinja', ze: false }, { id: 2102, ime: 'Tilen Zupanc', klub: 'NTK Celje', ze: true }] }),
    ro({ email: 'lara.kotnik@siol.net', ime: 'Lara', priimek: 'Kotnik', klubZelja: 'NTK Velenje', status: 'CAKA', rojstvo: '2009-09-15', ustvarjenOb: dan(2), nar: { paket: 'PREMIUM', status: 'AKTIVNA', ciklus: 'MESECNO', obdobjeDo: naprej(29), veljavna: true } }),
    ro({ email: 'matej.rozman@gmail.com', vloga: 'ORGANIZATOR', ime: 'Matej', priimek: 'Rozman', klubZelja: 'NTK Savinja', status: 'CAKA', ustvarjenOb: dan(3), nar: { paket: 'ORGANIZATOR_PLUS', status: 'AKTIVNA', ciklus: 'LETNO', obdobjeDo: naprej(362), veljavna: true } }),
    ro({ email: 'gasper.hribar@gmail.com', ime: 'Gašper', priimek: 'Hribar', klubZelja: 'KNTK Žalec', status: 'CAKA', rojstvo: '1998-01-23', ustvarjenOb: dan(4), nar: { paket: 'PREMIUM', status: 'AKTIVNA', ciklus: 'LETNO', obdobjeDo: naprej(361), veljavna: true }, predlogi: [{ id: 2103, ime: 'Gašper Hribar', klub: 'KNTK Žalec', ze: false }, { id: 2104, ime: 'Gašper Hribar', klub: 'NTK Celje', ze: false }] }),
    ro({ email: 'ana.vidmar92@siol.net', ime: 'Ana', priimek: 'Vidmar', status: 'CAKA', emailPotrjen: false, ustvarjenOb: dan(0), rojstvo: '1992-06-11' }),
    ro({ email: 'blaz.bizjak@gmail.com', ime: 'Blaž', priimek: 'Bizjak', status: 'CAKA', emailPotrjen: true, skrbnikPotrjen: false, ustvarjenOb: dan(2), rojstvo: '2013-02-08', klubZelja: 'NTK Maribor' }),
    ro({ email: 'peter.turk@t-2.net', vloga: 'ORGANIZATOR', ime: 'Peter', priimek: 'Turk', status: 'CAKA', emailPotrjen: false, ustvarjenOb: dan(1), klubZelja: 'NTK Ptuj' }),
    ro({ email: 'admin@turnirko-nt.si', vloga: 'ADMIN', ime: 'Nejc', priimek: 'Vrhovnik', ustvarjenOb: dan(410), nar: { paket: null, status: null, ciklus: null, obdobjeDo: null, veljavna: true }, zadnjaPrijava: cas(0, 9, 12), prijav30: 41 }),
    ro({ email: 'jan.petric@gmail.com', ime: 'Jan', priimek: 'Petrič', klub: 'NTK Savinja', idIgralec: 1, imeIgralca: 'Jan Petrič', vir: 'SAMODEJNO', povezanOb: dan(300), ustvarjenOb: dan(300), nar: { paket: 'PREMIUM', status: 'AKTIVNA', ciklus: 'LETNO', obdobjeDo: naprej(18), veljavna: true }, zadnjaPrijava: cas(0, 8, 31), prijav30: 27, geslo: dan(120) }),
    ro({ email: 'nina.golob@gmail.com', ime: 'Nina', priimek: 'Golob', klub: 'NTK Celje', idIgralec: 2, imeIgralca: 'Nina Golob', vir: 'ADMIN', povezanOb: dan(55), ustvarjenOb: dan(58), nar: { paket: 'PREMIUM', status: 'PREKLICANA', ciklus: 'MESECNO', obdobjeDo: naprej(6), veljavna: true }, zadnjaPrijava: cas(3, 19, 4), prijav30: 9 }),
    ro({ email: 'klemen.mlakar@siol.net', vloga: 'ORGANIZATOR', ime: 'Klemen', priimek: 'Mlakar', klubZelja: 'NTK Savinja', klub: 'NTK Savinja', idKlub: 1, ustvarjenOb: dan(240), povezanOb: dan(238), nar: { paket: 'ORGANIZATOR_PRO', status: 'AKTIVNA', ciklus: 'LETNO', obdobjeDo: naprej(125), veljavna: true }, zadnjaPrijava: cas(1, 20, 47), prijav30: 22, poraba: { lige: [5, 5], turnirji: [7, 10] } }),
    ro({ email: 'urska.kos@gmail.com', ime: 'Urška', priimek: 'Kos', klub: 'NTK Velenje', idIgralec: 3, imeIgralca: 'Urška Kos', vir: 'SAMODEJNO', povezanOb: dan(14), ustvarjenOb: dan(14), aktiven: false, zadnjaPrijava: cas(9, 7, 55), prijav30: 3 }),
  ];
  ruce.forEach((r, i) => { r.id = 100 + i; out.push(r); });
  const uporabljeni = new Set(out.map((r) => r.email));
  for (let i = 0; i < 205; i++) {
    const zen = R() < 0.35; const ime = (zen ? IM_Z : IM_M)[Math.floor(R() * (zen ? IM_Z : IM_M).length)];
    const pri = PRI[Math.floor(R() * PRI.length)];
    let em = asc(ime) + (R() < 0.5 ? '.' : '') + asc(pri) + (R() < 0.3 ? String(70 + Math.floor(R() * 36)) : '') + '@' + DOM[Math.floor(R() * DOM.length)];
    while (uporabljeni.has(em)) em = em.replace('@', Math.floor(R() * 90) + '@');
    uporabljeni.add(em);
    const org = R() < 0.1; const ust = 4 + Math.floor(R() * R() * 420);
    const klub = KLUBI[Math.floor(R() * KLUBI.length)];
    const rr = R(); const zavrnjen = !org && rr < 0.03; const izk = !zavrnjen && R() < 0.045;
    const r = ro({ email: em, vloga: org ? 'ORGANIZATOR' : 'IGRALEC', ime, priimek: pri, klubZelja: R() < 0.8 ? klub : null, ustvarjenOb: dan(ust), rojstvo: org ? null : (1955 + Math.floor(R() * 57)) + '-0' + (1 + Math.floor(R() * 9)) + '-1' + Math.floor(R() * 9), status: zavrnjen ? 'ZAVRNJEN' : 'POTRJEN', aktiven: !izk && !zavrnjen });
    if (org) { r.klub = R() < 0.9 ? klub : null; r.idKlub = r.klub ? 1 : null; r.povezanOb = dan(Math.max(0, ust - 1)); }
    else if (!zavrnjen) { r.idIgralec = 3000 + i; r.imeIgralca = ime + ' ' + pri; r.klub = klub; r.vir = R() < 0.65 ? 'SAMODEJNO' : 'ADMIN'; r.povezanOb = dan(Math.max(0, ust - (r.vir === 'ADMIN' ? Math.floor(R() * 4) : 0))); }
    if (org) {
      const p = R(); const paket = p < 0.1 ? null : p < 0.5 ? 'ORGANIZATOR_BASIC' : p < 0.82 ? 'ORGANIZATOR_PLUS' : 'ORGANIZATOR_PRO';
      if (paket) { const st = R() < 0.06 ? 'CAKA_PLACILO' : 'AKTIVNA'; r.nar = { paket, status: st, ciklus: 'LETNO', obdobjeDo: naprej(10 + Math.floor(R() * 350)), veljavna: st === 'AKTIVNA' }; const m = MAX[paket]; r.poraba = { lige: [Math.min(m.lig, Math.floor(R() * (m.lig + 1))), m.lig], turnirji: [Math.floor(R() * (m.turnirjev + 1)), m.turnirjev] }; }
      else r.nar = { paket: null, status: null, ciklus: null, obdobjeDo: null, veljavna: false };
    } else if (!zavrnjen && R() < 0.24) {
      const q = R(); const st = q < 0.78 ? 'AKTIVNA' : q < 0.9 ? 'PREKLICANA' : 'ZAPADLA'; const cik = R() < 0.55 ? 'MESECNO' : 'LETNO';
      const doN = st === 'ZAPADLA' ? -(3 + Math.floor(R() * 40)) : 2 + Math.floor(R() * (cik === 'LETNO' ? 360 : 28));
      r.nar = { paket: 'PREMIUM', status: st, ciklus: cik, obdobjeDo: naprej(doN), veljavna: st !== 'ZAPADLA' };
    }
    if (zavrnjen) { r.zadnjaPrijava = null; r.prijav30 = 0; }
    else { const g = Math.floor(R() * R() * 150); r.zadnjaPrijava = cas(g, 7 + Math.floor(R() * 15), Math.floor(R() * 60)); r.prijav30 = g > 30 ? 0 : Math.max(1, Math.floor(R() * 14)); }
    if (R() < 0.12 && !zavrnjen) r.geslo = dan(Math.floor(R() * 100));
    r.id = 200 + i; out.push(r);
  }
  out.forEach((r) => { r.dnevnik = dnevnik(r, R); });
  return out;
}

export function igralci(vsi) {
  const R = rng(77); const res = []; const ze = new Set();
  vsi.forEach((r) => { if (r.idIgralec) { res.push({ id: r.idIgralec, ime: r.imeIgralca, klub: r.klub, ze: true }); ze.add(r.imeIgralca); } r.predlogi.forEach((p) => { if (!res.find((x) => x.id === p.id)) res.push({ id: p.id, ime: p.ime, klub: p.klub, ze: p.ze }); }); });
  for (let i = 0; i < 40; i++) { const zen = R() < 0.3; const ime = (zen ? IM_Z : IM_M)[Math.floor(R() * (zen ? IM_Z : IM_M).length)]; const pri = PRI[Math.floor(R() * PRI.length)]; if (!ze.has(ime + ' ' + pri)) { ze.add(ime + ' ' + pri); res.push({ id: 5000 + i, ime: ime + ' ' + pri, klub: KLUBI[Math.floor(R() * KLUBI.length)], ze: false }); } }
  return res;
}
