// Primerjava izvedene strani »Dostopi« z referenčnimi posnetki.
// Zagon (iz mape vmesnik/):  node ../design_handoff_dostopi/referenca/primerjava/preveri.mjs
// Okolje:  BASE_URL (privzeto http://localhost:5173)  POT (privzeto /racuni)  SAMO=ime-scenarija (neobvezno)
// Zahteva:  npm i -D playwright pngjs pixelmatch  &&  npx playwright install chromium
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import { PNG } from 'pngjs';
import pixelmatch from 'pixelmatch';

const BASE = process.env.BASE_URL ?? 'http://localhost:5173';
const POT = process.env.POT ?? '/racuni';
const SAMO = process.env.SAMO ?? '';
const DIR = import.meta.dirname;
const FIX = path.resolve(DIR, '..', 'fixture');
const REF = path.resolve(DIR, '..', '..', 'posnetki');
const OUT = path.join(DIR, 'izhod');
const DOVOLJENO = 0.05; // % različnih slikovnih točk, ki še velja za enako (protizaglajevanje pisav)
fs.mkdirSync(OUT, { recursive: true });

const NAMIZJE = { viewport: { width: 1280, height: 900 }, deviceScaleFactor: 1 };
const TELEFON = { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true };

const vrstica = (page, t) => page.locator('[data-dostopi="kartoteka-vrstica"]').filter({ hasText: t }).first();
const nabiralnik = (page, t) => page.locator('[data-dostopi="nabiralnik-vrstica"]').filter({ hasText: t }).first();
const naVrh = (page) => page.locator('[data-dostopi="kartoteka-seznam"]').evaluate((e) => { e.scrollTop = 0; });
const izberiRacun = async (page) => { await vrstica(page, 'Klemen Mlakar').click(); await naVrh(page); await page.mouse.move(0, 0); };

/* obmocja = samo ta pravokotnika (v px referenčne slike) se primerjata; sicer cela slika.
   d02: kontrolnik kluba je v produkciji iskalno polje (IzbirnikKluba), ne žetoni - vse pod njim se zamakne. */
const SCENARIJI = [
  { ime: 'desktop-01-privzeto', n: NAMIZJE, koraki: async () => {} },
  { ime: 'desktop-02-zahteva-organizator', n: NAMIZJE, obmocja: [{ x: 0, y: 0, w: 1280, h: 392 }], koraki: async (p) => { await nabiralnik(p, 'Matej Rozman').click(); await p.mouse.move(0, 0); } },
  { ime: 'desktop-03-racun-organizator', n: NAMIZJE, koraki: izberiRacun },
  { ime: 'desktop-04-geslo-urejanje', n: NAMIZJE, koraki: async (p) => { await izberiRacun(p); await p.getByRole('button', { name: 'Nastavi geslo' }).click(); await p.getByPlaceholder('novo geslo (vsaj 8 znakov)').fill('turnir2026!'); await p.mouse.move(0, 0); } },
  { ime: 'desktop-05-potrditev-izbrisa', n: NAMIZJE, koraki: async (p) => { await izberiRacun(p); await p.getByRole('button', { name: 'Nastavi geslo' }).click(); await p.getByRole('button', { name: 'Prekliči', exact: true }).click(); await p.getByRole('button', { name: 'Izbriši račun' }).click(); await p.mouse.move(0, 0); } },
  { ime: 'desktop-06-filter-organizatorji', n: NAMIZJE, koraki: async (p) => { await p.getByRole('button', { name: /^Organizatorji/ }).click(); await p.locator('[data-dostopi="razvrsti"]').selectOption('prijava'); await p.mouse.move(0, 0); } },
  { ime: 'desktop-07-iskanje-horvat', n: NAMIZJE, koraki: async (p) => { await p.locator('[data-dostopi="iskanje"]').fill('horvat'); await p.mouse.move(0, 0); } },
  { ime: 'mobile-01-privzeto', n: TELEFON, mobile: true, koraki: async () => {} },
  { ime: 'mobile-02-zahteva-list', n: TELEFON, mobile: true, koraki: async (p) => { await nabiralnik(p, 'Tilen Zupan').click(); } },
  { ime: 'mobile-03-racun-list', n: TELEFON, mobile: true, koraki: async (p) => { await vrstica(p, 'Klemen Mlakar').click(); } },
  { ime: 'mobile-04-filtri-kartoteka', n: TELEFON, mobile: true, koraki: async (p) => { await p.getByRole('button', { name: /^Filtri/ }).click(); await p.evaluate(() => window.scrollTo(0, 540)); } },
];

const KARTE = { '/racuni': 'racuni.json', '/igralci': 'igralci.json', '/klubi': 'klubi.json', '/auth/me': 'auth-me.json' };
const BLOKIRAJ_ANIMACIJE = '*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important;scrollbar-width:none!important}*::-webkit-scrollbar{display:none!important}';

async function posnemi(browser, s) {
  const ctx = await browser.newContext({ ...s.n, reducedMotion: 'reduce', locale: 'sl-SI', timezoneId: 'Europe/Ljubljana' });
  await ctx.addInitScript(() => sessionStorage.setItem('turnirko-poverilnice', btoa('admin:admin')));
  await ctx.route('**/api/v1/**', (route) => {
    const p = new URL(route.request().url()).pathname.replace('/api/v1', '');
    if (route.request().method() !== 'GET') return route.fulfill({ status: 204 });
    const f = KARTE[p];
    return route.fulfill({ contentType: 'application/json', body: f ? fs.readFileSync(path.join(FIX, f), 'utf8') : '[]' });
  });
  const page = await ctx.newPage();
  await page.clock.setFixedTime(new Date('2026-10-11T12:00:00'));
  await page.goto(BASE + POT);
  await page.locator('[data-dostopi="kartoteka-seznam"], [data-dostopi="kartoteka-vrstica"]').first().waitFor();
  await page.addStyleTag({ content: BLOKIRAJ_ANIMACIJE });
  await page.evaluate(() => document.fonts.ready);
  await s.koraki(page);
  await page.waitForTimeout(250);
  const datoteka = path.join(OUT, s.ime + '.png');
  await page.screenshot({ path: datoteka, fullPage: !s.mobile });
  await ctx.close();
  return datoteka;
}

function preberi(f) { return PNG.sync.read(fs.readFileSync(f)); }
function izrezi(img, x, y, w, h) { const o = new PNG({ width: w, height: h }); PNG.bitblt(img, o, x, y, w, h, 0, 0); return o; }

function primerjaj(s, izhod) {
  let ref = preberi(path.join(REF, s.ime + '.png'));
  const out = preberi(izhod);
  if (s.mobile) ref = izrezi(ref, 2, 2, ref.width - 4, ref.height - 4); // referenčni okvir telefona ima 1 px (2 px pri 2x) črn rob
  const poročilo = { ime: s.ime, ref: `${ref.width}x${ref.height}`, izhod: `${out.width}x${out.height}` };
  const deli = s.obmocja ?? [{ x: 0, y: 0, w: Math.min(ref.width, out.width), h: Math.min(ref.height, out.height) }];
  let razlika = 0, skupaj = 0;
  deli.forEach((d, i) => {
    const a = izrezi(ref, d.x, d.y, d.w, d.h), b = izrezi(out, d.x, d.y, d.w, d.h), diff = new PNG({ width: d.w, height: d.h });
    razlika += pixelmatch(a.data, b.data, diff.data, d.w, d.h, { threshold: 0.1 });
    skupaj += d.w * d.h;
    fs.writeFileSync(path.join(OUT, `diff-${s.ime}${deli.length > 1 ? '-' + i : ''}.png`), PNG.sync.write(diff));
  });
  poročilo.odstotek = +((razlika / skupaj) * 100).toFixed(3);
  poročilo.velikostEnaka = ref.width === out.width && ref.height === out.height;
  poročilo.ok = poročilo.odstotek <= DOVOLJENO && (s.obmocja ? true : poročilo.velikostEnaka);
  return poročilo;
}

const browser = await chromium.launch({ args: ['--hide-scrollbars', '--font-render-hinting=none'] });
const rezultati = [];
for (const s of SCENARIJI.filter((x) => !SAMO || x.ime.includes(SAMO))) {
  try { rezultati.push(primerjaj(s, await posnemi(browser, s))); }
  catch (e) { rezultati.push({ ime: s.ime, ok: false, napaka: String(e.message).split('\n')[0] }); }
}
await browser.close();
console.table(rezultati);
const slabi = rezultati.filter((r) => !r.ok);
console.log(slabi.length ? `\nNE UJEMA SE: ${slabi.map((r) => r.ime).join(', ')}\nOdpri izhod/diff-*.png (rdeče = razlika), popravi, ponovi.` : '\nVSI POSNETKI SE UJEMAJO.');
process.exit(slabi.length ? 1 : 0);
