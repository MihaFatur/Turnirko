# Handoff: Dostopi — prenova administratorske strani (različica 1b »Nabiralnik + kartoteka«)

## 0. Najprej preberi

Naloga: stran `/racuni` (`vmesnik/src/strani/RacuniStran.tsx`, v meniju »Dostopi«) se **v celoti nadomesti** z novo zasnovo 1b. Poslovna logika (poizvedbe, mutacije, pravila potrjevanja) ostane; spremeni se postavitev, videz in nekaj novih podatkov.

**Obvezen postopek (ne preskoči):**

1. Preberi ta dokument do konca, nato `vmesnik/turnirko-profil-redesign/project/DESIGN.md` in `RacuniStran.tsx`.
2. Postavi preverjanje (razdelek 3) **preden** začneš pisati vmesnik, da vidiš izhodišče.
3. Implementiraj.
4. Zaženi `preveri.mjs`, odpri **vsak** par `posnetki/<ime>.png` (referenca) · `izhod/<ime>.png` (tvoje) · `izhod/diff-<ime>.png` (razlika) in popravljaj, **dokler se vsi scenariji ne ujemajo** (razdelek 3.4). Ne nehaj pri »približno«. Referenčnih posnetkov nikoli ne spreminjaj in ne popuščaj mej, da bi scenarij »prešel«.
5. Na koncu `npm run build` (tsc) mora biti čist.

## 1. Pregled

Danes je stran en dolg seznam: kartice čakajočih zahtev, nato dve tabeli z do štirimi gumbi v vsaki vrstici. Pri 200+ računih ni iskanja, filtrov ali razvrščanja, statusi in naročnine so težko berljivi, čakajoče zahteve se ne ločijo dovolj.

Zasnova 1b ima dva dela z dvema opraviloma:

- **Nabiralnik** (zgoraj): število čakajočih zahtev je naslov strani (velika rjasta številka). Zahteve se obdelajo ena za drugo; izbrana zahteva je odprta kot »karton« na desni.
- **Kartoteka** (spodaj): vsi računi po abecedi (priimek), abecedno kazalo, iskanje, filtri, razvrščanje. Ob seznamu je stalen **karton** izbranega računa z vsemi podatki in dejanji. Ko nič ni izbrano, karton kaže **»Stanje dostopov«** (porazdelitve s palicami).
- **Telefon** (≤ 640 px): isti dve sekciji, karton je spodnji list čez stran, abecedno kazalo je navpičen trak ob desnem robu.

Vsa dejanja so v kartonu (stranski panel); nič ni v vrstici seznama.

## 2. O oblikovnih datotekah

Datoteke v `referenca/` so **oblikovne reference, narejene v HTML** (Design Components): prototipi, ki kažejo videz in obnašanje. **Niso produkcijska koda** in jih ne kopiraj. Nalogo opraviš tako, da zasnovo **poustvariš v obstoječem vmesniku** (React 19 + TypeScript + Vite, navaden CSS v `slog.css` z BEM razredi v slovenščini, TanStack Query), z obstoječimi vzorci in spremenljivkami.

**Natančnost: visoka (hi-fi).** Barve, pisave, velikosti, razmiki in stanja so končni. Poustvari jih piksel na piksel. Vir točnih vrednosti sta `referenca/DostopiKarton.dc.html` (karton) in `referenca/Dostopi - prenova.dc.html` (blok `id="1b"`, razdelki »b-namizje« in »b-telefon«). Če se ta README in prototip razlikujeta, velja prototip + posnetek. (Odprtje `.dc.html` datotek: delujejo samo prek HTTP strežnika, npr. `npx serve referenca`, ne prek `file://`. Del prototipa 1a v isti datoteki ignoriraj.)

Poleg `referenca/Dostopi - trenutno.dc.html` je zvesta poustvaritev današnje strani (samo za primerjavo »prej/potem«).

## 3. Preverjanje s posnetki (zanka do popolnega ujemanja)

### 3.1 Kaj je v paketu
- `posnetki/` — 11 referenčnih posnetkov (namizje 1280 px širine, celotna višina strani; telefon 390×844 @2x, vključno z 1 px črnim robom okvirja, ki ga skripta odreže):
  `desktop-01-privzeto`, `desktop-02-zahteva-organizator`, `desktop-03-racun-organizator`, `desktop-04-geslo-urejanje`, `desktop-05-potrditev-izbrisa`, `desktop-06-filter-organizatorji`, `desktop-07-iskanje-horvat`, `mobile-01-privzeto`, `mobile-02-zahteva-list`, `mobile-03-racun-list`, `mobile-04-filtri-kartoteka`.
- `referenca/fixture/*.json` — **točni testni podatki** (217 računov v obliki `RacunIgralcaDto` + nova polja, 210 igralcev, 10 klubov, `auth-me`). Posnetki so narejeni s temi podatki; brez njih se ne morejo ujemati.
- `referenca/dostopi-podatki.js` — generator teh podatkov (samo za razumevanje; fiksen seme).
- `referenca/primerjava/preveri.mjs` — skripta, ki zajame tvojo stran v istih stanjih in jo primerja s posnetki.

### 3.2 Kar mora tvoja stran izpostaviti (atributi za test)
Dodaj te `data-dostopi` atribute (neškodljivi, ostanejo v kodi):

| Atribut | Element |
|---|---|
| `nabiralnik` | koren zgornje sekcije |
| `nabiralnik-vrstica` | vsaka vrstica čakajoče zahteve (gumb) |
| `kartoteka-seznam` | drsni vsebnik seznama računov na namizju; na telefonu koren sekcije kartoteke |
| `kartoteka-vrstica` | vsaka vrstica računa (gumb) |
| `karton` | koren kartona (posamezna instanca) |
| `iskanje` | iskalno polje kartoteke (`input`) |
| `razvrsti` | izbirnik razvrščanja (nativni `select`) |

Besedila gumbov in `placeholder`-jev morajo biti **natanko** taka kot v razdelku 6 (skripta jih išče po besedilu).

### 3.3 Zagon
```
cd vmesnik
npm i -D playwright pngjs pixelmatch
npx playwright install chromium
npm run dev                       # v drugem oknu
node ../design_handoff_dostopi/referenca/primerjava/preveri.mjs
# izbor: SAMO=desktop-03 node ...   |   drug naslov: BASE_URL=http://localhost:5173 POT=/racuni
```
(Pot do skripte prilagodi, kamor paket razpakiraš.) Skripta sama: nastavi `sessionStorage['turnirko-poverilnice']` (admin), prestreže `GET /api/v1/{racuni,igralci,klubi,auth/me}` s fixture, zamrzne čas na **11. 10. 2026 12:00** (relativni datumi »pred 3 d« so odvisni od tega), skrije drsnike, izklopi animacije, zajame stran v 11 stanjih (kot na posnetkih) in izpiše tabelo `% različnih točk`. Izhod: `izhod/<ime>.png` in `izhod/diff-<ime>.png`. Vsa nespremenljiva (POST/PUT/DELETE) klica vrne 204 — fixture se po dejanju ne osveži, zato testni scenariji dejanj ne potrjujejo.

### 3.4 Merilo »ujema se«
- Vsak scenarij: `≤ 0,05 %` različnih točk (zgolj protizaglajevanje pisav) **in** enaka velikost slike (višina celotne strani na namizju mora biti enaka referenčni).
- Pred vsakim popravkom **sam poglej** referenco, svoj izhod in `diff-*.png` (razlike so rdeče). Pogoste vzroke išči v tem vrstnem redu: velikost/teža/razmik črk pisave → višine vrstic (padding) → barva → manjkajoča črta (1 px) → poravnava → zamik, ki se prenese navzdol (popravi prvi vzrok zgoraj, ostali izginejo).
- Edina dovoljena odstopanja so v razdelku 9 (»Odločitve in znane razlike«). Vse drugo mora biti identično.
- Namizni scenarij `desktop-02` primerja samo območje nad kontrolnikom kluba (glej 9.1); ostalo preveri z očmi.
- Pisave: aplikacija jih nalaga lokalno (`@fontsource`), prototip iz Googla; razlike so zanemarljive. Če je besedilo vseeno za piksel drugje, preveri `font-optical-sizing` (Bricolage Grotesque ima os `opsz`, brskalnik jo nastavi po velikosti pisave sam — ne vsiljuj `font-variation-settings`).

## 4. Omejitve sistema (DESIGN.md) — vse so spoštovane

Radij povsod `0`; brez senc (edina izjema: obstoječi podčrtaj navigacije); brez gradientov; samo tri pisne družine (`--pisava-display`, `--pisava-telo`, `--pisava-mono`); samo barve iz `:root`; brez emojijev; ikon ni (razen obstoječe spodnje vrstice na telefonu); vse dejanje je vsaj 44 px visoko; animacij ni (samo `transition` barve/obrobe ≤ 120 ms, kot že obstaja). Zasnova ne uvaja nove barve. Rjasta (`--barva-negativna`) pomeni »čaka na tvoje dejanje« (kot že v predalu »Več«, `.predal__kontekst--nujno`) in »nevarno«.

Vzorec je nov, zato so novi razredi upravičeni: **prefiks `.dostopi-…`** (BEM, slovensko, brez šumnikov), nov razdelek v `slog.css` »Dostopi (nabiralnik in kartoteka)«. Ne uporabljaj obstoječih `.racun*` razredov (po prenovi so odveč; odstrani jih, če jih nič drugega ne uporablja). Na koncu v `DESIGN.md` doda odstavek v razdelek 4 »Vzorci« (»Nabiralnik + kartoteka: …«) in v razdelek 4 omeni nova pravila (veliko število 112 px je v mejah `--tip-rezultat`).

### Barve → spremenljivke
| V prototipu | Spremenljivka |
|---|---|
| `#FBF9F5` | `--barva-papir` |
| `#14110F` | `--barva-crnilo` |
| `#332E29` | `--barva-crnilo-2` |
| `#5B534D` | `--barva-crnilo-3` |
| `#6E655E` | `--barva-crnilo-4` |
| `#DED7CE` | `--barva-crta` |
| `#EDE7DF` | `--barva-polnilo` |
| `#F3EFE9` | `--barva-vrstica-hover` |
| `#FFFFFF` | `--barva-bela` |
| `#0088CE` | `--barva-glavna` |
| `#0071AB` | `--barva-glavna-polna` / `--barva-glavna-tekst` |
| `#EAF3F9` | `--barva-glavna-mehko` |
| `#7BB900` | `--barva-poudarek` |
| `#4A7500` | `--barva-poudarek-tekst` |
| `#EAF4D6` | `--barva-poudarek-mehko` |
| `#B23A1E` | `--barva-negativna` |
| `#8C2B14` | `--barva-negativna-tekst` |
| `#F8E5DF` | `--barva-negativna-mehko` |
| `#B9B0A6` (oslabljena črka kazala, rob značke »Brez kode«) | `--barva-na-crnilu-2` |

Pisave: display = Bricolage Grotesque (800), telo = Karla (300/400/600/700), mono = IBM Plex Mono (400/500/600). Ritem: 4 / 8 / 12 / 16 / 24 / 40 / 48 / 56 px.

## 5. Zasloni

Skupna okolica (obstoječa, ne spreminjaj): `Postavitev` (masthead z »Dostopi« aktivnim; na telefonu `glava-telefon` + `spodnja-vrstica` s petimi postavkami, nobena aktivna), `.vsebina` (padding 48/40/64, gap 56) in `section` (gap 56). Besedila v mastheadu: Domov · Turnirji · Lige · Lestvica · Igralci · **Dostopi** · Šifranti · Uvoz NTZS · Rating; desno `admin`.

### 5.1 Namizje (1280 px) — `posnetki/desktop-01…07`

**A. Nabiralnik** — mreža `400px minmax(0,1fr)`, zgoraj `border-top: 3px solid crnilo`.

*Levi stolpec* (`padding: 24px 40px 0 0`, stolpec, gap 24):
- Vrstica `flex; align-items:flex-end; gap:20`: **številka** (display 800, 112 px, line-height 0.8, letter-spacing −0.05em, tabularne številke, barva `negativna`; pri 0 barva `crnilo`) + **oznaka** (mono 500 12 px/1.4, črkovni razmik 0.1em, verzalke, `crnilo-3`, `padding-bottom:4px`; besedilo »Čaka na« / »potrditev« v dveh vrsticah).
- Pri 0 zahtevah: »Ni novih zahtev.« (display 800 24 px/1.1, −0.02em).
- Seznam čakajočih: vsebnik `border-top:1px solid crnilo`. **Vrstica** (gumb, ni `<a>`): mreža `28px 1fr`, gap 8, `align-items:center`, `padding:12px`, `border-left:4px solid negativna`, `border-bottom:1px solid crta`; izbrana: ozadje `negativna-mehko`; hover `vrstica-hover`. Zaporedna številka `01…` mono 600 12 px, `negativna`. Ime Karla 600 18 px (rez z `…`). Podvrstica mono 500 11 px/1.4, 0.06em, verzalke, `crnilo-3`: `{Vloga} · reg. {rel}` (npr. »Igralec · reg. včeraj«, »Organizator · reg. pred 3 d«).

*Desni stolpec* (`padding:24px 0 0 40px; border-left:1px solid crta; min-height:420px`):
- Vrstica pagerja (`flex; space-between; center; margin-bottom:16`): levo mono 500 12 px, 0.12em, verzalke, `crnilo-3`: »Zahteva 1 od 4«. Desno dva kvadrata 44×44, gap 4: `←` `→` (mono 500 16 px, `border:1px solid crta`, hover obroba `crnilo`).
- **Karton** izbrane zahteve (5.3).
- Pri 0 zahtevah namesto kartona: »Nove registracije se pojavijo tukaj, ko lastnik potrdi e-pošto.« (17 px/300, `crnilo-3`, `max-width:36ch`).

**B. Kartoteka** (razmik od nabiralnika 56 px):
- Naslovna vrstica: `border-top:3px solid crnilo; padding-top:16`; `h2` »Kartoteka« (display 800 40 px/1, −0.03em) levo, meta desno (mono 500 12 px, 0.1em, verzalke, `crnilo-3`): `{prikazano} od {vseh}` (npr. »217 od 217«).
- Krmila (`margin-top:24`, stolpec, gap 8):
  - Vrstica 1 (`flex; gap:8; wrap; center`): iskalno polje (širina 360, višina 48, Karla 17 px, `padding:10px 14px`, `border:1px solid crnilo`, bela podlaga, placeholder »Išči po imenu, e-pošti ali klubu«, `data-dostopi="iskanje"`); `select` paketi (višina 48, `padding:0 10px`, `border:1px solid crnilo`, bela, Karla 400 15 px; možnosti: Vsi paketi · Brezplačno · Premium · Basic · Plus · Pro · Brez paketa); `select` razvrščanje (možnosti: Priimek A–Ž · Zadnja prijava · Naročnina · Stanje; `data-dostopi="razvrsti"`); stikalo »Samodejno povezani« (višina 48, `padding:0 12px`, obroba `crta` (izklopljeno) / `crnilo` (vklopljeno), kvadratek 16×16 z obrobo `crnilo-3`, poln `poudarek` ko je vklopljeno, oznaka mono 500 12 px/1.2, 0.1em, verzalke, `crnilo`).
  - Vrstica 2 (`flex; gap:4; wrap`): **žetoni** vloge (Vsi · Igralci · Organizatorji · Admin) + presledek 16 px + žetoni stanja (Vsi · Čaka · Potrjeni · Izklopljeni · Zavrnjeni · Brez kode). Žeton: višina 44, `padding:0 12px`, `border:1px solid`, mono 500 12 px/1.2, 0.1em, verzalke; neaktiven: obroba `crta`, besedilo `crnilo-3`, prozoren; aktiven: podlaga in obroba `crnilo`, besedilo `papir`. Za imenom **število** (teža 400), `Ime {n}`; števila so **skupna** (ne glede na filtre).
  - Vrstica 3 (samo pri razvrščanju »Priimek A–Ž«) **abecedno kazalo**: `flex`, `border-top` in `border-bottom:1px solid crta`, `margin-top:8`; 25 gumbov `flex:1`, višina 44, display 800 20 px/1: A B C Č D E F G H I J K L M N O P R S Š T U V Z Ž; črke z računi `crnilo`, brez računov `#B9B0A6` (kazalec privzet, brez klika); hover `vrstica-hover`. Klik: seznam se pomakne tako, da je glava skupine zgoraj.
- Mreža (`margin-top:24; grid-template-columns: minmax(0,1fr) 440px; gap:48; align-items:start`):
  - **Seznam**: `height:680px; overflow-y:auto; border-top:1px solid crnilo` (`data-dostopi="kartoteka-seznam"`). **Glava skupine** (samo ob A–Ž): `position:sticky; top:0; z-index:2`, ozadje `papir`, `flex; space-between; baseline`, `padding:16px 12px 4px 16px`, `border-bottom:1px solid crnilo`; črka display 800 36 px/1, −0.03em; število mono 500 11 px, 0.1em, `crnilo-3`. **Vrstica**: gumb, mreža `1fr auto`, gap 16, `padding:12px`, `border-left:4px solid {vloga}`, `border-bottom:1px solid crta`; izbrana ozadje `glavna-mehko`, hover `vrstica-hover`. *Levo:* ime Karla 600 17 px (izbrana: barva `glavna-tekst`; rez z `…`) + za imenom oznaka vloge (samo organizator/admin; mono 600 10 px/1.2, 0.1em, verzalke, barva vloge); pod njim e-pošta Karla 300 13 px, `crnilo-3`. *Desno* (stolpec, desno poravnano, gap 4): značka stanja (padding 4/8, mono 600 10 px/1.2, 0.1em, verzalke, `border:1px solid`) in vrstica mono 500 11 px/1.3, 0.06em, verzalke, `crnilo-3`, `white-space:nowrap`: `{PAKET} · {PRIJAVA}`.
  - **Desna ploskev** (`border-top:1px solid crnilo; padding-top:16`): izbran račun → vrstica (levo mono 500 12 px, 0.12em, verzalke, `crnilo-3`: »Karton«; desno gumb »Zapri ×«, višina 44, mono 500 12 px, `glavna-tekst`; `margin-bottom:16`) + **karton**. Nič izbrano → **Stanje dostopov** (5.4).

**Barva roba vrstice po vlogi** (isto v seznamu in na telefonu): igralec `crta`, organizator `glavna` (`#0088CE`), admin `negativna`. Barva oznake vloge: igralec `crnilo-3`, organizator `glavna-tekst`, admin `negativna`.

**Značke stanja** (izpeljava po vrstnem redu): 
| Pogoj | Besedilo | Podlaga | Besedilo | Obroba |
|---|---|---|---|---|
| `status=CAKA` in e-pošta potrjena in skrbnik ≠ false | Čaka | `negativna` | `#FFFFFF` | `negativna` |
| `status=CAKA`, ostalo | Brez kode (e-pošta ni potrjena) / Čaka skrbnika (potrjena) | prozorna | `crnilo-3` | `#B9B0A6` |
| `ZAVRNJEN` | Zavrnjen | `negativna-mehko` | `negativna-tekst` | `negativna-mehko` |
| `!aktiven` | Izklopljen | `polnilo` | `crnilo-3` | `polnilo` |
| sicer | Potrjen | `poudarek-mehko` | `poudarek-tekst` | `poudarek-mehko` |

### 5.2 Telefon (390 px) — `posnetki/mobile-01…04`

Stran drsi po oknu; `glava-telefon` je lepljiva, `spodnja-vrstica` fiksna (obstoječa). Vsebina: `padding: 20px 36px 96px 20px` (desno 36 px zaradi kazala), `gap:28`.

- **Nabiralnik**: `border-top:3px solid crnilo; padding-top:16`; stolpec gap 16. Številka display 800 **88 px**/0.8, −0.05em, `negativna`; poleg oznaka »Čaka na potrditev« (mono 500 12 px, 0.1em, verzalke, `crnilo-3`, `padding-bottom:2px`, `gap:14`, `align-items:flex-end`). Vrstice (`border-top:1px solid crnilo`): mreža `24px 1fr auto`, gap 8, `padding:10px 0 10px 12px`, `border-left:4px solid negativna`, `border-bottom:1px solid crta`, `min-height:56`; številka mono 600 12 px `negativna`; ime Karla 600 17 px; podvrstica mono 500 11 px/1.4, 0.06em: `{Vloga} · {rel}` (brez »reg.«); desno »Odpri →« (mono 600 11 px/1.2, 0.1em, `glavna-tekst`). Klik odpre **list** (rjav zgornji rob).
- **Kartoteka**: `border-top:3px solid crnilo; padding-top:16`; `h2` 32 px; meta desno. Vrstica: iskalno polje (višina 48, Karla 16 px, `padding:10px 12px`) + gumb »Filtri« (višina 48, `padding:0 12px`, `border:1px solid crnilo`, mono 500 12 px; ob aktivnih filtrih črna podlaga, besedilo `papir`, »Filtri · 2«). Razprta plošča (`margin-top:12; gap:12; padding:12px 0; border-top/bottom:1px solid crta`): oznaki »Vloga« / »Stanje« (mono 500 11 px, 0.1em) nad žetoni, `select` paket + `select` razvrščanje (po 50 %, gap 8), stikalo »Samodejno povezani« + gumb »Počisti« (`border:1px solid crta`, Karla 600 14 px, `crnilo-3`).
- **Seznam** (`margin-top:8`): glava skupine `position:sticky; top:59px` (pod glavo telefona), `padding:12px 0 4px`, `border-bottom:1px solid crnilo`, črka display 800 **32 px**. **Vrstica**: `padding:12px 0 12px 12px`, `border-left:4px` (barva vloge), `border-bottom:1px solid crta`, `min-height:44`; izbrana ozadje `glavna-mehko`. Vrstica 1 `flex; space-between; center; gap:8`: ime Karla 600 17 px + značka stanja (padding 3/6, mono 600 10 px/1.2); vrstica 2 e-pošta Karla 300 14 px `crnilo-3`; vrstica 3 (`margin-top:4`) mono 500 11 px/1.4, 0.06em, verzalke: levo `{Paket}{ · stanje naročnine}` (rez z `…`, rjasto, če naročnina poteče v ≤ 30 d ali ne velja), desno `{prijava}`.
- **Abecedno kazalo**: `position:fixed; right:0; top:132px; bottom:76px; width:24px; z-index:11`, stolpec `justify-content:space-between`, ozadje `papir`, `border-left:1px solid crta`; črke mono 600 11 px/1 (enake barve kot na namizju). Klik: `window.scrollTo` tako, da je glava skupine pod lepljivo glavo (odmik 59 px).
- **List** (karton): prekrivalo čez celo stran (`z-index` nad spodnjo vrstico), zastor `--barva-zastor` (`rgb(20 17 15 / .28)`); na vrhu ostane 56 px zastora (glava telefona je vidna); klik na zastor zapre. List: ozadje `papir`, `border-top:3px solid crnilo` (list zahteve iz nabiralnika: `negativna`), `max-height:90%`, `overflow-y:auto`, `padding:4px 20px 28px`. Prva vrstica lista: desno »Zapri ×« (višina 44, mono 500 12 px, `glavna-tekst`); pri listu zahteve levo še »Zahteva 1 od 4« (mono 500 12 px, 0.12em, `negativna`). Sledi karton. Brez drsne animacije.

### 5.3 Karton (skupna komponenta za oba zaslona) — `referenca/DostopiKarton.dc.html`

Stolpec, `gap:24`. Bloki po vrsti (neprisotni se izpustijo):

1. **Glava**: vrstica `flex; gap:8; center; wrap`: vloga (mono 600 11 px/1.4, 0.1em, verzalke, barva vloge) + značka stanja (`padding:5px 8px`, mono 600 11 px/1.2, 0.1em, verzalke). Ime display 800 **32 px**/1.05, −0.03em, `margin-top:12`, `text-wrap:balance`. E-pošta Karla 300 15 px, `crnilo-3`, `margin-top:4`, `overflow-wrap:anywhere`.
2. **Obvestilo po dejanju** (`padding:12px 14px; background:poudarek-mehko; border-left:4px solid poudarek`; Karla 600 14 px): »Dostop potrjen: {Ime Priimek}«, »Zahteva zavrnjena: {Ime Priimek}«, »Račun je spet med čakajočimi.«
3. **Zahteva** (samo čakajoča; `border-left:4px solid negativna; padding-left:16`; stolpec gap 12):
   - oznaka mono 500 12 px, 0.1em, verzalke, `negativna`: igralec »Poveži z igralcem«, organizator »Klub organizatorja«;
   - namig Karla 14 px, `crnilo-2`: organizator »Brez kluba upravlja samo tekmovanja, ki jih ustvari sam.«; igralec brez predlogov »Ni ujemanja po priimku. Poišči igralca z imenom.«; igralec s predlogi »Samodejna povezava ni nastala. Izberi pravega.«;
   - **igralec — predlogi** kot izbirne vrstice (`min-height:52; padding:8px 12px; border-left:4px solid {izbran: glavna, sicer prozorno}; border-bottom:1px solid crta`; izbrana ozadje `glavna-mehko`, hover enako): kvadratek 16×16 (obroba `crnilo-3`; izbran poln in obroba `glavna`), ime Karla 15 px (600; onemogočen 400, `crnilo-3`), podvrstica mono 500 11 px/1.3, 0.06em, verzalke, `crnilo-3`: `{Klub} · predlog po priimku` ali `{Klub} · že ima dostop` (onemogočena, ne da se izbrati). Pod seznamom iskalno polje (`margin-top:8`, višina 44, Karla 16 px, `padding:10px 12px`, placeholder »Poišči med vsemi igralci«); do 5 zadetkov v isti obliki; izbira zadetka ga postavi na vrh seznama kot izbranega in izprazni polje. Predizbran je prvi predlog brez računa;
   - **organizator — klub**: žetoni (»Brez kluba« + klubi; izbran črn, kot filter), predizbran klub, ki ga je organizator navedel (glej 9.1);
   - gumbi (`flex; gap:8; wrap`): glavni `flex:1 1 160px`, višina 44, `padding:12px 16px`, Karla 700 15 px; omogočen podlaga `glavna-polna`, obroba `glavna`, besedilo bela; **onemogočen** (igralec brez izbire): podlaga/obroba `polnilo`, besedilo `crnilo-4`, `cursor:not-allowed`; oznaka »Potrdi dostop« / »Potrdi organizatorja« (organizator je vedno omogočen). »Zavrni«: `padding:12px 20px`, `border:1px solid crta`, besedilo `negativna`, Karla 600 15 px, hover obroba `negativna`.
4. **Račun brez potrjene e-pošte** (`border-left:4px solid crta; padding-left:16`): Karla 14 px `crnilo-2`: »Čaka kodo skrbnika. Izbriše se samodejno po 30 dneh.« / »Lastnik še ni vpisal kode. Izbriše se samodejno po 48 urah.«; gumb »Izbriši registracijo« (kot »Zavrni«).
5. **Dejanja računa** (status ≠ CAKA): mreža 2 stolpca, gap 8; gumbi višina 44, `padding:12px 16px`, Karla 600 15 px, `border:1px solid crnilo` (hover besedilo `glavna-tekst`, obroba `glavna`): »Izklopi« / »Vklopi«; »Nastavi geslo« (ko je urejevalnik odprt: črna podlaga, besedilo `papir`, oznaka »Prekliči«); »Razveži od igralca« (samo povezan igralec; obroba `crta`, besedilo `crnilo-3`, hover `crnilo`); »Izbriši račun« (obroba `crta`, besedilo `negativna`).
   - *Urejevalnik gesla* (`padding:12px; background:polnilo; gap:8`): polje (višina 44, placeholder »novo geslo (vsaj 8 znakov)«), vrstica: »Nastavi« (`flex:1 1 120px`, Karla 700 14 px; onemogočen pod 8 znaki kot glavni gumb) + »Generiraj naključno« (`border:1px solid crnilo`, Karla 600 14 px).
   - *Novo geslo* (`padding:8px 12px; border-left:4px solid poudarek; background:poudarek-mehko`; mono 400 14 px/1.5): »Geslo: **{geslo}**« + vrstica Karla 300 13 px »Izroči ga lastniku, kasneje ga ni več mogoče prebrati.«
6. **Potrditev** (`padding:12px 14px; background:negativna-mehko; border-left:4px solid negativna; gap:12`): besedilo Karla 600 14 px, `negativna-tekst`; gumba višina 44, `padding:10px 20px`, Karla 14 px: potrdi (podlaga/obroba `negativna`, besedilo bela, 700) in »Prekliči« (`border:1px solid crnilo`, 600). Besedila: zavrni »Zavrnem zahtevo za {e-pošta}? Račun ostane (da se ista e-pošta ne registrira znova), a brez dostopa.« (gumb »Zavrni«); razveži »Razvežem račun {e-pošta} od igralca {imeIgralca}? Račun se vrne med čakajoče.« (»Razveži«); izbris računa »Izbrišem račun {e-pošta}? E-pošta se sprosti za novo registracijo. Igralec in njegove tekme ostanejo.« (»Izbriši«); izbris registracije »Izbrišem registracijo {e-pošta}? Naslov se sprosti takoj.« (»Izbriši«).
7. **Podatkovne skupine**: naslov (`flex; gap:8; center`, mono 500 12 px, 0.12em, verzalke, `crnilo-3`, `padding-bottom:8; border-bottom:1px solid crnilo`) + vrstice (`flex; space-between; baseline; gap:16; padding:9px 0; border-bottom:1px solid crta`): oznaka mono 500 11 px/1.4, 0.08em, verzalke, `crnilo-3`; vrednost Karla 600 15 px, desno, `overflow-wrap:anywhere` (opozorilne vrednosti `negativna`). Skupine in vrstice:
   - **Račun**: Vloga · Registriran (`{d. m. yyyy} · {rel}`) · E-pošta (potrjena / ni potrjena — rjasto) · Skrbnik (samo če `skrbnikPotrjen ≠ null`: »soglasje dano« / »čaka kodo« — rjasto) · Rojen (samo igralec z datumom) · Navedeni klub (samo če je naveden in klub še ni potrjen).
   - **Naročnina** (ne za admina): Paket (`imeNarocnine`; »Brez paketa« rjasto) · samo pri plačljivem paketu še: Obračun (letno / mesečno) · Stanje (aktivna · preklicana, velja do konca · potekla · zapadla · čaka plačilo; rjasto pri zapadla/potekla) · Velja do (`{datum} · čez N d` ali `· pred N d`; rjasto pri ≤ 30 d ali preteklo).
   - **Povezava** (igralec, status ≠ CAKA): Igralec · Klub · Povezal (samodejno / administrator) · Povezan (datum). **Klub** (organizator, status ≠ CAKA): Klub (ali »brez kluba«) · Potrjen (datum).
   - **Aktivnost** + oznaka NOVO (samo `POTRJEN`): Zadnja prijava (`{d. m. yyyy HH:MM} · {rel}` ali »nikoli«) · Prijav v 30 dneh.
8. **Poraba paketa** + NOVO (samo če `poraba`): dve vrstici (»Tekoče lige«, »Turnirji v sezoni«): zgoraj mono 500 11 px, 0.08em, verzalke, `crnilo-3` levo oznaka, desno mono 600 `{x} / {y}` (+ » · polno« ko x ≥ y), `crnilo`; pod njo palica višine 6 px (podlaga `polnilo`, polnilo `glavna`, širina `x/y`), vrstica `padding:12px 0; border-bottom:1px solid crta`.
9. **Dnevnik** + NOVO: do 8 dogodkov, najnovejši prvi; vrstica mreža `104px 1fr`, gap 12, `padding:9px 0`, `border-bottom:1px solid crta`, baseline; datum mono 400 12 px, tabularno, `crnilo-3` (`d. m. yyyy`); besedilo Karla 14 px `crnilo-2`.

**Oznaka NOVO**: `mono 600 10px/1.2`, črkovni razmik 0.1em, barva `glavna-tekst`, `border:1px solid glavna`, `padding:2px 4px`. Pomeni »podatek, ki ga API danes ne vrača«. Ni del končnega vmesnika, v posnetkih pa je. Pravilo: med preverjanjem jo izrisuj (konstanta `POKAZI_NOVO = true` v `RacuniStran.tsx`), da se posnetki ujemajo. Ko vsa ujemanja držijo, postavi `POKAZI_NOVO = false`; razlike v primerjavi so potem samo te oznake (pričakovano). Ko zaledje polja dostavi, konstanto in oznake odstrani.

### 5.4 »Stanje dostopov« (karton brez izbire, namizje)
Oznaka »Stanje dostopov« (mono 500 12 px, 0.12em, verzalke, `crnilo-3`, `margin-bottom:8`). Štiri skupine (vsaka `margin-top:24`): naslov display 800 24 px/1, −0.02em, `padding-bottom:8; border-bottom:1px solid crnilo` (pri »Prijave v 30 dneh« z NOVO); vrstice `padding:10px 0; border-bottom:1px solid crta`: levo ime Karla 15 px, desno število mono 600 16 px/1.2 (tabularno), pod njima palica 6 px (`polnilo` / `glavna`, širina `n / vseh računov`, zaokroženo na cel %), `margin-bottom:6` nad palico. Skupine:
1. **Vloge**: Igralci · Organizatorji · Administratorji.
2. **Naročnine**: Brezplačno (`BREZPLACNO`) · Premium · Organizatorski paketi (`ORGANIZATOR_*`) · Organizator brez paketa.
3. **Povezave z igralcem**: Samodejno (`virPovezave=SAMODEJNO` in povezan) · Ročno (administrator) · Brez povezave (igralec brez `idIgralec`).
4. **Prijave v 30 dneh** (NOVO): Aktivni (`zadnjaPrijava` ≤ 30 d) · Neaktivni (potrjen račun brez prijave v 30 d).

## 6. Besedila (natančno)
Naslovi: »Čaka na potrditev«, »Kartoteka«, »Stanje dostopov«, »Karton«, »Zahteva {i} od {n}«, »Ni novih zahtev.«. Placeholderji: »Išči po imenu, e-pošti ali klubu« (telefon: »Išči po imenu ali e-pošti«), »Poišči med vsemi igralci«, »novo geslo (vsaj 8 znakov)«. Gumbi: Potrdi dostop · Potrdi organizatorja · Zavrni · Izklopi · Vklopi · Nastavi geslo · Prekliči · Nastavi · Generiraj naključno · Razveži od igralca · Izbriši račun · Izbriši registracijo · Izbriši · Zapri × · Filtri · Počisti · Samodejno povezani · Odpri → · Obdelaj →. »Ni zadetkov.« + gumb »Počisti filtre« (prazen seznam). Relativni čas `rel`: 0 d → »danes«; 1 d → »včeraj«; < 14 d → »pred N d«; < 60 d → »pred ⌊N/7⌉ t«; sicer »pred ⌊N/30⌉ m«. Datumi `d. m. yyyy` (brez ničel), ura `HH:MM`. Imena paketov: »Brezplačno«, »Premium«, »Basic«, »Plus«, »Pro«, »Brez paketa« (obstoječa `imeNarocnine`). Stanje naročnine: obstoječa `stanjeNarocnine`.

## 7. Obnašanje

- **Iskanje**: besede (ločene s presledki) se morajo vse pojaviti, brez ločevanja šumnikov in velikosti črk, v `email`, `prijavljenoIme`, `prijavljeniPriimek`, `imeIgralca`, `klub`, `klubZelja`. Takoj ob vnosu.
- **Filtri** (AND): vloga, stanje (po izpeljavi iz razdelka 5.1), paket (`BREZ` = `paket === null`), »Samodejno povezani« (`virPovezave === 'SAMODEJNO'` in `idIgralec ≠ null`). Števila na žetonih so skupna.
- **Razvrščanje**: *Priimek A–Ž* (`localeCompare(…, 'sl')`, nato ime; grupirano po prvi črki priimka, glave skupin), *Zadnja prijava* (najnovejša prva, brez prijave zadnji; brez skupin in brez kazala), *Naročnina* (brez paketa < Brezplačno < Premium < Basic < Plus < Pro, nato priimek), *Stanje* (Čaka < Brez kode < Izklopljen < Zavrnjen < Potrjen, nato priimek).
- **Nabiralnik**: čakajoča = `status === 'CAKA' && emailPotrjen && skrbnikPotrjen !== false` (obstoječa `pripravljenaZaAdmina`). Vrstni red kot v odgovoru API (v fixture je najnovejša prva). Privzeto izbrana prva. Gumba ← → obhodita seznam (z obratom). Ko izbrana zahteva izgine (potrjena, zavrnjena), se samodejno izbere prva preostala; obvestilo o dejanju ostane na vrhu naslednje zahteve. Klik na vrstico izbere zahtevo (karton se prikaže brez premika strani).
- **Kartoteka vsebuje vse račune**, tudi čakajoče (značka »Čaka«) in brez kode. Izbira vrstice odpre karton v desni ploskvi (neodvisno od nabiralnika; izbira nabiralnika in kartoteke sta ločena stanja). Klik na izbrano vrstico ali »Zapri ×« zapre karton → spet »Stanje dostopov«.
- **Karton**: ob zamenjavi računa se ponastavijo urejevalnik gesla, potrditev, iskanje igralca, obvestilo; predizbira (igralec: prvi predlog brez računa; organizator: navedeni klub, če obstaja med klubi). Obstoječe mutacije: `potrdi` / `potrdiOrganizatorja`, `zavrni`, `nastaviAktiven`, `nastaviGeslo`, `ponastaviGeslo`, `razvezi`, `izbrisi`; po vsaki `invalidateQueries(['racuni'])`. Napake: obstoječi `SporociloNapake` pod blokom dejanja.
- **Razveži** vrne račun med čakajoče (status `CAKA`, brez povezave) — pojavi se v nabiralniku. **Izbris** zapre karton. **Brez prekrivanj**: potrditve so v kartonu, ne modalno okno (glej 9.2).
- **Telefon**: razprtje/zaprtje filtrov je lokalno stanje; list se odpre ob kliku na vrstico/zahtevo, zapre z »Zapri ×« ali klikom na zastor; med odprtim listom se stran pod njim ne drsi (`overflow:hidden` na `body`, fokus v list, `inert` na ozadje — kot `PredalVec`). Kazalo je skrito pri drugih razvrščanjih kot A–Ž.
- **Naložitev**: med nalaganjem »Nalaganje …« (obstoječe `.obvestilo`); napaka poizvedbe `SporociloNapake`.
- **Gibanje**: nobenih animacij (glej 4). `prefers-reduced-motion` ne zahteva ničesar dodatnega.
- **Dostopnost**: vrstice so `<button type="button">` z enakim videzom; viden fokus je obstoječi (2 px `glavna`, odmik 2 px); kazalo črk ima `aria-label="Skoči na črko X"`; obvestilo po dejanju `role="status"`; karton je `aria-live="polite"` samo za obvestilo.
- **Odzivnost**: ≤ 640 px = telefon (obstoječi `useTelefon`). Med 641 in 1279 px v prototipu ni zasnovano: ohrani mrežo, a pod 1024 px naj se nabiralnik zloži (številka in seznam nad kartonom) in seznam kartoteke nad kartonom. To nima posnetka; zadrži enake mere pisav in razmikov.

## 8. Stanje in podatki

**Strežniško stanje** (TanStack Query): `['racuni']` (`racuniApi.seznam`), `['igralci']`, `['klubi']` — kot danes.
**Lokalno stanje strani**: iskanje (niz), filtri (vloga, stanje, paket, samodejno), razvrščanje, izbrani račun v kartoteki (id), izbrana zahteva v nabiralniku (id), na telefonu še `filtriOdprti`, odprt list. **Lokalno stanje kartona** (ponastavi se ob zamenjavi računa): `izbIgralec`, `izbKlub`, `iskanjeIgralca`, `gesloUrejanje`, `gesloVnos`, `novoGeslo`, `potrditev` (`zavrni` | `razveži` | `izbriši` | null), `obvestilo`. Vse izpeljano (skupine, števila, kazalo, pregled) računaj z `useMemo` iz seznama; seznam je že ves na klientu (200+), brez virtualizacije.

### 8.1 Spremembe zaledja (nova polja v `RacunIgralcaDto` — v prototipu označena NOVO)
| Polje | Tip | Opomba |
|---|---|---|
| `zadnjaPrijava` | ISO datum-čas ali `null` | zadnja uspešna prijava računa |
| `prijavNaZadnjih30Dni` | število | |
| `poraba` | `{ lige: { uporabljeno, najvec }, turnirji: { uporabljeno, najvec } }` ali `null` | samo organizator s paketom; `najvec` iz `OMEJITVE_ORGANIZATORJA` |
| `dnevnik` | `[{ ob: ISO, tekst: string }]` najnovejši prvi, ≤ 8 | registracija, potrditev e-pošte, povezava, potrditev, plačilo, nastavitev gesla, izklop/vklop |
| `klub` pri igralcu | `string \| null` | **danes je pri igralcu `null`**; prototip prikazuje klub povezanega igralca v karton in »Povezava«. Zaledje naj ga izpolni iz zapisa igralca. |

Dokler polj ni, vmesnik skrije vrstice/skupine, ki jih ne more prikazati (vrstica ali skupina odpade; to je edini dovoljen razlog za razliko od posnetkov v živem okolju). Fixture za preverjanje že vsebuje vsa polja, zato se tam vse prikaže.

## 9. Odločitve in znane razlike od prototipa

1. **Klub organizatorja.** Prototip za 10 klubov prikaže žetone. V registru je 70+ klubov, zato v produkciji uporabi obstoječ `IzbirnikKluba` (polje z iskanjem, predizbran `klubZelja`) z oznako »Klub organizatorja« in placeholderjem »Brez kluba · vpiši ime«. Zato se v scenariju `desktop-02` primerja samo območje nad kontrolnikom; vse pod njim se zamakne in se preveri z očmi (barve, črte, razmiki naj ostanejo isti).
2. **Potrditve** so v prototipu vrinjene v karton (blok 6), ne modalno okno `PotrditveniOkno`. README projekta pravi »za nepovratna dejanja se vedno odpre potrditveno okno«. **Odločitev lastnika naj se potrdi pred združitvijo**; do takrat implementiraj po prototipu (vrinjeno) in v `DESIGN.md` zapiši vzorec.
3. **Iskanje igralcev** v zahtevi: prototip ima preprosto polje z do 5 zadetki pod njim. Uporabi pomožne funkcije iskanja iz `IskalniIzbirnik.tsx` (`besedeIskanja`, `ustrezaBesedam`, `zadetihZacetkov`), izris pa naj bo v vrsti (ne plavajoč seznam), kot na posnetku.
4. **Gesli** v prototipu sta lokalni; v aplikaciji kliči `nastaviGeslo` / `ponastaviGeslo` in prikaži vrnjeno geslo (blok 5).
5. Vse ostalo (mere, barve, besedila, stanja) mora biti identično.

## 10. Oblikovne vrednosti (povzetek)

- **Tipografija**: Bricolage Grotesque 800: 112 / 88 (številka nabiralnika), 40 (`Kartoteka`), 36 / 32 (črka skupine), 32 (ime v kartonu, naslov sekcije na telefonu), 24 (naslov skupine pregleda), 20 (črka kazala); Karla: 17–18 (imena), 15 (osnovno), 14, 13; IBM Plex Mono 11–12 (oznake, meta; črkovni razmik 0.06–0.12em, verzalke), 14–16 (števila, geslo).
- **Črte**: `3px` črnilo (naslovne črte sekcij, rjava za list zahteve), `1px` črnilo (glave seznamov), `1px` `crta` (vrstice), `4px` levi rob (vloga / zahteva / izbira).
- **Radij**: 0. **Sence**: ni. **Gradienti**: ni.
- **Višine kontrolnikov**: 44 (gumbi, žetoni, kazalo), 48 (iskalno polje, selecti, stikalo — glavna krmila), 52 (izbirna vrstica predloga), 56 (vrstica nabiralnika na telefonu), 6 (palica).
- **Širine**: stolpec nabiralnika 400, desna ploskev kartoteke 440, iskalno polje 360, razmik mrež 48, višina seznama 680.

## 11. Sredstva
Brez slik. Edina grafika: obstoječi znak Turnirko (logotip v glavi) in obstoječe ikone spodnje vrstice telefona (Lucide, v `IkoneNavigacije.tsx`). Pisave iz `@fontsource` (že v projektu).

## 12. Datoteke v paketu
- `README.md` — ta dokument.
- `posnetki/` — 11 referenčnih posnetkov.
- `referenca/Dostopi - prenova.dc.html` — prototip obeh različic (zanima te okvir `1b`).
- `referenca/DostopiKarton.dc.html`, `referenca/DostopiOkvir.dc.html` — karton in okvir (masthead, glava/spodnja vrstica telefona).
- `referenca/Dostopi - trenutno.dc.html` — poustvaritev današnje strani.
- `referenca/dostopi-podatki.js`, `referenca/support.js` — podatki in zagon prototipov.
- `referenca/fixture/` — `racuni.json`, `igralci.json`, `klubi.json`, `auth-me.json`.
- `referenca/primerjava/preveri.mjs` — skripta za primerjavo.

Izvorne datoteke v repozitoriju, ki jih zadeva: `vmesnik/src/strani/RacuniStran.tsx` (nadomesti), `vmesnik/src/slog.css` (nov razdelek `.dostopi-*`, odstrani odvečne `.racun*`), `vmesnik/src/api/tipi.ts` (nova polja v `RacunIgralcaDto`), `vmesnik/src/komponente/Postavitev.tsx` (brez sprememb; `.vsebina--telefon` potrebuje desni odmik 36 px za to stran), `vmesnik/turnirko-profil-redesign/project/DESIGN.md` (dodatek).
