# Handoff: Spodnja navigacijska vrstica z ikonami (predlog 1A »Drsna poteza«)

## Overview
Spodnja vrstica na telefonu (`≤ 640 px`, komponenta `Postavitev`) trenutno nosi samo besedilne
oznake (DOMOV · TURNIRJI · LIGE · LESTVICA · VEČ). Predlog doda **ikono nad oznako** in
**eno samo animacijo**: modra 3 px poteza na vrhu vrstice **zdrsne** z prejšnjega zavihka na
novega, aktivna ikona se dvigne za 2 px, ploskev zavihka se prebarva v mehko modro.

Nič drugega v vmesniku se ne spremeni: glava telefona, predal »Več«, namizna navigacija in
vsebina strani ostanejo enaki.

## About the Design Files
Datoteke v tem paketu so **oblikovalske reference, narejene v HTML** — prototipi, ki kažejo
želen izgled in vedenje, **ne produkcijska koda za kopiranje**. Naloga je predlog
**poustvariti v obstoječi kodni bazi** (`vmesnik/`: React + react-router + TypeScript, en sam
globalni `src/slog.css` z BEM-podobnimi razredi in CSS spremenljivkami) po njenih uveljavljenih
vzorcih — torej z razredi v `slog.css` in spremembami v `src/komponente/Postavitev.tsx`,
ne z inline stili, kot so v prototipu (inline stili so tam samo zato, ker gre za samostojno HTML datoteko).

## Fidelity
**High-fidelity.** Barve, tipografija, mere in časi prehodov so končni. Rezultat naj se
piksel za pikslom ujema s posnetki v `screenshots/`.

## ⚠️ Odstopanje od DESIGN.md
`slog.css` in `DESIGN.md` na več mestih pravita, da so **ikone prepovedane** (»Prozilnik
uporabnika je besedilo v mono, ne ikona (ikone so prepovedane)«, »Edina ikona v vmesniku je
logotip«). Ta predlog je **namerna, odobrena izjema, omejena na spodnjo vrstico na telefonu**.
Ob implementaciji:
- posodobi komentar v `DESIGN.md` in nad `.spodnja-vrstica` v `slog.css`, da izjema ne izgleda kot napaka;
- nikjer drugje (glava, gumbi, meniji, predal) ikon ne dodajaj.

## Screens / Views

### Zaslon: katera koli stran na telefonu (na posnetkih: Lestvica)
- **Purpose**: navigacija med štirimi javnimi sklopi + predal »Več« za urejevalca.
- **Layout**: nespremenjen glede na danes — `.glava-telefon` (56 px vrsta + 1 px črta + 2 px
  presledek + 3 px črta), vsebina `.vsebina--telefon`, spodaj fiksna `.spodnja-vrstica`.
- **Sprememba je samo v `.spodnja-vrstica`.**

#### Spodnja vrstica (novo)
- Nosilec: `position: fixed; left/right/bottom: 0; z-index: 15; display: grid;`
  `grid-template-columns: repeat(5, minmax(0, 1fr))` (za gosta/igralca `repeat(4, …)` prek
  `.spodnja-vrstica--stiri`), `background: var(--barva-papir)`,
  `border-top: 3px solid var(--barva-crnilo)`, `padding-bottom: env(safe-area-inset-bottom, 0px)`.
  **Novo:** `position: fixed` že je; dodaj le nič — drsna poteza je absolutno pozicionirana
  glede na vrstico, zato vrstica ostane vsebnik (fixed je že vsebnik za absolute).
- Postavka (`a` / `button`): `display: flex; flex-direction: column; align-items: center;`
  `justify-content: center; gap: 5px; min-height: 64px` (prej 60 px — ikona + oznaka rabita 4 px več;
  z `env(safe-area-inset-bottom)` je skupna višina še vedno pod 1/6 zaslona),
  `border: none; border-radius: 0; background: none; cursor: pointer`.
- Ikona: 22 × 22 px, `stroke-width: 1.75`, `stroke: currentColor`, `fill: none`,
  `stroke-linecap/linejoin: round`. Ikone so v `ikone/` (Lucide, ISC licenca).
  Preslikava: Domov = `house`, Turnirji = `trophy`, Lige = `shield`,
  Lestvica = `chart-no-axes-column` (tri palice — isti zapis kot logotip), Več = `ellipsis`.
- Oznaka: `font: 500 11px/1.2 var(--pisava-mono)`, `letter-spacing: 0.06em`,
  `text-transform: uppercase`. Aktivna: `font-weight: 600`.
- Mirno stanje: `color: var(--barva-crnilo-3)` (`#5b534d`), ploskev prozorna.
- Hover: `color: var(--barva-crnilo)`, brez podčrtaja (kot danes).
- **Aktivno stanje**: `color: var(--barva-glavna-tekst)` (`#0071ab`),
  `background: var(--barva-glavna-mehko)` (`#eaf3f9`), oznaka 600, ikona `translateY(-2px)`.
  Modra 3 px poteza NI več `border-top` na postavki (kot danes z negativnim robom), ampak
  **skupen drsni element** — sicer ne more zdrsniti.
- Fokus: obstoječi globalni `:focus-visible { outline: 2px solid var(--barva-glavna) }` ostane.

#### Drsna poteza (edini nov element)
```
<span class="spodnja-vrstica__poteza" aria-hidden="true" style={{ transform: `translateX(${indeks * 100}%)` }} />
```
```css
.spodnja-vrstica__poteza {
  position: absolute;
  top: -3px;                /* sede NA debelo črto, da je vrh ena poteza */
  left: 0;
  width: 20%;               /* 100 / število postavk; pri štirih postavkah 25% */
  height: 3px;
  background: var(--barva-glavna);
  transition: transform 260ms cubic-bezier(.2, .8, .2, 1);
}
.spodnja-vrstica--stiri .spodnja-vrstica__poteza { width: 25%; }
```
`transform` je edina animirana lastnost (kompozitorska, brez preračuna postavitve).
Ko ni aktivna nobena postavka (predal »Več« zaprt, pot ni v nobenem sklopu) poteza ostane
na zadnjem znanem indeksu; če indeksa ni, jo skrij z `opacity: 0` (brez animacije opacitete).

## Interactions & Behavior
- Klik/tap na postavko: navigacija prek `NavLink` (nespremenjeno). »Več« odpre predal (nespremenjeno).
- **Animacije (edine tri, vse 260 ms):**
  | Kaj | Lastnost | Trajanje | Easing |
  |---|---|---|---|
  | drsna poteza | `transform: translateX()` | 260 ms | `cubic-bezier(.2, .8, .2, 1)` |
  | ikona aktivnega | `transform: translateY(0 → -2px)` | 260 ms | `cubic-bezier(.2, .8, .2, 1)` |
  | ploskev + barva postavke | `background`, `color` | 260 ms | `ease` |
- Aktivni indeks se izračuna z obstoječo funkcijo `jeVSklopu(pot, naslov)` in `PODPOTI`
  (kategorija spada pod Turnirje, srečanje pod Lige) — logike ne spreminjaj, le iz nje
  izpelji `indeksAktivne` za `translateX`.
- Ko je odprt predal »Več«, je aktiven zavihek »Več« (kot danes: `odprtVec` prevlada) —
  poteza torej zdrsne na peti stolpec in se ob zaprtju vrne.
- `@media (prefers-reduced-motion: reduce)`: `transition: none` za vse tri prehode
  (obvezno — vrstica mora ostati uporabna brez gibanja).
- Temna tema: nič dodatnega, vse barve so spremenljivke; ikone rišejo `currentColor`.
- Nad 640 px vrstice ni (izriše jo samo `useTelefon()`), zato medijske poizvedbe ne rabiš.

## State Management
Novih stanj ni. Potrebna je samo izpeljana vrednost v `Postavitev`:
```ts
const indeksAktivne = odprtVec
  ? spodnjePovezave.length                       // »Več«
  : spodnjePovezave.findIndex((p) => jeVSklopu(p.pot, naslov))
```
Obstoječe: `odprtVec`, `useLocation().pathname`, `jeAdmin/jeOrganizator` (koliko stolpcev).

## Design Tokens (vse že obstajajo v `slog.css`)
- `--barva-papir #fbf9f5` · `--barva-crnilo #14110f` · `--barva-crnilo-3 #5b534d`
- `--barva-crta #ded7ce` · `--barva-glavna #0088ce` · `--barva-glavna-tekst #0071ab`
- `--barva-glavna-mehko #eaf3f9` · `--barva-poudarek #7bb900`
- Pisave: `--pisava-display` Bricolage Grotesque 800 · `--pisava-telo` Karla · `--pisava-mono` IBM Plex Mono
- Ritem 8 px: postavka 64 px, ikona 22 px, gap ikona↔oznaka 5 px, poteza 3 px
- Brez zaobljenih robov, brez senc (hišni zapis).

## Assets
- `ikone/*.svg` — 5 ikon iz **Lucide** (`lucide-icons/lucide`, veja `main`, ISC licenca):
  `house`, `trophy`, `shield`, `chart-no-axes-column`, `ellipsis`. Poti so nespremenjene,
  prilagojena je le `stroke-width` (2 → 1.75) zaradi 22 px velikosti.
  V projektu jih vgradi kot inline React komponente (kot `ZnakTurnirko`) ali kot `?react` SVG —
  **ne kot `<img>`**, ker morajo dedovati `currentColor`.
- Ne dodajaj novih pisav; vse tri so že lokalno vgrajene (fontsource).

## Files
- `1A Spodnja vrstica.dc.html` — referenčni prototip 1A (klikljivi zavihki, 390 px zaslon).
- `Primerjava 1A in 1B.dc.html` — kontekst: današnje stanje, 1A in zavrnjena varianta 1B.
- `support.js` — runtime za oba HTML prototipa (samo da se odpreta v brskalniku).
- `screenshots/01-05` — ciljni izgled za vseh pet aktivnih stanj.
- `ikone/` — SVG ikone.

## Navodilo Claude Codu: primerjaj z posnetki, dokler se ne ujema
1. Implementiraj spremembo v `src/komponente/Postavitev.tsx` in razdelku »Spodnja vrstica« v
   `src/slog.css` (razdelek je namenoma zadnji v datoteki — pravila telefona morajo prevladati).
2. Zaženi `npm run dev`, odpri app v napravi širine **390 px** (Chrome DevTools → iPhone 12/13,
   svetla tema, brez zooma) na strani `/lestvica`.
3. Za **vsako** od petih postavk (Domov, Turnirji, Lige, Lestvica, Več) naredi posnetek zaslona
   spodnje vrstice in ga primerjaj z ustreznim posnetkom v `screenshots/`:
   `01-aktivno-domov.png`, `02-aktivno-turnirji.png`, `03-aktivno-lige.png`,
   `04-aktivno-lestvica.png`, `05-aktivno-vec.png`.
   (Posnetki so narejeni pri 260 ms prehodih **po** koncu animacije, torej v mirnem stanju.)
4. Preveri po tem seznamu in popravljaj, dokler ni vse ✔:
   - [ ] 5 stolpcev enake širine; postavka visoka 64 px; vrstica ima 3 px črno črto na vrhu
   - [ ] ikone 22 px, stroke 1.75, poravnane v sredino, 5 px nad oznako
   - [ ] oznaka 11 px IBM Plex Mono, uppercase, letter-spacing 0.06em; aktivna 600, ostale 500
   - [ ] aktivna postavka: ploskev `#eaf3f9`, besedilo in ikona `#0071ab`, ikona 2 px višje
   - [ ] modra poteza 3 px leži točno nad aktivnim stolpcem in prekriva črno črto (ne pod njo, ne dvojna črta)
   - [ ] neaktivne postavke `#5b534d`, prozorna ploskev
   - [ ] razmiki in tipografija vsebine nad vrstico se niso premaknili (primerjaj tudi zgornji del posnetka)
   - [ ] klik na zavihek: poteza **zdrsne** (ne preskoči) v 260 ms; ni utripa ali skoka postavitve
   - [ ] `prefers-reduced-motion: reduce` → brez prehodov, stanja pravilna
   - [ ] temna tema (`prefers-color-scheme: dark`) — barve iz spremenljivk, kontrast v redu
   - [ ] gost/igralec (4 postavke): stolpci 25 %, poteza 25 % široka
   - [ ] tipkovnica: `Tab` obide potezo (`aria-hidden`), fokus viden na postavkah
5. Če se posnetek in implementacija razlikujeta v čemer koli od zgornjega, **popravi kodo in
   ponovi korak 3** — ne prilagajaj posnetkov in ne »izboljšuj« oblikovanja po svoje.
   Če je razlika posledica nečesa, česar prototip ne more vedeti (npr. resnična dolžina oznake
   v drugem jeziku), to zapiši v PR opis namesto tihe spremembe.
