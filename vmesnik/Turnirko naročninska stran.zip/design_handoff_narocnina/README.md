# Handoff: prenova strani Naročnina (igralec)

## Pregled
Prenova strani `/narocnina` (`vmesnik/src/strani/NarocninaStran.tsx`), ki se odpre, ko prijavljeni igralec v uporabniškem meniju klikne »Naročnina«. Stran:
- v naslovu pokaže ime paketa, ki ga ima igralec (`Igralec Premium` / `Igralec Free`),
- poudari, kaj Premium prinese,
- pokaže začetek naročnine, trenutno obdobje, dni do obnove in datum obnove,
- omogoča preklop mesečno ↔ letno, preklic in obnovo preklicane naročnine,
- igralcu brez Premium ponudi nadgradnjo (primerjalna tabela kot v registraciji).

Vizualni jezik je namerno isti kot razdeljeno okno registracije (`RegistracijaTok.tsx`, razredi `.registracija__*` v `slog.css`): temen levi stolpec na namizju, temen trak na telefonu, kolofonske vrstice, segmenti napredka, izbirnik z diagonalnim trakom »−10%«.

Velja organizatorski del obstoječe strani (paketi Basic/Plus/Pro) — **tega ne spreminjaj**, prenova zadeva samo igralca (`vloga === 'IGRALEC'`).

## O datotekah v paketu
`Naročnina.dc.html` je **oblikovna referenca v HTML** (prototip z inline slogi), ne produkcijska koda. Naloga je stran **poustvariti v obstoječem vmesniku** (React + TypeScript + `slog.css` z BEM razredi v slovenščini), po pravilih iz `turnirko-profil-redesign/project/DESIGN.md`. Inline slogov ne prepisuj v JSX — dodaj razrede v `slog.css` (nov razdelek `.narocnina__*`) in kjer se da, **ponovno uporabi obstoječe** (`.gumb`, `.gumb--glavni`, `.gumb--nevaren`, `.izbirnik`, `.izbirnik__gumb--trak`, `.izbirnik__trak`, `.naslov-strani`, `.registracija__stolpec`, `.registracija__korak*`, `.registracija__izbira*`, `.registracija__trak*`, `.registracija__kolofon*`, `.registracija__primerjava*`, `.registracija__stolp*`, `.registracija__znesek*`, `.registracija__obvestilo--uspeh`, `.registracija__noga`). Logotip = `ZnakTurnirko` iz `Postavitev.tsx`. Glava strani in spodnja vrstica ostaneta iz `Postavitev.tsx` (nista del te naloge — v prototipu sta samo za kontekst).

Prototip odpreš v brskalniku (`Naročnina.dc.html`, poleg mora biti `support.js`). Stanje izbereš s parametrom: `?stanje=brez|mesecno|letno|preklicano`, pogled vsiliš z `&pogled=namizje` ali `&pogled=telefon`. Mlajši od 21: `&mlajsi=1`.

## Natančnost
**High-fidelity.** Barve, tipografija, razmiki, besedila in stanja so končni. Poustvari jih do piksla.

## ⚠ Obvezno: primerjava s posnetki zaslona
V `posnetki/` je 12 posnetkov (6 stanj × namizje 1280 px in telefon 390 px, telefon v 2×):

| Datoteka | Stanje |
|---|---|
| `namizje-1-premium-mesecno.png` / `telefon-1-…` | Premium, mesečno, aktiven |
| `namizje-2-premium-letno.png` / `telefon-2-…` | Premium, letno, aktiven |
| `namizje-3-free.png` / `telefon-3-…` | Brez Premium (Free), izbrano mesečno |
| `namizje-4-preklicano.png` / `telefon-4-…` | Preklicana, velja do konca obdobja |
| `namizje-5-preklop-na-letno.png` / `telefon-5-…` | Mesečni naročnik je v izbirniku kliknil »Letno« |
| `namizje-6-potrditev-preklica.png` / `telefon-6-…` | Kliknjeno »Prekliči naročnino« — potrditev |

**Postopek, ki ga moraš ponavljati, dokler se ne ujema popolnoma:**
1. Implementiraj stanje.
2. Zaženi vmesnik (`npm run dev` v `vmesnik/`), odpri `/narocnina` kot igralec v ustreznem stanju (po potrebi z začasnim mockom podatkov uporabnika/naročnine).
3. Naredi posnetek celotne strani pri **točno 1280 px** in **390 px** širine (npr. Playwright: `page.setViewportSize({width:1280,height:900})`, `page.screenshot({fullPage:true})`; telefon z `deviceScaleFactor: 2`).
4. Primerjaj svoj posnetek s posnetkom iz `posnetki/` — vizualno IN po meritvah (odmiki, velikosti pisav, širine stolpcev, barve, prelomi vrstic, vrstni red elementov). Za pomoč lahko uporabiš pixel diff (npr. `pixelmatch`) — razlika naj bo samo še v anti-aliasingu pisave.
5. Popravi razlike in ponovi od 3. koraka. **Ne zaključi, dokler se vseh 12 posnetkov ne ujema.** Pri vsakem popravku preberi še izvor v `Naročnina.dc.html` — mere so tam zapisane natančno.

Opomba: v posnetkih zgornja glava in spodnja vrstica prikazujeta obstoječo `Postavitev`; pri primerjavi mora biti tvoja glava enaka tej na posnetku (je že v kodi). Pred primerjavo zagotovi, da so naložene pisave (Bricolage Grotesque, Karla, IBM Plex Mono — v aplikaciji prek fontsource).

## Zaslon: Naročnina (igralec)

### Postavitev (od zgoraj navzdol, znotraj `.vsebina > section`)
1. **Glava strani** — `display:flex; flex-wrap:wrap; gap:24px 56px; align-items:flex-end`.
   - Levo (`flex: 999 1 420px`): samo en naslov — **ime paketa** (`OZNAKE_PAKET[paket]` → »Igralec Premium« / »Igralec Free«), Bricolage 800, `clamp(44px, 8cqw, 88px)` (namizje 88, telefon 44), `line-height .88`, `letter-spacing -0.035em`. **Brez nadnaslova »Račun« in brez uvodnega odstavka.**
   - Desno (`flex: 1 1 300px; max-width:380px`):
     - Premium aktiven: modri blok `#0071ab`, padding `16px 16px 14px`, gap 12. Velika številka dni do obnove (Bricolage 800, `clamp(72px,9cqw,96px)`, `-0.04em`, lh .85, bela) + mono 12 px uppercase »dni do obnove« v `#e8f5c4`. Pod črto `1px #0088ce` (padding-top 10): levo »Obnova 12. 10. 2026«, desno cena naslednje obnove v `#e8f5c4`; mono 600 12 px, `0.08em`, uppercase.
     - Preklicano: isti blok, a podlaga `#ede7df`, `border-left:4px solid #6e655e`, številka `#14110f`, oznaka »dni Premium še velja« `#5b534d`, črta `#ded7ce`, desno »Brez obnove« v `#8c2b14`.
     - Free: kolofon z `border-top:3px solid #14110f`; vrstice Paket · Free / Premium mesečno · 4,99 € / Premium letno · 53,49 € (`.registracija__kolofon-vrstica` mere).
2. **Plošča** (`border:1px solid #14110f`, `display:flex; flex-wrap:wrap`) — zgradba kot `.registracija`.
   - **Namizje, levi stolpec** 280 px, `#14110f`, padding `32px 24px`, gap 40: logotip + »Turnirko« (20 px); seznam s glavo »Premium · vključeno« (Free: »Premium · kaj dobiš«) in 5 vrstic v slogu `.registracija__korak`: št. »OK« v `#7bb900` + ime v `#fbf9f5` (Premium/preklicano) oz. »01…05« in ime v `#9a9189` (Free). Funkcije: Forma in nasprotniki · Napoved tekme · Nizi, točke in razrezi · Spremljanje lig · Zasebna statistika. Na dnu (`margin-top:auto`) »Tvoja naročnina« kot `.registracija__izbira`: Paket, Plačevanje, Cena.
   - **Telefon, trak** namesto stolpca (`.registracija__trak`): logotip 20 + status mono (»Naročnina · aktivna«), desno cena (`#e8f5c4`, npr. »4,99 € / mesec«, preklicano »Brez obnove«); pod tem 12 segmentov 4 px (pretečeni `#0088ce`, ostali `#4a433d`). Free: brez segmentov.
   - **Desni stolpec** (`flex: 999 1 340px`), odmiki `clamp(20px,5%,48px)`:
     - Glava (samo namizje): vrstica min 44 px — levo status mono (»Naročnina · aktivna« / »Naročnina · preklicana« / »Paket · Free«), desno »Obnova 12. 10. 2026« / »Velja do …« / »Preklic kadarkoli«.
     - Naslov 48 px Bricolage 800: »Igralec Premium« oz. »Nadgradi na Premium«.
     - Obdobje (Premium/preklicano): mono vrstica »Obdobje 12. 9. 2026 – 12. 10. 2026« (`#14110f`) in »Še 18 dni« (`#5b534d`; preklicano »Še 18 dni, nato Free«); 12 segmentov 6 px, gap 4, pretečeni `#0088ce`, ostali `#ede7df`. Število pretečenih = `round((1 − dniDoKonca / dniObdobja) × 12)`.
     - Telo (padding `24px x 32px`, gap 24):
       - Premium/preklicano: **kolofon** (`border-top:1px #ded7ce`): Naročen od · Plačevanje (»Mesečno · 4,99 €«) · Trenutno obdobje · Naslednja obnova (»12. 10. 2026 · 4,99 €«; preklicano »Velja do« v `#8c2b14`). Po zabeleženem preklopu dodatna vrstica »Od obnove · Letno · 53,49 € / leto« v `#4a7500`. Vrednosti `white-space:nowrap`.
       - **Spremeni plačevanje** (mono glava z `border-bottom:1px #ded7ce`, `0.12em`): izbirnik `.izbirnik` z »Mesečno · trenutno« in »Letno« + trak »−10%« (`.izbirnik__gumb--trak`). Ko je izbran drug cikel, se pokaže predogled: odstavek 17/300, nato vrstica `.registracija__znesek` s `border-top:3px #14110f` (oznaki »Ob obnovi 12. 10. 2026« in zeleno »Prihraniš 6,39 € na leto« / znesek 56 px), gumba `gumb--glavni` »Preklopi na letno« in `gumb` »Ostani pri mesečnem« (oba `flex:1 1 200px/160px`). Sicer samo pojasnilo 14/300 `#5b534d`.
       - **Preklic** (samo aktiven): besedilo 15/300 + `gumb--nevaren` »Prekliči naročnino«. Klik → potrditveni blok: `border-left:4px solid #b23a1e`, podlaga `#f8e5df`, padding 16, naslov 24 px 800 »Prekličem Premium?«, besedilo, gumba »Da, prekliči« (polna `#b23a1e`, bela, hover `#8c2b14`) in »Obdrži Premium« (`gumb` na `#fbf9f5`).
       - **Obnova** (samo preklicano): besedilo + `gumb--glavni` »Obnovi · 4,99 € / mesec« (cikel po izbirniku; glava izbirnika tedaj »Plačevanje ob obnovi«).
       - Free: izbirnik (privzeto Mesečno), primerjalna tabela **identična** koraku »Paket« v registraciji (stolpca »Free / 0 € / Vedno / Trenutno« in »Premium / cena / Na mesec|Na leto / Izbrano« z modro podlago stolpca), pojasnilo cene po starosti (`starejsiOd21`).
     - Noga (`.registracija__noga`): levo mono »Plačilo prek Stripe«; desno Free: `gumb--glavni` »Nadgradi na Premium · 4,99 €«, Premium: `gumb` »Kartica in računi v Stripe« (odpre obstoječi Stripe Billing Portal).
3. **Sekcija »Kaj dobiš s Premium«** — naslov sekcije (`border-top:3px`, padding-top 16, h2 40 px 800), desno mono »5 od 5 vključeno« (Free: »Od 4,99 € / mesec«). 5 vrstic: grid `40px minmax(0,1fr) auto`, padding 20px 0, `border-bottom:1px #ded7ce`; mono številka (zelena `#4a7500` pri Premium, sicer `#5b534d`); ime 24 px 800 (`flex:1 1 260px`) in opis 15/300 (`flex:2 1 320px`) v vrsti, ki se na telefonu prelomi; desno povezava mono 600 12 px: »Profil →« (`/moj-profil`), »1 na 1 →« (`/dvoboj`), »Lige →« (`/lige`) v `#0071ab`; Free: »Premium« v `#6e655e`.

### Odzivnost
Prelom na 640 px prek `useTelefon()` (levi stolpec ↔ trak — ista odločitev kot v `RegistracijaTok`). Ostalo se prelaga samo s flex-wrap. Prototip za velikosti uporablja `cqw` na korenu širine strani; v aplikaciji uporabi `clamp()` z `vw` ali medijsko poizvedbo 640 px, da dobiš iste končne mere (namizje/telefon): naslov 88/44, dni 96/72, odmiki vsebine 48·40/20·20.

## Interakcije in stanje
- `izbran: 'MESECNO'|'LETNO'` — izbira v izbirniku (privzeto trenutni cikel; Free: MESECNO).
- `vprasanjePreklic: boolean`.
- `obvestilo: string|null` — zelen trak `.registracija__obvestilo--uspeh` na vrhu telesa (po preklopu z gumbom »Razveljavi«).
- Preklop cikla: začne veljati ob naslednji obnovi (mesečno → letno ob koncu meseca; letno → mesečno ob koncu leta). Po potrditvi: obvestilo »Od 12. 10. 2026 plačuješ letno, 53,49 € / leto.«
- Preklic: naročnina ostane aktivna do konca obdobja (`paketAktiven` ostane `true`), stanje preide v »preklicano«.
- Obnova preklicane: brez plačila do konca obdobja.
- Nadgradnja (Free): obstoječi `placilaApi.nadgradnja({ paket:'PREMIUM', ciklus })` → Stripe Checkout; med čakanjem napis gumba »Preusmerjam na plačilo …«.
- Napake: obstoječi `<div className="napaka">` nad ploščo.

### Potrebni podatki / zaledje
`Uporabnik` danes nima datumov. Za to stran potrebuješ (predlog, uskladi z zaledjem — `NarocninaStoritev`, `PlacilaStoritev`):
- `narocenOd` (ISO), `obdobjeOd`, `obdobjeDo` (ISO), `preklicana: boolean`, `naslednjiCiklus: CiklusPlacila|null` (zabeležen preklop).
- Endpointi: sprememba cikla ob obnovi, preklic ob koncu obdobja, razveljavitev preklica (Stripe: `subscription schedule` oz. `cancel_at_period_end`). Če tega ni mogoče narediti takoj, naj gumbi preklica/preklopa začasno odprejo obstoječi `placilaApi.portal()`, izgled pa ostane enak.
- Cene iz `CENA_PREMIUM_MESECNO` / `CENA_PREMIUM_LETNO` (nikoli vtipkane), oblikovanje z `oblikujCeno`, datumi z `oblikujDatum` (oblika »12. 10. 2026«).

## Oblikovni žetoni
Vsi so že v `:root` v `slog.css`: `--barva-crnilo #14110f`, `--barva-crnilo-2 #332e29`, `--barva-crnilo-3 #5b534d`, `--barva-crnilo-4 #6e655e`, `--barva-crta #ded7ce`, `--barva-polnilo #ede7df`, `--barva-papir #fbf9f5`, `--barva-namizje #dcd8d1`, `--barva-glavna #0088ce`, `--barva-glavna-polna #0071ab`, `--barva-glavna-polna-mocna #005a88`, `--barva-glavna-mehko #eaf3f9`, `--barva-na-glavni-2 #e8f5c4`, `--barva-poudarek #7bb900`, `--barva-poudarek-tekst #4a7500`, `--barva-poudarek-mehko #eaf4d6`, `--barva-negativna #b23a1e`, `--barva-negativna-tekst #8c2b14`, `--barva-negativna-mehko #f8e5df`, `--barva-na-crnilu-2 #b9b0a6`, `--barva-na-crnilu-3 #9a9189`, `--barva-crta-na-crnilu #332e29`, `--barva-crta-na-crnilu-2 #4a433d`. Radij 0 povsod, brez senc, ritem 8 px, mono oznake 12 px / 500 / `0.08em` uppercase.

## Sredstva
Brez slik. Logotip = `ZnakTurnirko`. Ikone spodnje vrstice so obstoječe (`IkoneNavigacije.tsx`).

## Datoteke
- `Naročnina.dc.html` — prototip (vsa stanja, logika v razredu `Component` na dnu datoteke).
- `support.js` — izvajalnik prototipa (samo za odpiranje v brskalniku).
- `posnetki/*.png` — referenčni posnetki za primerjavo.
