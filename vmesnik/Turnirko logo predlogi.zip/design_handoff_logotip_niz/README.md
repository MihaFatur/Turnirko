# Handoff: novi znak Turnirko — „Niz“ (1D)

## Pregled

Zamenjava obstoječega logotipa aplikacije Turnirko. Star znak (`ZnakTurnirko` v
`vmesnik/src/komponente/Postavitev.tsx`) je lopar + žogica — najbolj generičen znak te
panoge. Nov znak **„Niz“** so štiri navpične poteze zapisnika: tri odigrane, četrta
(zelena) odloči. Hkrati bere kot tekstura mrežice in kot stolpec rezultata.

Zamenja se **samo znak**. Napis „Turnirko“, masthead, navigacija, barve, tipografija in
vse ostalo v vmesniku ostanejo nedotaknjeni.

## O datotekah v paketu

Datoteke v tem paketu so **oblikovalska referenca, narejena v HTML** — ne produkcijska
koda za lepljenje. Naloga je znak ponoviti v obstoječem okolju repozitorija
(React + TypeScript + navaden CSS z BEM razredi v slovenščini), po pravilih
`vmesnik/turnirko-profil-redesign/project/DESIGN.md`. Nobene nove knjižnice, nobenega
ikonskega paketa.

## Fidelity

**Hi-fi.** Vse mere, koordinate in barve spodaj so končne. Rezultat mora biti pikselsko
enak posnetkom v `posnetki/`.

---

## 1. Geometrija znaka

`viewBox="0 0 28 28"`, štirje pravokotniki, brez radija, brez obrisa, brez transformacij:

| poteza | x    | y | širina | višina | barva                        |
|--------|------|---|--------|--------|------------------------------|
| 1      | 1.5  | 4 | 3      | 20     | `--barva-crnilo` (#14110F)   |
| 2      | 8.5  | 4 | 3      | 20     | `--barva-crnilo` (#14110F)   |
| 3      | 15.5 | 4 | 3      | 20     | `--barva-glavna` (#0088CE)   |
| 4      | 22.5 | 4 | 3      | 20     | `--barva-poudarek` (#7BB900) |

Korak med potezami je 7 enot, vrzel 4 enote, zrak zgoraj in spodaj po 4 enote.
Te vrednosti se ne zaokrožujejo in ne prilagajajo.

## 2. Koda komponente

Zamenjaj celotno funkcijo `ZnakTurnirko` v `vmesnik/src/komponente/Postavitev.tsx`
(privzeta velikost 24 px ostane, `aria-hidden` ostane — napis „Turnirko“ poleg znaka že
nosi pomen):

```tsx
/* Edina ikona v vmesniku: stiri poteze zapisnika. Tri so crnilo, tretja glavna
   (modra), cetrta poudarek (zelena) - odlocilni niz. Barve nosi CSS, da se
   ujemata obe temi in tisk. */
export function ZnakTurnirko({ velikost = 24 }: { velikost?: number }) {
  return (
    <svg
      className="logo-znak"
      width={velikost}
      height={velikost}
      viewBox="0 0 28 28"
      aria-hidden="true"
    >
      <rect className="logo-znak__poteza" x="1.5" y="4" width="3" height="20" />
      <rect className="logo-znak__poteza" x="8.5" y="4" width="3" height="20" />
      <rect className="logo-znak__poteza logo-znak__poteza--glavna" x="15.5" y="4" width="3" height="20" />
      <rect className="logo-znak__poteza logo-znak__poteza--izid" x="22.5" y="4" width="3" height="20" />
    </svg>
  )
}
```

## 3. Sprememba v `vmesnik/src/slog.css`

V razdelku 2 (masthead) **odstrani** tri pravila starega znaka in komentar nad njimi:

```css
/* ODSTRANI */
.logo-znak__lopar { fill: var(--barva-glavna); }
.logo-znak__rocaj { stroke: var(--barva-crnilo); }
.logo-znak__zogica { fill: var(--barva-poudarek); }
```

**Nadomesti** z:

```css
/* Edina ikona v vmesniku je logotip: stiri poteze niza. */
.logo-znak {
  display: block;
  flex: none;
}

.logo-znak__poteza {
  fill: var(--barva-crnilo);
}

.logo-znak__poteza--glavna {
  fill: var(--barva-glavna);
}

.logo-znak__poteza--izid {
  fill: var(--barva-poudarek);
}
```

`.logo-znak` ostane nespremenjen, če že obstaja — ne podvajaj pravila.

V razdelku 16 (tisk) dodaj enobarvno različico; tisk je črno-bel, zato so tri poteze
polne, četrta pa samo obrisana:

```css
@media print {
  .logo-znak__poteza,
  .logo-znak__poteza--glavna {
    fill: #000;
  }

  .logo-znak__poteza--izid {
    fill: none;
    stroke: #000;
    stroke-width: 1;
  }
}
```

Temna tema ne potrebuje ničesar novega: `--barva-crnilo` se v `prefers-color-scheme: dark`
že obrne na `#F2F0EA`, modra in zelena ostaneta isti.

## 4. Favicon

V paketu sta `znak-turnirko.svg` (prosojna podlaga, za splošno rabo) in `favicon.svg`
(s podlago papirja, obe temi). Kopiraj `favicon.svg` v `vmesnik/public/` in v
`vmesnik/index.html` v `<head>` dodaj:

```html
<link rel="icon" type="image/svg+xml" href="/favicon.svg" />
```

Datoteki `.png` različic ne delaj — SVG zadošča in ostane oster.

## 5. Kje se znak pojavi

`ZnakTurnirko` je edino mesto, ki riše znak; uvožen je v masthead
(`Postavitev.tsx`, `.glava__logotip`, gap 10 px, napis 24 px display 800,
`letter-spacing: -0.02em`). Po zamenjavi preveri:

- masthead na širini 1280 px, svetla tema → `posnetki/02-masthead-svetla-tema.png`
- masthead v temni temi → `posnetki/04-masthead-temna-tema.png`
- masthead na telefonu (`max-width` pravilo v razdelku 2 skrči logotip na 20 px)
- prijavno okno in vse, kar `ZnakTurnirko` uvozi z drugo vrednostjo `velikost`

Znak se ne uporablja pod 16 px.

## 6. Barvni žetoni (nič novega)

| Žeton | Svetla | Temna |
|---|---|---|
| `--barva-crnilo` | `#14110F` | `#F2F0EA` |
| `--barva-glavna` | `#0088CE` | `#0088CE` |
| `--barva-poudarek` | `#7BB900` | `#7BB900` |
| `--barva-papir` | `#FBF9F5` | `#12100F` |

Nobene nove barve, nobenega gradienta, nobene sence, `border-radius: 0`.

---

## 7. Postopek za Claude Code — primerjaj s posnetki, dokler se ne ujema

V mapi `posnetki/` so referenčni posnetki. **Implementacija ni končana, dokler se
zaslon ne ujema s posnetkom.** Delaj po korakih:

1. Uvedi spremembe iz razdelkov 2–4.
2. Zaženi aplikacijo in odpri domačo stran na širini okna 1280 px, svetla tema.
3. Naredi posnetek zaslona masthead-a in ga **postavi ob**
   `posnetki/02-masthead-svetla-tema.png`. Primerjaj po vrsti:
   - razmik med znakom in napisom (10 px), poravnava osnovnih črt,
   - višina znaka (24 px) in debelina posamezne poteze,
   - vrstni red barv poteze 1–4 (črnilo, črnilo, modra, zelena),
   - tanka 1 px in za njo polna 3 px črta pod mastheadom,
   - odmiki 24 px zgoraj in 40 px levo/desno.
4. Ponovi za temno temo (`prefers-color-scheme: dark`) proti
   `posnetki/04-masthead-temna-tema.png`.
5. Ponovi za velikosti 16/20/24/48 px in ploščice proti
   `posnetki/03-velikosti-in-ploscice.png`; preveri, da poteze pri 16 px ostanejo
   ločene in ne zlijejo.
6. Preveri geometrijo proti `posnetki/01-znak-konstrukcija.png` — koordinate iz
   tabele v razdelku 1 morajo biti v kodi dobesedno.
7. Če odstopa karkoli, popravi kodo (ne posnetka) in se vrni na korak 3. Nadaljuj,
   dokler razlike ni več.
8. Na koncu preglej `git diff`: spremenjeni smejo biti samo `Postavitev.tsx`,
   `slog.css`, `index.html` in dodan `public/favicon.svg`. Nič drugega.

Če se med delom pojavi potreba po novi barvi, senci, radiju ali animaciji, je predlog
napačen — `DESIGN.md` je nadrejen.

---

## 8. Datoteke v paketu

| Datoteka | Vsebina |
|---|---|
| `Znak Turnirko — Niz.dc.html` | oblikovalska referenca (odpri v brskalniku): geometrija, masthead v obeh temah, velikosti |
| `support.js` | izvajalno okolje za zgornjo HTML datoteko (ne kopiraj v aplikacijo) |
| `znak-turnirko.svg` | znak s prosojno podlago |
| `favicon.svg` | favicon s podlago papirja, obe temi |
| `posnetki/01-znak-konstrukcija.png` | znak 240 px + konstrukcijska mreža + tabela koordinat |
| `posnetki/02-masthead-svetla-tema.png` | masthead 1280 px, svetla tema |
| `posnetki/03-velikosti-in-ploscice.png` | 16/20/24/48 px, favicon, temna ploščica, enobarvni tisk |
| `posnetki/04-masthead-temna-tema.png` | masthead 1280 px, temna tema |
