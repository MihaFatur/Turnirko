# Handoff: Turnirko — prenova mobilne navigacije, turnirjev in kategorij

## Pregled

Prenova mobilnega pogleda aplikacije Turnirko (vodenje namiznoteniških turnirjev). Rešuje tri težave, ki jih ima obstoječi vmesnik na telefonu:

1. **Navigacija** — vodoravno drsna vrstica zavihkov v glavi, kjer polovica postavk ni vidna. → Zamenja jo **spodnja vrstica** (Domov · Turnirji · Lige · Lestvica · Več) in **lepljiva glava** z nazaj/kontekstom.
2. **Previsoke vrstice** — vrstica turnirja se pri 390 px sesuje v dvostolpično mrežo, visoko 130–150 px; enako vrstica dogodka. → **Enovrstična postavitev**, 68–72 px.
3. **Dvojna končna razvrstitev** — zaključena kategorija prikaže sekcijo »Razvrstitev« (podij 1–3) IN sekcijo »Končni vrstni red« (celoten seznam), poleg tega pa še zavihek »Razvrstitev« z lestvico. → **Ena sekcija »Končna razvrstitev«**: prva tri mesta poudarjena na vrhu istega seznama. Ta sprememba velja **tudi na desktopu** (edina zahtevana sprememba desktop pogleda).

Cilj publike: **igralci in gledalci**. Dejanja urejevalca (nov turnir, nov dogodek, žreb, zaključi) niso več pred vsebino, ampak v lepljivi glavi.

## O datotekah v tem paketu

Datoteke `*.dc.html` so **oblikovalske reference, narejene v HTML** — prototipi, ki kažejo želen izgled in obnašanje. **Niso produkcijska koda za kopiranje.** Naloga je te postavitve poustvariti v obstoječem okolju aplikacije Turnirko (React + TypeScript + react-router + TanStack Query, slogi v `src/slog.css`) po njenih uveljavljenih vzorcih: razredi v `slog.css` (BEM v slovenščini), brez `border-radius`, brez senc, brez ikon razen logotipa, vse mere večkratnik 8.

V prototipu so slogi zapisani inline (tako pač deluje orodje, v katerem je narejen). **V Turnirku pripadajo v `src/slog.css`** kot novi razredi oz. razširitve obstoječih (`.kartica`, `.glava`, `.podnavigacija`, `.podij`, `.vrstni-red` …).

## Fidelity

**High-fidelity.** Barve, tipografija, mere in razmiki so končni in izpeljani iz obstoječega `src/slog.css` (isti žetoni). Rekonstrukcija naj bo pikselsko natančna — glej razdelek »Postopek primerjave«.

## Datoteke v paketu

| Datoteka | Kaj je |
|---|---|
| `Turnirko - prenova (mobile).dc.html` | **Cilj.** Štirje mobilni zasloni (390 × 844) + desktop popravek razvrstitve. |
| `Turnirko - trenutno stanje (mobile).dc.html` | Rekreacija **obstoječega** stanja pri 390 px z opisom napak — za primerjavo »prej/potem«. |
| `support.js` | Runtime, da se `.dc.html` odpre v brskalniku. Ni del implementacije. |
| `screenshots/01-turnirji.png` | Referenca: seznam turnirjev. |
| `screenshots/02-turnir-kategorije.png` | Referenca: stran turnirja s kategorijami. |
| `screenshots/03-kategorija-razvrstitev.png` | Referenca: zaključena kategorija z eno razvrstitvijo. |
| `screenshots/04-vec-predal.png` | Referenca: predal »Več«. |
| `screenshots/05-desktop-razvrstitev.png` | Referenca: desktop »Končna razvrstitev« (1120 px). |

Posnetki so v merilu 2× (784 × 1692 px za mobilne zaslone) — logično 390 × 844 px @2x.

## Datoteke v aplikaciji, ki se spremenijo

| Del | Datoteka | Kaj |
|---|---|---|
| Navigacija | `src/komponente/Postavitev.tsx` | Nova spodnja vrstica + lepljiva glava; `.glava__navigacija` na telefonu odpade. |
| Slogi | `src/slog.css` | Novi razredi za spodnjo vrstico, lepljivo glavo, znižane vrstice; popravki v `@media (max-width: 640px)`. |
| Seznam turnirjev | `src/strani/TurnirjiStran.tsx` | Naslov z mono nadnaslovom, filtri v en izbirnik, nova vrstica turnirja, dejanje v glavi. |
| Turnir | `src/strani/TurnirStran.tsx` | Kompaktna glava, kolofon 2 × 2, nova vrstica dogodka, dejanja v glavi. |
| Kategorija (dogodek) | `src/strani/DogodekStran.tsx` | Komponenta `Zakljucek` — združi `podij` + `Končni vrstni red` v eno sekcijo; podnavigacija takoj pod glavo. |
| Podnavigacija | `src/komponente/PodnavigacijaDogodka.tsx` | Pas se prestavi pod glavo strani, brez `povzetek` na telefonu. |

---

## Oblikovalski žetoni (iz `src/slog.css`, nespremenjeni)

Barve:

```
--barva-papir            #fbf9f5
--barva-namizje          #dcd8d1
--barva-crnilo           #14110f
--barva-crnilo-2         #332e29
--barva-crnilo-3         #5b534d
--barva-crnilo-4         #6e655e
--barva-crta             #ded7ce
--barva-polnilo          #ede7df
--barva-bela             #ffffff
--barva-glavna           #0088ce   (črte, palice, robovi)
--barva-glavna-polna     #0071ab   (ploskev pod besedilom)
--barva-glavna-tekst     #0071ab
--barva-glavna-mehko     #eaf3f9
--barva-poudarek         #7bb900
--barva-poudarek-tekst   #4a7500
--barva-poudarek-mehko   #eaf4d6
--barva-negativna        #b23a1e
```

Pisave: display `Bricolage Grotesque` (800 / 200), telo `Karla` (300/400/500/600/700), mono `IBM Plex Mono` (400/500/600).

Ritem: 4 / 6 / 8 / 10 / 12 / 16 / 20 / 24 / 32 px. `border-radius: 0` povsod. Brez senc. Zadetkovna površina vsaj 44 px.

**Nove mere, ki jih prinaša prenova (mobile ≤ 640 px):**

```
glava (lepljiva)          višina 56 px, padding 0 20px, pod njo 1 px črnilo + 3 px črnilo
spodnja vrstica           5 enakih stolpcev, višina postavke 60 px, border-top 3 px črnilo
vsebina                   padding 20px 20px 96px  (96 = 60 vrstica + 36 zrak)
naslov strani             mono nadnaslov 12 px + display 800 36 px (seznam), 32 px (podstran), 26 px (kategorija)
vrstica turnirja          grid 40px / 1fr / auto, gap 12 px, padding 12px 0 12px 10px, ~68 px
vrstica kategorije        grid 1fr / auto, gap 12 px, padding 12px 0 12px 10px, ~72 px
palica napredka           4 px (na mobilu; na desktopu ostane 6 px)
```

---

## Zaslon 1 — Turnirji (`/turnirji`)

Referenca: `screenshots/01-turnirji.png`

**Lepljiva glava** (`position: sticky; top: 0`, podlaga `#fbf9f5`):
- levo logotip: znak 22 px (`ZnakTurnirko`, obstoječa komponenta) + »Turnirko« Bricolage 800, 20 px, `letter-spacing: -0.02em`, gap 8 px;
- desno: `+ Turnir` (samo urejevalec) — mono 600 11 px, verzalke, `letter-spacing: .08em`, padding 8px 10px, ozadje `#0071ab`, rob 1 px `#0088ce`, besedilo belo, min-height 36 px; nato prožilnik uporabnika »MN ▾« mono 500 12 px verzalke `#14110f`, min-height 44 px;
- pod glavo: `border-top: 1px solid #14110f`, `padding-top: 2px`, nato `div` višine 3 px `#14110f` (obstoječi vzorec `.glava__crta`).

**Naslov:**
- nadnaslov »TEKMOVANJA« mono 500 12 px, `letter-spacing: .12em`, verzalke, `#5b534d`;
- naslov »Turnirji« Bricolage 800 36 px, `line-height: .95`, `letter-spacing: -.035em`, margin-top 4 px.

**Vrstica krmil** (flex, space-between, gap 8 px, margin-top 12 px):
- izbirnik statusa: en gumb `VSI · 14 ▾`, mono 500 12 px verzalke `letter-spacing: .1em`, rob 1 px `#14110f`, brez ozadja, padding 10px 12px, min-height 44 px. Odpre nativni izbor / list vseh statusov (`Vsi`, `V teku`, `Priprava`, `Zaključeni`) z števci — nadomesti sedanje štiri gumbe `.izbirnik__gumb`;
- desno mono `OSVEŽENO 10:42`, 12 px, `#5b534d`.

**Sekcija »Danes v dvorani«** (samo če obstaja turnir v teku):
- naslovna vrstica: `border-top: 3px solid #14110f`, `padding-top: 10px`, naslov Bricolage 800 24 px, desno mono števec;
- vrstica turnirja v teku: `display: grid; grid-template-columns: 40px minmax(0,1fr) auto; column-gap: 12px; align-items: center; padding: 12px 12px 12px 10px; margin-top: 10px; border-left: 4px solid #0088ce; background: #eaf3f9`
  - datumski blok (sredinjen): dan mono 600 18 px `tabular-nums`, mesec mono 500 11 px verzalke `#5b534d`;
  - ime: 17 px / 700 / `line-height 1.2`, ena vrstica z `text-overflow: ellipsis`;
  - meta: mono 500 12 px `#5b534d`, ena vrstica z ellipsis, vsebina `13.–14. 8. · Celje` (obdobje · kraj);
  - palica napredka: višina 4 px, podlaga `#ffffff` (na modri ploskvi), polnilo `#0088ce`, margin-top 6 px;
  - značka statusa: mono 600 10 px verzalke, padding 5px 7px, `#0071ab` / belo.

**Sekcija »Vsi turnirji«:**
- enaka naslovna vrstica (3 px črta), desno skupno število;
- vrstice: ista mreža kot zgoraj, `padding: 12px 0 12px 10px`, `border-bottom: 1px solid #ded7ce`, `border-left: 4px solid` po statusu (`#ded7ce` priprava, `#0088ce` v teku, `#7bb900` zaključen), brez podlage;
- meta: `5. 9. · Ljubljana` (datum/obdobje · kraj) — število dogodkov je s telefona odpadlo, ostane na strani turnirja;
- status desno kot **mono 600 10 px verzalke** v barvi (`#5b534d` priprava, `#4a7500` zaključen); polna značka je rezervirana za »V teku«;
- palica napredka samo pri turnirjih v teku.

**Spodnja vrstica** (`position: fixed; bottom: 0`): 5 enakih stolpcev, podlaga `#fbf9f5`, `border-top: 3px solid #14110f`; postavka = flex center, min-height 60 px, mono 500 11 px verzalke `letter-spacing: .06em`, `#5b534d`; aktivna: `margin-top: -3px; border-top: 3px solid #0088ce; background: #eaf3f9;` mono 600, `#0071ab`. Postavke: Domov, Turnirji, Lige, Lestvica, **Več**. »Več« se izriše **samo administratorju ali organizatorju** (`jeAdmin || jeOrganizator`); gost in igralec vidita štiri. Upoštevaj `env(safe-area-inset-bottom)`.

## Zaslon 2 — Turnir (`/turnirji/:id`)

Referenca: `screenshots/02-turnir-kategorije.png`

**Lepljiva glava:** levo `← TURNIRJI` (mono 500 12 px verzalke `#5b534d`, puščica 15 px `#14110f`, min-height 44 px, ellipsis); desno `+ Dogodek` (samo urejevalec, isti slog kot `+ Turnir`) in `⋯` (mono, min-height 44 px) za preostala dejanja (Zaključi turnir, Listki za tiskanje). Pogoj »Mogoče šele, ko so zaključeni vsi dogodki« se pokaže v tem meniju kot onemogočena postavka s pojasnilom, ne več kot ločena vrstica v verzalkah.

**Glava strani:** vrstica z mono »TURNIR« + značka statusa; naslov Bricolage 800 32 px `line-height .98`, `overflow-wrap: break-word`; pod njim mono 500 13 px `#5b534d`: `13.–14. 8. 2026 · Celje, ŠD Golovec`.

**Kolofon 2 × 2** (namesto štirih vrstic oznaka/vrednost): `display: grid; grid-template-columns: 1fr 1fr; border-top: 1px solid #14110f`; celica levo `padding: 10px 12px 10px 0`, desna `padding: 10px 0 10px 12px; border-left: 1px solid #ded7ce`; vse celice `border-bottom: 1px solid #ded7ce`; oznaka mono 500 11 px verzalke `#5b534d`, vrednost mono 600 20 px `tabular-nums`. Postavke: Prijavljenih, Odigranih, Dogodki, Šteje v ELO.

**Sekcija »Kategorije«** (naslov ostane vsebinsko »Dogodki« v kodi, na zaslonu »Kategorije«):
- naslovna vrstica s 3 px črto, desno število;
- vrstica: `display: grid; grid-template-columns: minmax(0,1fr) auto; column-gap: 12px; padding: 12px 0 12px 10px; border-left: 4px solid <status>; border-bottom: 1px solid #ded7ce`
  - ime 17 px / 700;
  - meta mono 500 12 px `#5b534d`: `Sistem · prijave · odigrano` (npr. `Skup + izl · 8 skupin po 4 · 42/61`, `Krožni · 12 prijav · 66/66`, `Skupine · 24 prijav · žreb še ni izveden`);
  - palica 4 px samo pri dogodkih v teku;
  - status: polna značka za »V teku«, mono barvna oznaka za ostalo.
- Namig »Dogodek je eno tekmovanje …« se na telefonu ne izriše (prostor), ostane na desktopu.

## Zaslon 3 — Kategorija, zaključena (`/dogodki/:id`)

Referenca: `screenshots/03-kategorija-razvrstitev.png`

**Lepljiva glava:** `← NTK SAVINJA 2026` (ime nadrejenega turnirja, ellipsis) + `⋯`.

**Blok naslova** (del lepljive glave, ne drsi z vsebino):
- naslov Bricolage 800 26 px `line-height 1`, ellipsis, ob njem značka statusa;
- mono 500 12 px `#5b534d`: `Ženske · do 21 let · krožni · na 5 nizov`;
- **zavihki takoj pod tem** (prej je bil pas pod ~1400 px vsebine): vodoravno drsna vrsta, gap 4 px, `padding: 0 20px 10px`, `border-bottom: 1px solid #ded7ce`; gumb mono 500 11 px verzalke, padding 8px 12px, min-height 40 px; aktivni `background: #14110f; color: #fbf9f5`, neaktivni rob `#ded7ce`, besedilo `#5b534d`. Zavihki nosijo števce: `Razvrstitev`, `Tekme · 66`, `Udeleženci · 12` (pri sistemih z izločilnim delom `Skupine`, `Izločilni del`).

**»Končna razvrstitev« — ENA sekcija** (nadomesti `podij` + `Končni vrstni red`):
- naslov Bricolage 800 24 px, desno mono 11 px verzalke `12 igralk` (`white-space: nowrap`);
- **mesta 1–3**: `display: grid; grid-template-columns: 34px minmax(0,1fr) auto; column-gap: 12px; align-items: center; padding: 14px 0 14px 10px; border-bottom: 1px solid #ded7ce; border-left: 4px solid`
  - 1. mesto: črta `#7bb900`, podlaga `#eaf4d6`, klub v `#4a7500`
  - 2. mesto: črta `#0088ce`, podlaga `#eaf3f9`, klub v `#0071ab`
  - 3. mesto: črta `#14110f`, brez podlage, klub v `#5b534d`
  - številka mesta: Bricolage 800 26 px `letter-spacing -.04em`; ime 19 px / 700; klub in rating mono 500 12 px; desno bilanca mono 600 14 px `tabular-nums` (`11–0`) in pod njo ELO mono 600 12 px (`+38` zeleno `#4a7500`, `−18` rjasto `#b23a1e`);
- **mesta 4+**: ista mreža, `padding: 11px 0 11px 14px`, brez leve črte in podlage; številka mono 600 15 px desno poravnana `#5b534d`; ime 16 px / 500; klub mono 400 11 px `#6e655e`; bilanca mono 500 13 px `#332e29`; ELO mono 600 11 px barvno;
- **brez** medalj, ikon in dodatnih naslovov. Ne izrisuj več sekcije »Razvrstitev« s podijem in ne sekcije »Končni vrstni red«.

## Zaslon 4 — Predal »Več« (samo urejevalec)

Referenca: `screenshots/04-vec-predal.png`

Predal se dvigne nad spodnjo vrstico: zatemnitev `#14110f` pri `opacity .28` nad vsebino; ploskev `#fbf9f5` z `border-top: 3px solid #14110f`, `padding: 16px 20px 8px`, sedi na `bottom: 63px` (nad vrstico).
- naslov »Več« Bricolage 800 24 px, desno »ZAPRI« mono 500 12 px verzalke `#5b534d`, min-height 44 px;
- postavke: flex space-between, min-height 52 px, `padding: 12px 0`, `border-bottom: 1px solid #ded7ce`, oznaka 17 px / 600 `#14110f`, desno mono 11 px verzalke kontekst (`418`, `3 čakajo` v `#b23a1e`, `Kraji, klubi`);
- postavke: **Igralci** (admin/organizator), **Dostopi** (admin), **Šifranti** (admin);
- na dnu mono 11 px verzalke `#6e655e`: »Moj profil in odjava sta v meniju zgoraj desno«;
- v spodnji vrstici je »Več« medtem aktiven.

## Desktop — edina sprememba

Referenca: `screenshots/05-desktop-razvrstitev.png` (okvir 1120 px)

`Zakljucek` v `DogodekStran.tsx` naj namesto dveh sekcij izriše eno »Končna razvrstitev«:
- naslovna vrstica: 3 px črta, naslov 40 px, desno mono `12 igralk · bilanca · ELO`;
- mesta 1–3 v treh stolpcih (`repeat(3, minmax(0,1fr))`, gap 0): padding 16px 24px, leva črta 4 px (`#7bb900` / `#0088ce` / `#14110f`), podlaga mehka pri 1. in 2. mestu; številka Bricolage 800 40 px, ime 20 px / 700, klub 15 px / 300 barvno, pod njim mono 600 14 px `11 – 0 · +38`;
- mesta 4+ v dveh stolpcih (`gap: 0 56px`; pri več kot 40 udeležencih trije stolpci, kot doslej), vrstica `grid-template-columns: 56px minmax(0,1fr) 88px 72px; gap: 16px; padding: 12px 0; border-bottom: 1px solid #ded7ce` — to je obstoječi `.vrstni-red__vrstica`, nespremenjen;
- naslov »Razvrstitev« in `.podij` odpadeta; CSS `.podij*` lahko ostane, če ga uporablja kaj drugega, sicer ga odstrani.

---

## Obnašanje in stanje

- **Spodnja vrstica**: `NavLink` s `end` na `/`; aktivna postavka po `isActive`. Vidnost »Več« = `jeAdmin || jeOrganizator` (`useAvtentikacija`). Vrstica je `position: fixed`, zato dodaj `padding-bottom` vsebini (96 px) in `env(safe-area-inset-bottom)`.
- **Predal »Več«**: lokalno stanje `odprtVec`; zapre se s klikom na zatemnitev, na »Zapri« in na `Escape`; ob odprtju ujemi fokus (isti vzorec kot `ModalnoOkno`).
- **Lepljiva glava**: `position: sticky; top: 0; z-index: 10`; ne skriva se ob drsenju.
- **Izbirnik statusa** na Turnirjih: isto stanje `filter` kot doslej, le prikaz je en gumb, ki odpre seznam štirih možnosti s števci.
- **Zavihki kategorije**: obstoječa logika `PodnavigacijaDogodka` (pogledi se določijo po tem, kaj dogodek ima). `povzetek` na telefonu ne izrisuj — podatki so v zavihkih (`Tekme · 66`).
- **Osveževanje**: nespremenjeno (`refetchInterval` prek `intervalOsvezevanja`).
- **Prehodi**: samo barva/rob do 120 ms, kot doslej; predal »Več« brez animacije ali z 120 ms `translateY`.
- **Prelomna točka**: nova mobilna postavitev velja pri `max-width: 640px` (obstoječa točka v `slog.css`); nad njo ostane sedanja glava z navigacijo in trenutne vrstice — razen združene razvrstitve, ki velja na vseh širinah.
- **Dostopnost**: vsak cilj ≥ 44 px; spodnja vrstica `<nav aria-label="Glavna navigacija">`; predal `role="dialog" aria-modal="true"`; ohrani `aria-pressed` na zavihkih.

## Postopek primerjave (obvezno)

Implementacija ni končana, dokler se posnetki ne ujemajo z referencami.

1. Zaženi aplikacijo (`npm run dev`) in odpri poglede v brskalniku pri **390 × 844, deviceScaleFactor 2** (npr. Playwright, iPhone 12/13/14 profil, svetla tema).
2. Za vsak zaslon naredi posnetek celotnega okvirja aplikacije:
   - `/turnirji` → primerjaj s `screenshots/01-turnirji.png`
   - `/turnirji/:id` (turnir v teku, 5 kategorij) → `screenshots/02-turnir-kategorije.png`
   - `/dogodki/:id` (zaključena kategorija, krožni sistem) → `screenshots/03-kategorija-razvrstitev.png`
   - `/turnirji` z odprtim predalom »Več« (kot admin) → `screenshots/04-vec-predal.png`
   - `/dogodki/:id` pri širini 1120 px → `screenshots/05-desktop-razvrstitev.png`
3. Posnetke postavi **enega ob drugega** z referenco in preveri po tem seznamu:
   - višina glave 56 px, pod njo 1 px + 3 px črta;
   - višina postavke spodnje vrstice 60 px, 3 px črta nad njo, aktivna postavka modra s podlago `#eaf3f9`;
   - vrstica turnirja ≤ 72 px in **nič** se ne prekriva ali reže (preveri tudi ime dolžine 40 znakov);
   - velikosti pisav: naslov 36 / 32 / 26 px, ime v vrstici 17 px, meta mono 12 px, mesta 1–3 v razvrstitvi 26 px;
   - barve leve črte po statusu in barve ELO (`#4a7500` / `#b23a1e`);
   - nikjer vodoravnega drsenja strani: `document.documentElement.scrollWidth === innerWidth`;
   - v zaključeni kategoriji je **natanko ena** sekcija z razvrstitvijo.
4. Kjer se razlikuje, popravi CSS/JSX in **ponovi korake 2–3**. Iteriraj, dokler ni razlik, ki bi jih oko opazilo (razlike v podatkih so seveda pričakovane — primerjaj postavitev, mere, barve in tipografijo, ne imen igralcev).
5. Za konec preveri še 360 px in 430 px širino ter temno temo (`prefers-color-scheme: dark`) — nova postavitev mora vzdržati oboje z obstoječimi žetoni.

## Sredstva

Nič novega. Edina ikona ostane obstoječi `ZnakTurnirko` iz `src/komponente/Postavitev.tsx`. Pisave so že vgrajene lokalno (fontsource) — v prototipu so naložene z Google Fonts samo zato, da se datoteka odpre samostojno; v aplikaciji uporabi obstoječe.
