# Predaja: uvodna animacija Turnirka (1a · Poteze)

## Povzetek

Ob prvem odprtju strani v zavihku se čez celo okno pokaže papir z znakom Turnirka v sredini. Štiri poteze znaka se od leve proti desni »naložijo« (prve tri kot palice napredka), nato se prižge zelena, ob znaku se po črkah izpiše »Turnirko«, celoten logotip odleti točno na svoje mesto v glavi, črti glave (1 px in 3 px) se narišeta od leve proti desni, nazadnje se v vrstah dvigne vsebina strani. Logo pristane po **1,70 s**, vsa vsebina je na mestu po **≈ 2,7 s**. Vsebina se medtem nalaga v ozadju; dolžina animacije je **vedno enaka** (ni vezana na nalaganje).

Odločitve lastnika (Tweaks v prototipu):
- različica **1a · Poteze**,
- tempo **Srednje** (×1,0; vsi časi spodaj so že v tem tempu),
- **namizje in telefon**,
- **enkrat na sejo** (zavihek) — `sessionStorage`,
- ob `prefers-reduced-motion` **enaka animacija** (izrecna odločitev lastnika; glej razdelek »DESIGN.md«).

## O datotekah v paketu

Datoteke v `prototip/` so **oblikovni referenčni prototip v HTML**, ne produkcijska koda. Naloga je animacijo **poustvariti v obstoječem vmesniku** (`vmesnik/`, React + Vite, slogi v `slog.css`, komponente v `src/komponente/`) po hišnih vzorcih — ne kopirati HTML-ja. Domača stran pod animacijo v prototipu je prepis obstoječe `DomacaStran.tsx` (pogled gosta) in služi samo kot ozadje za primerjavo.

- `prototip/Turnirko uvodna animacija.dc.html` — prototip (logika je v `<script data-dc-script>` na dnu: razred `Component`, metoda `predvajaj()` je **vir resnice** za vse čase in krivulje). Odpri prek HTTP (`npx serve prototip`), ne `file://`. Ploščica spodaj levo: izbira 1a/1b in »Predvajaj znova«. Različica 1b (Odboj) je bila zavrnjena — ne implementiraj je.
- `prototip/support.js` — izvajalno okolje prototipa (samo za ogled).
- `posnetki/` — referenčni posnetki (28 PNG), glej razdelek »Primerjava s posnetki«.
- `primerjava/zajemi.mjs` — predloga skripte (Playwright + pixelmatch) za zajem in primerjavo.

## Natančnost

**Visoka (hi-fi).** Barve, pisave, mere, časi in krivulje so dokončni. Animacija mora biti posnetkom enaka do piksla (glej spodaj).

---

## Zgradba

### Kje živi

Nova komponenta `komponente/UvodnaAnimacija.tsx`, izrisana **v `Postavitev.tsx`** (ena za namizje in telefon), skozi portal v `document.body`. Merjenje glave mora potekati po izrisu `Postavitev` (`useLayoutEffect` + čakanje na pisave). Slogi v nov razdelek `slog.css` »Uvodna animacija« (razredi `.uvod`, `.uvod__podlaga`, `.uvod__znamka`, `.uvod__vrsta`, `.uvod__znak`, `.uvod__znak-notranji`, `.uvod__poteza`, `.uvod__duh`, `.uvod__polnilo`, `.uvod__napis`, `.uvod__merilo`, `.uvod__crka`). Glavo (`.glava__crta` ima danes `::after`) razdeli na dva elementa, ali animiraj `::after` posebej, da se črti 1 px in 3 px rišeta ločeno.

### Plasti (od spodaj navzgor)

1. Stran, kot je (`Postavitev` + trenutna stran). Med uvodom je logotip v glavi neviden, črti glave sta `scaleX(0)`, ciljni elementi vsebine `opacity: 0`.
2. `.uvod` — `position: fixed; inset: 0; z-index: 100` (nad maskoto, predalom in vsem drugim; pod nič), `aria-hidden="true"`, `pointer-events: auto` do pristanka.
3. `.uvod__podlaga` — `position: absolute; inset: 0; background: var(--barva-papir)`.
4. Centrirni ovoj (`position: absolute; inset: 0; display: flex; align-items: center; justify-content: center`) z `.uvod__znamka` v njem.

### Znamka (povečan logotip iz glave)

Znamka je **ista postavitev kot `.glava__logotip`, povečana k-krat**, da se ob pristanku z njim pokrije do piksla.

- Izmeri `.glava__logotip` v glavi: `fs` = font-size (24 px namizje, 20 px telefon), `razmik` = `column-gap` (10 / 8 px), `znak` = širina `svg` (24 / 22 px), `L` = `getBoundingClientRect()` logotipa.
- `W` = širina okna. `k = clamp(1.5, 5, W × (W ≤ 640 ? 0.82 : 0.56) / L.width)`.
- `.uvod__znamka`: `font-family: var(--pisava-display); font-weight: 800; font-size: fs×k px; letter-spacing: -0.02em; line-height: 1.5; color: var(--barva-crnilo); white-space: nowrap; transform-origin: 0 0;` in **`font-variation-settings: 'opsz' <fs>`**. Brez tega Bricolage pri velikosti fs×k izbere drugo optično velikost (os `opsz`) in besede v glavi se ne pokrijeta.
- `.uvod__vrsta`: `display: flex; align-items: center; gap: razmik×k px`.
- `.uvod__znak`: `position: relative; flex: none; width = height = znak×k px` (`S`). V njem `.uvod__znak-notranji` (`position: absolute; inset: 0; transform-origin: 50% 50%`) s štirimi potezami v odstotkih mreže 28 (iz `ZnakTurnirko`): `left` 5.357 % / 30.357 % / 55.357 % / 80.357 %, `top: 14.286%`, `width: 10.714%`, `height: 71.429%`. Vsaka poteza ima:
  - `.uvod__duh` (`position: absolute; inset: 0; opacity: 0`): poteze 1–3 `background: var(--barva-polnilo)` (#EDE7DF); poteza 4 `border: 1px dashed var(--barva-poudarek)` (#7BB900), brez podlage.
  - `.uvod__polnilo` (`position: absolute; inset: 0; transform-origin: 50% 100%; transform: scaleY(0)`): barve #14110F, #14110F, #0088CE, #7BB900.
- `.uvod__napis` (`position: relative; clip-path: inset(-50% -20% 0 -20%)`): vsebuje `.uvod__merilo` (`visibility: hidden`, besedilo »Turnirko« kot EN tekstovni vozel) in 8 `.uvod__crka` (`position: absolute; top: 0; opacity: 0`, po ena črka). **Položaj črk**: za vsak znak i izmeri `Range` (setStart/setEnd na tekstovnem vozlu merila) in nastavi `left = range.left − napis.left`. Tako črke stojijo točno tam kot v celi besedi s spodsekavanjem (kerning) — brez tega logo ob pristanku poskoči.
- Po merjenju: `Z` = `getBoundingClientRect()` znamke (brez transformov), `odmik = (Z.width − S) / 2`, `dx = L.left − Z.left`, `dy = L.top − Z.top`.

---

## Časovnica (ms, tempo Srednje)

Vse animacije so Web Animations API, `fill: 'both'`; animirata se samo `transform` in `opacity` (in `clip-path` je statičen). Krivulje:
- `IZHOD` = `cubic-bezier(.2,.8,.2,1)`
- `INOUT` = `cubic-bezier(.65,0,.35,1)`
- `POLET` = `cubic-bezier(.7,0,.2,1)`

| Element | Od (zamik) | Trajanje | Ključne sličice | Krivulja |
|---|---|---|---|---|
| Duh poteze 1, 2, 3 | 20 / 50 / 80 | 200 | opacity 0 → 1 | ease-out |
| Duh poteze 4 (zelena črtkana) | 20 | 800 | opacity 0 → 1 (25 %) → 0.35 (56.25 %) → 1 (77.5 %) → 1 (85 %) → 0 (97.5 %) → 0 | linear |
| Polnilo 1, 2, 3 | 100 / 220 / 340 | 320 | scaleY 0 → 0.58 (45 %, segment `cubic-bezier(.3,0,.2,1)`) → 1 (segment `cubic-bezier(.5,0,.2,1)`) | po segmentih |
| Polnilo 4 — zelena se prižge | 660 | 360 | scaleY 0 → 1.12 (50 %, `cubic-bezier(.2,.9,.3,1)`) → 0.97 (78 %, ease-in-out) → 1 (ease-out) | po segmentih |
| Sunek znaka (`.uvod__znak-notranji`) | 680 | 450 | scale 1 → 1.07 (30 %) → 1 | `cubic-bezier(.3,.7,.3,1)` |
| Vrsta (`.uvod__vrsta`) — znak se umakne levo | 760 | 380 | translateX(odmik px) → 0 | INOUT |
| Črke i = 0…7 | 800 + i × 22 | 340 | opacity 0 → 1, translateY(80%) → 0 | IZHOD |
| Polet znamke | 1240 | 460 | translate(0,0) scale(1) → translate(dx, dy) scale(1/k) | POLET |
| Papir (`.uvod__podlaga`) | 1340 | 420 | opacity 1 → 0 | ease |
| Tanka črta glave (1 px) | 1400 | 500 | scaleX 0 → 1, `transform-origin: 0 50%` | INOUT |
| Debela črta glave (3 px) | 1480 | 500 | scaleX 0 → 1, `transform-origin: 0 50%` | INOUT |
| Logotip v glavi | 1700 | 1 | opacity 0 → 1 (takojšnja menjava) | — |
| Znamka | 1730 | 1 | opacity 1 → 0 | — |
| Vsebina, element z indeksom n | 1540 + n × 30 | 500 | opacity 0 → 1, translateY(14px) → 0 | IZHOD |
| Spodnja vrstica (telefon) | 1540 | 500 | translateY(100%) → 0 | IZHOD |

**Konec**: ob koncu animacije logotipa (1700) dobi `.uvod` `pointer-events: none`. Ko se končajo **vse** animacije (`Promise.all(animacije.map(a => a.finished))`), se `.uvod` odstrani, vse animacije strani pa se `cancel()`-ajo (končno stanje je enako naravnemu, zato ni skoka). Konca ne veži na `setTimeout`, ampak na `finished`: zajem posnetkov animacije ustavi in pospravljanje mora počakati.

### Vrstni red vsebine (indeks n)

Domača stran (ista kot prototip; atribut `data-uvod` v prototipu):
- **Namizje**: povezave navigacije 0–3, »Gost · prijava« 4, naslovni vrstici »Turnirji« in »Lige« 5, vrstice turnirjev 6–9, kartice lig 6–7, naslovna vrstica »Lestvica« 10, opis lestvice 11, glava tabele 12, vrstice 13–20.
- **Telefon**: »Gost · prijava« 0, »Turnirji« 1, vrstice turnirjev 2–5, »Lige« 6, kartice lig 7–8, »Lestvica« 9, opis 10, vrstice 11–18.

Druge strani: navigacija in uporabnik kot zgoraj, nato neposredni otroci `.vsebina > section` (in vrstice njihovih seznamov), ki so v prvem zaslonu, oštevilčeni po navpičnem položaju (`top`). Kar je pod prvim zaslonom, se samo pokaže (brez animacije).

### Robni primeri

- **Enkrat na sejo**: ključ `sessionStorage['turnirko-uvod-predvajan'] = '1'`, zapisan ob začetku predvajanja. Če ključ obstaja, se uvod ne izriše (ne prikaži ga niti za en okvir). Uvod velja za prvo nalaganje aplikacije, ne za premike med stranmi.
- **Pisave**: pred merjenjem počakaj `document.fonts.load()` za `800 24px` in `800 120px` Bricolage, `400 16px` in `700 19px` Karla, `500 12px` in `600 16px` IBM Plex Mono, največ 2,5 s. Do takrat je viden samo papir.
- **Skrit zavihek**: začni šele, ko je `document.visibilityState === 'visible'` (sicer počakaj na `visibilitychange`).
- **Drsenje**: ob začetku `scrollTo(0, 0)`; med uvodom je `body` brez drsenja (`overflow: hidden`), ob koncu se vrne.
- **Telefon na podstrani brez logotipa** (glava s puščico »←«): ni cilja za polet. Znamka ob 1240 namesto poleta zbledi (opacity 1 → 0, scale 1 → 0.96, 300 ms, INOUT), vse ostalo ostane enako.
- **Maskota (5b)** in **oglas Premium (5c)** se med uvodom ne smeta pokazati; urnik maskote začne šteti po koncu uvoda.
- **Fokus**: uvod je `aria-hidden`, fokusa ne prevzame; ozadje dobi `inert` do pristanka (1700).

---

## Žetoni (vsi obstajajo v `slog.css`)

- Papir `--barva-papir` #FBF9F5 (podlaga uvoda), namizje `--barva-namizje` #DCD8D1
- Črnilo `--barva-crnilo` #14110F (poteze 1–2, napis, črti glave)
- Glavna `--barva-glavna` #0088CE (poteza 3)
- Poudarek `--barva-poudarek` #7BB900 (poteza 4, črtkani duh)
- Polnilo `--barva-polnilo` #EDE7DF (duhovi potez 1–3)
- Pisave: `--pisava-display` (Bricolage Grotesque, 800, opsz), `--pisava-telo`, `--pisava-mono`
- Radij 0, brez senc, brez gradientov.

## DESIGN.md — nova izjema (vpiši kot 5e in jo omeni v točki 12 razdelka 5)

> **5e. Izjema: uvodna animacija.** Odločitev lastnika, 22. 10. 2026. Ob prvem nalaganju aplikacije v zavihku (enkrat na sejo, `sessionStorage`) papir čez celo okno pokaže znak Turnirka: poteze se naložijo od leve proti desni, prižge se zelena, izpiše se »Turnirko«, logotip odleti na svoje mesto v glavi, črti glave se narišeta, vsebina se dvigne. Trajanje je stalno: logo pristane ob 1,7 s, konec je pod 3 s (WCAG 2.2.2). Animirata se samo `transform` in `opacity`; barve, pisave in oblike so hišne (radij 0, brez senc in gradientov). Predvaja se tudi ob `prefers-reduced-motion` (odločitev lastnika, kot pri 5b). Uvod je `aria-hidden`, ne prevzame fokusa in ne zakasni nalaganja podatkov. Drugih uvodnih ali prehodnih animacij ni.

---

## Primerjava s posnetki — obvezno, dokler se ne ujemata popolnoma

`posnetki/` vsebuje 14 sličic za vsak pogled, posnetih iz prototipa pri točno določenih časih časovnice (animacije ustavljene z `animation.pause(); animation.currentTime = t`, drsniki skriti):

- `namizje-XXXXms.png` — okno **924 × 540**, gost, domača stran.
- `telefon-XXXXms.png` — okno **390 × 492**, gost, domača stran.
- Časi: 0, 150, 300, 450, 600, 750, 900, 1050, 1240, 1450, 1700, 1900, 2200, 3200 ms.

Podatki na posnetkih so vzorčni in so v prototipu (`TURNIRJI`, `LIGE`, `IGRALCI` v logiki). Za primerjavo postrezi aplikacijo z **enakimi podatki** (prestrezi odgovore API-ja v Playwrightu: `page.route` za `turnirji`, `domov/lige`, `lige`, `statistika/lestvica`, `domov/turnirji`) in stalnim spolom lestvice (»Moški · Člani«; naključni spol v `DomacaStran` za zajem fiksiraj). Koledar in »Ena na ena« sta pod prvim zaslonom in nista del primerjave.

Postopek (ponavljaj, dokler skripta ne javi »UJEMA SE«):

1. Postrezi prototip prek HTTP in z `primerjava/zajemi.mjs prototip` preveri, da tvoje okolje (Chromium, pisave, `deviceScaleFactor: 1`) reproducira posnetke. Če se prototip sam s seboj ne ujema s PNG-ji, je razlika v okolju (pisave, glajenje): takrat je merilo **prototip, zajet v istem brezglavem Chromu** (kot je za `/o-ratingu` zapisano v `CLAUDE.md`), PNG-ji pa so vizualna kontrola.
2. Implementiraj, zaženi `zajemi.mjs aplikacija`, odpri slike `razlika-*.png`.
3. Popravi vsako razliko: položaj in velikost znamke (k, opsz, črke prek `Range`), čase in krivulje iz tabele, vrstni red vsebine, črti glave.
4. Ponavljaj. Sprejemljivo je največ **0,05 % pikslov** razlike na sličico (samo glajenje robov); vsaka vidna razlika v položaju, barvi ali času je napaka. Ne zaključi, dokler ni vseh 28 sličic znotraj meje.
5. Na koncu ročno preveri na namizju (1280+ px, kjer se ob straneh pokaže namizje #DCD8D1) in na pravem telefonu, da se uvod pokaže samo enkrat na zavihek.
