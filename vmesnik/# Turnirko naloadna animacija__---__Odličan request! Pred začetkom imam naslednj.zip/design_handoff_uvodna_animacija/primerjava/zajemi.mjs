// Zajem in primerjava uvodne animacije s posnetki v ../posnetki.
// Predloga za Claude Code; prilagodi URL-je in izbor (gumb ponovitve velja samo za prototip).
//
//   npm i -D playwright pixelmatch pngjs
//   npx serve ../prototip -l 5050        (prototip mora teči prek HTTP, ne file://)
//   node zajemi.mjs prototip             -> zajem prototipa (kontrola, ali okolje ujame posnetke)
//   node zajemi.mjs aplikacija           -> zajem implementacije in primerjava
//
// Časi so v ms na časovnici animacije (tempo »Srednje«, ×1,0).
import { chromium } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'
import { PNG } from 'pngjs'
import pixelmatch from 'pixelmatch'

const CASI = [0, 150, 300, 450, 600, 750, 900, 1050, 1240, 1450, 1700, 1900, 2200, 3200]
const POGLEDI = [
  { ime: 'namizje', viewport: { width: 924, height: 540 }, isMobile: false },
  { ime: 'telefon', viewport: { width: 390, height: 492 }, isMobile: true },
]
const CILJ = process.argv[2] ?? 'aplikacija'
const URL = {
  prototip: 'http://localhost:5050/Turnirko%20uvodna%20animacija.dc.html',
  aplikacija: 'http://localhost:5173/', // vite dev; gost, brez sessionStorage
}[CILJ]
const IZHOD = path.resolve('zajem-' + CILJ)
fs.mkdirSync(IZHOD, { recursive: true })

const brskalnik = await chromium.launch()
let napak = 0
for (const pogled of POGLEDI) {
  const stran = await brskalnik.newPage({ viewport: pogled.viewport, isMobile: pogled.isMobile, deviceScaleFactor: 1 })
  // Vsak zajem je nova seja: uvod se mora predvajati.
  await stran.addInitScript(() => sessionStorage.clear())
  await stran.goto(URL)
  await stran.addStyleTag({ content: '*{scrollbar-width:none}*::-webkit-scrollbar{display:none}' })
  if (CILJ === 'prototip') {
    // Prototip pri 390 px sam izbere telefonski pogled (»Samodejno«). Ploščico za izbiro skrij.
    await stran.evaluate(() => {
      const gumb = [...document.querySelectorAll('button')].find((b) => b.textContent.includes('Predvajaj'))
      gumb.parentElement.style.display = 'none'
    })
  }
  // Počakaj, da uvod ustvari animacije (po nalaganju pisav).
  await stran.waitForFunction(() => document.getAnimations().length > 20, null, { timeout: 8000 })
  for (const ms of CASI) {
    await stran.evaluate((t) => document.getAnimations().forEach((a) => { a.pause(); a.currentTime = t }), ms)
    await stran.waitForTimeout(120)
    const ime = `${pogled.ime}-${String(ms).padStart(4, '0')}ms.png`
    const pot = path.join(IZHOD, ime)
    await stran.screenshot({ path: pot })
    const ref = path.resolve('../posnetki', ime)
    if (fs.existsSync(ref)) {
      const a = PNG.sync.read(fs.readFileSync(ref))
      const b = PNG.sync.read(fs.readFileSync(pot))
      if (a.width !== b.width || a.height !== b.height) { console.log(`${ime}: velikost ${b.width}x${b.height} ≠ ${a.width}x${a.height}`); napak++; continue }
      const razlika = new PNG({ width: a.width, height: a.height })
      const n = pixelmatch(a.data, b.data, razlika.data, a.width, a.height, { threshold: 0.1 })
      fs.writeFileSync(path.join(IZHOD, 'razlika-' + ime), PNG.sync.write(razlika))
      const delez = (100 * n) / (a.width * a.height)
      console.log(`${ime}: ${n} px (${delez.toFixed(3)} %)`)
      if (delez > 0.05) napak++
    }
  }
  await stran.close()
}
await brskalnik.close()
console.log(napak ? `NE UJEMA SE: ${napak} posnetkov` : 'UJEMA SE')
process.exit(napak ? 1 : 0)
