# Handoff: Celozaslonski oglas »Igralec Premium«

## Pregled
Celozaslonski oglas (popup) za naročnino **Igralec Premium** v Turnirku. Pokaže se, ko igralec brez Premiuma klikne zaklenjeno funkcijo (**spremljanje / urejanje lig** ali **zasebna statistika**). Obstajajo **tri različice** (1a Zavesa, 1b Ključavnica, 1c Končni izid), vsaka v postavitvi za **namizje (1280×800)** in **telefon (390×844)**.

**Ob vsakem odprtju se naključno izbere ena od treh različic** (`Math.random()`; enaka verjetnost 1/3). Postavitev (namizje / telefon) se izbere po širini zaslona (telefon < 768 px).

## O datotekah
Datoteke v `design/` so **referenčni prototipi v HTML** (ne produkcijska koda). Naloga je, da jih **na novo implementiraš v obstoječi kodi `vmesnik/`** (React + TypeScript, `slog.css`) po njenih vzorcih: CSS razredi v `slog.css` po BEM (`.premium-oglas__…`), komponente v `src/komponente/`, cene iz `src/api/tipi.ts`, maskota po vzoru `MaskotaPrizori.tsx`.

Prototip odpreš tako, da `design/Premium popup.dc.html` odpreš v brskalniku (potrebuje `support.js` v isti mapi). V njem so vse tri različice drug ob drugem. Gumb »Ponovi animacijo« ponovno zažene animacije.

## Natančnost: HI-FI — ujemanje s posnetki je obvezno
Oblikovanje je končno: barve, pisave, velikosti, razmiki in animacije.

**Postopek preverjanja (obvezen):**
1. Implementiraj različico.
2. Naredi posnetek zaslona svoje implementacije v **enaki velikosti okna** (namizje 1280×800 pri 1×; telefon 390×844 — posnetki v mapi so pri 2×, torej 780×1688) in v **končnem stanju animacije** (počakaj ≥ 5 s ali izklopi animacije z `prefers-reduced-motion`).
3. Primerjaj s posnetkom v `screenshots/` (vizualno ali s pixel-diff orodjem, npr. `pixelmatch` / Playwright `toHaveScreenshot`).
4. Popravljaj in ponavljaj, **dokler se posnetka popolnoma ne ujemata**: postavitev, velikosti pisave, prelomi vrstic, barve, obrobe, položaj maskote, ključavnice, nalepk in žigov. Ne zaključi, dokler je razlika vidna.
5. Ponovi za vseh 6 zaslonov.

Posnetki so v privzetem stanju: kontekst **zasebna statistika**, uporabnik **gost**, cikel **Letno**, U21 **izklopljen**.

| Posnetek | Zaslon |
|---|---|
| `screenshots/1a-zavesa-namizje.png` | 1a, 1280×800 |
| `screenshots/1a-zavesa-telefon.png` | 1a, 390×844 @2× |
| `screenshots/1b-kljucavnica-namizje.png` | 1b, 1280×800 |
| `screenshots/1b-kljucavnica-telefon.png` | 1b, 390×844 @2× |
| `screenshots/1c-koncni-izid-namizje.png` | 1c, 1280×800 |
| `screenshots/1c-koncni-izid-telefon.png` | 1c, 390×844 @2× |
| `screenshots/_pregled.png` | vseh šest skupaj (samo za pregled) |

Za točne mere je **vir resnice HTML** (`design/Premium popup.dc.html`). Vsi slogi so inline, zato lahko vrednosti prepišeš neposredno. Posnetki kažejo samo končno stanje; potek animacije je opisan spodaj in v JS kodi prototipa.

---

## Skupno vsem različicam

### Podatki / logika
- Cene iz `src/api/tipi.ts`: `CENA_PREMIUM_MESECNO = { mlajsi: 3.99, starejsi: 4.99 }`, `CENA_PREMIUM_LETNO = { mlajsi: 42.99, starejsi: 53.49 }`.
- Izpeljane vrednosti (pas = `u21 ? 'mlajsi' : 'starejsi'`):
  - `cena` = CENA[cikel][pas]
  - `sidro` = MESECNO[pas] × 12 (59,88 €), izpisano prečrtano
  - `prihranek` = sidro − LETNO[pas] (6,39 €)
  - `naTeden` = letno ? cena/52 : cena×12/52 (1,03 €)
- Oblika zneska: `toLocaleString('sl-SI', {minimumFractionDigits:2, maximumFractionDigits:2}) + '\u00a0€'` (nedeljivi presledek).
- **Stanje:** `cikel: 'LETNO' | 'MESECNO'` (privzeto **LETNO**), `u21: boolean` (privzeto false), `zapriViden` (false → true po **2000 ms**).
- **Kontekst** (kaj je sprožilo oglas): `'statistika' | 'lige'`. Besedila za vsak kontekst so v objektu `KONTEKST` v JS prototipa (oznaka, naslovi, značke, predogled, poudarjena vrstica v primerjavi). Prepiši jih dobesedno.
- **Uporabnik:** `gost` (ni prijavljen) ali `igralec` (prijavljen, paket FREE).
  - gost: CTA `Ustvari račun · Premium {cena}` → tok za ustvarjanje računa (`RegistracijaTok`) s predizbranim Premiumom in izbranim ciklom. Sekundarna povezava: `Že imaš račun? Prijavi se →` → prijava.
  - igralec: CTA `Nadgradi na Premium · {cena}` → Stripe checkout za izbrani cikel. Sekundarna povezava: `Primerjaj in spremeni paket v Naročnini →` → stran Naročnina (`NarocninaStran`).
- **Socialni dokaz:** `412 igralcev iz tvojega kluba že ima Premium`. **Številka je izmišljena**: nadomesti jo s pravim podatkom iz API-ja, ali pa vrstico skrij, če podatka ni. Začetnice v kvadratkih (MK, AŽ, TP, +N) so prav tako le primer.
- »Ne zdaj ×«: ob odprtju `opacity:0; pointer-events:none`, po 2 s prehod `opacity 300ms`. Klik zapre oglas. Zapiranje z Esc naj deluje po 2 s.
- Izbirnik Mesečno/Letno: dva gumba v mreži `1fr 1fr`, gap 8, višina 44, `border-radius:0`. Na gumbu Letno je diagonalni trak `−10%` (80×16, `rotate(45deg)`, `top:10px; right:-22px`, `overflow:hidden` na gumbu).
- U21 stikalo: kvadratek 20×20, obroba 2 px. Ko je vklopljeno: polnilo #7BB900, ozadje #EAF4D6, obroba #4A7500. Besedilo: `Mlajši od 21? Plačaš samo {cena_mlajsi}` oz. `Cena do 21. leta: {…} na leto/mesec`.
- Dostopnost: `role="dialog" aria-modal="true"`, fokus ob odprtju na CTA, pri `prefers-reduced-motion: reduce` brez animacij (takoj končno stanje).

### Oblikovni žetoni
- Barve: črnilo `#14110F`, papir `#FBF9F5`, bela `#FFFFFF`, glavna `#0071AB`, glavna svetla `#0088CE`, glavna temna `#005A88`, poudarek (zelena) `#7BB900`, zelena temna `#4A7500`, zelena svetla `#EAF4D6` / `#E8F5C4`, modra svetla `#EAF3F9`, sivine `#332E29 #4A433D #5B534D #6E655E #9A9189 #B9B0A6 #DED7CE`.
- Pisave: **Bricolage Grotesque** (200/800, naslovi, `letter-spacing` −0.02 do −0.05em), **Karla** (300/400/600/700, besedilo), **IBM Plex Mono** (500/600/700, oznake z VELIKIMI črkami, `letter-spacing .06–.12em`, 12 px).
- Brez zaobljenih robov in brez senc (`border-radius:0` povsod).
- Logotip: 4 navpični pasovi 3×20 v 28×28 (bela, bela, #0088CE, #7BB900; na svetlem ozadju sta prva dva #14110F; pri 1b je tretji #14110F).

### Maskota
Stickman iz `MaskotaPrizori.tsx` (bela glava r7, zeleni trak s pentljo, **modra majica #0071AB**, črne hlačke, zelene zapestnice). V `design/Maskota.dc.html` so poze `zavesa` in `semafor` (1a, 1c), v `design/Prizor kljucavnica.dc.html` pa celoten prizor 1b. SVG geometrijo prenesi 1:1.

---

## 1a — Zavesa
**Namizje:** ozadje #14110F. Glava 72 px (padding 0 40, spodnja obroba 1 px #332E29): logotip + oznaka `ZAKLENJENO · …` (ozadje #0071AB) + »Ne zdaj«. Pod njo mreža `minmax(0,1fr) 500px`.
- **Levo (predogled):** padding 32/32/40/40; papirnat panel. Na vrhu trak 40 px #005A88 (`SAMO ZA PREMIUM` | ime funkcije), pod njim naslov 40 px, nato 4 vrstice, v katerih so vrednosti zamegljene `filter: blur(6px)`. Na desnih 44 % panela je **zavesa**: `repeating-linear-gradient(90deg,#0071AB 0 34px,#005A88 34px 48px)`, leva obroba 3 px #14110F. Maskota (213×230) stoji na robu zavese in jo drži.
- **Desno (prodaja):** papir, padding 36/40/32, gap 16:
  - Naslov: `Zavesa gor.` (200, 40 px), pod njim kratek naslov (800, 64 px, lh .86).
  - 3 črne značke (mono 12).
  - Nato z `margin-top:auto` izbirnik.
  - Cena 92 px/800; pod njo mono vrstica `NA LETO · NAMESTO ~~59,88 €~~ · 1,03 € NA TEDEN`.
  - **Zelena nalepka** `PRIHRANIŠ / 6,39 €` (obroba 3 px črnilo, `rotate(7deg)`, `right:-8px; top:14px`, `pointer-events:none`), samo pri Letno.
  - U21; nato vrstica ločena s 3 px črto zgoraj: socialni dokaz, CTA 56 px #0071AB, povezava.

**Telefon:** glava 56 px; panel predogleda 292 px (zavesa od 52 %, maskota 139×150). Pod njim papirnat del (padding 20/16/16), v njem si sledijo:
- naslov 26/34 px;
- izbirnik;
- cena 40 px s prečrtanim sidrom;
- vrstica z ceno na teden;
- U21;
- spodaj (`margin-top:auto`, 3 px črta) socialni dokaz, CTA 52 px in povezava.

**Animacija:**
- **Zavesa:** začne v `translateX(-127%)` (namizje) oz. `-108%` (telefon), 20 % časa miruje, nato zdrsne na 0. Trajanje 1800 ms, `cubic-bezier(.5,0,.2,1)`.
- **Maskota:** se premika z zaveso. Leva roka vleče, po 1800 ms desna podlaket dvakrat pomaha, glava se nagne.
- **Nalepka:** priletí z zamikom 1700 ms v 420 ms (`scale 2.8 rotate(-10°)` → `scale .9 rotate(7°)` → `scale 1`, `cubic-bezier(.6,0,.9,.4)`).

## 1b — Ključavnica
**Namizje:** ozadje #0071AB. Glava 72 px (oznaka ima ozadje #FBF9F5 in besedilo #0071AB, »Ne zdaj« ima belo obrobo). Mreža `600px minmax(0,1fr)`.
- **Levo:** prizor 560×342, `left:24; bottom:124` (SVG viewBox 0 0 360 220, tla na y=199).
- **Desno** (padding 48/64/40/24, navpično sredinsko):
  - `Odkleni` 200/44 + glavni naslov 800/76 v beli;
  - uvod 17 px;
  - vrstica z 1 px belo črto: **cena na teden 104 px** + 3 mono vrstice;
  - izbirnik z belimi obrobami (izbran: ozadje #FBF9F5, besedilo #0071AB);
  - U21;
  - blok z 1 px belo črto: socialni dokaz (prvi kvadratek ima ozadje #FBF9F5 in besedilo #0071AB, obrobe kvadratkov #0071AB, besedilo belo), **CTA 60 px #7BB900 z besedilom #14110F in spodnjo obrobo 4 px #14110F**, povezava (bela, podčrtana) in `STRIPE · PREKLIC KADARKOLI`.

**Telefon:** oznaka zgoraj levo; prizor 346×212 v 300 px visokem pasu; naslov 28/44; cena na teden 64 px; izbirnik; U21; spodaj (`margin-top:auto`) dokaz, CTA 56 px in povezava.

**Prizor (SVG, prenesi iz `Prizor kljucavnica.dc.html`):**
- **Ključavnica:** telo 90×104 #14110F, na vrhu 12 px trak, notranji okvir #332E29, 4 zakovice, ključavnica (krog r11 + trapez), napis `PREMIUM` mono 9 px #7BB900.
- **Lok:** debelina 16, desni krak je daljši in je os vrtenja; svetel rob #B9B0A6.
- **Ključ:** držalo je zelen lopar (r18) s kvadratno luknjo, steblo #FBF9F5 in dva zoba. Steblo je obrezano s `clipPath` pri x=259 (sredina ključavnice), zato izgleda, kot da gre v ključavnico.

**Časovnica (skupaj 4700 ms, vse s `fill: both`):**
| ms | dogodek |
|---|---|
| 0–910 | maskota priteče z leve (−230 px → −56 px) s ključem pred sabo; noge ±24°, poskakovanje −7 px, pentlja plapola |
| 910–1180 | zamah nazaj (−72 px, nagib −9°), usta ravna črta |
| 1180–1350 | sunek: ključ gre v ključavnico (0 px), ključavnica se strese +5 px |
| 1350–2420 | **ključ miruje v ključavnici** (namerna pavza) |
| 2420–2910 | ključ se obrne (`scaleY 1 → 0.08 → −1`), zapestje se zasuka −14° |
| 2930 | **KLIK**: odprtina ključavnice in trak postaneta zelena (trak utripne v #FBF9F5), telo poskoči za 3 px, lok skoči za 26 px (z nihajem −8 px) |
| 2950–3200 | pojavi se napis `KLIK!` (Bricolage 800 40 px, #7BB900, obroba 7 px #14110F, −9°), iskre, 10 konfetov |
| 3220–3600 | lok se odpre okoli desnega kraka (`scaleX −1 → 1.12 → 1`) |
| 3260–4000 | maskota spusti ključ, obe roki gresta v zrak, dva skoka (−26 px, −12 px) in pomežik |

Točne keyframe vrednosti so v `igraj()` v `Prizor kljucavnica.dc.html` (funkcija `w()` preslika odmike v čas). Končno stanje (brez animacije) je odprta ključavnica, v kateri je ključ, in maskota z rokama v zraku, ki mežika.

## 1c — Končni izid
**Namizje:** ozadje #FBF9F5. Glava s padding 24/40, pod njo dvojna črta (1 px + 3 px #14110F). Mreža `minmax(0,1fr) 420px`, gap 48.
- **Levo:**
  - pas 140 px: mono oznaka, uvod in maskota v pozi `semafor` (148×160, desno; žonglira z žogico);
  - **izid**: vrstica s 3 px črto, `Free` (siva) | **`2 : 6`** (Bricolage 800 144 px; 2 #6E655E, 6 #0071AB) | `Premium` (modra);
  - žig `PREMIUM ZMAGA`: obroba 3 px #4A7500, ozadje #EAF4D6, `rotate(-8deg)`, `left:56%; top:-20px`;
  - primerjalna tabela s 6 vrsticami (stolpca Free/Premium po 112 px; Premium stolpec ima ozadje #EAF3F9). Vrstica, ki ustreza kontekstu, ima levo obrobo 4 px #0088CE in krepko pisavo.
- **Desno — »Listek«:** bela kartica z 1 px obrobo.
  - Glava #14110F: `LISTEK · IGRALEC PREMIUM` | `STRIPE` (#7BB900).
  - Izbirnik.
  - **Račun:**
    - `12 × 4,99 €` … ~~59,88 €~~ (siva, črtkana ločnica);
    - `Letni popust −10 %` … `−6,39 €` (zelena #4A7500, 600);
    - 3 px črta, nato `SKUPAJ NA LETO` + `1,03 € NA TEDEN` | **53,49 €** (56 px).
  - **Zelen trak #7BB900**: `Prihraniš 6,39 €` (Bricolage 800 22 px) | `VEČ KOT MESEC / ZASTONJ`.
  - Pri Mesečno namesto teh dveh blokov vrstica `1 mesec … 4,99 €` in črtkan zelen gumb `Z letnim paketom prihraniš 6,39 € →`, ki preklopi na Letno.
  - U21.
  - Črtkana ločnica 2 px.
  - Socialni dokaz, CTA in povezava.
- Pod kartico: `VARNO PLAČILO · PREKLIC KADARKOLI`.

**Telefon:**
- Zgoraj oznaka, maskota in žig. Izid 80 px, tabela, izbirnik, U21 in kratek račun (dve vrstici) se pomikajo.
- **Fiksna spodnja vrstica** (bela, zgornja obroba 3 px):
  - socialni dokaz;
  - cena 32 px + `NA LETO` | zelena značka `PRIHRANIŠ 6,39 €` (pri Mesečno `{naTeden} / TEDEN`);
  - CTA 52 px in povezava.

**Animacija:**
- Izid se **šteje od 0:0 do 2:6** v zaporedju točk `P F P P F P P P`. Prva točka pade pri 400 ms, prvih pet v razmikih po 210 ms, zadnje tri po 170 ms. Ob vsaki točki številka poskoči (`translateY(-10px) scale(1.18)` → none, 220 ms).
- Pri **2150 ms** pade žig `PREMIUM ZMAGA` (420 ms, `scale 2.6 rotate(-14°)` → `scale .92` → 1, `cubic-bezier(.6,0,.9,.4)`). Ob udarcu se vrstica z izidom stresne za 4 px (260 ms, zamik 2450 ms).

---

## Datoteke
- `design/Premium popup.dc.html`: vse tri različice (namizje + telefon), logika cen, besedila (`KONTEKST`, `PRIMERJAVA`) in animacije (`scena()`, `stej()`).
- `design/Prizor kljucavnica.dc.html`: SVG prizor in časovnica za 1b.
- `design/Maskota.dc.html`: maskota v pozah za 1a in 1c.
- `design/support.js`: samo za odpiranje prototipov v brskalniku (ne prenašaj v kodo).
- `screenshots/`: referenčni posnetki za primerjavo 1:1.

Povezani obstoječi viri v `vmesnik/`: `src/komponente/NarocninaIgralec.tsx`, `src/strani/NarocninaStran.tsx`, `src/komponente/RegistracijaTok.tsx`, `src/komponente/MaskotaPrizori.tsx`, `src/api/tipi.ts`, `src/slog.css`, `turnirko-profil-redesign/project/DESIGN.md`.

Oglas zavestno odstopa od »zapisniškega« tona v DESIGN.md (glasnejši ton, maskota tudi na telefonu). To velja **samo** za ta popup, zato v DESIGN.md dodaj izjemo zanj.
