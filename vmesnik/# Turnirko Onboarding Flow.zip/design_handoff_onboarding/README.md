# Handoff: Registracija s paketom (smer 1b »Razdeljeno okno«)

## Overview
Nov tok registracije za Turnirko (turnirko-nt.si), ki nadomesti `RegistracijaObrazec` in `KodaObrazec` v `vmesnik/src/komponente/PrijavaOkno.tsx`. Ima dve veji, igralec in organizator:

**vloga → paket → podatki → klub (+ zapis med igralci) → [skrbnik, če je igralec mlajši od 15 let] → povzetek in plačilo → koda iz e-pošte → [koda skrbnika] → prvi koraki**

Izbrana je smer **1b**: široko modalno okno s temnim stolpcem korakov na levi. Na telefonu je okno čez cel zaslon in ima zgoraj kompakten temen trak napredka.

## About the Design Files
Datoteke v `prototip/` so **referenčni prototipi v HTML**, ne produkcijska koda. Naloga je, da isti videz in obnašanje **na novo zgradiš v obstoječem vmesniku** (React + TypeScript + `slog.css`, BEM razredi v slovenščini, `@tanstack/react-query`). Drži se vzorcev iz `turnirko-profil-redesign/project/DESIGN.md`. Inline slogov iz prototipa ne prenašaj: vsak slog gre v `slog.css` kot razred (npr. `.registracija`, `.registracija__stolpec`, `.registracija__korak--aktiven` …), vrednosti pa iz obstoječih spremenljivk (`--barva-…`, `--r1…`, `--tip-…`).

Prototip odpreš tako, da `prototip/Turnirko Onboarding.dc.html` odpreš v brskalniku. Razdelek **1b** je izbrana smer, 1a le za primerjavo. Vsi zasloni so klikljivi.

## Fidelity
**High-fidelity.** Barve, tipografija, razmiki, besedila in stanja so končni. Zgradi pixel-perfect.

## ⚠ Obvezno: primerjava s posnetki zaslona
V `posnetki/` so posnetki vsakega koraka za namizje (okno 1040 px, 1×) in telefon (390 px, 2×). **Ko zgradiš posamezen korak, ga posnemi pri isti širini in ga primerjaj s pripadajočim posnetkom. Popravljaj in ponavljaj, dokler se popolnoma ne ujemata**: postavitev, razmiki, velikosti in teže pisav, barve, črte, prelomi vrstic, besedila. Ne nadaljuj na naslednji korak, dokler se trenutni ne ujema. Na koncu še enkrat pojdi čez vse posnetke, za obe vlogi in obe širini.

Kako posnameš: vmesnik poženeš lokalno (`npm run dev`) in odpreš okno »Ustvari račun«. Za namizje nastavi okno brskalnika tako, da je modalno okno široko 1040 px; za telefon uporabi viewport 390 × 844. Za zajem uporabi npr. Playwright (`page.setViewportSize`, `locator('.modal').screenshot()`) ali DevTools »Capture node screenshot«. Posnetka primerjaj drugega ob drugem ali s prekrivanjem (npr. `pixelmatch`).

Znana izjema posnetkov: potrditveno polje »Strinjam se s pogoji« je na posnetkih povzetka narisano prazno, čeprav je bilo obkljukano (omejitev orodja za zajem). V tem stanju je glavni gumb omogočen.

| Posnetek | Stanje |
|---|---|
| `igralec-01-vloga-*` | Izbira vloge, igralec izbran |
| `igralec-02-paket-*` | Primerjava Brezplačno ↔ Premium, Premium izbran, mesečno |
| `igralec-02b-paket-brezplacno-namizje` | Isto, izbrano Brezplačno |
| `igralec-03-podatki-*` | Osebni podatki (predizpolnjeni), moč gesla |
| `igralec-03b-podatki-mlajsi-namizje` | Datum rojstva < 15 let: pripis o skrbniku, v stolpcu se pojavi korak »Skrbnik« |
| `igralec-04a-klub-zapis-*` | Klub izbran, najden en zapis, gumba »To sem jaz« / »Ni moj zapis« |
| `igralec-04b-klub-potrjen-*` | Po »To sem jaz«: zeleno obvestilo |
| `igralec-04c-klub-ni-zapisa-*` | Ni zadetka: sivo obvestilo |
| `igralec-04d-skrbnik-*` | Korak skrbnika |
| `igralec-05-povzetek-*` | Povzetek s plačilom (Premium 4,99 €) |
| `igralec-06-koda-*` | Koda vpisana, obvestilo »Stripe je potrdil plačilo«, odštevanje |
| `igralec-07-konec-*` | Račun je pripravljen, prvi koraki |
| `organizator-01-vloga-*` … `organizator-07-konec-*` | Ista pot za organizatorja (paket Plus, klub NTK Mladost) |
| `organizator-04-klub-iskanje-*` | Iskanje kluba s predlogi |
| `organizator-05b-preusmerjanje-namizje` | Gumb »Preusmerjam na plačilo …« (onemogočen) |
| `organizator-06-koda-prazno-telefon` | Prazna polja kode |

## Screens / Views

### Lupina okna (vsi koraki)
- **Namizje:** zastor kot `.modal__zastor` (`rgb(20 17 15 / .55)`, odmik 56 px zgoraj, 16 px ob straneh, 40 px spodaj). Okno ima `max-width: 1040px`, podlago `#FBF9F5`, obrobo `1px #14110F` in radij 0. Je `display:flex; flex-wrap:wrap` z dvema stolpcema:
  - **Levi stolpec** `flex: 0 0 280px`, podlaga `#14110F`, besedilo `#FBF9F5`, `padding: 32px 24px`, navpični flex z `gap: 40px`.
    - Logotip: znak 24 px (poteze `#FBF9F5`, `#FBF9F5`, `#0088CE`, `#7BB900`) in »Turnirko« v Bricolage 800 24 px, `letter-spacing -0.02em`, razmik 10 px.
    - Glava seznama: mono 12/500, `0.1em`, verzalke, barva `#B9B0A6`, besedilo »Nov račun · Igralec|Organizator«, `padding-bottom 12px`, črta `1px #4A433D`.
    - Vrstica koraka: gumb, mreža `32px 1fr`, `gap 8px`, `min-height 48px`, `padding 12px 0 12px 12px`, `margin-left -12px`, levi rob `3px`, spodnja črta `1px #332E29`.
      - številka: mono 12/600 `0.08em`;
      - ime: Karla 15 px.
      - Stanja:
        - **opravljen:** številka se zamenja z »OK« v `#7BB900`, ime `#FBF9F5` 400, klikljiv (vrne na korak);
        - **aktiven:** številka `#0088CE`, ime `#FBF9F5` 700, levi rob `#0088CE`;
        - **prihodnji:** oboje `#9A9189`, neklikljiv.
    - Na dnu (`margin-top:auto`) blok »Tvoja izbira«:
      - glava mono `#B9B0A6` s črto `1px #FBF9F5`;
      - tri vrstice kolofona (Vloga / Paket / Cena), vsaka `padding 10px 0`, črta `1px #332E29`; oznaka je mono 12 `#B9B0A6`, vrednost mono 600 15 px `#FBF9F5`.
  - **Desni stolpec** `flex: 999 1 340px`, navpični flex.
    - Glava: `padding: 24px clamp(20px,5%,48px) 0`.
      - vrstica: mono »KORAK 02 / 06« (`#5B534D`) levo, »✕« (mono 14 px, 44×44) desno;
      - pod njo naslov: nadnaslov Bricolage 200 32 px `#5B534D` (»Nov račun« / »Igralec« / »Organizator« / »Registracija«), razmik 8 px, glavni naslov Bricolage 800 48 px, `line-height .88`, `letter-spacing -0.035em`.
    - Telo: `padding: 24px clamp(20px,5%,48px) 32px`, navpično `gap 20px`. Prvi element je uvod Karla 300 17 px, `#332E29`, `max-width 56ch`.
    - Noga: `margin-top:auto`, `padding 16px clamp(20px,5%,48px)`, zgornja črta `1px #DED7CE`, `justify-content: space-between`.
      - levo: »Nazaj« (`.gumb`) oz. povezava »Že imaš račun? Prijava« na prvem koraku;
      - desno: glavni gumb (`.gumb--glavni`, `min-width 160px`, `padding 12px 20px`, `white-space: nowrap`).
- **Telefon (≤ 640 px):** okno je čez cel zaslon, brez zastora in brez spodnje vrstice. Levi stolpec se zamenja s **trakom** čez vso širino: podlaga `#14110F`, `padding 14px 20px 16px`, `gap 12px`.
  - vrstica: znak 20 px + mono »KORAK 02 / 06« `#FBF9F5` levo; mono 600 cena `#E8F5C4` in ✕ (`#B9B0A6`) desno;
  - pod njo segmenti napredka: `flex:1`, višina 4 px, razmik 4 px. Opravljen `#7BB900`, aktiven `#0088CE`, prihodnji `#4A433D`.
  - Nadnaslov in naslov ostaneta 32/48 px; naslov se lomi (`text-wrap: balance`).

### 1. Vloga
- Mreža `repeat(auto-fit, minmax(min(240px,100%),1fr))`, `gap 12px`. Na namizju sta kartici v dveh stolpcih, na telefonu v enem.
- Kartica je gumb z `padding 20px` in navpičnim flexom z `gap 12px`:
  - vrstica: mono »01« levo, »IZBRANO« `#0071AB` desno;
  - naslov Bricolage 800 32 px;
  - opis Karla 300 15 px `#332E29`;
  - noga: mono, zgornja črta `1px #DED7CE`.
- Izbrana kartica: obroba `1px #0088CE`, levi rob `4px #0088CE`, podlaga `#EAF3F9`. Neizbrana: obroba `1px #14110F`, levi rob `4px #14110F`, podlaga `#FFF`. Na hover gre obroba v `#0088CE`.
- Besedila:
  - »Tvoj profil, rating in zgodovina tekem. Račun povežemo z zapisom med igralci.« / noga »Brezplačno ali Premium od 3,99 € / mesec«;
  - »Klub ali oseba, ki vodi turnirje in lige. Vlogo potrdi administrator.« / »Letni paket od 89,99 €«.
- Privzeto je izbran igralec. Preklop vloge ponastavi paket (igralec → `BREZPLACNO`, organizator → `ORGANIZATOR_PLUS`).

### 2a. Paket — igralec
- Segmentni izbirnik kot `.izbirnik__gumb`: »Mesečno« in »Letno · 11 × mesečna«. Aktiven gumb ima podlago `#14110F` in besedilo `#FBF9F5`.
- Tabela je mreža `minmax(0,1fr) min(26%,132px) min(26%,132px)`, `gap 0 8px`, ovoj ima `container-type: inline-size`.
  - Glavna vrstica: levo mono »KAJ DOBIŠ«. Stolpca sta gumba z `padding 12px 4px` in zgornjim robom 3 px (izbran `#0088CE`, sicer `#DED7CE`). Izbran stolpec ima podlago `#EAF3F9` po vsej višini.
  - Vsebina stolpca: ime Karla 700 (14/15 px), cena Bricolage 800 `clamp(20px, 6.5cqw, 32px)` `nowrap`, enota mono (»VEDNO« / »NA MESEC« / »NA LETO«), stanje mono 600 (»IZBRANO« `#0071AB` / »IZBERI« `#5B534D`).
  - Pod glavo je črta `1px #14110F`.
  - Vrstice s črto `1px #DED7CE`: ime funkcije Karla 15 px (`padding 14px 0`), vrednosti mono 600 12 px na sredini. »DA« je `#4A7500`, »—« `#6E655E`.
  - Vrstice: Rezultati, lestvice, koledar · Prijava z lastnim računom · Forma in nasprotniki · Napoved tekme · Nizi, točke in razrezi · Spremljanje lig na domači strani.
- Cena Premium: 3,99 € do 21. leta, 4,99 € po njem (`CENA_PREMIUM_MESECNO`, `jeStarejsiOd21ZaCeno`). Letno je 11 × mesečna (`MESECEV_V_LETNI_NAROCNINI`): 43,89 / 54,89 €. Če datum rojstva še ni vpisan, se prikaže 3,99 € z enoto »OD · NA MESEC«.
- Pripis pod tabelo je Karla 300 14 px `#5B534D` (glej `cenaPojasnilo` v prototipu).

### 2b. Paket — organizator
- Glava: mreža `minmax(0,1fr) 56px 72px 96px`, `gap 8px`, mono »PAKET · LIGE · TURNIRJI · NA LETO«, črta `1px #14110F`.
- Vrstica je gumb z `min-height 72px`, `padding 16px 12px`, levim robom 4 px in črto `1px #DED7CE`:
  - ime Bricolage 800 24 px in pod njim »IZBRANO« mono `#0071AB`;
  - števili mono 600 18 px `tabular-nums`;
  - cena mono 600 16 px desno.
- Izbrana vrstica: levi rob `#0088CE`, podlaga `#EAF3F9`. Hover `#F3EFE9`.
- Vrednosti vzemi iz `OMEJITVE_ORGANIZATORJA` in `CENA_ORGANIZATOR_LETNO`.

### 3. Podatki
- Polja so `.obrazec__polje` (mono oznaka, `input` z obrobo `1px #14110F`, podlaga bela, `min-height 44px`, `padding 12px 14px`, 17 px).
  - Ime + Priimek: `.obrazec__vrstica--par`.
  - Datum rojstva (samo igralec) s pripisom 14/300 `#5B534D`. Pri < 15 letih se pripisu doda »Mlajši od 15 let: sledi korak za skrbnika.«
  - E-pošta, Geslo.
- Moč gesla: v oznaki desno mono napis (»Vsaj 8 znakov« / »Prekratko« `#8C2B14` / »Šibko« / »Srednje« / »Dobro« / »Močno«), pod poljem 4 segmenti po 6 px z razmikom 4 px.
  - Barve po moči 1–4: `#B23A1E`, `#0088CE`, `#0088CE`, `#7BB900`; prazen segment `#EDE7DF`.
- Gumb »Naprej« je onemogočen, dokler manjka ime, priimek ali (pri igralcu) datum, dokler e-pošta nima »@« ali ima geslo manj kot 8 znakov.
  - Onemogočen gumb: podlaga `#EDE7DF`, besedilo `#6E655E`, `cursor: not-allowed`.

### 4. Klub (+ zapis med igralci)
- **Izbran klub:**
  - vrstica z obrobo `1px #14110F`, levim robom `4px #0088CE`, podlago `#EAF3F9` in `min-height 56px`;
  - v njej ime 18/600 in kraj v mono;
  - desno povezava »Zamenjaj« (`.povezava-gumb`).
- **Brez kluba:**
  - iskalno polje;
  - pod njim seznam do 4 predlogov (bela podlaga, obroba `1px #DED7CE` brez zgornje; vrstica `min-height 48px`, ime 17 px levo, kraj v mono desno, hover `#F3EFE9`);
  - na koncu povezava »Nisem član kluba«.
  - V produkciji uporabi obstoječi `IzbirnikKluba` / `IskalniIzbirnik` in mu prilagodi videz.
- **Zapis med igralci (samo igralec):**
  - podnaslov sekcije »ZAPIS MED IGRALCI«;
  - ob enem zadetku: mono »NAJDEN EN ZAPIS« `#4A7500`, ime Bricolage 800 40 px, desno blok ratinga (podlaga `#0071AB`, število Bricolage 800 48 px bele barve, »RATING« mono `#E8F5C4`);
  - kolofon s tremi vrsticami (Klub v zapisu, Rojena, Tekem · sezona);
  - gumba »To sem jaz« (glavni) in »Ni moj zapis« (`flex: 1 1 160px`).
  - Po izbiri se prikaže obvestilo z levim robom 4 px in povezavo »Razveljavi«:
    - potrjeno: `#7BB900` na `#EAF4D6`, »Račun se poveže s tem zapisom takoj, ko potrdiš e-pošto.«;
    - zavrnjeno: `#6E655E` na `#EDE7DF`, »Račun poveže administrator. Do takrat si prijavljen kot gost.«
  - Brez zadetka: sivo obvestilo »Med igralci ni natanko enega zapisa z imenom … in tem datumom rojstva. Račun poveže administrator.«
- ⚠ **Zaledje:** predogled zapisa pred registracijo danes ne obstaja. Zaledje povezavo naredi samo ob potrditvi e-pošte (glej komentar v `PrijavaOkno.tsx`). Potreben je nov javni endpoint (npr. `igralciApi.poisciZaRegistracijo({ime, priimek, datumRojstva})`), ki vrne največ en zadetek z omejenimi podatki. Če endpointa ne bo, pokaži le obvestilo »Račun povežemo ob potrditvi e-pošte«. Najprej vprašaj lastnika.

### 5. Skrbnik (igralec < 15 let)
- Kolofonska vrstica »STAROST · 13 let« med dvema hairlinama.
- Polje »E-pošta starša oz. skrbnika« s pripisom »Na ta naslov gre koda s soglasjem, ki velja 24 ur. Vpišeš jo po svoji kodi.«

### 6. Povzetek in plačilo
- Seznam z zgornjo črto `3px #14110F`. Vrstica je mreža `minmax(96px,30%) 1fr auto`: oznaka mono, vrednost Karla 600 16 px, »Uredi« (`.povezava-gumb`) skoči na ustrezni korak.
- Znesek:
  - levo mono »ZA PLAČILO DANES« in »OBNOVA d. m. llll«;
  - desno Bricolage 800 56 px, `line-height .85`.
- Potrditveno polje 28×28 z `accent-color #0088CE`, besedilo »Strinjam se s pogoji uporabe in obdelavo podatkov.« Brez kljukice je gumb onemogočen.
- Pri plačljivem paketu še mono pripis »Plačilo prek Stripe. Račun nastane, ko Stripe potrdi plačilo.«
- Glavni gumb: »Nadaljuj na plačilo · 4,99 €« (→ `placilaApi.registracija`, preusmeritev na `seja.url`) oz. »Ustvari račun« (→ `authApi.registracija`). Med čakanjem piše »Preusmerjam na plačilo …« in gumb je onemogočen.

### 7. Koda iz e-pošte
- Po vrnitvi s Stripe Checkouta (`RegistracijaZakljucenaStran`, `?stanje=`) se okno odpre naravnost na tem koraku.
- Obvestilo »Stripe je potrdil plačilo X €. Paket se vklopi, ko potrdiš e-pošto.« (zelena črta in mehka zelena podlaga).
- 6 polj: mreža `repeat(6, minmax(0,56px))`, `gap 8px`, višina 64 px, bela podlaga.
  - Prazno polje ima obrobo `#DED7CE`, izpolnjeno `#14110F`, aktivno še `outline 2px #0088CE` (`offset -2px`).
  - Števka mono 600 28 px.
  - Izvedba: eno pravo polje (`inputMode="numeric"`, `autoComplete="one-time-code"`, `maxLength 6`), nevidno raztegnjeno čez celice.
- Pod poljem levo »KODA VELJA 10 MINUT« (za skrbnika 24 UR), desno »Pošlji kodo znova (56 s)«. Odštevanje traja 60 s (`ODMIK_PONOVNEGA_POSILJANJA`), med njim je besedilo `#6E655E`.
- Gumb »Potrdi« je aktiven pri 6 števkah. Pri < 15 letih po prvi kodi sledi še »Koda skrbnika« (isti zaslon). Klici so `authApi.potrdiEposto` / `potrdiSkrbnika` / `ponovnoPoslji`.

### 8. Račun je pripravljen
- Organizator dobi značko »ČAKA POTRDITEV ADMINISTRATORJA« (`.znacka`, podlaga `#EDE7DF`, `#5B534D`).
- Kolofon s tremi vrsticami. Uspešne vrednosti so v `#4A7500`.
- Sekcija »Prvi koraki«: naslov h3 24/800 s črto 3 px, desno mono »0 OD 3«. Vrstica je mreža `40px 1fr auto`, `padding 16px 0`, črta `1px #DED7CE`; številka mono, naslov 18/600, opis 14/300, desno mono povezava (`#0071AB`) ali nedejavna oznaka (`#6E655E`).
- Vsebina:
  - igralec: Profil → / Lige → (brez Premium »PREMIUM«) / 1 na 1 →;
  - organizator: tri postavke »PO POTRDITVI« z omejitvami iz paketa.
- Gumb »Na pregled« zapre okno.

## Interactions & Behavior
- Klik na opravljen korak v levem stolpcu vrne nanj. Na korakih koda in konec to ni mogoče; tam tudi ni gumba »Nazaj«.
- ✕, Escape in klik na zastor zaprejo okno. Obnašanje ModalnoOkno (portal, `inert`, vračanje fokusa) ostane.
- Prehodi so samo barva/obroba do 120 ms (DESIGN.md §5.12). Drugih animacij ni.
- Vrstni red korakov se izračuna sproti: korak »skrbnik« se vstavi, ko je starost < 15 let.
- Napake strežnika pokaži s `.napaka` nad nogo (`opisNapake(e)`).

## State Management
Stanje: `vloga`, `korak`, `paket`, `ciklus`, `ime`, `priimek`, `datumRojstva`, `email`, `geslo`, `idKlub`, `povezava ('da'|'ne'|null)`, `emailSkrbnika`, `pogoji`, `poteka`, `koda`, `korakKode ('EPOSTA'|'SKRBNIK')`, `odstevanje`. Logika je že v `RegistracijaObrazec` / `KodaObrazec`; tok jo samo razdeli na korake. Referenca je razred `Component` v `prototip/Registracija Okno.dc.html`.

## Design Tokens
Vsi obstajajo v `slog.css`. Novi so samo trije toni na temni podlagi stolpca, dodaj jih kot spremenljivke:
- `--barva-na-crnilu-2: #B9B0A6` (oznake);
- `--barva-na-crnilu-3: #9A9189` (prihodnji koraki);
- `--barva-crta-na-crnilu: #332E29` / `#4A433D` (črte, prazni segmenti).

Pisave: Bricolage Grotesque (200/800), Karla (300/400/600/700), IBM Plex Mono (500/600). Radij 0 povsod. Senc ni.

## Assets
Samo logotip (`ZnakTurnirko` iz `Postavitev.tsx`, poteze v barvah za temno podlago). Drugih ikon ni.

## Files
- `prototip/Turnirko Onboarding.dc.html`: platno z obema smerema (1b je izbrana)
- `prototip/Registracija Okno.dc.html`: celoten tok (predloga + logika), prop `smer="B"`, `telefon`
- `prototip/Posnetki.dc.html`: stran, s katero so nastali posnetki
- `posnetki/*.png`: referenčni posnetki za primerjavo
- Mesta za spremembe v vmesniku: `src/komponente/PrijavaOkno.tsx`, `src/komponente/ModalnoOkno.tsx` (nova različica, npr. `razdeljeno`), `src/slog.css`, po potrebi `src/api/zahteve.ts` (predogled zapisa)

Podatki v prototipu (klubi, zapis »Ana Novak«, rating 1612) so izmišljeni.
