# Predaja: prenova strani Pogoji in zasebnost (/pogoji), različica 1a

## Pregled
Nova postavitev strani `/pogoji` v Turnirku (repo `MihaFatur/Turnirko`, mapa `vmesnik/`). Cilj: ista pravna vsebina, ki se bere in pregleduje lažje. Novo je:
- zgoraj povzetek »Na kratko« (5 stolpcev) in kolofon s podatki o ponudniku,
- točke so oštevilčene (1.1–1.6, 2.1–2.8), naslov je levo, besedilo desno,
- lepljivo kazalo ob strani (namizje) oz. lepljiva vrstica zavihkov (telefon), ki med drsenjem označi trenutni razdelek,
- v točki 1.3 okvir »V kratkem« (naročnina), v točki 2.7 okvir »V številkah« (roki hranjenja),
- Kontakt kot tabela oznaka/vrednost.

## O datotekah v paketu
Datoteke v paketu so **oblikovne reference, narejene v HTML**. Ne kopiraj jih v produkcijo. Naloga je postavitev poustvariti v obstoječi kodi: React + `react-router-dom`, globalni `vmesnik/src/slog.css` s spremenljivkami v `:root`. Spreminjaš samo:
- `vmesnik/src/strani/PogojiStran.tsx`
- pravila `.pogoji*` v `vmesnik/src/slog.css` (staro `.pogoji { max-width: 760px }` in `.pogoji__kazalo` zamenjaj)

**Ne spreminjaj** `Postavitev.tsx`, globalnih razredov (`.naslov-strani`, `.uvod`, `.naslovna-vrstica`, `.vsebina` …) in pravnega besedila. Če potrebuješ drugačne vrednosti, dodaj modifikator, omejen na `.pogoji`.

## Natančnost
**Hi-fi.** Barve, pisave, razmiki in stanja so dokončni. Poustvari jih na piksel natančno in jih preveri s posnetki (glej *Zanka primerjave* spodaj).

## Besedilo — obvezna pravila
1. **Pravno besedilo vseh 14 točk ostane dobesedno takšno, kot je zdaj v `PogojiStran.tsx`**, vključno s pogojnimi deli (`PONUDNIK.zavezanecZaDdv`, `PONUDNIK.gostovanje`, `zPiko()`), povezavami (`<Link to="/o-ratingu">`, `<Link to="/narocnina">`, `/?statistika=izklop`, `ip-rs.si`, `mailto:`) in `<strong>Datum rojstva ni javen</strong>`. Spremeniš samo ovoj okoli besedila.
2. Podatki o ponudniku pridejo iz `pomozno/pravno.ts` (`PONUDNIK`, `POGOJI_VELJAJO_OD` prek `oblikujDatum`). Ničesar ne vpisuj na trdo.
3. Novi povzetni nazivi spodaj so odobreni. Uporabi jih točno tako, kot so zapisani.

### »Na kratko« (5 celic: oznaka / vrednost / pojasnilo)
| Oznaka | Vrednost | Pojasnilo |
|---|---|---|
| Javno | Rezultati in rating | Ime, priimek, klub, starostna kategorija, rezultati in rating. Brez prijave. |
| Ni javno | Datum rojstva | Uporablja se le za starostno kategorijo in za ločevanje igralcev z enakim imenom. |
| Piškotki | Ne uporabljamo | Statistika obiska teče na našem strežniku, brez piškotkov in brez osebnih podatkov. |
| Podatki | Ne prodajamo | Ne posredujemo jih za oglaševanje. |
| Naročnina | Odstop v 14 dneh | Kot potrošnik brez navedbe razloga. Preklic kadar koli. |

Desno od naslova sekcije: `Povzetek · velja besedilo spodaj`.

### Kolofon (desno od naslova strani)
| Oznaka | Vrednost |
|---|---|
| Upravljavec | `PONUDNIK.ime` |
| Sedež | kraj iz `PONUDNIK.naslov` (del za poštno številko → »Prebold«) |
| Veljajo od | `oblikujDatum(POGOJI_VELJAJO_OD)` |
| Kontakt | `PONUDNIK.eposta` (navadno besedilo, ne povezava) |
Vrstico, katere vrednost je `null`, izpusti.

### Okvir »V kratkem« (nad besedilom točke 1.3)
| Ključ | Vrednost |
|---|---|
| Cena | Izpisana pred nakupom in končna. Prodajalec ni zavezanec za DDV, zato DDV ni obračunan. *(če `zavezanecZaDdv`: »Izpisana pred nakupom in končna (vključuje DDV).«)* |
| Plačilo | Stripe. Račun za vsako plačilo (tudi za obnovo) prejmeš po e-pošti. |
| Obnova | Samodejna ob koncu obdobja (mesec ali leto), dokler je ne prekličeš. |
| Preklic | Kadar koli na strani Naročnina; velja do konca že plačanega obdobja. |
| Odstop | 14 dni od nakupa, brez navedbe razloga. Piši nam; vrnemo plačilo, zmanjšano za že porabljeni del obdobja. |

### Okvir »V številkah« (nad besedilom točke 2.7)
| Vrednost | Pojasnilo |
|---|---|
| 48 ur | Račun, katerega e-pošta ni potrjena. |
| 30 dni | Račun mlajšega od 15 let brez soglasja skrbnika. |
| 4 dni | Podatki registracije s plačljivim paketom, ki ni bila plačana. |
| Na zahtevo | Račun izbrišemo na tvojo zahtevo. |
| Po zakonu | Izdani računi za plačila: toliko časa, kot zahtevajo davčni predpisi, tudi po izbrisu računa. |
| Kratek čas | Dnevnik zahtev z naslovi IP, nato se prepiše. |
| Ostane | Rezultati tekmovanj kot zapis zgodovine tekmovanja. |

### Kontakt (tabela)
Vrstice: Ponudnik · Naslov · Matična številka · Davčna številka · E-pošta (`mailto:` povezava). Vrstico z vrednostjo `null` izpusti, kot zdaj.

### Številke in naslovi točk
1 Pogoji uporabe: 1.1 Kaj je javno · 1.2 Račun · 1.3 Naročnina Premium in paketi organizatorjev · 1.4 Česa ne smeš · 1.5 Točnost in odgovornost · 1.6 Spremembe pogojev
2 Varstvo osebnih podatkov: 2.1 Kdo je upravljavec · 2.2 Igralci na tekmovanjih · 2.3 Imetniki računov · 2.4 Plačila · 2.5 Obisk strani · 2.6 Kdo še obdeluje podatke · 2.7 Koliko časa · 2.8 Tvoje pravice
3 Kontakt

Desno od naslovov sekcij: `Razdelek 1 · 6 točk`, `Razdelek 2 · 8 točk`, `Razdelek 3`. Na telefonu samo `1`, `2`, pri Kontaktu nič.

## Sidra (obvezno)
- `#pogoji`, `#zasebnost`, `#kontakt` **morajo ostati**, ker registracija vodi na `/pogoji#zasebnost`.
- Dodaj še: `#na-kratko`, `#pogoji-javno`, `#pogoji-racun`, `#pogoji-narocnina`, `#pogoji-prepovedi`, `#pogoji-tocnost`, `#pogoji-spremembe`, `#zasebnost-upravljavec`, `#zasebnost-igralci`, `#zasebnost-racuni`, `#zasebnost-placila`, `#zasebnost-obisk`, `#zasebnost-obdelovalci`, `#zasebnost-cas`, `#zasebnost-pravice`.
- Kazalo in zavihki so prave povezave `<a href="#…">`. Klik prestreži in naredi gladek premik z odmikom (spodaj).

## Postavitev — namizje (okno 1280 × 900; cilj primerjave)
Vse mere so v CSS px. Glava (Postavitev) v maketi je visoka 74 px; v aplikaciji je, kakršna pač je.

**Telo** (`.vsebina`, že obstaja): padding 48 40 64, širina vsebine 1200. Stolpec `flex-direction: column; gap: 56`:
1. **Zgornji blok** (`#na-kratko`), stolpec z gap 56:
   - **Mreža naslova**: `grid-template-columns: minmax(0,1fr) 380px; gap: 56; align-items: start`.
     - Levo: `h1.naslov-strani` (nad: Bricolage 200 48px #5B534D; glavni: Bricolage 800 88px #14110F; line-height .88; letter-spacing −0.035em; glavni margin-top `calc(.08em + 6px)`), nato `p.uvod` (margin-top 20; Karla 300 20px/1.5 #332E29; max-width 48ch). Besedilo uvoda ostane enako.
     - Desno: kolofon, padding-top 12. Vrstica: `flex; baseline; space-between; gap 16; padding 10 0; border-bottom 1px #DED7CE`. Oznaka: Plex Mono 500 12px/1.4, letter-spacing .08em, VELIKE, #5B534D. Vrednost: Plex Mono 600 15px/1.4 #14110F, poravnana desno.
   - **Na kratko**: glava sekcije (glej spodaj, brez padding-bottom), gap 24, nato mreža `repeat(5, minmax(0,1fr))`. Celica: `border-left 1px #14110F; padding 0 20; flex column; gap 10`. Oznaka: Mono 500 12px, .1em, VELIKE, #5B534D. Vrednost: Bricolage 800 26px/1.05, −0.03em, #14110F. Pojasnilo: Karla 15px/1.45 #332E29.
2. **Mreža vsebine**: `grid-template-columns: 220px minmax(0,1fr); gap: 56; align-items: start`.
   - **Kazalo** `<aside>`: `position: sticky; top: 104` (= spodnji rob glave + 30; v aplikaciji `calc(var(--visina-glave) + 30px)`). Stolpec z gap 12.
     - Nadpis »Vsebina«: Mono 500 12px, .1em, VELIKE, #5B534D; padding-bottom 8; border-bottom 1px #14110F.
     - `<nav aria-label="Vsebina strani">`, postavke v stolpcu, brez razmika. Postavka: `flex; align-items: baseline; gap 10; min-height 36; border-left 4px solid; line-height 1.3`. Pred napisom je številka: Mono 500 11px, .08em, #5B534D, min-width 26 (prazno pri »Na kratko«, »1«, »2«, »3«, »1.1« …).
     - Prva raven (Na kratko, Pogoji uporabe, Varstvo osebnih podatkov, Kontakt): padding 6 12; Karla 15px.
     - Podtočke se izpišejo **samo za skupino, v kateri je bralec** (1.1–1.6 ali 2.1–2.8): padding 4 12 4 20; Karla 14px.
     - Stanja: **aktivna postavka** (trenutna točka ali naslov sekcije): rob #0088CE, podlaga #EAF3F9, besedilo #0071AB, 700. **Nadrejena skupina aktivne**: besedilo #14110F, 700, brez podlage. Neaktivna podtočka: #332E29, 400. Neaktivna prva raven: #5B534D, 400. Neaktiven rob je `transparent`.
   - **Glavni stolpec**: `flex column; gap 56; min-width 0`. Sekcije `#pogoji`, `#zasebnost`, `#kontakt`.
     - **Glava sekcije**: `border-top 3px #14110F; padding-top 16; padding-bottom 8; flex; baseline; space-between; gap 24`. h2: Bricolage 800 40px/1, −0.03em. Desno meta: Mono 500 12px, .1em, VELIKE, #5B534D.
     - **Točka** (vrstica): `grid 200px | minmax(0,1fr); gap 32; padding 24 0; border-bottom 1px #DED7CE`.
       - Levo: številka (Mono 500 12px/1.4, .1em, #5B534D), pod njo `h3` (margin-top 8; Bricolage 800 20px/1.15, −0.02em, #14110F).
       - Desno: stolpec z gap 20. Najprej okvir (samo pri 1.3 in 2.7), nato `p` (Karla 17px/1.55 #332E29; max-width 62ch; margin 0).
     - **Okvir »V kratkem« (1.3)**: border-top 3px #14110F. Nadpis: Mono 500 12px, .1em, VELIKE, #5B534D; padding 10 0 4. Vrstica: `grid 110px | 1fr; gap 16; padding 10 0; border-top 1px #DED7CE`. Ključ: Mono 500 12px/1.6, .08em, VELIKE, #5B534D. Vrednost: Karla 16px/1.5 #14110F.
     - **Okvir »V številkah« (2.7)**: enako, le vrstica je `grid 150px | 1fr; align-items: baseline`. Vrednost: Bricolage 800 24px/1.1, −0.03em. Pojasnilo: Karla 16px/1.45 #14110F.
     - **Kontakt**: vrstica `grid 200px | 1fr; gap 32; padding 12 0; border-bottom 1px #DED7CE; baseline`. Oznaka: Mono 500 12px, .08em, VELIKE, #5B534D. Vrednost: Karla 17px.

## Postavitev — telefon (okno 390 × 800; cilj primerjave; `max-width: 640px` kot drugod v aplikaciji)
Glava telefona (Postavitev) je v maketi visoka 56 px, črta pod njo 1 + 2 + 3 px (skupaj 62). Spodnja vrstica pride iz Postavitev.

- **Vrstica zavihkov** (nova, del strani): `position: sticky; top: 62` (tik pod glavo telefona), podlaga #FBF9F5, `display flex; overflow-x auto; padding 0 8; border-bottom 1px #DED7CE`, z-index nad vsebino. Zavihki: Na kratko · Pogoji · Zasebnost · Kontakt. Zavihek: `min-height 44; padding 0 12; flex: none`; Mono 600 12px/1.4, .08em, VELIKE. Aktiven: `border-bottom 3px #0088CE`, #14110F. Neaktiven: rob transparent, #5B534D. Aktivna je SKUPINA: v kateri koli točki 1.x je aktiven »Pogoji«.
- **Telo**: padding 32 20 40; stolpec z gap 40.
- **Zgornji blok** (stolpec, gap 40):
  - h1: nad Bricolage 200 28px, glavni Bricolage 800 44px (`overflow-wrap: break-word`), line-height .88. Uvod: margin-top 16, Karla 300 17px/1.5.
  - Kolofon: margin-top 16. Vrstice kot na namizju, le oznaka 11px in vrednost Mono 600 13px.
  - Na kratko: stolpec z gap 8. Glava: border-top 3px, padding-top 16, h2 32px. Postavka: padding 16 0, border-bottom 1px #DED7CE, stolpec z gap 6. Oznaka 12px, vrednost 26px, pojasnilo 15px/1.45.
- **Glava sekcije**: border-top 3px #14110F; padding-top 16; h2 Bricolage 800 32px/1; desno meta `1` / `2` (Mono 12px). Kontakt: brez mete, padding-bottom 8.
- **Točka**: padding 24 0; border-bottom 1px #DED7CE; stolpec z gap 12. Prva vrstica: številka (Mono 12px) in h3 (Bricolage 800 20px/1.15), `flex; baseline; gap 10`. Nato okvir, nato p (17px/1.55 #332E29).
- **Okvir »V kratkem«**: vrstica `grid 84px | 1fr; gap 12`. Ključ: Mono 11px/1.7, .06em. Vrednost: 15px/1.45.
- **Okvir »V številkah«**: vrstica `grid 116px | 1fr; gap 12`. Vrednost: Bricolage 800 20px/1.1. Pojasnilo: 15px/1.45.
- **Kontakt**: vrstica `flex column; gap 2; padding 12 0; border-bottom 1px #DED7CE`. Oznaka: Mono 11px. Vrednost: 17px.

## Vmesne širine (641–1099 px)
Te širine niso del primerjave s posnetki, a stran se ne sme lomiti in ne sme se pojaviti vodoravni drsnik.
- Pod 1100 px skrij `<aside>` in namesto njega pokaži vrstico zavihkov s telefona, lepljivo na `top: var(--visina-glave)`.
- Mreža »Na kratko« naj ima `repeat(auto-fit, minmax(200px, 1fr))`.
- Mreža naslova gre v en stolpec (kolofon pod uvod).
- Vrstica točke ostane `200px | 1fr`.

## Interakcije in vedenje
- **Označevanje med drsenjem** (scroll-spy): na `scroll` (prek `requestAnimationFrame`) je aktiven zadnji cilj (sekcija ali točka po vrstnem redu na strani), katerega vrh je ≤ **150 px** (namizje) oz. ≤ **120 px** (telefon) od vrha okna. Ko je stran odrsana do dna (`scrollY + innerHeight ≥ scrollHeight − 4`), je aktiven Kontakt. Na vrhu strani je aktiven »Na kratko«.
- **Klik v kazalu ali zavihku**: `preventDefault`, nato gladek premik, tako da vrh cilja pristane **100 px** (namizje) oz. **112 px** (telefon) pod vrhom okna. Ob `prefers-reduced-motion: reduce` je premik takojšen. Hash posodobi s `history.replaceState`.
- **Prihod s sidrom** (`/pogoji#zasebnost`): obstoječi `useEffect` naj upošteva isti odmik (100/112). Lahko z `scroll-margin-top` na ciljih, ki skupaj z obstoječim `scroll-padding-top: var(--visina-glave)` da isti rezultat.
- **Povezave**: #0071AB, brez podčrtaja; ob `:hover` podčrtaj. Fokus po obstoječem vzorcu aplikacije.
- Aktivni postavki v kazalu dodaj `aria-current="location"`.
- Prehodov in animacij ni, razen gladkega premika.

## Stanje
- `aktivniId: string` (id sekcije ali točke). Skupina (`pogoji` | `zasebnost` | `kontakt` | `na-kratko`) se izpelje iz id-ja.
- Brez nalaganja podatkov; vse je statično (`PONUDNIK`, `POGOJI_VELJAJO_OD`).
- Priporočilo: točke zapiši kot polje `{ id, st, naslov, vsebina: ReactNode }`. Iz istega polja nastanejo sekcije in kazalo, obstoječi JSX besedila pa ostane nespremenjen.

## Oblikovni žetoni (obstoječe spremenljivke v `:root`)
| Vrednost | Spremenljivka | Raba |
|---|---|---|
| #FBF9F5 | `--barva-papir` | podlaga |
| #14110F | `--barva-crnilo` | besedilo, debele črte 3px, robovi celic |
| #332E29 | `--barva-crnilo-2` | odstavki |
| #5B534D | `--barva-crnilo-3` | oznake, številke, neaktivno |
| #DED7CE | `--barva-crta` | tanke ločilne črte |
| #0088CE | `--barva-glavna` | rob aktivne postavke, črta zavihka |
| #0071AB | `--barva-glavna-tekst` | aktivno besedilo, povezave |
| #EAF3F9 | `--barva-glavna-mehko` | podlaga aktivne postavke |

Pisave: `--pisava-display` (Bricolage Grotesque), `--pisava-telo` (Karla), `--pisava-mono` (IBM Plex Mono). Lestvica: 11 · 12 (`--tip-mono`) · 13 · 14 · 15 · 16 · 17 (`--tip-telo`) · 20 (`--tip-uvod`) · 24 · 26 · 32 · 40 (`--tip-h2`) · 44 · 48 · 88 (`--tip-h1`). Razmiki so na ritmu 8 px (`--r1`…`--r8`) z izjemami 10, 12, 20, 26 in 30, ki so zapisane zgoraj. Polmer vogalov je 0, senc ni.

## Sredstva
Ni novih slik ali ikon. Logotip in ikone spodnje vrstice v posnetkih so iz obstoječe Postavitev.

## Datoteke
- `posnetki/namizje-1280/` in `posnetki/telefon-390/`
  - `00-celotna-stran.png`: cela stran; lepljivi elementi so v naravnem položaju (kot Playwright `fullPage`).
  - `01-vrh.png`: okno na vrhu.
  - `02-pogoji.png`: klik »Pogoji uporabe« oz. zavihek »Pogoji«.
  - `03-narocnina.png`: točka 1.3 (namizje: klik »1.3« v kazalu; telefon: premik na `#pogoji-narocnina`).
  - `04-zasebnost.png`: namizje točka 2.2, telefon zavihek »Zasebnost«.
  - `05-koliko-casa.png`: točka 2.7.
  - `06-kontakt.png`: dno strani.
- `meritve.json`: položaji (x, y, širina, višina) naslovov, sekcij, točk in odstavkov v referenci ter `scrollY` za vsak posnetek.
- `referenca/Pogoji in zasebnost 1a.dc.html` (+ `support.js` ob njem): delujoča referenca s scroll-spyjem. Vsi slogi so v vrstici (inline), zato jih lahko natančno pregledaš. Odpri jo v brskalniku (potrebuje internet za React in Google Fonts).

## Zanka primerjave (obvezna)
Implementacijo primerjaj s posnetki in popravljaj, **dokler se ne ujemata**. Ne zaključi prej.

1. Zaženi aplikacijo (`npm run dev` v `vmesnik/`) in odpri `/pogoji` kot neprijavljen gost.
2. V Playwrightu (Chromium; `deviceScaleFactor: 1`, skriti drsniki, `await document.fonts.ready`) za vsako okno (1280×900, 390×800) naredi stanja 01–06 enako kot zgoraj pri *Datoteke* in ob vsakem posnetku počakaj 300 ms, da se kazalo posodobi:
   - stanja 02–05: `window.scrollTo(0, el.getBoundingClientRect().top + scrollY − ODMIK)` z ODMIK = 100 (namizje) oz. 112 (telefon) ali klik na postavko kazala;
   - stanje 06: premik na dno;
   - stanje 00: `fullPage: true`.
3. Vsak posnetek primerjaj z ustreznim PNG (`pixelmatch`, `threshold: 0.1`). **Zakrij glavo in spodnjo vrstico iz Postavitev**: namizje y 0–74; telefon y 0–62 in spodnjih 60 px. Vrstica zavihkov na telefonu je del strani in se primerja. Če se višina glave v aplikaciji razlikuje od 74/62, poravnaj oba posnetka po vrhu `h1` (ali, v stanjih 02–06, po vrhu cilja) in primerjaj od tam navzdol.
4. Shrani sliko razlik, preglej jo in popravi CSS/strukturo. Ponavljaj korake 2–4.
5. **Merila ujemanja** (vsa morajo veljati za vseh 14 posnetkov):
   - v nezakritem delu se razlikuje ≤ 0,5 % pikslov;
   - **prelomi vrstic so v vsakem odstavku in naslovu enaki kot na posnetku** (ista beseda na koncu vsake vrstice);
   - položaji iz `meritve.json`, merjeni relativno na levi zgornji kot `h1`, se ujemajo na ±2 px;
   - stanje kazala in zavihkov (katera postavka je modra, katera skupina je razprta) je enako kot na posnetku.
   Ostanejo lahko le razlike v glajenju robov črk (posnetki so izrisani iz HTML-reference; Google Fonts proti fontsource), ki se na sliki razlik kažejo kot enakomerni obrisi črk, ne kot zamaknjeni bloki.
6. Na koncu poročaj tabelo: posnetek, % razlik, največji odmik elementa v px.

Posnetkov in referenčnih datotek ne dodajaj v produkcijsko kodo. Orodja za primerjavo (Playwright, pixelmatch, pngjs) namesti začasno ali kot `devDependencies` samo, če lastnik to odobri.
