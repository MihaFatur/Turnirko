# Handoff: mobilni pogled Lige + Lestvica (Turnirko)

## Namen

Na telefonu (≤ 640 px) imajo **Turnirji**, **Turnir** in **Dogodek** svoje mobilno drevo
(`useTelefon()` → `naslov-mobi`, `krmila-mobi`, `seznam-mobi`, `vrstica-mobi`, dejanja v lepljivi
glavi). **Lige (seznam)**, **Lestvica (globalna)** in **Liga (podrobno)** tega drevesa **nimajo** —
na telefonu se izriše namizna postavitev. Posledice v produkciji:

- `LigeStran`: `.kartica--liga` ima 5 stolpcev; pri ≤ 900 px pravilo `slog.css:1778` mrežo zniža na
  `minmax(0,1fr) auto`, zato format srečanja zleze pod ime, »1 ↑ · 2 ↓« pade v drugi stolpec in
  značka statusa v svojo tretjo vrsto. Vrstica meri ~150 px.
- `LestvicaStran`: naslov 56 px + uvod 20 px + iskalnik z oznako + števci + 8 gumbov filtra v štirih
  vrstah → do prve vrstice razvrstitve je ~620 px.
- `LigaStran`: lepljiva glava ne nosi konteksta (samo logotip, ker stran ne kliče `useNazaj`), pod
  njo pa naslov, uvod, stanje, napredek, dve dejanji in trije zavihki — lestvica se začne pod robom
  zaslona.

Ta paket vsebuje **prenovljeno postavitev teh treh strani** za telefon. Namizna postavitev se
**ne spreminja**.

## O datotekah v paketu

Datoteke so **oblikovalska referenca, napisana v HTML** — prototip, ki kaže želeni izgled, ne
produkcijska koda za kopiranje. Naloga je **prenesti ta izgled v obstoječe okolje projekta**
(React + TypeScript + Vite, react-router, TanStack Query, en sam `src/slog.css` brez CSS-in-JS in
brez utility knjižnic) po njegovih obstoječih vzorcih. Inline slogov v HTML referenci **ne
prenašaj** — vsaka vrednost naj postane razred v `slog.css`, tako kot pri obstoječih mobilnih
razredih (razdelek 17 datoteke).

- `Turnirko-mobilni-pregled.html` — samostojna referenca, odpri v brskalniku. Levo (`1a`) je
  današnje stanje, desno (`1b`) prenova. **Implementiraj samo `1b`.**
- `Turnirko mobilni pregled.dc.html` — izvorna oblikovalska datoteka (isti vsebini).
- `screenshots/01-lige-seznam.png` — /lige, prenova (390 × 844, 2×)
- `screenshots/02-lestvica.png` — /lestvica, prenova
- `screenshots/03-liga-lestvica.png` — /lige/:id, zavihek Lestvica
- `screenshots/04-liga-razpored.png` — /lige/:id, zavihek Razpored
- `PROMPT.md` — navodilo za začetek dela (vključno z zanko primerjave s posnetki).

## Fidelity

**Hi-fi.** Barve, tipografija, mere in razmiki so končni in izmerjeni. Rekreacija mora biti
piksel-natančna pri 390 × 844 px. Vsi razmiki so večkratniki 8 (izjema so navpični odmiki vrstic
10–14 px, ki so v sistemu že uveljavljeni), `border-radius` je **vedno 0**, `box-shadow` je
prepovedan.

## Oblikovalski žetoni (obstoječi, iz `src/slog.css`)

Ne uvajaj novih barv. Vse spodnje vrednosti so že spremenljivke; v novi kodi uporabljaj
spremenljivke, ne hex zapisov (hex je tu samo za preverjanje posnetkov v svetli temi).

| Spremenljivka | Svetla | Vloga v tej prenovi |
| --- | --- | --- |
| `--barva-papir` | `#fbf9f5` | podlaga glave, seznama, spodnje vrstice |
| `--barva-crnilo` | `#14110f` | besedilo, 3 px črte, aktiven zavihek |
| `--barva-crnilo-2` | `#332e29` | uvodni odstavki |
| `--barva-crnilo-3` | `#5b534d` | mono meta, neaktivni zavihki, mesta 4+ |
| `--barva-crnilo-4` | `#6e655e` | ločilo »–« med Z in P, opombe |
| `--barva-crta` | `#ded7ce` | 1 px črte vrstic, obrobe neaktivnih gumbov |
| `--barva-polnilo` | `#ede7df` | podlaga palice, odigrana kola, znak forme N |
| `--barva-glavna` | `#0088ce` | 4 px črta stanja »v teku«, obroba polnega gumba |
| `--barva-glavna-polna` | `#0071ab` | polna modra pod belim besedilom (značka, izbrano kolo) |
| `--barva-glavna-tekst` | `#0071ab` | mesta 1–3, rating moje vrstice |
| `--barva-glavna-mehko` | `#eaf3f9` | podlaga poudarjene vrstice / aktivne postavke vrstice |
| `--barva-poudarek` | `#7bb900` | 4 px črta cone napredovanja, status zaključen (črta) |
| `--barva-poudarek-tekst` | `#4a7500` | ↑ premik, zmage, »Zaključen« |
| `--barva-poudarek-mehko` | `#eaf4d6` | znak forme Z |
| `--barva-negativna` | `#b23a1e` | 4 px črta cone izpada, porazi |
| `--barva-negativna-tekst` | `#8c2b14` | ↓ premik |
| `--barva-negativna-mehko` | `#f8e5df` | znak forme P |

Pisave (že vgrajene lokalno prek fontsource):
`--pisava-display` Bricolage Grotesque · `--pisava-telo` Karla · `--pisava-mono` IBM Plex Mono.

Tipografija te prenove:

| Vloga | Zapis |
| --- | --- |
| Mono nadnaslov (`.naslov-mobi__nad`) | `500 12px/1.4` mono, `letter-spacing .12em`, uppercase, crnilo-3 |
| Naslov seznama (`.naslov-mobi--seznam`) | display `800 36px/0.95`, `letter-spacing -.035em`, `margin-top 4px` |
| Naslov podstrani (`.naslov-mobi--podstran`) | display `800 32px/1`, `letter-spacing -.035em`, `margin-top 6px`, ellipsis |
| Naslov sekcije (`.naslovna-mobi h2`) | display `800 24px/1`, `letter-spacing -.02em`, nad njim 3 px črta crnila + `padding-top 10px` |
| Ime v vrstici | telo `700 17px/1.2`, ellipsis v eni vrstici |
| Mono meta pod imenom | `500 12px/1.4` mono, `letter-spacing .04em`, crnilo-3, ellipsis |
| Velika številka desno (rating) | mono `600 26px/1`, `tabular-nums` |
| Velika številka desno (točke lige) | mono `600 24px/1`, `tabular-nums` |
| Mesto v vrstici | mono `600 17px/1.1` (lestvica) oz. `600 15px/1.1` (liga), desno poravnano |
| Značka statusa (`.znacka--drobna`) | mono `600 10px/1.2`, `letter-spacing .1em`, uppercase, `padding 5px 7px` |
| Mono status brez ploskve (`.status-mobi`) | mono `600 10px/1.2`, `letter-spacing .1em`, uppercase |

---

## Zaslon 1 — `/lige` (seznam lig)

Posnetek: `screenshots/01-lige-seznam.png`. Vir: `src/strani/LigeStran.tsx`.

### Postavitev (od zgoraj navzdol)

1. **Lepljiva glava** (obstoječa `Postavitev` + `.glava-telefon`, brez sprememb v ogrodju):
   logotip levo; desno prek `<GlavaDejanja>` gumb **`+ Liga`** (`.glava-telefon__gumb`,
   `min-height 36px`, `padding 8px 10px`, polna `--barva-glavna-polna`, mono `600 11px`, uppercase)
   in `UporabniskiMeni`. Pod vrsto 1 px + 3 px črta crnila.
   → `LigeStran` mora dejanje »+ Nova liga« na telefonu preseliti v `<GlavaDejanja>` (enako kot
   `TurnirjiStran`); nad seznamom gumba ni več.
2. **Naslovni blok** v vsebini (`padding 20px`, `gap 32px` med sklopi — to daje `.vsebina--telefon`):
   `naslov-mobi__nad` = »Ekipna tekmovanja«, `h1.naslov-mobi.naslov-mobi--seznam` = »Lige«.
   Uvodnega odstavka na telefonu **ni**.
3. **Krmila** (`.krmila-mobi`, `margin-top 12px`, `justify-content: space-between`):
   levo nativni `.izbor-statusa` s števci (`Vse · 5`, `V teku · 3`, `Priprava · 1`,
   `Zaključene · 1`) — `min-height 44px`, `padding 10px 30px 10px 12px`, `1px solid crnilo`,
   mono `500 12px`, uppercase, puščica `▾` absolutno `right: 12px`;
   desno `.osvezeno-mobi` »Osveženo 19:24« (mono `500 12px`, uppercase, crnilo-3).
4. **Sekcija »V teku«** (`.naslovna-mobi` + števec) → vrstice; prva vrstica (liga, ki jo gledalec
   spremlja oz. prva v teku) je poudarjena: `background --barva-glavna-mehko`,
   `padding-right 12px`, **brez** spodnje črte (enak vzorec kot `.vrstica-mobi--danes`).
5. **Sekcija »Vse lige«** (`.naslovna-mobi` + števec `5`) → vse vrstice, filtrirane z izborom.

### Vrstica lige — nov razred `.vrstica-mobi--liga`

```
display: grid;
grid-template-columns: minmax(0, 1fr) auto;
align-items: center;
column-gap: 12px;
padding: 12px 0 12px 10px;
border-left: 4px solid var(--barva-crta);   /* --V_TEKU → glavna, --ZAKLJUCEN → poudarek */
border-bottom: 1px solid var(--barva-crta);
```

Vsebina, natanko trije podatki (**število ekip, format srečanja in »↑ · ↓« odpadejo** — dobijo se na
strani lige):

- `.vrstica-mobi__ime` — ime lige, `700 17px/1.2`, ellipsis.
- `.vrstica-mobi__meta` — mono `500 12px`, crnilo-3, `margin-top 3px`:
  liga v teku »`2025/26 · 7. od 18 kol`«, v pripravi »`2025/26`«, zaključena »`2024/25`«.
  Če liga nima sezone, meta pade na `—` in nikoli ni prazna vrstica.
- **Status desno**: `V teku` → polna značka `.znacka--V_TEKU.znacka--drobna`;
  `Priprava` / `Zaključen` → `.status-mobi` (barvna mono oznaka, brez ploskve).
- **Palica napredka** (`.palica--tanka`, `height 4px`, `margin-top 6px`) samo pri ligi v teku;
  v poudarjeni vrstici je podlaga bela (`.palica--na-modri`), sicer `--barva-polnilo`.
  Polnilo = `odigranihKol / steviloKol`.

Cela vrstica je `<Link to={`/lige/${liga.id}`}>`, brez notranjih klikljivih elementov.

---

## Zaslon 2 — `/lestvica` (globalna lestvica)

Posnetek: `screenshots/02-lestvica.png`. Vir: `src/strani/LestvicaStran.tsx`.

### Postavitev

1. **Lepljiva glava**: logotip; desno prek `<GlavaDejanja>` preklopnik **`Išči`**
   (`min-height 36px`, `1px solid crnilo`, prozorna podlaga, mono `600 11px`, uppercase) in
   `UporabniskiMeni`. Klik odpre polje za iskanje **pod debelo črto** (`<GlavaNaslov>` oz. lasten
   pas): polje `.iskalnik` čez vso širino, `min-height 44px`, ob njem mono gumb `Prekliči`, ki
   izbriše iskanje in pas zapre. Ko je iskanje aktivno, gumb `Išči` dobi polno črno ploskev.
2. **Naslovni blok**: `naslov-mobi__nad` = »Klubski ELO«, `h1` = »Lestvica«. Uvoda ni.
3. **Krmila** — dva nativna izbora v vrsti (`display flex; gap 8px; margin-top 12px`, vsak `flex 1`,
   `min-height 44px`, `padding 10px 26px 10px 12px`, mono `500 12px`, uppercase):
   - **kategorija**: `Vsi · 96`, `Člani · 62`, `Članice · 21`, `U19 · 9`, `Veterani · 4`
     (ponudijo se samo kategorije, ki v podatkih obstajajo — logika ostane, kot je);
     aktivna obroba `1px solid crnilo`.
   - **razvrstitev**: `Rating`, `Uspešnost`, `Odigrane`; obroba `--barva-crta`, besedilo crnilo-3.
   Pas gumbov `.lestvica__filtri` na telefonu odpade v celoti.
4. **Sekcija »Razvrstitev«** (`.naslovna-mobi`): desno `.naslovna-mobi__stevec--drobno`
   »96 igralcev · 12 klubov«; ob aktivnem iskanju/filtru »Prikazanih 12 od 96«.
5. **Vrstice** (`margin-top 8px`), pod njimi opomba mono `500 11px/1.5`, uppercase, crnilo-4:
   »Gibanje in Δ: primerjava s stanjem pred 30 dnevi«. Namig o igralcih brez tekme ostane pod njo
   (`.namig`, na telefonu 15px/1.6, crnilo-3).
6. Tabela `.lestvica--globalna` se na telefonu **ne izriše** (`display: none` ali pogojno drevo prek
   `useTelefon()` — raje drugo, ker vrstica ni tabela).

### Vrstica lestvice — nov razred `.lestvica-mobi__vrstica`

```
display: grid;
grid-template-columns: 26px minmax(0, 1fr) auto;
align-items: center;
column-gap: 12px;
padding: 11px 0;
border-bottom: 1px solid var(--barva-crta);
```

- **Mesto** — `grid-row: 1 / span 2`, mono `600 17px/1.1`, `tabular-nums`, desno;
  mesta 1–3 `--barva-glavna-tekst`, ostala crnilo-3.
- **Ime** — vrstica 1, stolpec 2: `700 17px/1.2`, crnilo, ellipsis, `<Link>` na profil.
- **Meta** — vrstica 2, stolpec 2, `margin-top 2px`, mono `500 12px/1.4`,
  `letter-spacing .02em`, crnilo-3, ellipsis, oblika:
  `klub · Z–P · gibanje`, npr. `NTK Savinja · 41–12 · ↑2`.
  Klub brez podatka → `—`. Gibanje: `↑n` v `--barva-poudarek-tekst`, `↓n` v
  `--barva-negativna-tekst`, brez premika `–` v crnilo-3 (ohrani `aria-label` iz obstoječe
  funkcije `gibanje()`). Ločilo med številkama je en-dash `–` brez presledkov okoli pike.
- **Rating** — stolpec 3, `grid-row: 1 / span 2`, mono `600 26px/1`, `tabular-nums`, desno,
  crnilo; brez ratinga `—`.
- **Moja vrstica** (`igralec.idIgralca === mojIdIgralec`):
  `margin-left: -12px; padding: 11px 8px 11px 12px; border-left: 4px solid var(--barva-glavna);
  background: var(--barva-glavna-mehko);` brez spodnje črte, rating v `--barva-glavna-tekst`.
- Stolpca **Δ 30 dni** na telefonu ni (gibanje ga povzame).

---

## Zaslon 3 — `/lige/:id`, zavihek **Lestvica**

Posnetek: `screenshots/03-liga-lestvica.png`. Vir: `src/strani/LigaStran.tsx`.

### Lepljiva glava (vse ostane na zaslonu med drsenjem)

1. Vrsta 56 px: levo `← LIGE` (`useNazaj('/lige', 'Lige')` — stran mora ta kavelj **dodati**),
   desno meni `···` (`MeniDejanj`) z postavkama **Ekipe in kader** ter **Uredi pravila** (samo
   urejevalec) in `UporabniskiMeni`. Gumbov »Pravila« / »Ekipe in kader« pod naslovom ni več.
2. 1 px + 3 px črta crnila.
3. `<GlavaNaslov>` blok, `padding 12px 20px 0`:
   - mono nadnaslov `Liga · 2025/26 · moški` (`.naslov-mobi__nad`),
   - `h1.naslov-mobi--podstran` = ime lige (`800 32px/1`, ellipsis) + ob njem
     `.znacka--v-naslovu` s statusom (`padding 4px 7px`, mono `600 10px`),
   - vrsta stanja (`margin-top 8px`, `display flex; justify-content space-between`):
     levo mono `500 12px` crnilo-3 »`7. od 18 kol · naslednje 12. 4.`«
     (zaključena liga: »`Končano 6. 4.`«; brez razporeda: »`Razpored ni generiran`«),
     desno mono `600 12px` crnilo `39 %`,
   - palica 4 px (`margin-top 6px`, podlaga `--barva-polnilo`, polnilo `--barva-glavna`).
     Brez razporeda palice ni.
4. Zavihki (`.podnavigacija--telefon`, `margin-top 12px`, `padding 0 20px 10px`,
   `border-bottom 1px solid --barva-crta`, `gap 4px`): **Lestvica · Razpored · Pravila**, vsak
   `flex 1`, `min-height 40px`, mono `500 11px`, uppercase; aktiven = polna črna ploskev
   (`--barva-crnilo` / besedilo `--barva-papir`). »Pravila« ni zavihek vsebine, ampak odpre
   obstoječe modalno okno `PravilaOkno`.
   Stanje `mobilniPogled` že obstaja — razširi ga na `'LESTVICA' | 'RAZPORED'` + klic okna.
   Piramida sezone na telefonu odpade iz glavnega toka; postavi jo **na konec zavihka Lestvica**
   (obstoječa `.liga__piramida`, v enem stolpcu — pravilo `slog.css:5920` že obstaja).

### Vsebina zavihka (`padding 16px 20px 0`, `gap 16px`)

Naslovna vrstica **brez** 3 px črte (`.naslovna-mobi--brez-crte`, ker zavihki že režejo pas):
`h2` »Lestvica«, desno mono `500 11px` »10 ekip · Zadnjih 5«.

### Vrstica ekipe — nov razred `.lestvica-mobi__vrstica--ekipa`

```
display: grid;
grid-template-columns: 22px minmax(0, 1fr) auto;
align-items: center;
column-gap: 10px;
padding: 10px 0 10px 8px;
border-left: 4px solid var(--barva-crta);   /* cona: napreduje → poudarek, izpade → negativna */
border-bottom: 1px solid var(--barva-crta);
```

- **Mesto** — `grid-row: 1 / span 2`, mono `600 15px/1.1`, desno; v coni napredovanja
  `--barva-poudarek-tekst`, v coni izpada `--barva-negativna-tekst`, sicer crnilo-3.
  (Cono nosi `LestvicaEkipeDto.cona`, kot doslej.)
- **Ekipa** — vrstica 1: `700 17px/1.2`, ellipsis.
- **Vrstica 2** (`margin-top 4px`, `display flex; align-items center; gap 6px`):
  bilanca mono `500 11px/1.3` crnilo-3 v obliki `Z-N-P` (`6-1-0`), za njo forma zadnjih petih
  srečanj — kvadratki `12 × 12 px`, `gap 3px`: Z `--barva-poudarek-mehko`,
  P `--barva-negativna-mehko`, N `--barva-polnilo`. Črka ostane samo za bralnik zaslona
  (obstoječi `.lestvica__forma-crka`).
- **Točke** — stolpec 3, `grid-row: 1 / span 2`, mono `600 24px/1`, `tabular-nums`, desno.
- **Kader**: vrstica je gumb, ki razširi obstoječi `Kader` **pod** njo (isti `odprtaEkipa` state).
  Ločenega gumba »Kader ▾« v vrstici na telefonu ni; odprta vrstica dobi
  `background --barva-glavna-mehko`.
- **Legenda** pod seznamom (`.legenda`, mono `500 11px`, uppercase, `gap 12px`, `margin-top 12px`):
  16 × 4 px črta + besedilo »Napreduje v <ime višje lige>« / »Izpade v <ime nižje lige>«.
  Izriše se samo, če ima liga `stNapreduje > 0` oz. `stIzpade > 0`.

---

## Zaslon 4 — `/lige/:id`, zavihek **Razpored**

Posnetek: `screenshots/04-liga-razpored.png`. Ista lepljiva glava, aktiven zavihek »Razpored«.

1. **Krmar kola** — `display grid; grid-template-columns: 44px minmax(0,1fr) 44px; gap 12px;`
   `padding-bottom 10px; border-bottom: 2px solid var(--barva-crnilo)`.
   Levo/desno kvadratni gumb 44 × 44 z `←` / `→` (mono `500 12px`; onemogočen = obroba
   `--barva-crta`, besedilo crnilo-3; omogočen = obroba crnila). **Besedila »Prejšnje« /
   »Naslednje« na telefonu ni** — smer nosi puščica.
   Sredina: display `800 24px` »8. kolo«, pod njim mono `500 11px`, uppercase, crnilo-3
   »12. 4. 2026 · razpored« (odigrano kolo: »· odigrano«).
2. **Srečanja** — vrstica `display grid; grid-template-columns: minmax(0,1fr) 56px minmax(0,1fr);`
   `gap 10px; padding 14px 0; border-bottom: 1px solid var(--barva-crta)`.
   Domači desno poravnani, gost levo, oba `700 15px` z ellipsis; sredina mono `600 15px`:
   izid `3 : 4` na podlagi `--barva-polnilo` (`padding 6px 0`), pri nerazporejenem »vs« brez
   podlage v crnilo-3. Zmagovalec `font-weight 700`, poraženec crnilo-4.
   Mono povezava »Zapisnik / Postava« na telefonu odpade — vrstica vodi na srečanje cela.
3. **Trak vseh kol** — mono naslov `500 12px`, uppercase, crnilo-3 »Vsa kola«; pod njim
   `display flex; flex-wrap wrap; gap 4px; margin-top 10px`, gumbi **40 × 40 px** (namizje 44):
   odigrano = podlaga `--barva-polnilo` + crnilo, prihodnje = obroba `--barva-crta` + crnilo-3,
   izbrano = polna `--barva-glavna-polna` + belo besedilo. Prst dobi 44 px prek nevidnega
   `::after` (isti prijem kot `.glava-telefon__gumb`).

---

## Vedenje in stanja

- **Prelomna točka** je ista kot doslej: `POIZVEDBA_TELEFON = (max-width: 640px)` v
  `src/pomozno/telefon.ts`. Drevo izbira `useTelefon()`, mere in barve **vedno** CSS.
- **Nalaganje / napaka / prazno stanje**: obstoječi `NapakaPoizvedbe`, `<p className="obvestilo">`
  — izrišejo se pod naslovno vrstico sekcije, ne nad njo.
- **Osveževanje**: `refetchInterval` in `uraOsvezitve` ostaneta; ura se na /lige izriše v
  `.krmila-mobi` desno.
- **Iskanje na lestvici**: prazno iskanje pas zapre; iskanje ostane v stanju strani (ne v URL).
- **Filtri**: nativni `<select>` z `<span className="samo-za-bralnik">` oznako (vzorec iz
  `TurnirjiStran`), nikoli lasten spustni meni.
- **Dostopnost**: vsak cilj ≥ 44 px (`@media (pointer: coarse)` v `slog.css` že velja),
  puščice in barve nikoli edini nosilec pomena (`aria-label` iz `gibanje()`, `.samo-za-bralnik`
  črke forme), `aria-current` na izbranem kolu.
- **Temna tema**: brez novih pravil — vse barve so spremenljivke, ki jih
  `@media (prefers-color-scheme: dark)` že zamenja. Po implementaciji preveri oba pogleda.
- **Tisk**: teh strani ne zadeva.

## Kaj spremeniti v kodi

| Datoteka | Sprememba |
| --- | --- |
| `src/strani/LigeStran.tsx` | veja `if (jeTelefon)`: naslov-mobi, `.krmila-mobi` z izborom statusa, sekciji »V teku« + »Vse lige«, `VrsticaLigeMobi`; dejanje »+ Liga« v `<GlavaDejanja>` |
| `src/strani/LestvicaStran.tsx` | veja `if (jeTelefon)`: naslov-mobi, dva nativna izbora, preklopnik iskanja v glavi, `VrsticaLestviceMobi` namesto tabele |
| `src/strani/LigaStran.tsx` | `useNazaj('/lige', 'Lige')`; `<GlavaNaslov>` z nadnaslovom, imenom, značko, vrsto stanja in palico; zavihki v `<GlavaZavihki>`; `MeniDejanj` z »Ekipe in kader« / »Uredi pravila«; mobilni izris lestvice in razporeda; piramida na konec zavihka Lestvica |
| `src/komponente/Znacka.tsx` | ponovno uporabi `StatusMobi` / `ZnackaVNaslovu` — novih ni treba |
| `src/slog.css` | **samo razdelek 17 (Telefon)** + po potrebi obstoječi blok `@media (max-width: 720px)`: novi razredi `.vrstica-mobi--liga`, `.lestvica-mobi`, `.lestvica-mobi__vrstica`, `.lestvica-mobi__vrstica--ekipa`, `.lestvica-mobi__meta`, `.liga-mobi__stanje`, `.liga-mobi__krmar`, `.liga-mobi__srecanje`, `.liga-mobi__trak-gumb`. Namiznih pravil ne spreminjaj. |

Komentarji v `slog.css` in v straneh so del sloga te baze kode: vsak nov blok naj ima kratko
razlago **zakaj** (kaj je odpadlo in čemu), v istem tonu kot obstoječi razdelek 17.

## Sredstva

Novih sredstev ni. Edina ikona je obstoječi `ZnakTurnirko` (štirje pravokotniki) iz
`src/komponente/Postavitev.tsx`; puščice (`←`, `→`, `↑`, `↓`, `▾`, `···`) so besedilni znaki, ne
ikone. Pisave so že lokalno vgrajene.

## Zaporedje dela

1. `LigeStran` (najmanjša, postavi vzorec vrstice) → primerjaj z `01-lige-seznam.png`.
2. `LestvicaStran` → `02-lestvica.png`.
3. `LigaStran`, zavihek Lestvica → `03-liga-lestvica.png`.
4. `LigaStran`, zavihek Razpored → `04-liga-razpored.png`.
5. Ponovi vse štiri primerjave še v temni temi in pri 360 px ter 430 px (ni piksel-natančno, a
   nič se ne sme prelamljati ali iztekati iz zaslona).
