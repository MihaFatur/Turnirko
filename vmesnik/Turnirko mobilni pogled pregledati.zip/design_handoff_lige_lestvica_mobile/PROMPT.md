# Navodilo za Claude Code

Prilepi spodnje besedilo v Claude Code, ko je ta paket v korenu projekta (npr. v
`design_handoff_lige_lestvica_mobile/`).

---

V mapi `design_handoff_lige_lestvica_mobile/` je oblikovalski paket za prenovo **mobilnega pogleda**
(≤ 640 px) treh strani aplikacije Turnirko: `/lige`, `/lestvica` in `/lige/:id`.

Preberi `README.md` v celoti, preden začneš. HTML datoteka v paketu je **referenca izgleda**, ne
produkcijska koda — inline slogov ne prenašaj, vsaka vrednost naj postane razred v `src/slog.css`
(razdelek 17 »Telefon«), po vzorcu obstoječih razredov `naslov-mobi`, `krmila-mobi`, `vrstica-mobi`.
Namizne postavitve ne spreminjaj. Prelomna točka ostane `useTelefon()` / `(max-width: 640px)`.

## Zanka primerjave s posnetki — obvezno

Za vsak zaslon delaj v tej zanki, dokler se tvoja implementacija in posnetek **popolnoma ne
ujemata**:

1. Zaženi aplikacijo lokalno (`npm run dev`).
2. Naredi posnetek zaslona z brskalnikom pod nadzorom (Playwright ali Puppeteer), z
   **natanko temi nastavitvami**, ker so bili referenčni posnetki narejeni tako:
   - viewport `390 × 844`, `deviceScaleFactor: 2`
   - `prefers-color-scheme: light`
   - stran na vrhu (`scrollTop = 0`), počakaj, da so pisave naložene (`document.fonts.ready`)
   - posnetek naredi samo za območje aplikacije od vrha glave do spodnje navigacije
3. Primerjaj svoj posnetek z referenco:
   - `design_handoff_lige_lestvica_mobile/screenshots/01-lige-seznam.png` → `/lige`
   - `.../02-lestvica.png` → `/lestvica`
   - `.../03-liga-lestvica.png` → `/lige/:id`, zavihek Lestvica
   - `.../04-liga-razpored.png` → `/lige/:id`, zavihek Razpored
   Primerjaj **numerično** (npr. `pixelmatch` ali ImageMagick `compare -metric AE`) in **vizualno**
   (odpri oba posnetka in ju preglej).
4. Za vsako odstopanje ugotovi vzrok in ga popravi v CSS oz. v drevesu komponente. Preveri po
   vrsti: višina glave (56 px), debelina in zaporedje črt (1 px + 3 px), velikost in `letter-spacing`
   naslova, `padding` vsebine (20 px) in razmik med sklopi (32 px), mreža vrstice in širine prvega
   stolpca (26 px / 22 px), navpični `padding` vrstice (11 px / 10 px / 12 px), velikost velike mono
   številke desno (26 px / 24 px), barva in debelina 4 px črte stanja, višina spodnje navigacije
   (60 px + 3 px črta).
5. Ponovi 2–4, dokler razlika ni le v podatkih (imena, številke) — postavitev, mere, barve in
   tipografija se morajo ujemati piksel za piksel. **Ne nadaljuj na naslednji zaslon, dokler
   trenutni ni usklajen.**
6. Ko so vsi štirje zasloni usklajeni, ponovi posnetke še:
   - v temni temi (`prefers-color-scheme: dark`) — barve so spremenljivke, zato se ne sme pokvariti
     nič; preveri kontrast bele na modri ploskvi,
   - pri 360 px in 430 px — ni piksel-natančno, a nič se ne sme prelamljati, prekrivati ali iztekati
     iz zaslona,
   - z dolgimi imeni (»NTK Nova Gorica – Šempeter«, »Odprto prvenstvo NTK Savinja 2026«) — ime se
     odreže z ellipsis, mreža se ne premakne.

Podatki v posnetkih so izmišljeni; v svoji implementaciji uporabi resnične iz API-ja.

## Ko končaš

Napiši kratek povzetek: katere razrede si dodal v `slog.css`, katera drevesa v straneh, in rezultat
zadnje primerjave za vsak zaslon (število različnih pikslov). Če se kje z referenco namenoma ne
ujemaš (npr. ker podatka iz API-ja ni), to izrecno navedi.
