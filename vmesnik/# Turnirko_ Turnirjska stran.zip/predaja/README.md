# Predaja: prenova strani za turnirje (Turnirko)

## Kaj je to

Prenova treh obstoječih strani vmesnika Turnirko in ene nove faze prikaza:

| # | Pot | Zaslon | Posnetek |
|---|-----|--------|----------|
| 1 | `/turnirji` | seznam turnirjev + pas »Danes v dvorani« | `posnetki/01-seznam-turnirjev.png` |
| 2 | `/turnirji/:id` | turnir z dogodki (vrstice s palico napredka) | `posnetki/02-turnir-z-dogodki.png` |
| 3 | `/dogodki/:id` — zaključen | podij + končni vrstni red | `posnetki/03-dogodek-zakljucen.png` |
| 4 | `/dogodki/:id` — priprava | 100 prijavljenih v dveh stolpcih, iskanje + filter kluba | `posnetki/04-dogodek-priprava-100-prijav.png` |
| 5 | `/dogodki/:id` — v teku | podnavigacija, 25 skupin kot zložljive vrstice | `posnetki/05-dogodek-vteku-skupine-zaprte.png`, `posnetki/06-dogodek-vteku-skupina-odprta.png` |
| 6 | `/dogodki/:id` — v teku | izločilni del po kolih + osvetlitev poti igralca | `posnetki/07-dogodek-izlocilni-del.png`, `posnetki/08-izlocilni-pot-igralca-hover.png` |
| 7 | telefon 390 px | skupine in mreža na telefonu | `posnetki/09-telefon-skupine.png`, `posnetki/10-telefon-izlocilni-del.png` |

Izbrana smer je varianta **1a** iz oblikovalskega pregleda. Varianta 1b je zavržena in v tem paketu ni.

## O datotekah v paketu

`Turnirko - nova zasnova 1a.dc.html` (+ `support.js`) je **oblikovalska referenca v HTML** — prototip, ki kaže videz in vedenje. **Ni produkcijska koda za prepis.** Naloga je te zaslone poustvariti v obstoječem okolju aplikacije Turnirko: **React + TypeScript, `.tsx` strani v `vmesnik/src/strani/`, komponente v `vmesnik/src/komponente/`, ves slog v `vmesnik/src/slog.css` prek razredov in CSS spremenljivk.**

Prototip zaradi svojega okolja uporablja vrinjene (`inline`) sloge in surove šestnajstiške barve. **V aplikaciji tega ne ponavljaj.** Vsaka barva, mera in tip pisave, ki jo vidiš v prototipu, ima že obstoječo spremenljivko v `slog.css` — uporabi njo (preglednica spodaj).

## Natančnost

**Visoka (hi-fi).** Barve, tipografija, mere in interakcije so končne. Cilj je ujemanje s posnetki zaslona do piksla natančno pri širini okvirja 1280 px. Postopek preverjanja je v `NAVODILA-CLAUDE-CODE.md` — preberi ga pred začetkom.

## Zavezujoča pravila (iz `DESIGN.md` in glave `slog.css`)

Prenova ne sme prelomiti nobenega od teh pravil; posnetki jih vsi spoštujejo:

- `border-radius: 0` povsod — tudi gumbi, polja, značke, modalna okna.
- `box-shadow` ni dekoracija. Edini dovoljeni: podčrtaj aktivne navigacijske postavke in `inset` črta ob strani vrstice (npr. zelena črta »napreduje«).
- Brez gradientov (izjema: 8 % polnilo pod črto grafa ELO), brez ikon, brez emojijev.
- Vsaka mera je večkratnik 8 px. Izjema: navpični odmik vrstice 14–20 px.
- Barva besedila na obarvani podlagi je vedno zapisana izrecno.
- Tri pisave, nič več: `--pisava-display` (Bricolage Grotesque), `--pisava-telo` (Karla), `--pisava-mono` (IBM Plex Mono).
- Klikljivi cilji najmanj 44 px visoki.
- Vse besedilo je slovensko, brez okrajšav, ki jih sodnik ne bi prebral.

## Oblikovalski žetoni — preslikava prototip → `slog.css`

| V prototipu | Spremenljivka | Vloga |
|---|---|---|
| `#0088CE` | `--barva-glavna` | črte, palice napredka, obrobe (nikoli pod besedilom) |
| `#0071AB` | `--barva-glavna-polna` | polne ploskve z belim besedilom (gumb, značka »V teku«) |
| `#0071AB` (besedilo) | `--barva-glavna-tekst` | povezave, »odpri« |
| `#EAF3F9` | `--barva-glavna-mehko` | podlaga odprte skupine, osvetljena pot igralca |
| `#7BB900` | `--barva-poudarek` | črta »napreduje«, končan napredek |
| `#4A7500` | `--barva-poudarek-tekst` | število zmag |
| `#EAF4D6` | `--barva-poudarek-mehko` | značka »Zaključen«, opomba turnirja |
| `#B23A1E` | `--barva-negativna` | število porazov |
| `#FBF9F5` | `--barva-papir` | podlaga strani |
| `#DCD8D1` | `--barva-namizje` | podlaga za okvirjem |
| `#14110F` | `--barva-crnilo` | glavno besedilo, 3 px črta nad sekcijo |
| `#332E29` | `--barva-crnilo-2` | uvodni odstavek |
| `#5B534D` | `--barva-crnilo-3` | mono oznake, drugotno besedilo |
| `#6E655E` | `--barva-crnilo-4` | onemogočeno |
| `#DED7CE` | `--barva-crta` | ločnice vrstic, obrobe kartic |
| `#EDE7DF` | `--barva-polnilo` | prazen del palice napredka, značka »Priprava« |
| `#FFFFFF` | `--barva-bela` | podlaga kartice tekme |
| 8/16/24/32/40/48/56/64 px | `--r1`…`--r8` | odmiki |
| 12/14/17/18/20/24/40/48/88 px | `--tip-mono`, `--tip-drobno`, `--tip-telo`, `--tip-vrstica`, `--tip-uvod`, `--tip-h3`, `--tip-h2`, `--tip-h1-nad`, `--tip-h1` | tipografska lestvica |
| 1280 px | `--sirina-okvirja` | širina vsebine |

Mono oznake so vedno: `--tip-mono`, `font-weight: 500`, `letter-spacing: 0.08–0.12em`, `text-transform: uppercase`, barva `--barva-crnilo-3`.
Številke v tabelah imajo `font-variant-numeric: tabular-nums`.

## Zaslon 1 — `/turnirji` (`TurnirjiStran.tsx`)

**Namen:** sodnik najde turnir, ki ga vodi danes, v manj kot sekundi.

Nad obstoječim seznamom je nova sekcija **»Danes v dvorani«** — samo turnirji s statusom `V_TEKU`.

- Naslov sekcije po obstoječem vzorcu: 3 px črta `--barva-crnilo` na vrhu, `padding-top: --r2`, `h2` v `--tip-h2`, teža 800, `letter-spacing: -0.03em`; desno mono »osveženo ob HH.MM«.
- Vrstica turnirja: `display: grid`, stolpci `88px minmax(0,1fr) 232px 168px 112px`, `gap: --r3`, `padding: --r3 0`, leva črta `4px solid --barva-glavna`, podlaga `--barva-glavna-mehko`.
- Stolpec 1: dan (mono 20 px, teža 600) nad mesecem (mono 12 px, verzalke, `--barva-crnilo-3`).
- Stolpec 2: ime turnirja (Karla 24 px, teža 700) nad krajem in številom dogodkov (Karla 16 px, teža 300, `--barva-crnilo-3`).
- Stolpec 3: napredek — mono oznaka »Odigranih 84 / 181« in pod njo palica: višina 6 px, podlaga `--barva-polnilo`, polnilo `--barva-glavna` v širini deleža.
- Stolpec 4: obdobje, mono 15 px. Stolpec 5: značka statusa, sredinjena.
- Če ni turnirja v teku, sekcija se ne izriše (brez praznega stanja).

Seznam **»Vsi turnirji«** ostane, dobi pa:
- glavo stolpcev (mono 12 px, verzalke, ločnica 1 px `--barva-crnilo`): Začetek / Turnir / Dogodki / Obdobje / Status,
- filtri desno v naslovu sekcije dobijo števce: `Vsi · 8`, `V teku · 1`, `Priprava · 3`, `Zaključeni · 4`,
- ista mreža stolpcev kot pas zgoraj; leva 4 px črta v vrstici prevzame barvo statusa (`--barva-glavna` v teku, `--barva-poudarek` zaključen, `--barva-crta` priprava).

Turnir brez datuma prikaže `—` v stolpcu dneva in `—` v obdobju (glej zadnjo vrstico posnetka).

## Zaslon 2 — `/turnirji/:id` (`TurnirStran.tsx`)

Glava strani ostane nespremenjena (nadnaslov »Turnir« v `--tip-h1-nad`, ime v `--tip-h1`, kraj in obdobje v `--tip-uvod`, opomba z zeleno levo črto 4 px na `--barva-poudarek-mehko`).

Kolofon desno (širina 380 px) se razširi na štiri vrstice: Prijavljenih skupaj / Odigranih tekem / Dogodki / Šteje v ELO. Vsaka vrstica: mono oznaka levo, mono 16 px teža 600 desno, ločnica 1 px `--barva-crta`, `padding: 10px 0`.

**Vrstica dogodka** je jedro tega zaslona:
- mreža `minmax(0,1fr) 200px 200px 232px 112px`, `gap: --r3`, `padding: --r3 0 --r3 12px`, leva 4 px črta po statusu,
- ime dogodka (Karla 22 px / 700) nad podrobnostjo (spol · število nizov, Karla 16 px / 300),
- sistem tekmovanja kot mono 12 px z **2 px podčrtajem `--barva-poudarek`** (ne kot značka),
- prijave (mono 15 px), napredek (mono oznaka + palica kot na zaslonu 1),
- značka statusa.
- Dogodek pred žrebom nima palice — namesto nje mono besedilo »žreb še ni izveden« in siva leva črta.

Zaporedje dogodkov ostane po datumu ustvarjanja; ne razvrščaj po statusu.

## Zaslon 3 — `/dogodki/:id`, status `ZAKLJUCEN`

- Sekcija **Razvrstitev**: trije stolpci enake širine, vsak z levo 4 px črto (`--barva-poudarek`, `--barva-glavna`, `--barva-crta`), `padding: 0 --r3`. Mesto kot Bricolage 48 px / 800, pod njim ime (Karla 20 px / 700) in klub + rating (Karla 15 px / 300, `--barva-crnilo-3`).
- Sekcija **Končni vrstni red**: dva stolpca (`gap: 0 --r7`), vrstica `56px minmax(0,1fr) 88px 72px`: mesto (mono 17 px / 600, desno), ime nad klubom, izkupiček zmage–porazi (mono 14 px), sprememba ELO (mono 14 px / 600; `+` v `--barva-poudarek-tekst`, `−` v `--barva-negativna`).
- Pri 24 igralcih to pomeni 12 vrstic na stolpec. Pri več kot 40 igralcih uporabi tri stolpce.

## Zaslon 4 — `/dogodki/:id`, status `PRIPRAVA`

Glavni cilj: **100 prijavljenih na enem zaslonu prenosnika, brez straničenja.**

- Naslov sekcije »Prijavljeni«; desno polje za iskanje (širina 240 px, obroba 1 px `--barva-crnilo`, podlaga `--barva-bela`, `min-height: 44px`, ozdnak »išči po priimku«) in mono števec »N od 100 prikazanih«.
- Pod naslovom vrsta filtrov po klubu: gumbi `min-height: 44px`, `padding: 8px 12px`, mono 12 px verzalke, oblika `Ime kluba · N`. Izbrani gumb: podlaga `--barva-crnilo`, besedilo `--barva-papir`. Neizbrani: obroba `--barva-crta`, besedilo `--barva-crnilo-3`. Prvi gumb je »Vsi klubi · 100«.
- Seznam: **dva stolpca** (`grid-template-columns: repeat(2, minmax(0,1fr))`, `gap: 0 --r7`), vsak s svojo glavo `#` / Igralec / Rating. Vrstica: `44px minmax(0,1fr) 64px`, `padding: --r1 0`, ločnica 1 px `--barva-crta`, ime Karla 16 px, klub pripet za piko v 14 px / 300 `--barva-crnilo-3`, rating mono 14 px desno.
- Levo je prva polovica (mesta 1–50), desno druga (51–100). Iskanje in filter delujeta na celoten seznam in ga znova razpolovita, zato se stolpca vedno enako napolnita.
- Razvrstitev po ratingu navzdol; številka pred imenom je jakostno mesto, ki ga bo uporabil žreb.
- Desno od seznama ostane obstoječi blok »Dodaj igralce« (potrditvena polja 28 px, `min-height: 44px` na vrstico).
- Gumb »Izvedi žreb« je v glavi strani ob znački statusa: podlaga `--barva-poudarek`, besedilo `--barva-na-poudarku`.

Vedenje pri drugih velikostih: do 24 prijavljenih en stolpec, 25–120 dva stolpca, nad 120 trije. To je edina razlika med majhnim in velikim dogodkom.

## Zaslon 5 — `/dogodki/:id`, status `V_TEKU`, pogled Skupine

### Podnavigacija dogodka (nova komponenta)

Lepljiv pas pod glavo strani: `position: sticky; top: 0`, podlaga `--barva-papir`, 3 px črta `--barva-crnilo` na vrhu, 1 px `--barva-crta` spodaj, `padding: 12px --r5`.

- Levo gumbi pogleda: **Skupine / Izločilni del / Udeleženci**. Enak videz kot filtri klubov (mono 12 px verzalke, izbran = črna ploskev). Izriši samo pogled, ki v tem dogodku obstaja: krožni sistem ima »Razvrstitev« namesto »Skupine« in nima »Izločilni del«; nov sistem tekmovanja doda svoj gumb, brez posegov v ta pas.
- Desno mono povzetek: »25 skupin · odigranih 78 / 150«.

### Skupine kot zložljive vrstice

To je najpomembnejši del prenove. **Nikoli ne izriši vseh skupin odprtih.** Pri 100 prijavljenih je to 25 skupin.

- Glava stolpcev: Skupina / Igralci / (desno) Podrobno.
- Zaprta vrstica: mreža `64px minmax(0,1fr) 96px`, `gap: --r2`, `min-height: 56px`, `padding: 12px 0 12px 12px`, ločnica 1 px `--barva-crta`, leva 4 px črta prozorna.
  - oznaka skupine: Bricolage 24 px / 800, `letter-spacing: -0.02em`,
  - »4 igralci« v Karla 17 px `--barva-crnilo-2`,
  - desno mono »odpri« v `--barva-glavna-tekst`.
- Odprta vrstica: leva 4 px črta `--barva-glavna`, podlaga `--barva-glavna-mehko`, oznaka desno postane »zapri«.
- Odprta vsebina (pod vrstico, podlaga `--barva-glavna-mehko`, `padding: --r3 --r3 --r4 12px`): dva stolpca `minmax(0,1.1fr) minmax(0,1fr)`, `gap: --r5`.
  - Levo **lestvica skupine**: glava `#` / Igralec / Z / P / Nizi; vrstica `44px minmax(0,1fr) 44px 44px 72px`. Prvi dve mesti dobita `box-shadow: inset 4px 0 0 --barva-poudarek`. Pod lestvico legenda: 16×4 px zelen pravokotnik + mono »napredujeta v izločilni del«.
  - Desno **tekme po kolih**: mono naslov »1. kolo«, pod njim vrstice `minmax(0,1fr) 64px minmax(0,1fr)` — ime, rezultat na sredini (mono 16 px / 600), ime desno poravnano. Zmagovalec ima težo 700. Rezultat neodigrane tekme je `–` v `--barva-crnilo-4`, tekma v teku ima besedilo »v igri« v `--barva-glavna-tekst`.
- Odprta je največ **ena** skupina; klik na drugo prvo zapre. Klik na že odprto jo zapre.
- Uporabi obstoječo komponento `Lestvica.tsx` in razrede `.lestvica__*`; nove so samo vrstica skupine in njena zložljivost.

## Zaslon 6 — pogled Izločilni del

- Nad mrežo vrsta gumbov kol: `1/16 · 16`, `1/8 · 8`, `ČF · 4`, `PF · 2`, `F · 1` (oznaka + število tekem). Izbran gumb = črna ploskev. Desno mono opomba »miška nad igralcem osvetli njegovo pot«.
- **Mreža se ne izriše cela.** Izbrano kolo je prvi stolpec, desno od njega stojijo vsa naslednja kola. Privzeto izbrano kolo je najzgodnejše, ki še ni v celoti odigrano.
- Stolpec kola: `flex: 1 0 240px`, `min-width: 240px`; mono naslov kola z 1 px črto `--barva-crnilo` spodaj; tekme z `justify-content: space-around`, `gap: --r2`.
- Kartica tekme: podlaga `--barva-bela`, obroba 1 px `--barva-crta`, leva 4 px črta po stanju — `--barva-poudarek` odigrana, `--barva-glavna` v teku, `--barva-crta` še ni znana. Dve vrstici po `padding: 10px 14px`, med njima 1 px `--barva-polnilo`. Ime 16 px (zmagovalec 700), klub 13 px / 300 `--barva-crnilo-3`, nizi mono 18 px / 600 desno. Poraženec dobi `--barva-crnilo-4`.
- Neznan nasprotnik: besedilo »še ni znan« v `--barva-crnilo-4`, brez rezultata.
- Vsebnik ima `overflow-x: auto`; naslovi kol niso lepljivi (preverjeno — lepljivost se prekriva s prvo kartico).

### Osvetlitev poti igralca (`posnetki/08-…`)

Vsaka polovica kartice nosi `data-igralec="Ime Priimek"` (v aplikaciji raje `data-igralec-id`). Ob `mouseover` nad katerokoli tako polovico dobijo **vse** polovice z istim igralcem `background: --barva-glavna-mehko` in `box-shadow: inset 4px 0 0 --barva-glavna`; ob `mouseout` se odstranita. Tako se pot igralca skozi vsa kola prebere brez klika. Na dotičnih napravah naj isto stanje sproži tap (in ga drug tap odstrani).

## Zaslon 7 — telefon (390 px)

- Glava se skrči: logotip 20 px, brez navigacije, desno vloga uporabnika.
- Naslov dogodka `--tip-h1` pade na 44 px.
- Podnavigacija ostane lepljiva in vodoravno drsna (`overflow-x: auto`), gumbi `white-space: nowrap`, višina 44 px.
- Vrstica skupine se **ne prelomi**: mreža postane `40px minmax(0,1fr) 72px` — odpadeta samo stolpca, ki jih ni.
- Odprta skupina prikaže samo lestvico v obliki `32px minmax(0,1fr) 32px 56px` (mesto, ime, Z, nizi). Tekme so pod njo, brez drugega stolpca.
- Izločilni del ostane **vodoravno drsen** z ožjimi stolpci (232 px) in brez kluba pod imenom, če je prostor tesen.

## Stanje, ki ga je treba dodati

| Stanje | Privzeto | Sprožilec |
|---|---|---|
| `odprtaSkupina: string \| null` | `null` | klik na vrstico skupine (isti ključ zapre) |
| `pogled: 'skupine' \| 'mreza' \| 'udelezenci'` | prvi obstoječi pogled dogodka | gumbi podnavigacije |
| `izbranoKolo: string` | najzgodnejše nedokončano kolo | gumbi kol |
| `iskanje: string` | `''` | polje za iskanje prijavljenih |
| `klub: string` | `'vsi'` | gumbi klubov |
| `osvetljenIgralec: id \| null` | `null` | `mouseover` / `mouseout` v mreži |

Vse to je krajevno stanje strani dogodka; podatki se še naprej berejo prek obstoječih zahtev v `api/zahteve.ts`. Nobena nova poizvedba ni potrebna — palice napredka se izračunajo iz že prenesenih tekem (`odigrane / vse`).

## Odzivnost

| Širina | Vedenje |
|---|---|
| ≥ 1280 px | kot na posnetkih |
| 1024–1279 px | okvir se skrči, seznam prijavljenih ostane dvostolpčen, odprta skupina preide na en stolpec |
| 768–1023 px | seznam prijavljenih en stolpec, `--tip-h1` 56 px, kolofon pod glavo |
| < 768 px | telefonska različica (zaslon 7) |

## Datoteke v paketu

- `Turnirko - nova zasnova 1a.dc.html` — referenčni prototip; odpri v brskalniku, klikaj skupine, kola, klube, iskanje.
- `support.js` — izvajalno okolje prototipa (za aplikacijo ni relevantno).
- `posnetki/*.png` — 10 posnetkov, merilo 2×; merilo za ujemanje.
- `NAVODILA-CLAUDE-CODE.md` — postopek dela in preverjanja.

## Datoteke v aplikaciji, ki se jih dotika

- `vmesnik/src/strani/TurnirjiStran.tsx` — zaslon 1
- `vmesnik/src/strani/TurnirStran.tsx` — zaslon 2
- `vmesnik/src/strani/DogodekStran.tsx` — zasloni 3–6
- `vmesnik/src/komponente/Mreza.tsx`, `TekmaKartica.tsx` — mreža po kolih + osvetlitev poti
- `vmesnik/src/komponente/Lestvica.tsx`, `TekmeSeznam.tsx` — vsebina odprte skupine
- nova komponenta `vmesnik/src/komponente/PodnavigacijaDogodka.tsx`
- nova komponenta `vmesnik/src/komponente/SkupinaVrstica.tsx`
- `vmesnik/src/slog.css` — novi razredi v poglavja 8 (seznami tekmovanj), 9 (mreža), 10 (lestvice, skupine); brez novih barv
