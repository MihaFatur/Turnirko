# Navodila za Claude Code

Preberi najprej `README.md` v tej mapi, nato `vmesnik/turnirko-profil-redesign/project/DESIGN.md` in glavo `vmesnik/src/slog.css`. Šele potem začni pisati kodo.

## Pravila dela

1. **Prototip ni koda za prepis.** `Turnirko - nova zasnova 1a.dc.html` je referenca videza. Implementiraj v obstoječem okolju: React + TypeScript, strani v `vmesnik/src/strani/`, komponente v `vmesnik/src/komponente/`, ves slog kot razredi v `vmesnik/src/slog.css`.
2. **Nič vrinjenih slogov in nič surovih šestnajstiških barv v `.tsx`.** Vsaka barva in mera ima spremenljivko v `slog.css` (preglednica v `README.md`). Če je nimaš, ne izumljaj nove barve — uporabi najbližjo obstoječo.
3. **Ne spreminjaj obstoječega vedenja, ki ga prenova ne omenja** (avtentikacija, žreb, vnos rezultatov, zahteve v `api/`). Prenova je izgled in razporeditev, plus stanja, našteta v `README.md`.
4. **Slovenska besedila.** Prepiši jih natanko iz posnetkov, vključno z ločili (»· «, »/«, »–«).
5. Ohrani obstoječa imena razredov, kjer že opisujejo isto stvar (`.vrstica`, `.mreza__kolo`, `.tekma`, `.lestvica__*`, `.zavihki__gumb`). Nove razrede imenuj po istem vzorcu (`.skupina-vrstica`, `.skupina-vrstica__oznaka`, `.napredek`, `.napredek__palica`).
6. Delaj po zaslonih, en zaslon = ena zaključena sprememba. Vrstni red: zaslon 1 → 2 → 3 → 4 → 5 → 6 → telefon.

## Postopek preverjanja ujemanja s posnetki

Za **vsak** zaslon ponavljaj ta krog, dokler ni razlik:

1. Zaženi razvojni strežnik in odpri ustrezno pot v brskalniku pri širini okna **1280 px** (telefonske zaslone pri **390 px**), pomanjšava 100 %, svetla tema.
2. Napolni zaslon s **primerljivimi podatki**: dogodek s **100 prijavljenimi, 25 skupinami po 4, izločilnim delom od 1/16 finala**. Če take vsebine v razvojni bazi ni, jo ustvari (semenska skripta ali začasni pripomoček) — brez nje ujemanja ni mogoče presoditi.
3. Naredi posnetek zaslona istega izreza kot referenca (celoten okvir vsebine, širina 1280 px).
4. **Primerjaj svoj posnetek z referenco iz `posnetki/`, drugega ob drugem.** Preveri po tem seznamu:
   - zaporedje in poravnava stolpcev v mreži (širine stolpcev iz `README.md`),
   - velikost, teža in barva pisave vsakega besedilnega sloja,
   - navpični ritem: odmiki nad in pod naslovi sekcij, višina vrstic, `min-height: 56px` na vrstici skupine,
   - debelina in barva črt: 3 px nad sekcijo, 1 px ločnice, 4 px leve črte, 2 px podčrtaj sistema,
   - značke: barva podlage, barva besedila, verzalke, `letter-spacing`,
   - palice napredka: višina 6 px, barva polnila, delež,
   - poravnava številk (desno, `tabular-nums`),
   - da ni nikjer zaobljenih vogalov ali senc.
5. Vsako razliko popravi in ponovi od koraka 3. **Ne nadaljuj na naslednji zaslon, dokler se posnetka ne ujemata.**
6. Ko se zaslon ujema, preveri še interakcije:
   - klik na vrstico skupine odpre natanko eno skupino, klik na drugo prvo zapre, klik na odprto jo zapre,
   - gumbi pogleda preklapljajo Skupine / Izločilni del / Udeleženci,
   - gumbi kol premaknejo prvi stolpec mreže; desno ostanejo vsa naslednja kola,
   - `mouseover` nad imenom v mreži osvetli **vse** pojavitve istega igralca (primerjaj s `posnetki/08-izlocilni-pot-igralca-hover.png`),
   - iskanje in filter kluba delujeta hkrati in osvežita števec,
   - vsak klikljiv element je visok vsaj 44 px.
7. Na koncu preveri robne primere, ker se dogodki med sabo razlikujejo:
   - dogodek z **12 prijavljenimi** (en stolpec seznama, krožni sistem, brez izločilnega dela),
   - dogodek pred žrebom (brez skupin, brez mreže, palica napredka zamenjana z »žreb še ni izveden«),
   - zaključen dogodek (podij + končni vrstni red),
   - dogodek s sistemom, ki ga podnavigacija ne pozna — pas se mora izrisati brez napake in prikazati samo obstoječe poglede,
   - turnir brez datuma in turnir brez dogodkov.

## Ko končaš

Napiši kratko poročilo: kaj je implementirano, katere razlike do posnetkov si zavestno pustil in zakaj, ter kaj bi bilo treba dodati na strani zaledja (če kaj). Ne zaključi z odprtimi razlikami, ki jih nisi omenil.
