/* Vzorčni podatki in pogled-model sklopa »Moji igralci« (prenova 1c »Izkaznica«).
   Polja so že oblikovana za prikaz, kakor jih pričakuje MojiIgralciIzkaznica.dc.html.
   V pravi kodi jih izračuna funkcija, ki DomovIgralecDto preslika v pogled-model
   (glej README, razdelek »Podatki in pogled-model«). »Danes« je 3. 11. 2026. */
export function vzorec(st = 2) {
  const DAN = ['ned', 'pon', 'tor', 'sre', 'čet', 'pet', 'sob'];
  const MES = ['jan', 'feb', 'mar', 'apr', 'maj', 'jun', 'jul', 'avg', 'sep', 'okt', 'nov', 'dec'];
  const DANES = Date.UTC(2026, 10, 3);
  const razd = (iso) => { const [l, m, d] = iso.slice(0, 10).split('-').map(Number); return { l, m, d, ms: Date.UTC(l, m - 1, d) }; };
  const kratek = (iso) => { const x = razd(iso); return x.d + '. ' + MES[x.m - 1]; };
  const cez = (iso) => {
    const n = Math.round((razd(iso).ms - DANES) / 86400000);
    if (n <= 0) return 'danes';
    if (n === 1) return 'jutri';
    return 'čez ' + n + ' dni';
  };
  const dan = (iso) => DAN[new Date(razd(iso).ms).getUTCDay()];
  const predznak = (n) => (n >= 0 ? '+' : '−') + Math.abs(n);

  const surovi = [
    {
      id: 1, ime: 'Luka', priimek: 'Zupančič', klub: 'KTT Maribor', druzina: false, slika: true,
      rating: 1482, mesto: 14, skupaj: 212, spol: 'Moški', skupina: 'Člani',
      forma: ['Z', 'P', 'Z', 'Z', 'Z'], bilanca: { z: 18, p: 7 },
      srecanje: { iso: '2026-11-08T18:00:00', ura: '18.00', opis: 'KTT Maribor B – TTK Ptuj', pod: 'Liga Savinja D · 6. kolo · doma' },
      turnir: { iso: '2026-11-22', ime: 'Odprto prvenstvo Celja', status: 'Priprava' },
      zadnje: [
        { iso: '2026-10-25', nasprotnik: 'Žiga Horvat', tekmovanje: 'Liga Savinja D', n: 3, m: 1, d: 6 },
        { iso: '2026-10-18', nasprotnik: 'Rok Tomšič', tekmovanje: 'Liga Savinja D', n: 2, m: 3, d: -8 },
        { iso: '2026-10-11', nasprotnik: 'Matej Kos', tekmovanje: 'Jesenski turnir Maribor', n: 3, m: 0, d: 9 },
      ],
    },
    {
      id: 2, ime: 'Maja', priimek: 'Zupan', klub: 'TTK Ptuj', druzina: true, slika: false,
      rating: 1215, mesto: 31, skupaj: 88, spol: 'Ženske', skupina: 'Rekreativci',
      forma: ['Z', 'P', 'Z', 'Z', 'P'], bilanca: { z: 11, p: 9 },
      srecanje: null,
      turnir: { iso: '2026-11-22', ime: 'Odprto prvenstvo Celja', status: 'Priprava' },
      zadnje: [
        { iso: '2026-10-24', nasprotnik: 'Eva Krajnc', tekmovanje: 'Jesenski turnir Maribor', n: 3, m: 2, d: 11 },
        { iso: '2026-10-10', nasprotnik: 'Nina Vidmar', tekmovanje: 'Odprto prvenstvo Ptuja', n: 0, m: 3, d: -7 },
        { iso: '2026-09-27', nasprotnik: 'Sara Božič', tekmovanje: 'Odprto prvenstvo Ptuja', n: 3, m: 1, d: 5 },
      ],
    },
    {
      id: 3, ime: 'Jan', priimek: 'Rozman', klub: null, druzina: false, slika: false,
      rating: null, mesto: null, skupaj: 0, spol: 'Moški', skupina: 'Člani',
      forma: [], bilanca: null, srecanje: null, turnir: null, zadnje: [],
    },
  ];

  return surovi.slice(0, Math.max(1, Math.min(3, st))).map((p) => {
    const zadnje = p.zadnje.map((t) => ({
      datum: kratek(t.iso), nasprotnik: t.nasprotnik, tekmovanje: t.tekmovanje,
      izid: t.n + ':' + t.m, sprememba: predznak(t.d), barva: t.n > t.m ? '#4A7500' : '#B23A1E',
    }));
    const vsota = p.zadnje.reduce((s, t) => s + t.d, 0);
    const lestvicaKratko = p.spol + ' · ' + p.skupina;
    const srecanje = p.srecanje ? {
      kdaj: dan(p.srecanje.iso) + ', ' + kratek(p.srecanje.iso) + ' · ' + p.srecanje.ura,
      dan: dan(p.srecanje.iso), datum: kratek(p.srecanje.iso), ura: p.srecanje.ura,
      opis: p.srecanje.opis, pod: p.srecanje.pod, cez: cez(p.srecanje.iso),
    } : null;
    const turnir = p.turnir ? {
      kdaj: kratek(p.turnir.iso), ime: p.turnir.ime, status: p.turnir.status, cez: cez(p.turnir.iso),
    } : null;
    return {
      id: p.id, ime: p.ime, priimek: p.priimek, polnoIme: p.ime + ' ' + p.priimek,
      klub: p.klub || 'brez kluba', druzina: p.druzina, neDruzina: !p.druzina, slika: p.slika,
      rating: p.rating, ratingTxt: p.rating == null ? '—' : String(p.rating),
      mesto: p.mesto, skupaj: p.skupaj, lestvicaKratko,
      imaMesto: p.mesto != null,
      mestoTxt: p.mesto != null ? p.mesto + '. od ' + p.skupaj + ' · Lestvica ' + lestvicaKratko : '',
      forma: p.forma, imaForma: p.forma.length > 0,
      bilanca: p.bilanca ? { z: p.bilanca.z, p: p.bilanca.p, odstotek: Math.round(100 * p.bilanca.z / (p.bilanca.z + p.bilanca.p)) } : null,
      spremembaTxt: predznak(vsota), spremembaSmer: vsota > 0 ? 'gor' : vsota < 0 ? 'dol' : 'nic',
      srecanje, turnir,
      imaSrecanje: !!srecanje, imaTurnir: !!turnir, imaTermin: !!(srecanje || turnir), brezTermina: !(srecanje || turnir),
      zadnje, imaZadnje: zadnje.length > 0, brezTekem: zadnje.length === 0,
    };
  });
}
