# Predaja: »Moji igralci« na domači strani — prenova »Izkaznica« (1c)

> **Za Claude Code.** Preberi celotno datoteko, preden spremeniš kodo. Naloga ni končana, ko koda
> deluje, ampak ko se **vseh 14 posnetkov zaslona v `screenshots/` ujema z izrisom tvoje
> implementacije** (razdelek 2). Če česa ne razumeš ali se odločitev razlikuje od zapisane,
> vprašaj uporabnika; ne ugibaj.

## 1. Pregled

Sklop »Moji igralci« (`vmesnik/src/komponente/MojIgralecSklop.tsx`, na domači strani med
sklopoma Turnirji/Lige in Lestvica) pokaže igralce, ki jih račun spremlja. Danes je to vrstica na
igralca z dvema stolpcema (levo ime in rating, desno termin in zadnje tekme). Prenova »Izkaznica«:

- ena velika **izkaznica** naenkrat, igralci so **zavihki** (ob enem igralcu zavihkov ni),
- **ime kot plakat** (ime tanko 200, priimek 800 do 104 px) ob **portretu** (profilna slika ali obris),
- **rating v modrem bloku** (96–112 px), pod njim kolofon: klub, lestvica, mesto, sezonska bilanca,
- **naslednji termin kot »vstopnica«** (svetlomodra ploskev z ločilno črtkano črto),
- **forma zadnjih 5 tekem** (Z/P kvadratki) in zadnje 3 tekme s spremembo ratinga,
- gibanje: rating se naštevilči, vrstice se dvignejo ob vstopu (razdelek 7).

Uporabnik je izbral to različico (1c) med tremi; druge dve (trenutno, »Kartoteka«) nista del predaje.

## 2. Kako preveriš, da se ujema (obvezen postopek)

Uporabnik izrecno zahteva, da svojo kreacijo primerjaš s posnetki, **dokler se popolnoma ne ujemata**.

1. **Zgradi dev harness** po vzoru obstoječega `vmesnik/src/dev/PosnetkiOkna.tsx` (pot `/dev/posnetki`,
   samo `import.meta.env.DEV`, brez prijave in omrežja, podatki iz `primerPodatki.ts`). Dodaj
   `okno=moji-igralci` s parametri:

   | Parameter | Vrednosti |
   |---|---|
   | `stanje` | `vsebina` · `prazno` · `napaka` · `nalaganje` |
   | `st` | število igralcev 1–3 (vzorec: `referenca/moji-igralci-podatki.js`, `vzorec(st)`) |
   | `zacetni` | indeks izbranega zavihka (0–2) |
   | `sirina` | `1280` ali `390` — širina okvirja v CSS px |

   Okvir (`id="posnetek"`) ima **fiksno širino `sirina`**, ozadje `#FBF9F5` (papir) in notranji odmik
   **40px 40px 64px** (1280) oz. **20px 20px 40px** (390), kot ga v aplikaciji daje `.vsebina`.
   Sklop je v njem brez drugih sklopov domače strani. **Animacije izklopljene** (prefers-reduced-motion
   ali parameter), da je posnetek končno stanje. Mock `GumbSpremljanja`/`preklopi` naj ne kliče
   strežnika (kot `ligeApi.termini = async () => []` v obstoječem harnessu).

2. **Posnemi vseh 14 stanj** v brezglavem Chromu (Playwright ali `--headless=new`, kot
   `skripte/ikone/naredi.sh`), `deviceScaleFactor: 1`, počakaj na `document.fonts.ready`,
   posnetek **samo elementa `#posnetek`**.

3. **Primerjaj** vsak posnetek z istoimenskim PNG v `screenshots/`:
   - velikost mora biti **enaka** (tabela spodaj). Drugačna višina = drugačen prelom ali razmik.
   - nato pixel-diff (ImageMagick `compare -metric AE -fuzz 5%` ali `pixelmatch`) **in** oglej si oba
     PNG (`Read`) ter diff sliko. Odpri tudi referenco v živo (točka 5).
   - **Sprejemljivo:** razlike v antialiasingu besedila (< 0,3 % pikslov). **Napaka:** vsak premik
     ≥ 1 px, napačna barva, drugačen prelom vrstice, manjkajoč ali odvečen element.

4. **Popravi in ponovi** za vsa stanja, dokler ni nobenega odstopanja. Ne zaključi z »skoraj«.

5. **Referenca v živo (najnatančnejše merilo).** `referenca/` odpri prek HTTP (npr.
   `npx serve referenca`, nato `Izkaznica posnetki.dc.html`; prek `file://` se datoteke ne naložijo).
   Tam lahko v konzoli izmeriš `getBoundingClientRect()` katerega koli elementa in primerjaš s svojim.
   Vsak okvir ima `id` (npr. `namizje-01-luka-2-igralca`).

**Pogost vzrok razlik — pisave.** Referenca nalaga Google Fonts (`Bricolage Grotesque`, `Karla`,
`IBM Plex Mono`), aplikacija lokalni fontsource (`Bricolage Grotesque Variable`, `Karla Variable`).
Če so besede pri velikih naslovih (priimek 104 px, rating 112 px) širše ali ožje, preveri še
`font-optical-sizing` in `font-variation-settings` (`'opsz'`, `'wdth'`) pri Bricolage, dokler se
širine ujemajo z referenco. Teže: 200 (ime), 800 (priimek, številke), v mono 400/500/600.

### Posnetki (vsi `screenshots/*.png`, merilo 1:1 s CSS px)

| Datoteka | stanje | st | zacetni | sirina | Velikost (W×H) |
|---|---|---|---|---|---|
| namizje-01-luka-2-igralca | vsebina | 2 | 0 | 1280 | 1280×1231 |
| namizje-02-maja-2-igralca | vsebina | 2 | 1 | 1280 | 1280×1117 |
| namizje-03-jan-3-igralci | vsebina | 3 | 2 | 1280 | 1280×924 |
| namizje-04-1-igralec | vsebina | 1 | 0 | 1280 | 1280×1168 |
| namizje-05-prazno | prazno | 2 | 0 | 1280 | 1280×580 |
| namizje-06-napaka | napaka | 2 | 0 | 1280 | 1280×262 |
| namizje-07-nalaganje | nalaganje | 2 | 0 | 1280 | 1280×669 |
| telefon-01-luka-2-igralca | vsebina | 2 | 0 | 390 | 390×1499 |
| telefon-02-maja-2-igralca | vsebina | 2 | 1 | 390 | 390×1423 |
| telefon-03-jan-3-igralci | vsebina | 3 | 2 | 390 | 390×1049 |
| telefon-04-1-igralec | vsebina | 1 | 0 | 390 | 390×1436 |
| telefon-05-prazno | prazno | 2 | 0 | 390 | 390×525 |
| telefon-06-napaka | napaka | 2 | 0 | 390 | 390×292 |
| telefon-07-nalaganje | nalaganje | 2 | 0 | 390 | 390×745 |

Posnetki so izrisani iz maket (`referenca/`) z DOM-rasterizacijo, ne z zaslonom Chroma, zato je
antialiasing besedila lahko za odtenek drugačen. Višine in položaji škatel so zanesljivi.

**Dovoljene (pričakovane) razlike**, ker uporabljaš obstoječe komponente aplikacije:
- stanje `napaka`: uporabi `NapakaPoizvedbe` (besedilo in višina gumba 36 px sta tam avtoritativna;
  referenca ima 44 px in svoje besedilo). Gumb v tem sklopu povečaj na 44 px z modifikatorjem.
- `Spremljam` gumb = obstoječi `GumbSpremljanja` (isti videz kot referenca).
- Značka statusa = obstoječi `ZnackaStatusa` (isti videz).
Vse ostalo mora biti enako.

## 3. O oblikovalskih datotekah

Datoteke v `referenca/` so **oblikovalske reference v HTML** (prototipi izgleda in vedenja, narejeni
kot »Design Component«), **ne produkcijska koda**. Nalogo opravi tako, da sklop **poustvariš v
obstoječem okolju kodne baze**: React + TypeScript, ročno pisan CSS z BEM razredi v slovenščini v
`vmesnik/src/slog.css`, TanStack Query za podatke. HTML ne kopiraj.

- `referenca/MojiIgralciIzkaznica.dc.html` — **ciljni izgled** (predloga + logika gibanja).
- `referenca/Izkaznica posnetki.dc.html` + `moji-igralci-podatki.js` — vseh 14 stanj in vzorčni podatki.
- `referenca/MojiIgralciTrenutno.dc.html` — poustvarjen današnji videz (samo za primerjavo »prej«).
- `referenca/support.js` — zagonska datoteka za `.dc.html`, ne glej je.

## 4. Zvestoba

**Visoka (hifi).** Barve, pisave, velikosti, razmiki in besedila so končni. Poustvari jih
slikovno natančno z obstoječimi vzorci in razredi kodne baze (`GumbSpremljanja`, `ZnackaStatusa`,
`NapakaPoizvedbe`, `SlikaIgralca`, `.gumb--glavni`, `--barva-*` spremenljivke).

## 5. Zasloni in stanja

Sklop je **ena komponenta** in se širinsko prilagaja **širini svojega vsebnika, ne oknu**. Vsi
prelomi so določeni z `container-type: inline-size` in `cqw` v `clamp()` ter z `flex-wrap`; **media
queryjev ni**. To naredi enako v 1200 px (namizje) in 350 px (telefon, ≤ 640 px) in v vseh vmes.
Na korenu sklopa: `container-type: inline-size; width: 100%`. **Izraze `clamp(...)` prepiši
dobesedno** — da se pri vsaki širini ujemajo z referenco.

Okvir strani (daje ga aplikacija, ne sklop): namizje vsebina 1200 px (okvir 1280 − 2×40), telefon
350 px (okvir 390 − 2×20). Sklop v aplikaciji ostane na istem mestu (`<MojIgralecSklop />` v
`DomacaStran.tsx`, med `.domov__vrh` in lestvico).

Pisave: **D** = `'Bricolage Grotesque'` (`--pisava-display`), **K** = Karla (`--pisava-telo`),
**M** = `'IBM Plex Mono'` (`--pisava-mono`). Zapis `M 12/1.4 500 .1em UP` = mono, 12 px, line-height
1,4, teža 500, letter-spacing 0,1 em, uppercase. Barve so hišne spremenljivke (razdelek 9).

### 5.1 Glava sklopa
- Obstoječi `.naslovna-vrstica` (3 px črna črta zgoraj, `padding-top 16`, flex, baseline,
  `space-between`, `gap 8px 24px`, wrap). Naslov `h2`: **D 800 `clamp(28px,6cqw,40px)`/1, −0,03em**,
  `text-wrap: balance`. Besedilo: `Moji igralci` (≥ 2 igralca) oz. `Moj igralec` (1).
- Desno povezava `Dodaj igralca →` → `/lestvica`: **M 12/1.4 500 .1em UP**, barva `--barva-glavna-tekst`
  (#0071AB), `min-height: 44px` (inline-flex, align center), hover podčrtano. Prikazana tudi ob
  1 igralcu in v praznem stanju.

### 5.2 Zavihki (samo če je igralcev > 1)
- `role="tablist"`, `padding-top: 24px` nad njim (razmik od glave), `display:flex; gap:4px;
  overflow-x:auto; overflow-y:hidden; scrollbar-width:none; padding-right:1px`. Če se 3+ zavihkov ne
  prilega, se drsi vodoravno.
- Zavihek (`<button role="tab" aria-selected>`): `flex: 0 0 auto; min-height:64px; display:flex;
  align-items:center; gap:10px; padding:8px 12px; box-sizing:border-box; margin-bottom:-1px;
  position:relative; text-align:left; color:#14110F; cursor:pointer`.
  - aktiven: bg `#FFFFFF`; border `1px solid #14110F`; zgoraj `3px solid #14110F`; spodaj
    `1px solid #FFFFFF`; `z-index:2`.
  - neaktiven: bg `#EDE7DF`; border `1px solid #DED7CE`; zgoraj `3px solid #DED7CE`; spodaj
    `1px solid #14110F`; `z-index:1`.
  - vsebina: portret **36×36** (`box-sizing:border-box; 1px solid #14110F`, brez slike bel z obrisom
    glave, 60 %), desno stolpec: vrstica 1 **K 600 15/1.2 nowrap**: `{ime} ` + priimek v teži **800**;
    vrstica 2 **M 12/1.4 500 .04em nowrap, #5B534D**: `{rating} · {mesto}.` (rating `—` če ga ni; če
    mesta ni, samo rating).
  - širine (referenca): `Luka Zupančič` zavihek 176 px, `Maja Zupan` 157 px; dva se v 350 px prilegata
    (176+4+157 = 337).
- Tipkovnica (dodatek, ni v referenci): puščici levo/desno preklopita zavihek (standardni tablist).

### 5.3 Izkaznica (okvir)
`border:1px solid #14110F; border-top:3px solid #14110F; background:#FFFFFF; position:relative;
z-index:0`. Brez radija, brez senc. Znotraj po vrsti: pas 1–5 (spodaj). Vsak pas, označen z
**★**, je element z `data-vstop` (animacija vstopa, razdelek 7).

Skupni odmik: `P = clamp(16px, 2.4cqw, 24px)` (na 1200 px = 24, na 350 px = 16).

**Pas 1 — identiteta ★**: `padding: P; display:flex; flex-wrap:wrap; gap:24px`.
- **Levo (skupina)**: `flex:1 1 400px; min-width:0; display:flex; gap:P; align-items:flex-start`.
  - **Portret**: `flex:none; width: clamp(88px,20cqw,240px); aspect-ratio:1; box-sizing:border-box;
    border:1px solid #14110F`. Z `slika`: `<img>` (object-fit cover) prek `SlikaIgralca` (razširi ga,
    da širino prevzame iz CSS; velikost slike za strežnik izberi po največji širini 240 px). Brez
    slike: ozadje `#FFFFFF` in **obris glave in ramen** iz `SlikaIgralca.tsx`
    (`<svg viewBox="0 0 40 40" width="60%" height="60%" fill="none" stroke="#5B534D" stroke-width="2">
    <circle cx="20" cy="13" r="7.5"/><path d="M6 36c0-7.7 6.3-14 14-14s14 6.3 14 14"/></svg>`).
    V maketi je namesto slike za demonstracijo diagonalno črtkano polje z napisom `slika`
    (**M 12 500 .1em UP #5B534D**) — v aplikaciji tam stoji prava slika.
  - **Besedilo** (`min-width:0`): ime **D 200 `clamp(24px,4.4cqw,48px)`/1, −0,03em**; priimek
    (`margin-top:4px`) **D 800 `{vel}`/0.88, −0,045em, overflow-wrap:anywhere**, kjer je `vel` glede na
    dolžino priimka: ≤ 8 znakov `clamp(36px,9cqw,104px)`; 9–11 `clamp(32px,7cqw,80px)`; > 11
    `clamp(28px,5.2cqw,60px)`. Če je `druzina`: pod priimkom značka `Družina`
    (`margin-top:12px; display:inline-block; padding:6px 8px; background:#EAF4D6; color:#4A7500`,
    **M 11/1.2 600 .1em UP**).
- **Rating blok** (desno, na ozkem pod njo): `flex:none; width:min(100%,320px); box-sizing:border-box;
  background:#0071AB; color:#FFFFFF; padding:20px; display:flex; flex-direction:column;
  justify-content:space-between; gap:16px; min-height:150px`.
  - zgoraj `Turnirko rating`: **M 12/1.4 500 .1em UP #FFFFFF**
  - sredina število: **D 800 `clamp(64px,16cqw,112px)`/0.85, −0,04em, tabular-nums, #FFFFFF**;
    brez ratinga `—`
  - spodaj **M 13/1.4 600 .04em #FFFFFF**: `+7 v zadnjih 3 tekmah` / `−4 v zadnjih 3 tekmah` /
    `brez odigranih tekem`.

**Pas 2 — kolofon ★**: `display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
gap:1px; background:#DED7CE; border-top:1px solid #14110F; border-bottom:1px solid #14110F`
(1 px črte med celicami nastanejo iz `gap` na podlagi). Celica: `background:#FFFFFF;
padding:16px P`. Oznaka celice **M 12/1.4 500 .1em UP #5B534D**.
- `Klub` → vrednost **K 600 18/1.25**, `margin-top:8px` (`brez kluba` če ga ni).
- `Lestvica` → **K 600 18/1.25** `Moški · Člani` (spol · skupina; glej razdelek 8).
- `Mesto` → `margin-top:4px; display:flex; align-items:baseline; gap:8px; flex-wrap:wrap`:
  **D 800 40/1, −0,04em, tabular** `14.` + **M 12/1.4 500 .04em #5B534D** `od 212` (brez
  uvrstitve: `—` in `brez uvrstitve`).
- `Sezona` → enako: **D 800 40/1** `18–7` (en dash, `white-space:nowrap`) + `72 % zmag` (brez tekem:
  `—`, `brez tekem`); pod tem `margin-top:8px` palica: `height:6px; background:#EDE7DF`, polnilo
  `height:6px; background:#0088CE; width:{odstotek}%`.
- Na 350 px so 4 celice v mreži 2×2, na 1200 px v eni vrsti (posledica `auto-fit`).

**Pas 3 — »vstopnica« (naslednje) ★**: `background:#EAF3F9; border-top:2px dashed #14110F;
margin-top:-1px; padding:P`.
- Glava: `display:flex; justify-content:space-between; gap:16px`, **M 12/1.4 500 .1em UP #14110F**:
  `Naslednje` ‹→› `čez 5 dni` (razdelek 8: `cez`).
- **Srečanje** (če obstaja; cela vrstica je povezava na `/srecanja/:id`, `cursor:pointer`):
  `margin-top:12px; display:flex; flex-wrap:wrap; align-items:baseline; gap:8px 32px`.
  - datum (`flex:0 0 auto; min-width:140px`): dan **M 14/1.4 600 .04em UP #0071AB** (`ned`);
    datum **D 800 `clamp(36px,6cqw,56px)`/0.95, −0,04em** (`8. nov`); ura `margin-top:4px`
    **M 14/1.4 600 #14110F** (`18.00`; če ure ni, vrstice ni).
  - ekipe (`flex:1 1 220px; min-width:0`): **K 600 `clamp(18px,2.4cqw,22px)`/1.25** `KTT Maribor B – TTK Ptuj`;
    `margin-top:4px` **M 12/1.4 500 .04em #332E29** `Liga Savinja D · 6. kolo · doma`.
  - brez začetka srečanja: namesto dne/datuma/ure velik napis `6. kolo` (kot danes).
- **Turnir** (če obstaja; povezava `/turnirji/:id`): `margin-top:12px; padding-top:12px;
  border-top:1px solid #C9DCEA; display:flex; flex-wrap:wrap; align-items:baseline; gap:4px 16px`:
  `22. nov` (**M 14/1.4 600 .04em #0071AB nowrap**), ime turnirja (**K 600 17/1.3**), `Prijavljen`
  (**M 12/1.4 500 .04em #332E29**), `ZnackaStatusa`.
- Ni ne srečanja ne turnirja: `margin-top:12px` **M 12/1.4 500 .08em UP #332E29**
  `Ni napovedanega termina.`

**Pas 4 — forma in zadnje tekme**: `padding:P; display:flex; flex-wrap:wrap; gap:24px 48px;
border-top:1px solid #14110F`.
- **Forma ★** (`flex:1 1 280px; max-width:340px; min-width:0`): naslov
  `padding-bottom:6px; border-bottom:1px solid #14110F`, **M 12/1.4 500 .1em UP #5B534D**
  `Forma · zadnjih 5`. Pod njim `padding-top:16px; display:flex; gap:8px`, kvadratki **44×44**,
  `box-sizing:border-box; border:1px solid`, **M 16/1 600**, črka `Z`/`P`:
  - Z: bg `#EAF4D6`, barva in obroba `#4A7500`
  - P: bg `#F8E5DF`, barva `#8C2B14`, obroba `#B23A1E`
  Vrstni red: **najnovejša prva** (enak vrstni red kot seznam desno). Barva ni edini nosilec:
  črka je v kvadratku. Brez tekem: `margin-top:16px` **M 12/1.4 500 .08em UP #5B534D**
  `Brez odigranih tekem.`
- **Zadnje tekme** (`flex:1 1 360px; min-width:0`): naslov (★) enak kot pri formi, levo
  `Zadnje tekme`, desno `Rating +7` v barvi smeri (razdelek 8). Vsaka vrstica (★):
  `display:grid; grid-template-columns:64px minmax(0,1fr) 48px 48px; gap:12px; align-items:baseline;
  padding:12px 0; border-bottom:1px solid #DED7CE`:
  datum **M 14/1.4 500 #5B534D nowrap** (`25. okt`); nasprotnik **K 16** + `margin-top:2px`
  **M 12/1.4 500 .04em #5B534D** (tekmovanje); izid **M 14/1.4 600 tabular, desno** (`3:1`);
  sprememba isto (`+6`, `−8` z znakom U+2212). **Obe zadnji celici sta v barvi izida:** zmaga
  `#4A7500` (`.profil__zmaga`), poraz `#B23A1E` (`.profil__poraz`). Sprememba `null` = prazna celica.

**Pas 5 — noga ★**: `padding:8px P; display:flex; flex-wrap:wrap; align-items:center;
justify-content:space-between; gap:8px 24px; border-top:1px solid #14110F; background:#FBF9F5`.
- Levo `display:flex; flex:none; gap:0 24px; white-space:nowrap`: povezavi `Profil →`
  (`/igralci/:id/profil`) in `Sezonski zapisnik →` (`/igralci/:id/sezona`; **samo za račun s
  paketom**, kot danes `imaSirokoSpremljanje`). Povezavi: **M 12/1.4 500 .1em UP #0071AB**,
  `min-height:44px`, inline-flex, align center, hover podčrtano.
- Desno: **ne-družinski igralec** → obstoječi `GumbSpremljanja` (privzeti slog, 44 px; poln zelen
  kvadratek + `Spremljam`; prazen + `Spremljaj`). **Družinski igralec** → povezava `Zasebna
  statistika →` (`/igralci/:id/profil`), enak slog kot povezavi levo, brez gumba za spremljanje.

### 5.4 Prazno stanje (`stanje=prazno`)
Samo za **navijača** brez igralcev (kot danes: igralec/organizator/gost sklopa ne vidi, če ni
igralcev — ostane `return null`). Pod glavo: `margin-top:24px; border:2px dashed #14110F;
padding:clamp(16px,3cqw,32px); display:flex; flex-wrap:wrap; align-items:center; gap:24px 40px`.
- portret `flex:none; width:clamp(88px,16cqw,160px); aspect-ratio:1; border:1px solid #14110F;
  background:#FFFFFF` z obrisom glave.
- besedilo `flex:1 1 260px; min-width:0`: `Prazna` **D 200 `clamp(24px,4.4cqw,48px)`/1, −0,03em, #5B534D**;
  `izkaznica.` **D 800 `clamp(36px,9cqw,104px)`/0.88, −0,045em**; odstavek `margin-top:16px;
  max-width:46ch` **K 300 15px #5B534D**: »Na profilu igralca pritisni »Spremljaj«. Tu bosta potem
  njegov rating in naslednji termin, pod njima pa zadnje tekme.«; gumb `Poišči igralca` →
  `/lestvica`: `.gumb.gumb--glavni` z `min-height:48px; padding:12px 24px; margin-top:16px`.

### 5.5 Napaka (`stanje=napaka`)
Glava + `NapakaPoizvedbe` (`kaj="igralcev"`), `margin-top:16px` nad njo. Gumb »Poskusi znova« v
tem sklopu 44 px. Besedilo komponente je avtoritativno (referenca ima svoje; glej »dovoljene
razlike«).

### 5.6 Nalaganje (`stanje=nalaganje`)
Glava + okostje: `margin-top:24px; border:1px solid #14110F; background:#FFFFFF`, `aria-hidden`.
Vse sive ploskve `#EDE7DF`, brez animacije. Zgoraj `padding:24px; display:flex; flex-wrap:wrap;
gap:24px`: kvadrat `flex:none; width:clamp(88px,20cqw,240px); aspect-ratio:1`; stolpec
`flex:1 1 200px; display:flex; flex-direction:column; gap:12px` z letvama `height:28px; width:30%` in
`height:72px; width:70%`; blok `flex:none; width:min(100%,320px); min-height:120px`. Pod tem
`padding:0 24px 24px; display:flex; flex-direction:column; gap:12px` s tremi letvami `height:44px`.
**Pazi:** današnja koda ob nalaganju ne pokaže nič (da stran ne skače, če sklopa za ta račun ni).
Okostje pokaži le, če je znano, da bo sklop prikazan: navijač, ali `['moji-igralci']` (seznam
id-jev) vrne vsaj enega; sicer ostani pri `null`.

## 6. Vedenje in interakcije

- **Zavihki**: klik izbere igralca; aktivni indeks je lokalno stanje komponente (začetno 0). Ob
  menjavi se ponovi animacija vstopa (razdelek 7). Aktivni indeks se pri spremembi seznama zajame v
  mejah `[0, n−1]`.
- **Spremljam (preklop)**: kot danes `preklopi(idIgralec)` iz `useSpremljanjeIgralcev`; **ni
  optimistično** (strežnik lahko vrne 409 ob meji paketa — `SporociloNapake` pod glavo, kot danes).
  Ko seznam po osvežitvi igralca ne vsebuje več, izgine; aktivni indeks → 0. Maketa to
  simulira z izginotjem po 700 ms.
- **Poskusi znova** (napaka): `poizvedba.refetch()`.
- **Povezave**: ime/portret/Profil → profil igralca; vrstica srečanja → `/srecanja/:id`; vrstica
  turnirja → `/turnirji/:id`; `Dodaj igralca →` in `Poišči igralca` → `/lestvica`.
- **Hover**: povezave podčrtane; zavihki brez posebnega hovra (neaktiven je samo viden kot zavihek);
  `GumbSpremljanja` hover kot danes (modra obroba in besedilo).
- **Fokus**: vidni fokusni obroč kot drugod v aplikaciji; vsi klikljivi elementi ≥ 44 px visoki
  (zavihek 64, noga 44).
- Brez ikon (DESIGN.md). Edina risba je obris glave v portretu.

## 7. Gibanje (nova izjema od pravila 12 v DESIGN.md)

Uporabnik je izbral dve gibanji; vsi trajajo < 1,5 s, **animirata se samo `transform` in `opacity`**
(rating je številčni izpis), ob `prefers-reduced-motion: reduce` je **takoj končno stanje**.

1. **Rating se naštevilči** (samo število v modrem bloku): prikaz
   `round(rating − (1 − e) · 96)`, kjer `e = 1 − (1 − t)³` in `t` od 0 do 1 v **900 ms** (`rAF`).
   Začetna vrednost je `rating − 96`, končna `rating`. Brez ratinga ni animacije.
2. **Vrstice se dvignejo**: vsak element `data-vstop` (v DOM-vrstnem redu: pas 1, 2, 3, forma,
   naslov zadnjih tekem, vsaka vrstica tekme, noga) prek Web Animations API:
   `el.animate([{transform:'translateY(12px)',opacity:0},{transform:'none',opacity:1}],
   {duration:420, delay: Math.min(i,12)*45, easing:'cubic-bezier(.2,.8,.2,1)', fill:'backwards'})`.
Sproži se ob prvem prikazu vsebine, ob menjavi zavihka in ob prehodu nalaganje/napaka → vsebina.
Referenčna implementacija: `zagon()` v `MojiIgralciIzkaznica.dc.html`.

## 8. Podatki in pogled-model

Vzorec: `referenca/moji-igralci-podatki.js` (`vzorec(st)`; »danes« je 3. 11. 2026).

### 8.1 Kaj mora zaledje še vrniti (`DomovIgralecDto`, `GET /domov/moji-igralci-povzetki`)
Danes DTO nosi: `idIgralec, polnoIme, klub, rating, uvrstitev (mesto, skupajIgralcev, spol,
rekreativec), zadnje (3 × TekmaProfila), naslednjeSrecanje, prihajajociTurnir, druzina`.
Za prenovo dodaj (zaledje `DomovStoritev`/DTO, zrcalno v `api/tipi.ts`, in test):

| Polje | Opis |
|---|---|
| `forma: ('Z'\|'P')[]` | izidi **zadnjih 5** odigranih tekem (liga in turnir), **najnovejša prva** |
| `sezona: { zmage: number; porazi: number } \| null` | bilanca v tekoči sezoni; **uporabi isto definicijo sezone kot `pomozno/sezonskiZapisnik.ts` / `/igralci/:id/sezona`**; `null` brez tekem |
| `zgostitev: string \| null` | profilna slika igralca (kot pri 1 na 1 / profilu; glej `tipi.ts` okoli vrstic 216–237 in `pomozno/profilneSlike.ts`) |
| `ime`, `priimek` | ločeno (zdaj samo `polnoIme`; priimek z več besedami brez njiju ni zanesljiv) |

Če zaledja ni mogoče spremeniti: forma = prvih 3 (nepopolno), brez sezone in slike — **vprašaj
uporabnika**, preden spustiš kateri koli element.

### 8.2 Izpeljava polj (nova pomožna datoteka, npr. `pomozno/mojiIgralci.ts`, s testi)
- `lestvicaKratko` = `[spol === 'ZENSKI' ? 'Ženske' : 'Moški', rekreativec ? 'Rekreativci' : 'Člani'].join(' · ')`
  (kot `imeLestvice`, brez predpone »Lestvica«).
- `spremembaVsota` = vsota `zadnje[].spremembaRatinga` (null = 0); besedilo `+7` / `−4` (U+2212) / `+0`;
  smer: > 0 zelena `#4A7500`, < 0 rjasta `#B23A1E`, 0 `#5B534D`.
- `odstotek` bilance = `Math.round(100 · zmage / (zmage + porazi))`; prikaz `18–7` (en dash),
  `72 % zmag`.
- Srečanje: `dan` = `oblikujTermin(zacetek)` prva beseda (`ned`), `datum` =
  `oblikujDanKratekMesec(zacetek)` (`8. nov`), `ura` = `oblikujUro(zacetek)` (`18.00`, prazno če
  00:00), `opis` = `` `${ekipa} – ${nasprotnik}` `` (en dash z presledkoma), `pod` =
  `` `${liga} · ${kolo}. kolo · ${doma ? 'doma' : 'v gosteh'}` ``.
- **`cez`** (koledarski dnevi do datuma srečanja, v časovnem pasu Europe/Ljubljana):
  0 → `danes`, 1 → `jutri`, n ≥ 2 → `čez n dni`; za glavo stopnice se uporabi srečanje, če ga ni, turnir.
- Turnir: `kdaj` = `oblikujDanKratekMesec(datum)`, status prek `ZnackaStatusa`.
- Vrstica tekme: `datum` = `oblikujDanKratekMesec`, `izid` = `` `${niziZa}:${niziProti}` ``, barva po
  `tekma.zmaga`.
- Slovnica: `čez 2 dni`, `čez 5 dni` (vedno »dni«).

## 9. Oblikovalski žetoni (iz `slog.css`, vse hišne)

Barve: papir `#FBF9F5` (`--barva-papir`) · bela `#FFFFFF` · črnilo `#14110F` · črnilo-2 `#332E29` ·
črnilo-3 `#5B534D` · črta `#DED7CE` · polnilo `#EDE7DF` · glavna `#0088CE` · glavna-polna `#0071AB` ·
glavna-tekst `#0071AB` · glavna-mehko `#EAF3F9` · glavna-črta `#C9DCEA` · poudarek `#7BB900` ·
poudarek-tekst `#4A7500` · poudarek-mehko `#EAF4D6` · negativna `#B23A1E` · negativna-tekst `#8C2B14` ·
negativna-mehko `#F8E5DF`. Nobena barva ni nova.

Pisave: Bricolage Grotesque (200, 800), Karla (300, 400, 600, 700), IBM Plex Mono (400, 500, 600).
Radij povsod 0. Sence: nobene. Gradient: samo diagonalno črtkano polje v maketi (nadomesti prava slika).
Razmiki: 4/8/12/16/24/32/40 (+ 6, 10 pri optičnih poravnavah, kot v referenci); `P = clamp(16px,2.4cqw,24px)`.

## 10. Spremembe v kodni bazi (predlog)

- `vmesnik/src/komponente/MojIgralecSklop.tsx` — prepiši; ohrani izvoz `MojIgralecSklop` in
  pogoje prikaza (gost: nič; neNavijač brez igralcev: nič).
- `vmesnik/src/slog.css` — nadomesti blok »Moj igralec (V57)« (`.domov__igralec*`, okoli vrstic
  7592–7720, ter pravila v `@media` okoli 13240 in 13947–13960 in `.domov__igralec-druzina` okoli
  7330) z novim blokom (predlagani razredi: `.moji-igralci`, `.moji-igralci__zavihki`,
  `.moji-igralci__zavihek`, `.moji-igralci__izkaznica`, `…__pas`, `…__portret`, `…__ime`,
  `…__priimek`, `…__rating`, `…__kolofon`, `…__vstopnica`, `…__forma`, `…__tekma`, `…__noga`,
  `…__prazno`, `…__okostje`). Nobenih stranskih učinkov na `.domov__*` drugih sklopov.
- `vmesnik/src/api/tipi.ts` + zaledje (razdelek 8.1).
- `vmesnik/src/pomozno/mojiIgralci.ts` (pogled-model), `vmesnik/src/dev/PosnetkiOkna.tsx` +
  `primerPodatki.ts` (harness, razdelek 2).
- **`DESIGN.md`** (`vmesnik/turnirko-profil-redesign/project/DESIGN.md`) — dokumentiraj odločitve
  lastnika, sicer prenova krši pravila:
  1. **4d**: profilna slika stoji tudi na domači strani (sklop »Moji igralci«: portret 240/160 px,
     zavihek 36 px) — doslej 3 mesta.
  2. **Točka 12 / nov razdelek 5g**: rating se naštevilči (900 ms) in vrstice se dvignejo (420 ms
     + zamik), samo `transform`/`opacity`, ob reduced-motion takoj končno stanje.
  3. **Črtkana obroba** (`2px dashed #14110F`) za »vstopnico« in prazno izkaznico.
  4. **`container-type: inline-size` + `cqw` v `clamp()`** namesto media queryjev za ta sklop.
- Pospravi neuporabljene razrede in jih ne pusti »za vsak primer«.

## 11. Odprta vprašanja (vprašaj uporabnika, če ni jasno)

1. Definicija »sezone« za bilanco (privzeto kot sezonski zapisnik).
2. Ali je potrjena profilna slika kot 4. mesto (DESIGN.md 4d)? Maketa jo predpostavlja.
3. Forma: ali v njej štejejo tudi predaje/w.o.? Privzeto: vse obračunane tekme, po izidu.
4. Ali naj si sklop zapomni izbrani zavihek (sessionStorage)? Maketa ne.

## 12. Datoteke

- `README.md` — ta dokument
- `screenshots/` — 14 referenčnih PNG (tabela v razdelku 2)
- `referenca/MojiIgralciIzkaznica.dc.html` — ciljna maketa (predloga + logika)
- `referenca/Izkaznica posnetki.dc.html` — vseh 14 stanj; `referenca/moji-igralci-podatki.js` — vzorčni podatki
- `referenca/MojiIgralciTrenutno.dc.html` — današnji videz, za primerjavo
- `referenca/support.js` — zagon `.dc.html` (ni za kopiranje)
- Izvor iz kodne baze: `vmesnik/src/komponente/MojIgralecSklop.tsx`, `vmesnik/src/strani/DomacaStran.tsx`,
  `vmesnik/src/slog.css`, `vmesnik/src/komponente/SlikaIgralca.tsx`, `GumbSpremljanja.tsx`,
  `NapakaPoizvedbe.tsx`, `Znacka.tsx`, `vmesnik/src/api/tipi.ts` (`DomovIgralecDto`)
